# Agente Alpha

Independent Android prototype. It does not import code or runtime dependencies from Tunnel Turbo or Pulso.

## What it does

- Keeps a Spanish conversation history locally on the device.
- Offers ChatGPT, Gemini, or Claude as a **visible app** for conversation and task planning. It hands text and, during an active Operar step, a screenshot to the selected app through Android intents; this project has no provider API client and declares no Internet permission.
- Handles the direct task “abre [app]” locally through Android launch intents.
- For broader goals, captures the current screen during each planning round, shares that image with the selected visible model app, combines the image with the Accessibility tree, and executes one structured action. Text-labeled controls use semantic actions; unlabeled visual targets can use normalized screenshot coordinates through Accessibility gestures.
- Stops after eight actions, after 45 seconds without a readable model answer, or when the user presses Detener.
- Reports “unverified” when Android or the screen tree does not provide independent evidence of completion.

## First use

1. Install `app/build/outputs/apk/debug/app-debug.apk`.
2. Open Agente Alpha and enable its Accessibility service from the in-app button.
3. Choose an installed model app. Model requests are visible on the phone and in scrcpy when scrcpy mirrors the phone.
4. Use **Conversar** for chat or **Operar** for a device task.

The service reads visible semantic nodes and uses their labels, text, and editability. A screenshot is captured only while an Operar task is active, stored temporarily in the app cache, and shared to the selected model app as an image attachment. The temporary file is deleted after that model round completes. Screenshots are not taken in the background or in Conversar mode. The selected model app may send the image to its provider under that app's own account and privacy settings; “no direct API” does not mean “offline.” Android can refuse screenshots of secure windows, so the agent falls back to the semantic tree and reports that the visual input was unavailable. Coordinate gestures are normalized against the captured display dimensions, not hardcoded to this device. Alpha does not inspect another app's private storage.

## Current Alpha limits

The prototype has not yet been validated end to end against all three model apps. A provider can render its answer in a way that Android Accessibility does not expose; in that case the request times out and no response is invented. App UI changes, account state, regional package IDs, and Android background-launch rules can also interrupt a task. Cross-app launch during a long task is therefore a specific device validation item, not an assumed capability. Android 11 (API 30) or later is required for this screenshot path; Android 10 falls back to semantic-only observation.

The current action cap is intentional while the execution and verification loop is being validated. It prevents the infinite polling behavior seen in the earlier prototype. A future continuation policy should use persisted task state, observable progress, and a stop condition—not an unbounded loop.

## Build

```sh
./gradlew --no-daemon :app:assembleDebug
```

Build observed on 2026-10-20: `BUILD SUCCESSFUL`. No automated test suite was run for this Alpha.

## Research notes (consulted 2026-10-20)

- **Create an accessibility service** — Android Developers — <https://developer.android.com/guide/topics/ui/accessibility/service>. Supports semantic tree inspection, node actions, and gestures. It does **not** promise that every app exposes complete or stable content.
- **Activity security** — Android Developers — <https://developer.android.com/guide/components/activities/secure-bal>. Documents background activity-launch restrictions. It does **not** prove cross-app task switching will work from this service on every Android/OEM build.
- **AndroidWorld: A Dynamic Benchmarking Environment for Autonomous Agents** — Google Research / arXiv — <https://arxiv.org/abs/2405.14573>. Supports independent state-based verification and diverse task variations; its reported baseline and emulator results do **not** prove this phone app works.
- **JARVIS** — open-source Android project — <https://github.com/ansaribilal14/jarvis>. Its local-first observe/act/verify loop and its documented rewrites after real-device failures informed this prototype. It includes optional API/model and screenshot paths that this Alpha does **not** adopt; its claims do **not** validate this project.
- **Use of the AccessibilityService API** — Google Play Console Help — <https://support.google.com/googleplay/android-developer/answer/10964491>. Relevant if the app is ever submitted to Play; it does **not** constrain this sideload-only Alpha or establish device-level feasibility.
- **Gemini Nano** — Android Developers — <https://developer.android.com/ai/gemini-nano>. Shows an alternative local inference route that depends on Android AICore/device support and Android’s ML Kit APIs. This Alpha does **not** call that API because the chosen no-direct-model-API route is the visible installed apps.
- **AccessibilityService** — Android Developers — <https://developer.android.com/reference/android/accessibilityservice/AccessibilityService>. Supports screenshot capture from an enabled service on API 30+, Accessibility gestures, and reports capture failures; Android 14+ has an explicit secure-window failure. It does **not** guarantee that every OEM or app surface can be captured.
- **Send data to other apps** and **Sharing files** — Android Developers — <https://developer.android.com/develop/ui/compose/sharing/send> and <https://developer.android.com/training/secure-file-sharing>. Support `ACTION_SEND`, temporary `content://` URIs, and read grants for sharing a screenshot through the receiving app UI. They do **not** guarantee that a particular model app will attach, submit, or read that image correctly.
- **Recognize text with ML Kit on Android** — Google Developers — <https://developers.google.com/ml-kit/vision/text-recognition/v2/android>. Shows bundled on-device OCR can avoid a first-run model download at the cost of roughly 4 MB per script and architecture. It does **not** provide visual reasoning or prove device-level speed; this Alpha currently sends the image to the selected visible model app instead of adding another OCR dependency.
- **Agent Phone (adev0x/android-agent)** — GitHub — <https://github.com/adev0x/android-agent>. Demonstrates a similar screenshot + Accessibility observe/act loop, but depends on a Claude API. Its architecture supports the perception pattern only; its repository does **not** validate this no-provider-API implementation.
- **PhonePilot** — GitHub — <https://github.com/gotogrub/PhonePilot>. Demonstrates a local VLM route through Qwen/Ollama and a host-side stack. It contradicts any claim that fully local vision is automatically lightweight: its documented setup expects a separate host, Docker, and a multi-GB GPU. It does **not** show that such a model is viable on this phone.

### Evidence from the connected phone

On 2026-10-20, the installed ChatGPT package on the connected Android 16 phone advertised `ACTION_SEND` for `image/*` in its installed package filters. That is device evidence that an image handoff can be attempted without a provider API; it does **not** prove the ChatGPT app will preserve the attachment across future app updates or return a readable answer through Accessibility. Device-level attachment and answer validation remains necessary.
