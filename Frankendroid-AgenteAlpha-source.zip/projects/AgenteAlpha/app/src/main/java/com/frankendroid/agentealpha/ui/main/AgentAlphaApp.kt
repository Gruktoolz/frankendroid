package com.frankendroid.agentealpha.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.frankendroid.agentealpha.agent.AgentResult
import com.frankendroid.agentealpha.engine.Engine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class AlphaMessage(val id: Long, val fromUser: Boolean, val task: Boolean, val text: String, val time: Long = System.currentTimeMillis())

object AlphaConversation {
    private val ids = AtomicLong()
    private val mutable = MutableStateFlow<List<AlphaMessage>>(listOf(
        AlphaMessage(ids.incrementAndGet(), false, false, "Soy tu Agente Alpha. Puedo conversar con un motor visible o ejecutar una tarea paso a paso en Android. Empieza con algo como “abre Calculadora” o cambia a Operar para una meta más amplia.")
    ))
    val messages = mutable.asStateFlow()
    private val mutableProgress = MutableStateFlow("")
    val progress = mutableProgress.asStateFlow()
    fun setProgress(value: String) { mutableProgress.value = value }
    fun load(context: Context) {
        val saved = context.getSharedPreferences("alpha", Context.MODE_PRIVATE).getString("messages", null) ?: return
        val restored = runCatching {
            val array = JSONArray(saved)
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                AlphaMessage(
                    item.optLong("id"), item.optBoolean("user"), item.optBoolean("task"),
                    item.optString("text"), item.optLong("time")
                )
            }
        }.getOrNull() ?: return
        if (restored.isNotEmpty()) {
            mutable.value = restored.takeLast(100)
            ids.set(restored.maxOfOrNull { it.id } ?: 0L)
        }
    }
    fun add(fromUser: Boolean, task: Boolean, text: String) {
        mutable.value = mutable.value + AlphaMessage(ids.incrementAndGet(), fromUser, task, text)
        persist()
    }
    private fun persist() {
        val array = JSONArray()
        mutable.value.takeLast(100).forEach { message ->
            array.put(JSONObject().apply {
                put("id", message.id); put("user", message.fromUser); put("task", message.task)
                put("text", message.text); put("time", message.time)
            })
        }
        appContext?.getSharedPreferences("alpha", Context.MODE_PRIVATE)?.edit()?.putString("messages", array.toString())?.apply()
    }
    @Volatile private var appContext: Context? = null
    fun initialize(context: Context) { appContext = context.applicationContext; load(context) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentAlphaApp(
    engines: List<Engine>,
    initialEngine: Engine?,
    accessibilityEnabled: Boolean,
    onEngineSelected: (Engine) -> Unit,
    onEnableAccessibility: () -> Unit,
    onSend: (String, Boolean, Engine?) -> Unit,
    onStop: () -> Unit
) {
    val messages by AlphaConversation.messages.collectAsState()
    val progress by AlphaConversation.progress.collectAsState()
    val busy = progress.isNotBlank()
    var selectedEngine by remember { mutableStateOf(initialEngine ?: engines.firstOrNull()) }
    var taskMode by rememberSaveable { mutableStateOf(false) }
    var input by rememberSaveable { mutableStateOf("") }
    var showEnginePicker by remember { mutableStateOf(false) }
    if (selectedEngine == null && engines.isNotEmpty()) selectedEngine = engines.first()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { inset ->
        Column(
            modifier = Modifier.fillMaxSize().padding(inset).padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Text("A", Modifier.padding(horizontal = 17.dp, vertical = 10.dp), color = MaterialTheme.colorScheme.onPrimaryContainer, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f)) {
                    Text("Agente Alpha", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Alpha local · sin API de modelo", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { showEnginePicker = true }) { Text(selectedEngine?.label ?: "Elegir motor") }
            }

            if (!accessibilityEnabled) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("Activa el acceso operativo", fontWeight = FontWeight.SemiBold)
                            Text("Permite leer controles, actuar por etiquetas y capturar la pantalla durante una tarea activa.", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = onEnableAccessibility) { Text("Activar") }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !taskMode, onClick = { taskMode = false }, label = { Text("Conversar") })
                FilterChip(selected = taskMode, onClick = { taskMode = true }, label = { Text("Operar") })
                Spacer(Modifier.weight(1f))
                if (busy) TextButton(onClick = onStop) { Text("Detener") }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                reverseLayout = false
            ) {
                items(messages, key = { it.id }) { message ->
                    MessageCard(message)
                }
                if (busy) item {
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(Modifier.height(20.dp), strokeWidth = 2.dp)
                        Text(progress.ifBlank { "Trabajando en el teléfono…" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (taskMode) "Describe una meta; usaré accesibilidad y capturas para operar. Las imágenes se comparten con ${selectedEngine?.label ?: "el motor elegido"} y podrían procesarse en la nube." else "La consulta se abrirá en ${selectedEngine?.label ?: "un motor instalado"} y será visible en scrcpy.", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text(if (taskMode) "¿Qué quieres que haga?" else "Escribe un mensaje") },
                        minLines = 1,
                        maxLines = 4,
                        shape = RoundedCornerShape(22.dp)
                    )
                    Button(
                        enabled = !busy && input.isNotBlank(),
                        onClick = { val text = input.trim(); input = ""; onSend(text, taskMode, selectedEngine) }
                    ) { Text("Enviar") }
                }
            }
        }
    }

    if (showEnginePicker) AlertDialog(
        onDismissRequest = { showEnginePicker = false },
        title = { Text("Motor visible") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Sin API: se abre la app seleccionada y la consulta queda visible en el teléfono.", style = MaterialTheme.typography.bodySmall)
                engines.forEach { engine ->
                    TextButton(onClick = { selectedEngine = engine; onEngineSelected(engine); showEnginePicker = false }) {
                        Text(if (engine.id == selectedEngine?.id) "✓  ${engine.label}" else engine.label)
                    }
                }
                if (engines.isEmpty()) Text("Instala ChatGPT, Gemini o Claude para conversar con un motor.")
            }
        },
        confirmButton = { TextButton(onClick = { showEnginePicker = false }) { Text("Cerrar") } }
    )
}

@Composable
private fun MessageCard(message: AlphaMessage) {
    val color = if (message.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh
    val align = if (message.fromUser) Alignment.End else Alignment.Start
    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        Card(
            modifier = Modifier.fillMaxWidth(if (message.fromUser) .86f else .96f),
            colors = CardDefaults.cardColors(containerColor = color),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!message.fromUser) Text(if (message.task) "TAREA" else "ALPHA", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(message.text, style = MaterialTheme.typography.bodyLarge)
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.time)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
