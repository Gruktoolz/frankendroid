package com.frankendroid.agentealpha.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.hardware.HardwareBuffer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Context
import androidx.core.content.FileProvider
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executor
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class SemanticNode(val text: String, val description: String, val className: String, val editable: Boolean, val scrollable: Boolean)
data class SemanticFrame(val packageName: String, val nodes: List<SemanticNode>, val capturedAt: Long)
data class EngineReply(val requestId: String, val text: String?, val error: String? = null)
data class ScreenCapture(val uri: Uri, val file: File, val width: Int, val height: Int)

/** Reads the visible UI and captures screenshots only when an active user task requests them. */
class AlphaAccessibilityService : AccessibilityService() {
    companion object {
        private val _frame = MutableStateFlow<SemanticFrame?>(null)
        val frame: StateFlow<SemanticFrame?> = _frame
        private val mainHandler = Handler(Looper.getMainLooper())
        private val captureExecutor = Executor { command -> Thread(command, "alpha-screen-capture").start() }
        @Volatile private var active: AlphaAccessibilityService? = null
        @Volatile private var pending: PendingRequest? = null

        private data class PendingRequest(
            val id: String,
            val packageName: String,
            val prompt: String,
            val userText: String,
            val completion: CompletableDeferred<EngineReply>,
            var sent: Boolean = false,
            var baseline: Set<String> = emptySet(),
            var previousCandidate: String? = null,
            var stableCount: Int = 0,
            var lastCandidateAt: Long = 0L
        )

        suspend fun askVisibleEngine(
            context: Context,
            engine: Engine,
            userText: String,
            prompt: String,
            imageUri: Uri? = null,
            timeoutMs: Long = 45_000L
        ): EngineReply {
            val service = active ?: return EngineReply("", null, "Activa Accesibilidad de Agente Alpha para conectar el motor visible.")
            val completion = CompletableDeferred<EngineReply>()
            val request = PendingRequest(UUID.randomUUID().toString(), engine.packageName, prompt, userText, completion)
            pending?.completion?.complete(EngineReply(pending!!.id, null, "Consulta reemplazada por una nueva."))
            pending = request
            val currentPackage = _frame.value?.packageName
            if (imageUri != null || currentPackage != engine.packageName) {
                val launch = if (imageUri != null) {
                    Intent(Intent.ACTION_SEND).apply {
                        setPackage(engine.packageName)
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, imageUri)
                        putExtra(Intent.EXTRA_TEXT, prompt)
                        clipData = ClipData.newUri(context.contentResolver, "Captura de Agente Alpha", imageUri)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                } else {
                    context.packageManager.getLaunchIntentForPackage(engine.packageName)
                        ?: return finish(request, "No encuentro instalada la app ${engine.label}.")
                }
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { context.startActivity(launch) }.onFailure {
                    return finish(request, "No pude abrir ${engine.label}: ${it.message}")
                }
            } else {
                val root = service.rootInActiveWindow
                    ?: return finish(request, "No pude leer el árbol semántico de ${engine.label}.")
                val frame = _frame.value
                    ?: return finish(request, "La app abrió, pero todavía no hay un árbol semántico disponible.")
                service.processPending(root, frame)
            }
            mainHandler.postDelayed({
                if (pending === request) finish(request, "${engine.label} no expuso una respuesta legible por Accesibilidad dentro del tiempo límite.")
            }, timeoutMs)
            return try {
                withTimeout(timeoutMs + 1_000L) { completion.await() }
            } catch (cancelled: CancellationException) {
                if (pending === request) {
                    active?.stopProviderGeneration()
                    pending = null
                }
                throw cancelled
            }
        }

        fun cancelPending() {
            val request = pending ?: return
            active?.stopProviderGeneration()
            pending = null
            request.completion.complete(EngineReply(request.id, null, "Tarea detenida por el usuario."))
        }

        private fun finish(request: PendingRequest, error: String? = null, text: String? = null): EngineReply {
            if (pending === request) pending = null
            val reply = EngineReply(request.id, text, error)
            request.completion.complete(reply)
            return reply
        }

        fun currentFrame(): SemanticFrame? = _frame.value

        suspend fun captureScreen(context: Context): ScreenCapture {
            val service = active ?: error("Activa Accesibilidad para tomar una captura de pantalla.")
            check(Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                "La captura semántica requiere Android 11 o posterior."
            }
            return withTimeout(8_000L) {
                suspendCancellableCoroutine { continuation ->
                    service.takeScreenshot(Display.DEFAULT_DISPLAY, captureExecutor, object : TakeScreenshotCallback {
                        override fun onSuccess(result: ScreenshotResult) {
                            var hardwareBuffer: HardwareBuffer? = null
                            var bitmap: Bitmap? = null
                            try {
                                hardwareBuffer = result.hardwareBuffer
                                val hardwareBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, result.colorSpace)
                                    ?: error("Android no entregó una imagen para la captura.")
                                bitmap = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false)
                                    ?: error("No pude convertir la captura de pantalla.")
                                val directory = File(context.cacheDir, "screen-shares").apply { mkdirs() }
                                val file = File(directory, "screen-${UUID.randomUUID()}.png")
                                FileOutputStream(file).use { output ->
                                    check(bitmap!!.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                                        "No pude guardar la captura temporal."
                                    }
                                }
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
                                if (continuation.isActive) continuation.resume(ScreenCapture(uri, file, bitmap!!.width, bitmap!!.height)) else file.delete()
                            } catch (error: Throwable) {
                                if (continuation.isActive) continuation.resumeWithException(error)
                            } finally {
                                bitmap?.recycle()
                                hardwareBuffer?.close()
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            if (continuation.isActive) {
                                val message = when (errorCode) {
                                    ERROR_TAKE_SCREENSHOT_SECURE_WINDOW -> "Android bloqueó la captura porque esta pantalla está protegida."
                                    ERROR_TAKE_SCREENSHOT_NO_ACCESSIBILITY_ACCESS -> "Android no concedió acceso para capturar esta pantalla."
                                    ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT -> "La captura anterior fue demasiado reciente; espera un momento."
                                    else -> "Android no pudo capturar la pantalla (código $errorCode)."
                                }
                                continuation.resumeWithException(IllegalStateException(message))
                            }
                        }
                    })
                }
            }
        }

        fun discardCapture(capture: ScreenCapture) {
            capture.file.delete()
        }

        fun clickText(target: String): Boolean = active?.actOnText(target, AccessibilityNodeInfo.ACTION_CLICK) ?: false
        fun setText(target: String, value: String): Boolean = active?.setTextOnField(target, value) ?: false
        fun goBack(): Boolean = active?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun scroll(forward: Boolean): Boolean = active?.scrollFirst(forward) ?: false
        suspend fun tapPoint(x: Int, y: Int, width: Int, height: Int): Boolean =
            active?.dispatchScreenGesture(listOf(gestureStroke(x, y, x, y, 120, width, height))) ?: false
        suspend fun swipePath(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long, width: Int, height: Int): Boolean =
            active?.dispatchScreenGesture(listOf(gestureStroke(x1, y1, x2, y2, durationMs, width, height))) ?: false
        suspend fun holdPoint(x: Int, y: Int, durationMs: Long, width: Int, height: Int): Boolean =
            active?.dispatchScreenGesture(listOf(gestureStroke(x, y, x, y, durationMs, width, height))) ?: false

        private fun gestureStroke(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long, width: Int, height: Int): GestureDescription.StrokeDescription {
            require(width > 0 && height > 0) { "No conozco el tamaño de la pantalla." }
            require(x1 in 0..1000 && x2 in 0..1000 && y1 in 0..1000 && y2 in 0..1000) { "Las coordenadas visuales deben estar entre 0 y 1000." }
            val path = Path().apply {
                moveTo(x1 * width / 1000f, y1 * height / 1000f)
                lineTo(x2 * width / 1000f, y2 * height / 1000f)
            }
            return GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(80L, 2_000L))
        }

        fun isSensitiveTarget(target: String): Boolean {
            val sensitive = listOf("delete", "remove", "trash", "send", "submit", "purchase", "buy", "payment", "pay", "confirm", "borrar", "eliminar", "enviar", "comprar", "pagar", "confirmar")
            return sensitive.any { target.contains(it, ignoreCase = true) }
        }
    }

    override fun onServiceConnected() { active = this }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString().orEmpty()
        val nodes = ArrayList<SemanticNode>()
        collect(root, nodes, 0)
        val frame = SemanticFrame(pkg, nodes, System.currentTimeMillis())
        _frame.value = frame
        processPending(root, frame)
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<SemanticNode>, depth: Int) {
        if (depth > 24 || out.size > 600) return
        out += SemanticNode(
            node.text?.toString().orEmpty(),
            node.contentDescription?.toString().orEmpty(),
            node.className?.toString().orEmpty(),
            node.isEditable,
            node.isScrollable
        )
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            collect(child, out, depth + 1)
            child.recycle()
        }
    }

    private fun processPending(root: AccessibilityNodeInfo, frame: SemanticFrame) {
        val request = pending ?: return
        if (frame.packageName != request.packageName) return
        if (!request.sent) {
            val input = findNode(root) { it.isEditable || it.className?.contains("EditText", true) == true } ?: return
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, request.prompt) }
            if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return
            input.recycle()
            val send = findNode(root) { node ->
                if (!node.isClickable || !node.isEnabled) return@findNode false
                val label = "${node.text ?: ""} ${node.contentDescription ?: ""} ${node.viewIdResourceName ?: ""}"
                listOf("send", "submit", "enviar", "send_button", "sendbutton").any { label.contains(it, true) }
            } ?: return
            request.baseline = frame.nodes.map { it.text }.filter { it.isNotBlank() }.toSet()
            val clicked = send.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            send.recycle()
            if (clicked) request.sent = true
            return
        }

        val stopVisible = frame.nodes.any {
            val label = "${it.text} ${it.description}"
            listOf("stop generating", "stop response", "detener", "parar generación", "cancelar generación").any { token -> label.contains(token, true) }
        }
        val candidate = frame.nodes.asSequence()
            .filter { it.className.endsWith("TextView") && it.text.length > 8 }
            .map { it.text.trim() }
            .filterNot { text -> text in request.baseline || text.contains(request.userText, true) || text.contains("request_id", true) }
            .filterNot { text -> listOf("copy", "copiar", "share", "compartir", "regenerate", "regenerar").any { text.equals(it, true) } }
            .lastOrNull()
        if (candidate == null || stopVisible) {
            request.previousCandidate = null
            request.stableCount = 0
            return
        }
        val now = System.currentTimeMillis()
        if (candidate == request.previousCandidate && now - request.lastCandidateAt >= 400L) request.stableCount++
        else if (candidate != request.previousCandidate) request.stableCount = 1
        request.previousCandidate = candidate
        request.lastCandidateAt = now
        if (request.stableCount >= 3) finish(request, text = candidate)
    }

    private fun findNode(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (predicate(root)) return AccessibilityNodeInfo.obtain(root)
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val match = findNode(child, predicate)
            child.recycle()
            if (match != null) return match
        }
        return null
    }

    private fun actOnText(target: String, action: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNode(root) { candidate ->
            val text = "${candidate.text ?: ""} ${candidate.contentDescription ?: ""}"
            candidate.isVisibleToUser && candidate.isEnabled && candidate.isClickable && text.contains(target, true)
        } ?: return false
        return try { node.performAction(action) } finally { node.recycle() }
    }

    private fun setTextOnField(target: String, value: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNode(root) { candidate ->
            candidate.isEditable && (target.isBlank() || "${candidate.text ?: ""} ${candidate.contentDescription ?: ""}".contains(target, true))
        } ?: return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) }
        return try { node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) } finally { node.recycle() }
    }

    private fun scrollFirst(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNode(root) { it.isVisibleToUser && it.isScrollable } ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return try { node.performAction(action) } finally { node.recycle() }
    }

    private suspend fun dispatchScreenGesture(strokes: List<GestureDescription.StrokeDescription>): Boolean =
        withTimeout(4_000L) {
            suspendCancellableCoroutine { continuation ->
                val gesture = GestureDescription.Builder().apply { strokes.forEach(::addStroke) }.build()
                val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (continuation.isActive) continuation.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (continuation.isActive) continuation.resume(false)
                    }
                }, null)
                if (!accepted && continuation.isActive) continuation.resume(false)
            }
        }

    private fun stopProviderGeneration() {
        val root = rootInActiveWindow ?: return
        val node = findNode(root) { candidate ->
            val label = "${candidate.text ?: ""} ${candidate.contentDescription ?: ""}"
            candidate.isVisibleToUser && candidate.isEnabled && candidate.isClickable &&
                listOf("stop", "detener", "cancelar generación", "parar generación").any { label.contains(it, true) }
        } ?: return
        runCatching { node.performAction(AccessibilityNodeInfo.ACTION_CLICK) }
        node.recycle()
    }

    override fun onInterrupt() { }
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }
}
