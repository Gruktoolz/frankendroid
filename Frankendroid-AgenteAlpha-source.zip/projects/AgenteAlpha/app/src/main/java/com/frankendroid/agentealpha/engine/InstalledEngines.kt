package com.frankendroid.agentealpha.engine

import android.content.Context

data class Engine(val id: String, val label: String, val packageName: String)

object InstalledEngines {
    val known = listOf(
        Engine("chatgpt", "ChatGPT", "com.openai.chatgpt"),
        Engine("gemini", "Gemini", "com.google.android.apps.bard"),
        Engine("claude", "Claude", "com.anthropic.claude")
    )

    fun available(context: Context): List<Engine> = known.filter {
        context.packageManager.getLaunchIntentForPackage(it.packageName) != null
    }
}
