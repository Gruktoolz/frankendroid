package com.frankendroid.agentealpha

import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.frankendroid.agentealpha.agent.AlphaAgentRuntime
import com.frankendroid.agentealpha.engine.AlphaAccessibilityService
import com.frankendroid.agentealpha.engine.Engine
import com.frankendroid.agentealpha.engine.InstalledEngines
import com.frankendroid.agentealpha.theme.AgenteAlphaTheme
import com.frankendroid.agentealpha.ui.main.AgentAlphaApp
import com.frankendroid.agentealpha.ui.main.AlphaConversation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var activeJob: Job? = null
    private var accessibilityEnabled by mutableStateOf(false)
    private val prefs by lazy { getSharedPreferences("alpha", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlphaConversation.initialize(applicationContext)
        accessibilityEnabled = isAccessibilityEnabled()
        val engines = InstalledEngines.available(this)
        val initialEngine = engines.firstOrNull { it.id == prefs.getString("engine", "chatgpt") }
            ?: engines.firstOrNull()
        setContent {
            AgenteAlphaTheme {
                AgentAlphaApp(
                    engines = engines,
                    initialEngine = initialEngine,
                    accessibilityEnabled = accessibilityEnabled,
                    onEngineSelected = { engine -> prefs.edit().putString("engine", engine.id).apply() },
                    onEnableAccessibility = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    onSend = ::send,
                    onStop = ::stopTask
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accessibilityEnabled = isAccessibilityEnabled()
    }

    private fun send(text: String, task: Boolean, engine: Engine?) {
        if (text.isBlank()) return
        AlphaConversation.add(fromUser = true, task = task, text = text)
        activeJob = lifecycleScope.launch {
            AlphaConversation.setProgress(if (task) "Preparando tarea…" else "Abriendo motor visible…")
            try {
                val result = if (task) {
                    AlphaAgentRuntime.runTask(applicationContext, engine, text) { AlphaConversation.setProgress(it) }
                } else {
                    AlphaAgentRuntime.runConversation(applicationContext, engine, text)
                }
                val prefix = if (task) {
                    when {
                        result.verified -> "Verificado. ${result.message}"
                        result.message.contains("no pude comprobar", true) -> "Sin verificar. ${result.message}"
                        result.message.contains("no pude verificar", true) -> "Sin verificar. ${result.message}"
                        else -> "Pausé la tarea. ${result.message}"
                    }
                } else result.message
                AlphaConversation.add(fromUser = false, task = task, text = prefix)
            } catch (cancelled: CancellationException) {
                AlphaConversation.add(fromUser = false, task = task, text = "Tarea detenida. No ejecutaré más acciones de esta instrucción.")
                throw cancelled
            } catch (error: Throwable) {
                AlphaConversation.add(fromUser = false, task = task, text = "No pude completar la solicitud: ${error.message ?: error.javaClass.simpleName}")
            } finally {
                AlphaConversation.setProgress("")
            }
        }
    }

    private fun stopTask() {
        AlphaAccessibilityService.cancelPending()
        activeJob?.cancel()
        activeJob = null
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, AlphaAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        return enabled.split(':').any { it.equals(expected, true) }
    }
}
