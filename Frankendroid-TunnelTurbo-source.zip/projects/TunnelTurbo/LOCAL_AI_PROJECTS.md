# Proyectos de IA local

Esta lista contiene únicamente enlaces a proyectos. Tunnel Turbo no incluye ni redistribuye sus pesos.

- [LiteRT-LM](https://github.com/google-ai-edge/LiteRT-LM)
- [LiteRT](https://github.com/google-ai-edge/LiteRT)
- [llama.cpp](https://github.com/ggml-org/llama.cpp)
- [Ollama](https://github.com/ollama/ollama)
- [MLC-LLM](https://github.com/mlc-ai/mlc-llm)
- [ExecuTorch](https://github.com/pytorch/executorch)
