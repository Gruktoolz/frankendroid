"""Persistent Fast Observer with Adaptive Backoff, Signal Separation, and DeviceTracker integration."""

import asyncio
import logging
import time
from typing import Optional, Dict, Any, Callable
from ..state.engine import StateEngine
from .device_tracker import DeviceTracker

logger = logging.getLogger("persistent_observer")


class PersistentObserver:
    """Continuously observes fast device signals in the background with adaptive backoff rate switching."""

    def __init__(
        self,
        state_engine: StateEngine,
        device_tracker: Optional[DeviceTracker] = None,
        active_interval_s: float = 0.03,
        active_duration_s: float = 1.0,
    ):
        self.state_engine = state_engine
        self.device_tracker = device_tracker
        self.active_interval_s = active_interval_s
        self.active_duration_s = active_duration_s

        self._running: bool = False
        self._task: Optional[asyncio.Task] = None
        self._mode: str = "IDLE"  # "IDLE" or "ACTIVE"
        self._active_deadline: float = 0.0
        self._active_start_ns: int = 0
        self.last_active_duration_ms: float = 0.0

        # Backoff timing state
        self._last_change_time_s: float = time.monotonic()
        self._last_action_time_s: float = 0.0

        # Telemetry & Benchmarking metrics
        self.polls_idle_count: int = 0
        self.polls_active_count: int = 0
        self.adb_busy_time_ns: int = 0
        self.bytes_transferred: int = 0
        self.changes_detected: int = 0
        self.false_changes: int = 0

        self.last_live_refresh_ns: int = time.monotonic_ns()
        self.last_foreground_refresh_ns: int = time.monotonic_ns()
        self._start_time_ns: int = time.monotonic_ns()

        # Connect device tracker listener if available
        if self.device_tracker:
            self.device_tracker.on_state_change(self._on_device_state_change)

    def _on_device_state_change(self, serial: str, old_state: str, new_state: str):
        if serial == self.state_engine.serial:
            logger.info(f"Observer notified of device state transition: {old_state} -> {new_state}")
            if new_state == "device":
                self.trigger_active_mode(duration_s=1.0)

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def age_ms(self) -> float:
        """Time elapsed since the last fast-state check in milliseconds."""
        return round((time.monotonic_ns() - self.last_live_refresh_ns) / 1_000_000, 2)

    @property
    def foreground_age_ms(self) -> float:
        """Time elapsed since the last foreground check in milliseconds."""
        return round((time.monotonic_ns() - self.last_foreground_refresh_ns) / 1_000_000, 2)

    def trigger_active_mode(self, duration_s: Optional[float] = None) -> None:
        """Switch observer to high-frequency ACTIVE mode after an action."""
        dur = duration_s or self.active_duration_s
        now = time.monotonic()
        self._active_deadline = now + dur
        self._last_action_time_s = now
        self._active_start_ns = time.monotonic_ns()
        self._mode = "ACTIVE"

    def stop_active_mode(self) -> None:
        """Immediately exit ACTIVE mode when action verification is confirmed."""
        if self._mode == "ACTIVE":
            self.last_active_duration_ms = round((time.monotonic_ns() - self._active_start_ns) / 1_000_000, 2)
            self._mode = "IDLE"
            self._last_change_time_s = time.monotonic()

    def _compute_current_interval(self) -> float:
        """Compute the polling interval based on current mode and adaptive backoff."""
        if self._mode == "ACTIVE":
            return self.active_interval_s

        now = time.monotonic()
        time_since_change = now - self._last_change_time_s
        time_since_action = now - self._last_action_time_s

        # Recent activity window (settle period)
        if time_since_action < 3.0:
            return 0.25  # 250 ms: post-action stabilization
        elif time_since_change < 10.0:
            return 0.50  # 500 ms: recently active
        elif time_since_change < 30.0:
            return 1.00  # 1.0s: steady state
        else:
            return 2.00  # 2.0s: extended stable idle (massive reduction in ADB busy time!)

    async def _poll_once(self) -> None:
        # Check connection status via tracker if present
        if self.device_tracker and not self.device_tracker.is_connected(self.state_engine.serial):
            return

        t0 = time.monotonic_ns()
        try:
            prev_rev = (await self.state_engine.get_state(mode="fast")).revision
            fast_state = await self.state_engine.refresh_fast_state()
            new_rev = (await self.state_engine.get_state(mode="fast")).revision
            t1 = time.monotonic_ns()

            poll_duration = t1 - t0
            self.adb_busy_time_ns += poll_duration
            self.last_live_refresh_ns = t1
            self.last_foreground_refresh_ns = t1
            self.bytes_transferred += 210

            if self._mode == "ACTIVE":
                self.polls_active_count += 1
            else:
                self.polls_idle_count += 1

            if new_rev > prev_rev:
                self.changes_detected += 1
                self._last_change_time_s = time.monotonic()
                if self._mode == "ACTIVE":
                    self.stop_active_mode()
        except Exception as exc:
            logger.debug(f"Observer poll error: {exc}")

    async def _run_loop(self) -> None:
        logger.info("PersistentObserver started with adaptive backoff.")
        while self._running:
            now = time.monotonic()
            if self._mode == "ACTIVE":
                if now >= self._active_deadline:
                    self.stop_active_mode()

            await self._poll_once()
            interval = self._compute_current_interval()
            await asyncio.sleep(interval)

    def start(self) -> None:
        """Start the persistent observer background task."""
        if self._running:
            return
        self._running = True
        self._start_time_ns = time.monotonic_ns()
        self._task = asyncio.create_task(self._run_loop())

    async def stop(self) -> None:
        """Stop the persistent observer background task."""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        logger.info("PersistentObserver stopped.")

    def get_stats(self) -> Dict[str, Any]:
        """Alias for get_telemetry."""
        return self.get_telemetry()

    def get_telemetry(self) -> Dict[str, Any]:
        """Return operational telemetry metrics for benchmarking."""
        uptime_s = max((time.monotonic_ns() - self._start_time_ns) / 1_000_000_000, 0.001)
        total_polls = self.polls_idle_count + self.polls_active_count
        polls_per_min = round((total_polls / uptime_s) * 60, 2)
        bytes_per_min = round((self.bytes_transferred / uptime_s) * 60, 2)
        adb_busy_ms = self.adb_busy_time_ns / 1_000_000
        adb_busy_pct = round((adb_busy_ms / (uptime_s * 1000)) * 100, 2)

        tracker_state = self.device_tracker.get_device_state(self.state_engine.serial) if self.device_tracker else "UNKNOWN"

        return {
            "uptime_s": round(uptime_s, 2),
            "mode": self._mode,
            "observer_active": self._running,
            "current_interval_s": self._compute_current_interval(),
            "age_ms": self.age_ms,
            "foreground_age_ms": self.foreground_age_ms,
            "polls_idle_count": self.polls_idle_count,
            "polls_active_count": self.polls_active_count,
            "total_polls": total_polls,
            "polls_per_min": polls_per_min,
            "bytes_per_min": bytes_per_min,
            "adb_busy_time_ms": round(adb_busy_ms, 2),
            "adb_busy_percent": adb_busy_pct,
            "changes_detected": self.changes_detected,
            "false_changes": self.false_changes,
            "device_tracker": tracker_state,
            "last_active_duration_ms": self.last_active_duration_ms,
        }
