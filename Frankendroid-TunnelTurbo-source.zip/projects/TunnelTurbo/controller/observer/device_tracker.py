"""Device Tracker — Persistent event stream via adb track-devices.

Eliminates repetitive polling for device connectivity by listening to real-time ADB server events.
"""

import asyncio
import logging
from typing import Callable, Dict, Optional

logger = logging.getLogger("device_tracker")


class DeviceTracker:
    """Maintains a persistent background stream of device connectivity states using adb track-devices."""

    def __init__(self, target_serial: Optional[str] = None):
        self.target_serial = target_serial
        self._devices: Dict[str, str] = {}  # serial -> state ("device", "offline", etc.)
        self._proc: Optional[asyncio.subprocess.Process] = None
        self._task: Optional[asyncio.Task] = None
        self._running: bool = False
        self._on_change_callbacks = []
        self._first_event_event = asyncio.Event()

    def on_state_change(self, callback: Callable[[str, str, str], None]):
        """Register callback for (serial, old_state, new_state)."""
        self._on_change_callbacks.append(callback)

    @property
    def is_running(self) -> bool:
        return self._running

    def get_device_state(self, serial: Optional[str] = None) -> str:
        s = serial or self.target_serial
        return self._devices.get(s, "disconnected") if s else "disconnected"

    def is_connected(self, serial: Optional[str] = None) -> bool:
        return self.get_device_state(serial) == "device"

    def _parse_payload(self, text: str) -> Dict[str, str]:
        """Parse track-devices payload (format: 4-hex length + [serial\\tstate\\n]*)."""
        current: Dict[str, str] = {}
        # Strip hex length prefix if present (first 4 characters if they are hex)
        body = text[4:] if len(text) >= 4 and all(c in "0123456789abcdefABCDEF" for c in text[:4]) else text
        lines = body.strip().splitlines()
        for line in lines:
            parts = line.strip().split()
            if len(parts) >= 2:
                current[parts[0]] = parts[1]
        return current

    async def _stream_loop(self):
        while self._running:
            try:
                self._proc = await asyncio.create_subprocess_exec(
                    "adb", "track-devices",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                logger.info("adb track-devices process spawned successfully.")

                while self._running and self._proc.stdout:
                    line_bytes = await self._proc.stdout.readline()
                    if not line_bytes:
                        break

                    line_str = line_bytes.decode("utf-8", errors="replace")
                    new_devices = self._parse_payload(line_str)

                    # Detect transitions
                    all_serials = set(self._devices.keys()).union(new_devices.keys())
                    for s in all_serials:
                        old_st = self._devices.get(s, "disconnected")
                        new_st = new_devices.get(s, "disconnected")

                        if old_st != new_st:
                            logger.info(f"Device [{s}] state changed: {old_st} -> {new_st}")
                            for cb in self._on_change_callbacks:
                                try:
                                    cb(s, old_st, new_st)
                                except Exception as exc:
                                    logger.error(f"Error in device tracker callback: {exc}")

                    self._devices = new_devices
                    self._first_event_event.set()

            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning(f"Device tracker error: {exc}. Reconnecting in 1.0s...")
                await asyncio.sleep(1.0)
            finally:
                if self._proc:
                    try:
                        self._proc.terminate()
                        await self._proc.wait()
                    except Exception:
                        pass
                    self._proc = None

    def start(self):
        """Start tracking devices in background."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._stream_loop())

    async def wait_ready(self, timeout_s: float = 2.0) -> bool:
        """Wait for the initial device snapshot to be processed."""
        try:
            await asyncio.wait_for(self._first_event_event.wait(), timeout=timeout_s)
            return True
        except asyncio.TimeoutError:
            return False

    async def stop(self):
        """Stop tracking devices."""
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self._proc:
            try:
                self._proc.terminate()
                await self._proc.wait()
            except Exception:
                pass
            self._proc = None
        self._task = None
        logger.info("DeviceTracker stopped.")
