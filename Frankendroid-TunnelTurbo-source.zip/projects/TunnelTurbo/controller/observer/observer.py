"""Adaptive Observer for low-latency state tracking with IDLE and ACTIVE modes."""

import asyncio
import time
from typing import Optional, Callable
from ..state.engine import StateEngine


class AdaptiveObserver:
    """Monitors device state adaptively using cheap fast signals without triggering UI layout."""

    def __init__(self, state_engine: StateEngine):
        self.engine = state_engine
        self._running = False
        self._poll_task: Optional[asyncio.Task] = None
        self._idle_interval_s: float = 1.0
        self._on_change_callbacks = []

    def on_change(self, callback: Callable):
        self._on_change_callbacks.append(callback)

    async def observe_after_action(
        self,
        timeout_s: float = 2.0,
        check_interval_s: float = 0.08,
    ) -> bool:
        """ACTIVE mode: Poll fast state frequently after an action until change detected or timeout."""
        start_rev = (await self.engine.get_state(mode="fast")).revision
        deadline = time.monotonic() + timeout_s

        while time.monotonic() < deadline:
            await self.engine.refresh_fast_state()
            current_rev = (await self.engine.get_state(mode="fast")).revision
            if current_rev > start_rev:
                # State changed! UI already marked stale by state engine.
                for cb in self._on_change_callbacks:
                    try:
                        cb(current_rev)
                    except Exception:
                        pass
                return True

            await asyncio.sleep(check_interval_s)

        return False

    async def _idle_loop(self):
        while self._running:
            try:
                await self.engine.refresh_fast_state()
            except Exception:
                pass
            await asyncio.sleep(self._idle_interval_s)

    def start_idle_polling(self, interval_s: float = 1.0):
        """IDLE mode: Conservative background polling for fast signals."""
        if self._running:
            return
        self._running = True
        self._idle_interval_s = interval_s
        self._poll_task = asyncio.create_task(self._idle_loop())

    def stop_idle_polling(self):
        self._running = False
        if self._poll_task and not self._poll_task.done():
            self._poll_task.cancel()
