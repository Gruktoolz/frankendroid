"""Tunnel Turbo MCP Server — High-speed perception & control interface for Antigravity."""

import asyncio
import logging
import sys
import time
from typing import Optional, Dict, Any, List

# Ensure all logging goes exclusively to stderr (stdout is reserved for MCP JSON-RPC)
logging.basicConfig(
    stream=sys.stderr,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [TunnelTurboMCP] %(message)s",
)
logger = logging.getLogger("tunnel_turbo_mcp")

import os

# Ensure repository root is in sys.path when executed directly as a script
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from mcp.server.mcpserver import MCPServer

from controller.adb.client import AdbClient
from controller.state.engine import StateEngine
from controller.actions.engine import ActionEngine
from controller.actions.sequence import SequenceExecutor, SequenceResult, SequenceValidationError
from controller.observer.persistent import PersistentObserver
from controller.observer.device_tracker import DeviceTracker
from controller.actions.models import (
    ActionResult,
    ExpectedActivity,
    ExpectedPackage,
    ActivityChanged,
    StateChanged,
)


class TunnelTurboMCPServer:
    """Encapsulates Core Tunnel Turbo engines and exposes public MCP tools."""

    def __init__(self, serial: Optional[str] = None):
        self.server = MCPServer("tunnel-turbo")
        self.adb = AdbClient()
        self.serial = serial
        self.state_engine: Optional[StateEngine] = None
        self.action_engine: Optional[ActionEngine] = None
        self.device_tracker: Optional[DeviceTracker] = None
        self.persistent_observer: Optional[PersistentObserver] = None
        self.sequence_executor: Optional[SequenceExecutor] = None
        self._init_lock = asyncio.Lock()
        self._register_tools()

    async def ensure_initialized(self) -> None:
        """Lazily initialize device engines on first tool invocation."""
        if self.state_engine and self.action_engine:
            return

        async with self._init_lock:
            if self.state_engine and self.action_engine:
                return

            if not self.serial:
                devices = await self.adb.list_devices()
                if not devices:
                    raise RuntimeError("NO_DEVICE: No connected Android devices detected via ADB.")
                self.serial = devices[0].serial
                logger.info(f"Auto-selected device serial: {self.serial}")

            self.state_engine = StateEngine(serial=self.serial, adb_client=self.adb)
            await self.state_engine.initialize()
            self.action_engine = ActionEngine(
                serial=self.serial,
                state_engine=self.state_engine,
                adb_client=self.adb,
            )
            self.device_tracker = DeviceTracker(target_serial=self.serial)
            self.device_tracker.start()
            self.persistent_observer = PersistentObserver(
                self.state_engine,
                device_tracker=self.device_tracker,
            )
            self.persistent_observer.start()
            self.sequence_executor = SequenceExecutor(self.action_engine)
            logger.info("Tunnel Turbo Core engines, DeviceTracker, PersistentObserver & SequenceExecutor initialized.")

    def _format_response(
        self,
        core_result: Any,
        t_req_received: int,
        t_core_start: int,
        t_core_end: int,
    ) -> Dict[str, Any]:
        """Wrap result in standard MCP response schema with latency instrumentation."""
        t_resp_sent = time.monotonic_ns()

        mcp_pre_core_ms = (t_core_start - t_req_received) / 1_000_000
        core_ms = (t_core_end - t_core_start) / 1_000_000
        mcp_post_core_ms = (t_resp_sent - t_core_end) / 1_000_000
        mcp_overhead_ms = mcp_pre_core_ms + mcp_post_core_ms
        total_server_ms = (t_resp_sent - t_req_received) / 1_000_000

        metrics = {
            "mcp_pre_core_ms": round(mcp_pre_core_ms, 3),
            "core_ms": round(core_ms, 2),
            "mcp_post_core_ms": round(mcp_post_core_ms, 3),
            "mcp_overhead_ms": round(mcp_overhead_ms, 3),
            "total_server_ms": round(total_server_ms, 2),
        }

        if isinstance(core_result, SequenceResult):
            d = core_result.to_dict()
            return {
                "success": core_result.success,
                "completed_steps": core_result.completed_steps,
                "total_steps": core_result.total_steps,
                "failed_step": core_result.failed_step,
                "remaining_steps": core_result.remaining_steps,
                "steps": d.get("steps", []),
                "metrics": {
                    **d.get("metrics", {}),
                    "core_ms": metrics["core_ms"],
                    "mcp_pre_core_ms": metrics["mcp_pre_core_ms"],
                    "mcp_post_core_ms": metrics["mcp_post_core_ms"],
                    "mcp_overhead_ms": metrics["mcp_overhead_ms"],
                    "total_server_ms": metrics["total_server_ms"],
                },
                "layouts": core_result.layout_invocations,
                "screenshots_used": core_result.screenshots_used,
                "error": core_result.error,
            }

        elif isinstance(core_result, ActionResult):
            d = core_result.to_dict()
            return {
                "success": core_result.execution_ok and core_result.verified,
                "verified": core_result.verified,
                "verification": core_result.verification,
                "action": core_result.action,
                "revision": {
                    "before": core_result.before_revision,
                    "after": core_result.after_revision,
                },
                "changes": core_result.changes,
                "execution": {
                    "backend": core_result.backend,
                    "resolver": core_result.resolver,
                    "source": core_result.source,
                },
                "metrics": {
                    **d.get("metrics", {}),
                    "core_ms": metrics["core_ms"],
                    "mcp_pre_core_ms": metrics["mcp_pre_core_ms"],
                    "mcp_post_core_ms": metrics["mcp_post_core_ms"],
                    "mcp_overhead_ms": metrics["mcp_overhead_ms"],
                    "total_server_ms": metrics["total_server_ms"],
                },
                "layout_invocations": core_result.layout_invocations,
                "screenshots_used": core_result.screenshots_used,
                "details": core_result.details,
                "error": core_result.error,
            }

        elif isinstance(core_result, dict):
            # Pass dictionary result
            return {
                "success": True,
                "data": core_result,
                "metrics": metrics,
                "screenshots_used": 0,
            }

        return {
            "success": True,
            "data": str(core_result),
            "metrics": metrics,
            "screenshots_used": 0,
        }

    def _format_error(self, code: str, message: str, recoverable: bool = True) -> Dict[str, Any]:
        return {
            "success": False,
            "error": {
                "code": code,
                "message": message,
                "recoverable": recoverable,
            },
            "screenshots_used": 0,
        }

    def _register_tools(self) -> None:
        """Register all official Tunnel Turbo MCP tools with detailed LLM descriptions."""

        @self.server.tool()
        async def tunnel_list_devices() -> Dict[str, Any]:
            """List all connected Android devices available through ADB.

            When to use: Call this at the start of a session or when checking device connectivity.
            When NOT to use: Do not call repetitively during interaction on an already active device.
            Returns: List of devices with serial numbers, connection state, model and USB port.
            """
            t0 = time.monotonic_ns()
            try:
                t1 = time.monotonic_ns()
                devices = await self.adb.list_devices()
                t2 = time.monotonic_ns()
                dev_list = [
                    {
                        "serial": d.serial,
                        "state": d.state,
                        "model": d.model,
                        "product": d.product,
                        "usb": d.usb,
                    }
                    for d in devices
                ]
                return self._format_response({"devices": dev_list, "count": len(dev_list)}, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ADB_ERROR", str(exc))

        @self.server.tool()
        async def tunnel_get_state(mode: str = "fast") -> Dict[str, Any]:
            """Retrieve the structured state of the connected Android device.

            Modes:
              - 'cache' / 'cached' (~0.001 ms): Instantaneous in-memory state. Reads RAM without any device queries.
              - 'fast' (~50–70 ms ADB): Updates live fast signals (foreground app/activity, screen power, rotation) via lightweight ADB calls. Zero layout calls, zero screenshots.
              - 'ui': Returns Fast State PLUS UI layout nodes. If UI in memory is valid, reuses cache (0.003 ms); if stale, captures new layout (~1.3s).
              - 'fresh_ui': Explicitly forces a fresh UI hierarchy capture.
            When to use: Use mode='cache' for instant state, or mode='fast' to check what screen/app is currently active on the device.
            When NOT to use: Do NOT use mode='fresh_ui' unless you explicitly require fresh layout inspection.
            Returns: Device state dictionary with revision number, foreground activity, and metrics.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                mode_lower = mode.lower()
                if mode_lower in ("cache", "cached"):
                    state = await self.state_engine.get_state(mode="fast")
                elif mode_lower in ("fast", "live", "fast_live"):
                    await self.state_engine.refresh_fast_state()
                    state = await self.state_engine.get_state(mode="fast")
                elif mode_lower in ("ui", "fresh_ui"):
                    state = await self.state_engine.get_state(mode=mode_lower)
                else:
                    raise ValueError(f"Unknown mode '{mode}'. Use 'cache', 'fast', 'ui', or 'fresh_ui'.")
                t2 = time.monotonic_ns()
                include_ui_nodes = (mode_lower in ("ui", "fresh_ui"))
                st_dict = state.to_dict(include_ui=include_ui_nodes)
                if self.persistent_observer:
                    st_dict["age_ms"] = self.persistent_observer.age_ms
                    st_dict["foreground_age_ms"] = self.persistent_observer.foreground_age_ms
                    st_dict["observer_mode"] = self.persistent_observer.mode
                    st_dict["observer"] = {
                        "observer_active": self.persistent_observer.is_running,
                        "mode": self.persistent_observer.mode,
                        "age_ms": self.persistent_observer.age_ms,
                        "foreground_age_ms": self.persistent_observer.foreground_age_ms,
                    }
                else:
                    st_dict["age_ms"] = 0.0
                    st_dict["foreground_age_ms"] = 0.0
                    st_dict["observer_mode"] = "OFFLINE"

                if self.device_tracker:
                    raw_dev_state = self.device_tracker.get_device_state(self.serial)
                    st_dict["device_tracker"] = "CONNECTED" if raw_dev_state == "device" else raw_dev_state.upper()
                else:
                    st_dict["device_tracker"] = "CONNECTED" if self.serial else "UNKNOWN"

                return self._format_response(st_dict, t0, t1, t2)
            except Exception as exc:
                return self._format_error("STATE_ERROR", str(exc))

        @self.server.tool()
        async def tunnel_get_changes(since_revision: int, limit: int = 100) -> Dict[str, Any]:
            """Get Event Journal events and structural diff since a specified revision number.

            When to use: When you already have a previous state and want to know what occurred (e.g. Activity transitioned, node added/removed, toggle checked) while the model was thinking.
            When NOT to use: Do not call if you do not have a prior revision number.
            Args:
              - since_revision: Revision number to query from.
              - limit: Maximum number of events to return (default 100). Never truncates silently.
            Returns: Event Journal events recorded since since_revision plus structural diff and pagination metadata.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                changes_data = self.state_engine.get_changes(since_revision=since_revision, limit=limit)
                t2 = time.monotonic_ns()
                return self._format_response(changes_data, t0, t1, t2)
            except Exception as exc:
                return self._format_error("DIFF_ERROR", str(exc))

        @self.server.tool()
        async def tunnel_get_layout(freshness: str = "cached") -> Dict[str, Any]:
            """Retrieve the live UI hierarchy nodes of the current screen.

            Freshness options:
              - 'cached' (default): Re-uses UI hierarchy stored in RAM if available (<0.01 ms).
              - 'if_stale': Re-uses cache if valid; only queries device if the screen/Activity changed.
              - 'fresh': Forces live acquisition from device via Android CLI (~1.3 s).
            When to use: Call when you need to inspect interactive elements (buttons, inputs, titles) on screen.
            When NOT to use: Do NOT call if you only need to know what Activity is open (use tunnel_get_state instead).
            Returns: List of UI nodes with resource IDs, text, content descriptions, center coordinates, and interactability flags.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                curr_state = await self.state_engine.get_state(mode="fast")

                if freshness == "cached":
                    if curr_state.ui and curr_state.ui.nodes:
                        state = curr_state
                    else:
                        state = await self.state_engine.get_state(mode="ui")
                elif freshness == "if_stale":
                    state = await self.state_engine.get_state(mode="ui")
                elif freshness == "fresh":
                    state = await self.state_engine.get_state(mode="fresh_ui")
                else:
                    raise ValueError(f"Unknown freshness '{freshness}'. Use 'cached', 'if_stale', or 'fresh'.")

                t2 = time.monotonic_ns()
                nodes_summary = [
                    {
                        "key": n.key,
                        "resource_id": n.resource_id,
                        "class": n.class_name,
                        "text": n.text,
                        "desc": n.content_desc,
                        "interactions": n.interactions,
                        "state": n.state,
                    }
                    for n in state.ui.nodes
                ]
                res_data = {
                    "revision": state.ui.revision,
                    "stale": state.ui.stale,
                    "dirty": state.ui.dirty,
                    "source": state.ui.source,
                    "nodes_count": len(nodes_summary),
                    "nodes": nodes_summary,
                }
                return self._format_response(res_data, t0, t1, t2)
            except Exception as exc:
                return self._format_error("LAYOUT_ERROR", str(exc))

        @self.server.tool()
        async def tunnel_open_settings() -> Dict[str, Any]:
            """Open the main Android Settings screen directly.

            When to use: Use this instead of tapping a settings icon on the home screen.
            Performance: Direct system intent (~180 ms), verified via Fast State with zero layout calls and zero screenshots.
            Returns: ActionResult with success, new revision, and activity transition diff.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                res = await self.action_engine.open_settings()
                t2 = time.monotonic_ns()
                return self._format_response(res, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ACTION_FAILED", str(exc))

        @self.server.tool()
        async def tunnel_open_wifi_settings() -> Dict[str, Any]:
            """Open Wi-Fi Settings directly.

            When to use: Use this whenever the user wants to inspect or configure Wi-Fi.
            Performance: Fastest direct path (~190 ms). Bypasses home screen and manual navigation completely.
            Returns: ActionResult confirmed via Fast State (SUCCESS_VERIFIED_FAST).
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                res = await self.action_engine.open_wifi_settings()
                t2 = time.monotonic_ns()
                return self._format_response(res, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ACTION_FAILED", str(exc))

        @self.server.tool()
        async def tunnel_open_bluetooth_settings() -> Dict[str, Any]:
            """Open Bluetooth Settings directly.

            When to use: Use this whenever the user wants to configure Bluetooth devices.
            Performance: Fastest direct path (~190 ms). Bypasses multi-step UI navigation.
            Returns: ActionResult confirmed via Fast State.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                res = await self.action_engine.open_bluetooth_settings()
                t2 = time.monotonic_ns()
                return self._format_response(res, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ACTION_FAILED", str(exc))

        @self.server.tool()
        async def tunnel_open_app(package: str) -> Dict[str, Any]:
            """Launch an application directly by its Android package name.

            Args:
              - package: The Android application ID (e.g. 'com.android.settings', 'com.google.android.youtube').
            When to use: Use to open any installed application directly without needing to swipe or find its icon on the launcher.
            Returns: ActionResult with activity transition.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                res = await self.action_engine.open_app(package_name=package)
                t2 = time.monotonic_ns()
                return self._format_response(res, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ACTION_FAILED", str(exc))

        @self.server.tool()
        async def tunnel_semantic_tap(selector: str, match: str = "single") -> Dict[str, Any]:
            """Tap an on-screen element using a semantic selector (e.g. text, resource ID, or content description).

            Args:
              - selector: Semantic query string. Supports:
                  * "text=Bluetooth" or "txt=Bluetooth" (substring, case-insensitive)
                  * "res=android:id/title" (resource ID)
                  * "desc=Buscar" (content description)
                  * Combined: "text=Ajustes,clickable=true"
              - match: 'single' (fails safely if multiple elements match) or 'first' (clicks first matching element).
            When to use: Use to click on buttons, list items, switches, or menu entries without needing coordinates.
            Performance: Resolves selector locally in RAM (<0.2 ms) and dispatches tap via ADB input (~40 ms). Total execution ~160 ms.
            Returns: ActionResult with updated revision, verification status, and diff.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                res = await self.action_engine.semantic_tap(selector=selector, match=match)
                t2 = time.monotonic_ns()
                return self._format_response(res, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ACTION_FAILED", str(exc))

        @self.server.tool()
        async def tunnel_press_key(key: str) -> Dict[str, Any]:
            """Press a standard Android hardware or navigation key.

            Args:
              - key: One of 'BACK', 'HOME', or 'ENTER'.
            When to use: Use 'BACK' to return to the previous screen; use 'HOME' to return to the launcher; use 'ENTER' to submit input.
            Returns: ActionResult with state change verification.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                key_upper = key.strip().upper()
                if key_upper == "BACK":
                    res = await self.action_engine.press_back()
                elif key_upper == "HOME":
                    res = await self.action_engine.press_home()
                elif key_upper == "ENTER":
                    res = await self.action_engine.act_and_observe(
                        action_name="press_enter",
                        action_coro_fn=lambda: self.adb.execute_raw(["shell", "input", "keyevent", "66"], serial=self.serial),
                        source="adb_direct",
                    )
                else:
                    return self._format_error("INVALID_ARGUMENT", f"Unsupported key '{key}'. Supported: BACK, HOME, ENTER.")

                t2 = time.monotonic_ns()
                return self._format_response(res, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ACTION_FAILED", str(exc))

        @self.server.tool()
        async def tunnel_act_and_observe(
            action: str,
            target: Optional[str] = None,
            expected: Optional[str] = None,
        ) -> Dict[str, Any]:
            """Execute an arbitrary high-level action and observe the result in a single condensed round-trip.

            Args:
              - action: Action type ('tap', 'open_settings', 'open_wifi', 'open_bluetooth', 'back', 'home').
              - target: Selector string (required for 'tap') or package name.
              - expected: Expected activity name/pattern to verify (e.g. 'WifiSettings').
            When to use: Central high-level primitive for executing an action and receiving verified diff + metrics.
            Returns: Complete ActionResult with zero screenshots and minimal diff.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                exp_cond = ExpectedActivity(expected) if expected else None
                act_norm = action.strip().lower()

                if act_norm == "tap":
                    if not target:
                        return self._format_error("MISSING_ARGUMENT", "Action 'tap' requires a target selector.")
                    res = await self.action_engine.semantic_tap(selector=target, expected=exp_cond)
                elif act_norm in ("open_settings", "settings"):
                    res = await self.action_engine.open_settings(expected=exp_cond)
                elif act_norm in ("open_wifi", "wifi"):
                    res = await self.action_engine.open_wifi_settings(expected=exp_cond)
                elif act_norm in ("open_bluetooth", "bluetooth"):
                    res = await self.action_engine.open_bluetooth_settings(expected=exp_cond)
                elif act_norm in ("back", "press_back"):
                    res = await self.action_engine.press_back(expected=exp_cond)
                elif act_norm in ("home", "press_home"):
                    res = await self.action_engine.press_home(expected=exp_cond)
                elif act_norm == "open_app":
                    if not target:
                        return self._format_error("MISSING_ARGUMENT", "Action 'open_app' requires target package.")
                    res = await self.action_engine.open_app(package_name=target, expected=exp_cond)
                else:
                    return self._format_error("UNKNOWN_ACTION", f"Action '{action}' is not recognized.")

                t2 = time.monotonic_ns()
                return self._format_response(res, t0, t1, t2)
            except Exception as exc:
                return self._format_error("ACTION_FAILED", str(exc))

        @self.server.tool()
        async def tunnel_execute_sequence(
            steps: List[Dict[str, Any]],
            stop_on_failure: bool = True,
        ) -> Dict[str, Any]:
            """Execute a short ordered sequence of already-supported Android actions locally.
            Each step is observed and verified by Tunnel Turbo before continuing.
            Prefer this tool when the user's request already implies multiple deterministic actions and no intermediate model reasoning is required.
            Do not use a sequence when the next action depends on unknown information that must first be observed or reasoned about.

            Args:
              - steps: Ordered list of action dictionaries to execute (e.g. [{'action': 'open_wifi_settings'}, {'action': 'press_key', 'key': 'BACK'}, {'action': 'open_bluetooth_settings'}]).
              - stop_on_failure: If True (default), halts execution immediately if any step fails verification.
            Returns: SequenceResult with executed step status, timings, and verification results.
            """
            t0 = time.monotonic_ns()
            try:
                await self.ensure_initialized()
                t1 = time.monotonic_ns()
                if self.persistent_observer:
                    self.persistent_observer.trigger_active_mode(duration_s=2.5)

                seq_res = await self.sequence_executor.execute_sequence(
                    steps=steps,
                    stop_on_failure=stop_on_failure,
                )
                t2 = time.monotonic_ns()
                return self._format_response(seq_res, t0, t1, t2)
            except SequenceValidationError as val_err:
                return self._format_error("VALIDATION_ERROR", str(val_err), recoverable=False)
            except Exception as exc:
                return self._format_error("SEQUENCE_FAILED", str(exc))

    def run(self) -> None:
        """Run the server using stdio transport (compatible with MCP v2 SDK)."""
        logger.info("Starting Tunnel Turbo MCP server on stdio transport...")
        self.server.run(transport="stdio")


def main():
    server = TunnelTurboMCPServer()
    server.run()


if __name__ == "__main__":
    main()
