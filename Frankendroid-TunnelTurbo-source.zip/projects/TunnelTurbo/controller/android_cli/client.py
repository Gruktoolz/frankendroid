"""Android CLI client implementation for high-speed structured perception."""

import asyncio
import json
import shutil
import time
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


@dataclass
class LayoutResult:
    ok: bool
    duration_ms: float
    bytes_count: int
    windows_count: int
    nodes_count: int
    raw_data: List[Dict[str, Any]] = field(default_factory=list)
    stderr: str = ""
    error: Optional[str] = None


class AndroidCliClient:
    """Client for executing Android CLI operations and parsing structured UI."""

    def __init__(self, cli_path: Optional[str] = None):
        self.cli_bin = cli_path or shutil.which("android") or "android"

    def is_available(self) -> bool:
        """Check if android binary is available."""
        return shutil.which(self.cli_bin) is not None

    def _extract_json(self, raw_text: str) -> Any:
        """Robustly extract JSON from output, ignoring non-JSON banners/messages."""
        text = raw_text.strip()
        first_bracket = text.find("[")
        first_brace = text.find("{")

        if first_bracket == -1 and first_brace == -1:
            raise ValueError("No JSON object or array found in output")

        if first_bracket != -1 and (first_brace == -1 or first_bracket < first_brace):
            start_idx = first_bracket
            end_idx = text.rfind("]")
            if end_idx == -1:
                raise ValueError("Unmatched JSON array closing bracket")
            json_substr = text[start_idx : end_idx + 1]
        else:
            start_idx = first_brace
            end_idx = text.rfind("}")
            if end_idx == -1:
                raise ValueError("Unmatched JSON object closing brace")
            json_substr = text[start_idx : end_idx + 1]

        return json.loads(json_substr)

    async def get_layout(
        self,
        serial: Optional[str] = None,
        flat: bool = True,
        no_idle: bool = True,
        full: bool = False,
        timeout_s: float = 12.0,
    ) -> LayoutResult:
        """Fetch structured layout tree or flat list from device."""
        cmd = [self.cli_bin, "layout"]
        if serial:
            cmd.append(f"--device={serial}")
        if flat:
            cmd.append("--flat")
        if no_idle:
            cmd.append("--no-idle")
        if full:
            cmd.append("--full")

        t0 = time.monotonic_ns()
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_s
            )
            t1 = time.monotonic_ns()
            duration_ms = (t1 - t0) / 1_000_000

            stdout_str = stdout_bytes.decode("utf-8", errors="replace")
            stderr_str = stderr_bytes.decode("utf-8", errors="replace")

            if proc.returncode != 0:
                return LayoutResult(
                    ok=False,
                    duration_ms=duration_ms,
                    bytes_count=len(stdout_bytes),
                    windows_count=0,
                    nodes_count=0,
                    stderr=stderr_str,
                    error=f"Command exited with code {proc.returncode}: {stderr_str}",
                )

            data = self._extract_json(stdout_str)
            if not isinstance(data, list):
                data = [data]

            windows_count = len(data)
            nodes_count = sum(len(win.get("content", [])) for win in data if isinstance(win, dict))

            return LayoutResult(
                ok=True,
                duration_ms=duration_ms,
                bytes_count=len(stdout_bytes),
                windows_count=windows_count,
                nodes_count=nodes_count,
                raw_data=data,
                stderr=stderr_str,
            )

        except asyncio.TimeoutError:
            t1 = time.monotonic_ns()
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            return LayoutResult(
                ok=False,
                duration_ms=(t1 - t0) / 1_000_000,
                bytes_count=0,
                windows_count=0,
                nodes_count=0,
                error=f"Timed out after {timeout_s}s",
            )
        except Exception as exc:
            t1 = time.monotonic_ns()
            return LayoutResult(
                ok=False,
                duration_ms=(t1 - t0) / 1_000_000,
                bytes_count=0,
                windows_count=0,
                nodes_count=0,
                error=str(exc),
            )
