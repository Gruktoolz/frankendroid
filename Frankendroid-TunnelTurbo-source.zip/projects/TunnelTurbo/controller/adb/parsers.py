"""Parsers and dataclasses for ADB outputs."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import re


@dataclass(frozen=True)
class AdbDevice:
    serial: str
    state: str
    usb: Optional[str] = None
    product: Optional[str] = None
    model: Optional[str] = None
    device: Optional[str] = None
    transport_id: Optional[str] = None


@dataclass(frozen=True)
class DeviceProps:
    serial: str
    manufacturer: str
    model: str
    android_version: str
    api_level: int
    raw_props: Dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class ForegroundApp:
    package: Optional[str] = None
    activity: Optional[str] = None
    window_title: Optional[str] = None


@dataclass
class AdbResult:
    ok: bool
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: float


def parse_adb_devices(raw_stdout: str) -> list[AdbDevice]:
    """Parse output of `adb devices -l` into a list of AdbDevice."""
    devices: list[AdbDevice] = []
    lines = raw_stdout.strip().splitlines()
    for line in lines:
        line = line.strip()
        if not line or line.startswith("*") or line.startswith("List of devices attached"):
            continue

        parts = line.split()
        if len(parts) < 2:
            continue

        serial = parts[0]
        state = parts[1]

        extra_info: Dict[str, str] = {}
        for token in parts[2:]:
            if ":" in token:
                k, v = token.split(":", 1)
                extra_info[k] = v

        devices.append(
            AdbDevice(
                serial=serial,
                state=state,
                usb=extra_info.get("usb"),
                product=extra_info.get("product"),
                model=extra_info.get("model"),
                device=extra_info.get("device"),
                transport_id=extra_info.get("transport_id"),
            )
        )
    return devices


def parse_foreground_window(raw_dumpsys: str, display_id: int = 0) -> ForegroundApp:
    """Extract package and activity from `dumpsys window` or `dumpsys activity` output, honoring display_id."""
    # 1. First check display-specific topResumedActivity
    disp_pattern = rf"Display #{display_id}\s*\(activities from top to bottom\):.*?topResumedActivity=ActivityRecord\{{[0-9a-fA-F]+\s+u\d+\s+([^/\s]+)/([^}}\s]+)"
    match = re.search(disp_pattern, raw_dumpsys, re.DOTALL)
    if match:
        return ForegroundApp(package=match.group(1), activity=match.group(2))

    # 2. Fallback to mCurrentFocus
    match = re.search(r"mCurrentFocus=Window\{[0-9a-fA-F]+\s+u\d+\s+([^/\s]+)/([^}\s]+)\}", raw_dumpsys)
    if not match:
        # Fallback to mFocusedApp
        match = re.search(r"mFocusedApp=ActivityRecord\{[0-9a-fA-F]+\s+u\d+\s+([^/\s]+)/([^}\s]+)", raw_dumpsys)

    if match:
        pkg = match.group(1)
        act = match.group(2)
        return ForegroundApp(package=pkg, activity=act)

    return ForegroundApp()
