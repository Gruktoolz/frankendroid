"""Internal ADB client implementation with safe allowlist and async execution."""

import asyncio
import shutil
import time
from typing import Optional, List, Dict
import re

from .parsers import (
    AdbDevice,
    DeviceProps,
    ForegroundApp,
    AdbResult,
    parse_adb_devices,
    parse_foreground_window,
)


class AdbClient:
    """High-level async client for ADB interactions."""

    def __init__(self, adb_path: Optional[str] = None):
        self.adb_bin = adb_path or shutil.which("adb") or "adb"

    def is_available(self) -> bool:
        """Check if adb binary exists in system."""
        return shutil.which(self.adb_bin) is not None

    async def execute_raw(
        self,
        args: List[str],
        serial: Optional[str] = None,
        timeout_s: float = 10.0,
    ) -> AdbResult:
        """Execute an adb command with strict timeout and duration tracking."""
        cmd = [self.adb_bin]
        if serial:
            cmd.extend(["-s", serial])
        cmd.extend(args)

        t0 = time.monotonic_ns()
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_s
            )
            t1 = time.monotonic_ns()
            duration_ms = (t1 - t0) / 1_000_000

            return AdbResult(
                ok=(proc.returncode == 0),
                exit_code=proc.returncode if proc.returncode is not None else -1,
                stdout=stdout_bytes.decode("utf-8", errors="replace"),
                stderr=stderr_bytes.decode("utf-8", errors="replace"),
                duration_ms=duration_ms,
            )
        except asyncio.TimeoutError:
            t1 = time.monotonic_ns()
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            return AdbResult(
                ok=False,
                exit_code=-1,
                stdout="",
                stderr=f"Command timed out after {timeout_s}s",
                duration_ms=(t1 - t0) / 1_000_000,
            )
        except Exception as exc:
            t1 = time.monotonic_ns()
            return AdbResult(
                ok=False,
                exit_code=-1,
                stdout="",
                stderr=str(exc),
                duration_ms=(t1 - t0) / 1_000_000,
            )

    async def list_devices(self) -> List[AdbDevice]:
        """List attached devices with metadata."""
        res = await self.execute_raw(["devices", "-l"], timeout_s=5.0)
        if not res.ok:
            return []
        return parse_adb_devices(res.stdout)

    async def get_device_props(self, serial: str) -> DeviceProps:
        """Fetch system properties for a specific device."""
        res = await self.execute_raw(
            [
                "shell",
                "getprop ro.product.manufacturer; "
                "echo '---'; "
                "getprop ro.product.model; "
                "echo '---'; "
                "getprop ro.build.version.release; "
                "echo '---'; "
                "getprop ro.build.version.sdk",
            ],
            serial=serial,
            timeout_s=5.0,
        )

        manufacturer = "Unknown"
        model = "Unknown"
        version = "Unknown"
        api_level = 0

        if res.ok:
            blocks = [b.strip() for b in res.stdout.split("---")]
            if len(blocks) >= 4:
                manufacturer = blocks[0]
                model = blocks[1]
                version = blocks[2]
                try:
                    api_level = int(blocks[3])
                except ValueError:
                    api_level = 0

        return DeviceProps(
            serial=serial,
            manufacturer=manufacturer,
            model=model,
            android_version=version,
            api_level=api_level,
        )

    async def get_display_size(self, serial: str) -> Dict[str, int]:
        """Get display resolution via wm size."""
        res = await self.execute_raw(["shell", "wm", "size"], serial=serial, timeout_s=4.0)
        # Output: Physical size: 1220x2712 or Override size: ...
        width, height = 0, 0
        if res.ok:
            matches = re.findall(r"(\d+)x(\d+)", res.stdout)
            if matches:
                # take last match in case of override
                width, height = int(matches[-1][0]), int(matches[-1][1])
        return {"width": width, "height": height}

    async def get_foreground_app(self, serial: str, display_id: int = 0) -> ForegroundApp:
        """Get foreground app and activity honoring display_id."""
        res = await self.execute_raw(
            ["shell", "dumpsys activity activities | grep -E 'Display #|topResumedActivity|mFocusedApp'"],
            serial=serial,
            timeout_s=5.0,
        )
        if not res.ok or not res.stdout.strip():
            # Fallback to window focus
            res = await self.execute_raw(
                ["shell", "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'"],
                serial=serial,
                timeout_s=5.0,
            )
        if not res.ok or not res.stdout.strip():
            return ForegroundApp()
        return parse_foreground_window(res.stdout, display_id=display_id)
