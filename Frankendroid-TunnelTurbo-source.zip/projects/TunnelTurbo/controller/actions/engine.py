"""Action Engine coordinating direct and semantic actions with Fast Observation and Verification."""

import asyncio
import time
from typing import Optional, Callable, Any, Dict, List

from ..adb.client import AdbClient
from ..android_cli.client import AndroidCliClient
from ..state.engine import StateEngine
from .models import (
    ActionResult,
    ActionMetrics,
    VerificationLevel,
    ActionBackend,
    ExpectedCondition,
    ExpectedActivity,
    ActivityChanged,
    StateChanged,
)
from .direct import DirectActions
from .semantic import SemanticActions


class ActionEngine:
    """Dispatches actions and performs reactively verified observation cycles."""

    def __init__(
        self,
        serial: str,
        state_engine: StateEngine,
        adb_client: Optional[AdbClient] = None,
        cli_client: Optional[AndroidCliClient] = None,
    ):
        self.serial = serial
        self.state = state_engine
        self.adb = adb_client or state_engine.adb
        self.cli = cli_client or state_engine.cli
        self.direct = DirectActions(self.adb, self.serial)
        self.semantic = SemanticActions(cli_bin=self.cli.cli_bin, serial=self.serial)
        self._action_lock = asyncio.Lock()

    async def act_and_observe(
        self,
        action_name: str,
        action_coro_fn: Callable[[], Any],
        expected: Optional[ExpectedCondition] = None,
        timeout_ms: int = 2500,
        source: str = "direct",
        resolver: str = "NONE",
        backend: str = ActionBackend.DIRECT_INTENT.value,
        selector_resolution_ms: float = 0.0,
        details: Optional[Dict[str, Any]] = None,
    ) -> ActionResult:
        """Core execution loop:

        1. Capture fast state in RAM
        2. Execute action
        3. Reactive observation via Fast State
        4. Verification
        5. Minimal diff computation
        6. Return structured ActionResult
        """
        async with self._action_lock:
            t0 = time.monotonic_ns()

            # 1. State snapshot in RAM
            init_state = await self.state.get_state(mode="fast")
            init_rev = init_state.revision
            init_fast = init_state.fast
            init_act = init_fast.activity
            init_pkg = init_fast.package

            # 2. Dispatch action
            t_disp0 = time.monotonic_ns()
            try:
                exec_res = await action_coro_fn()
            except Exception as exc:
                t_err = time.monotonic_ns()
                return ActionResult(
                    action=action_name,
                    execution_ok=False,
                    verified=False,
                    verification=VerificationLevel.FAILED.value,
                    before_revision=init_rev,
                    after_revision=init_rev,
                    before_activity=init_act,
                    after_activity=init_act,
                    source=source,
                    resolver=resolver,
                    backend=backend,
                    metrics=ActionMetrics(
                        selector_resolution_ms=selector_resolution_ms,
                        dispatch_ms=(t_err - t_disp0) / 1_000_000,
                        total_ms=(t_err - t0) / 1_000_000,
                    ),
                    details=details or {},
                    error=str(exc),
                )

            t_disp1 = time.monotonic_ns()
            dispatch_ms = (t_disp1 - t_disp0) / 1_000_000

            execution_ok = getattr(exec_res, "ok", True)
            if not execution_ok:
                t_err = time.monotonic_ns()
                err_msg = getattr(exec_res, "error", "") or getattr(exec_res, "stderr", "")
                return ActionResult(
                    action=action_name,
                    execution_ok=False,
                    verified=False,
                    verification=VerificationLevel.FAILED.value,
                    before_revision=init_rev,
                    after_revision=init_rev,
                    before_activity=init_act,
                    after_activity=init_act,
                    source=source,
                    resolver=resolver,
                    backend=backend,
                    metrics=ActionMetrics(
                        selector_resolution_ms=selector_resolution_ms,
                        dispatch_ms=dispatch_ms,
                        total_ms=(t_err - t0) / 1_000_000,
                    ),
                    details=details or {},
                    error=f"Command execution failed: {err_msg}",
                )

            # 3. Reactive observation loop
            t_det0 = time.monotonic_ns()
            deadline = time.monotonic() + (timeout_ms / 1000.0)
            detected = False
            fast_queries = 0
            requires_ui = expected.requires_ui() if expected else False

            poll_interval = 0.02

            while time.monotonic() < deadline:
                fast_queries += 1
                curr_fast = await self.state.refresh_fast_state()

                if expected:
                    if not requires_ui and expected.is_satisfied_fast(init_fast, curr_fast):
                        detected = True
                        break
                else:
                    if curr_fast.activity != init_act or curr_fast.package != init_pkg:
                        detected = True
                        break

                await asyncio.sleep(poll_interval)
                poll_interval = min(poll_interval + 0.015, 0.08)

            t_det1 = time.monotonic_ns()
            detection_ms = (t_det1 - t_det0) / 1_000_000

            # 4. Verification
            t_ver0 = time.monotonic_ns()
            verified = False
            verification_level = VerificationLevel.EXECUTED_UNVERIFIED
            layout_invocations = 0

            if expected and requires_ui:
                ui_state = await self.state.refresh_ui_state()
                layout_invocations = 1
                if expected.is_satisfied_ui(ui_state):
                    verified = True
                    verification_level = VerificationLevel.SUCCESS_VERIFIED_UI
            elif detected:
                verified = True
                verification_level = VerificationLevel.SUCCESS_VERIFIED_FAST
            else:
                curr_state = await self.state.get_state(mode="fast")
                if curr_state.revision > init_rev:
                    verified = True
                    verification_level = VerificationLevel.SUCCESS_VERIFIED_FAST
                else:
                    verification_level = VerificationLevel.EXECUTED_UNVERIFIED

            t_ver1 = time.monotonic_ns()
            verification_ms = (t_ver1 - t_ver0) / 1_000_000

            # 5. Diff & Result assembly
            curr_state = await self.state.get_state(mode="fast")
            diff_data = self.state.get_changes(since_revision=init_rev)
            if isinstance(diff_data, dict):
                changes_list = diff_data.get("events", [])
            elif hasattr(diff_data, "changes"):
                changes_list = [c.to_dict() for c in diff_data.changes]
            else:
                changes_list = []

            t_end = time.monotonic_ns()
            total_ms = (t_end - t0) / 1_000_000

            # Journal event recording
            if hasattr(self.state, "journal"):
                ev_type = "action_completed" if verified else "verification_failed"
                self.state.journal.record(
                    ev_type,
                    curr_state.revision,
                    source="action_engine",
                    details={
                        "action": action_name,
                        "verified": verified,
                        "verification": verification_level.value,
                        "total_ms": round(total_ms, 2),
                    },
                )

            return ActionResult(
                action=action_name,
                execution_ok=True,
                verified=verified,
                verification=verification_level.value,
                before_revision=init_rev,
                after_revision=curr_state.revision,
                before_activity=init_act,
                after_activity=curr_state.fast.activity,
                changes=changes_list,
                source=source,
                resolver=resolver,
                backend=backend,
                coordinates_hidden_from_caller=True,
                metrics=ActionMetrics(
                    selector_resolution_ms=selector_resolution_ms,
                    dispatch_ms=dispatch_ms,
                    detection_ms=detection_ms,
                    verification_ms=verification_ms,
                    total_ms=total_ms,
                ),
                layout_invocations=layout_invocations,
                fast_queries=fast_queries,
                screenshots_used=0,
                model_round_trips_required=1,
                details=details or {},
            )

    # ==================================================================
    # HIGH-LEVEL ACTION WRAPPERS
    # ==================================================================

    async def press_back(self, expected: Optional[ExpectedCondition] = None) -> ActionResult:
        """Simulate hardware BACK button and observe."""
        cond = expected or ActivityChanged()
        return await self.act_and_observe(
            action_name="press_back",
            action_coro_fn=self.direct.press_back,
            expected=cond,
            source="adb_direct",
            backend=ActionBackend.ADB_INPUT.value,
        )

    async def press_home(self, expected: Optional[ExpectedCondition] = None) -> ActionResult:
        """Simulate hardware HOME button and observe."""
        cond = expected or ExpectedActivity("launcher|Launcher")
        return await self.act_and_observe(
            action_name="press_home",
            action_coro_fn=self.direct.press_home,
            expected=cond,
            source="adb_direct",
            backend=ActionBackend.ADB_INPUT.value,
        )

    async def open_settings(self, expected: Optional[ExpectedCondition] = None) -> ActionResult:
        """Open main device Settings."""
        cond = expected or ExpectedActivity("Settings|MiuiSettings")
        return await self.act_and_observe(
            action_name="open_settings",
            action_coro_fn=self.direct.open_settings,
            expected=cond,
            source="adb_direct",
            backend=ActionBackend.DIRECT_INTENT.value,
        )

    async def open_wifi_settings(self, expected: Optional[ExpectedCondition] = None) -> ActionResult:
        """Open Wi-Fi Settings directly."""
        cond = expected or ExpectedActivity("WifiSettings")
        return await self.act_and_observe(
            action_name="open_wifi_settings",
            action_coro_fn=self.direct.open_wifi_settings,
            expected=cond,
            source="adb_direct",
            backend=ActionBackend.DIRECT_INTENT.value,
        )

    async def open_bluetooth_settings(self, expected: Optional[ExpectedCondition] = None) -> ActionResult:
        """Open Bluetooth Settings directly."""
        cond = expected or ExpectedActivity("BluetoothSettings|SubSettings")
        return await self.act_and_observe(
            action_name="open_bluetooth_settings",
            action_coro_fn=self.direct.open_bluetooth_settings,
            expected=cond,
            source="adb_direct",
            backend=ActionBackend.DIRECT_INTENT.value,
        )

    async def open_app(self, package_name: str, expected: Optional[ExpectedCondition] = None) -> ActionResult:
        """Launch an app by package name."""
        cond = expected or ActivityChanged()
        return await self.act_and_observe(
            action_name=f"open_app({package_name})",
            action_coro_fn=lambda: self.direct.open_app(package_name),
            expected=cond,
            source="adb_direct",
            backend=ActionBackend.DIRECT_INTENT.value,
        )

    async def fast_semantic_tap(
        self,
        selector: str,
        match: str = "single",
        expected: Optional[ExpectedCondition] = None,
    ) -> ActionResult:
        """FAST SEMANTIC TAP: Resolves selector against cached UiState into node.center

        and dispatches directly via `adb shell input tap X Y`.
        """
        curr_state = await self.state.get_state(mode="fast")
        disp_w = curr_state.static.display_width or 1220
        disp_h = curr_state.static.display_height or 2712

        from .resolver import SemanticResolver, MatchStatus

        resolve_res = SemanticResolver.resolve(
            ui_state=curr_state.ui,
            selector=selector,
            display_width=disp_w,
            display_height=disp_h,
            match=match,
        )

        if not resolve_res.ok:
            # Cannot use fast route! Return explicit status
            init_rev = curr_state.revision
            act = curr_state.fast.activity
            return ActionResult(
                action=f"fast_semantic_tap({selector})",
                execution_ok=False,
                verified=False,
                verification=VerificationLevel.FAILED.value,
                before_revision=init_rev,
                after_revision=init_rev,
                before_activity=act,
                after_activity=act,
                source="cache_resolver",
                resolver="CACHE",
                backend=ActionBackend.ADB_INPUT.value,
                metrics=ActionMetrics(
                    selector_resolution_ms=resolve_res.duration_ms,
                ),
                details={
                    "status": resolve_res.status.value,
                    "candidates": resolve_res.candidates_count,
                },
                error=resolve_res.error,
            )

        x, y = resolve_res.coordinates
        cond = expected or ActivityChanged()

        # Execute coordinate tap via ADB without exposing coords to caller
        res = await self.act_and_observe(
            action_name=f"fast_semantic_tap({selector})",
            action_coro_fn=lambda: self.direct.input_tap(x, y),
            expected=cond,
            source="fast_semantic",
            resolver="CACHE",
            backend=ActionBackend.ADB_INPUT.value,
            selector_resolution_ms=resolve_res.duration_ms,
            details={"match_status": resolve_res.status.value},
        )

        # Invalidate UI according to outcome:
        # If activity changed -> stale = True
        # If same activity -> dirty = True (elements on screen may have changed state)
        if res.after_activity != res.before_activity:
            self.state.invalidate_ui(reason=f"fast_tapped_{selector}", dirty_only=False)
        else:
            self.state.invalidate_ui(reason=f"fast_tapped_{selector}", dirty_only=True)

        return res

    async def semantic_tap(
        self,
        selector: str,
        match: str = "single",
        expected: Optional[ExpectedCondition] = None,
        wait_ms: int = 1500,
    ) -> ActionResult:
        """Unified semantic tap: Tries fast path via UI cache first; if stale/missing,

        falls back to Android CLI.
        """
        curr_state = await self.state.get_state(mode="fast")
        if curr_state.ui and not curr_state.ui.stale and curr_state.ui.nodes:
            fast_res = await self.fast_semantic_tap(selector, match=match, expected=expected)
            if fast_res.execution_ok:
                return fast_res

        # Fallback to Android CLI input tap
        cond = expected or ActivityChanged()
        res = await self.act_and_observe(
            action_name=f"semantic_tap({selector})",
            action_coro_fn=lambda: self.semantic.tap(selector, match=match, wait_ms=wait_ms),
            expected=cond,
            source="android_cli_semantic",
            resolver="ANDROID_CLI",
            backend=ActionBackend.ANDROID_INPUT.value,
        )
        self.state.invalidate_ui(reason=f"cli_tapped_{selector}")
        return res

    async def fallback_a_layout_then_tap(
        self,
        selector: str,
        match: str = "single",
        expected: Optional[ExpectedCondition] = None,
    ) -> ActionResult:
        """Fallback A: Fetch fresh layout -> local resolve -> adb input tap."""
        await self.state.refresh_ui_state()
        return await self.fast_semantic_tap(selector, match=match, expected=expected)

    async def fallback_b_android_input_tap(
        self,
        selector: str,
        match: str = "single",
        expected: Optional[ExpectedCondition] = None,
    ) -> ActionResult:
        """Fallback B: android input tap <selector>."""
        cond = expected or ActivityChanged()
        res = await self.act_and_observe(
            action_name=f"fallback_b_android_input_tap({selector})",
            action_coro_fn=lambda: self.semantic.tap(selector, match=match, wait_ms=1500),
            expected=cond,
            source="android_cli_semantic",
            resolver="ANDROID_CLI",
            backend=ActionBackend.ANDROID_INPUT.value,
        )
        self.state.invalidate_ui(reason="cli_tap")
        return res

    async def semantic_swipe(
        self,
        selector: str,
        direction: str = "up",
        distance: float = 0.3,
        match: str = "first",
    ) -> ActionResult:
        """Fast semantic swipe using cached element center."""
        curr_state = await self.state.get_state(mode="fast")
        disp_w = curr_state.static.display_width or 1220
        disp_h = curr_state.static.display_height or 2712

        from .resolver import SemanticResolver
        resolve_res = SemanticResolver.resolve(
            curr_state.ui, selector, disp_w, disp_h, match=match
        )

        if not resolve_res.ok:
            # Fallback to CLI swipe
            return await self.act_and_observe(
                action_name=f"swipe({selector},{direction})",
                action_coro_fn=lambda: self.semantic.swipe(selector, direction=direction, distance=distance),
                source="android_cli_semantic",
                resolver="ANDROID_CLI",
                backend=ActionBackend.ANDROID_INPUT.value,
            )

        x1, y1 = resolve_res.coordinates
        # Calculate swipe target offset
        delta_x = 0
        delta_y = 0
        if direction == "up":
            delta_y = -int(disp_h * distance)
        elif direction == "down":
            delta_y = int(disp_h * distance)
        elif direction == "left":
            delta_x = -int(disp_w * distance)
        elif direction == "right":
            delta_x = int(disp_w * distance)

        x2 = max(10, min(disp_w - 10, x1 + delta_x))
        y2 = max(10, min(disp_h - 10, y1 + delta_y))

        res = await self.act_and_observe(
            action_name=f"fast_swipe({selector},{direction})",
            action_coro_fn=lambda: self.direct.input_swipe(x1, y1, x2, y2, duration_ms=250),
            source="fast_semantic",
            resolver="CACHE",
            backend=ActionBackend.ADB_INPUT.value,
            selector_resolution_ms=resolve_res.duration_ms,
        )
        self.state.invalidate_ui(reason="swiped", dirty_only=True)
        return res

    async def semantic_text(
        self,
        selector: str,
        text: str,
        submit: bool = False,
        match: str = "first",
    ) -> ActionResult:
        """Experimental fast semantic text input:

        1. Focus element by tapping center via ADB
        2. Enter text via `adb shell input text`
        3. Optional ENTER keycode 66
        """
        curr_state = await self.state.get_state(mode="fast")
        disp_w = curr_state.static.display_width or 1220
        disp_h = curr_state.static.display_height or 2712

        from .resolver import SemanticResolver
        resolve_res = SemanticResolver.resolve(
            curr_state.ui, selector, disp_w, disp_h, match=match
        )

        if not resolve_res.ok:
            # Fallback to Android CLI text
            return await self.act_and_observe(
                action_name=f"type_text({selector})",
                action_coro_fn=lambda: self.semantic.type_text(selector, text=text, submit=submit),
                source="android_cli_semantic",
                resolver="ANDROID_CLI",
                backend=ActionBackend.ANDROID_INPUT.value,
            )

        x, y = resolve_res.coordinates

        async def _text_sequence():
            # Tap element to focus
            await self.direct.input_tap(x, y)
            await asyncio.sleep(0.1)
            # Send text
            await self.direct.input_text(text)
            if submit:
                await asyncio.sleep(0.05)
                await self.adb.execute_raw(["shell", "input", "keyevent", "66"], serial=self.serial)
            return True

        res = await self.act_and_observe(
            action_name=f"fast_text({selector})",
            action_coro_fn=_text_sequence,
            source="fast_semantic",
            resolver="CACHE",
            backend=ActionBackend.ADB_INPUT.value,
            selector_resolution_ms=resolve_res.duration_ms,
        )
        self.state.invalidate_ui(reason="typed_text", dirty_only=True)
        return res
