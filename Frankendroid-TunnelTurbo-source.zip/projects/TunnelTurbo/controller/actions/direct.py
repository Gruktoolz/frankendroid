"""Direct actions executed via ADB (Intents, Activities, Keyevents)."""

from typing import Optional, List
from ..adb.client import AdbClient
from ..adb.parsers import AdbResult


class DirectActions:
    """Encapsulates safe direct Android system and ADB actions."""

    def __init__(self, adb: AdbClient, serial: str):
        self.adb = adb
        self.serial = serial

    async def input_tap(self, x: int, y: int) -> AdbResult:
        """Execute coordinate tap directly via ADB."""
        return await self.adb.execute_raw(
            ["shell", "input", "tap", str(x), str(y)],
            serial=self.serial,
            timeout_s=3.0,
        )

    async def input_swipe(
        self, x1: int, y1: int, x2: int, y2: int, duration_ms: int = 300
    ) -> AdbResult:
        """Execute coordinate swipe directly via ADB."""
        return await self.adb.execute_raw(
            ["shell", "input", "swipe", str(x1), str(y1), str(x2), str(y2), str(duration_ms)],
            serial=self.serial,
            timeout_s=4.0,
        )

    async def input_text(self, text: str) -> AdbResult:
        """Input text via ADB shell input text (spaces encoded as %s)."""
        # Escape spaces for adb shell input text
        escaped = text.replace(" ", "%s")
        return await self.adb.execute_raw(
            ["shell", "input", "text", escaped],
            serial=self.serial,
            timeout_s=4.0,
        )

    async def press_back(self) -> AdbResult:
        """Simulate hardware BACK button (KEYCODE_BACK = 4)."""
        return await self.adb.execute_raw(
            ["shell", "input", "keyevent", "4"],
            serial=self.serial,
            timeout_s=3.0,
        )

    async def press_home(self) -> AdbResult:
        """Simulate hardware HOME button (KEYCODE_HOME = 3)."""
        return await self.adb.execute_raw(
            ["shell", "input", "keyevent", "3"],
            serial=self.serial,
            timeout_s=3.0,
        )

    async def start_activity(self, component_or_intent: str) -> AdbResult:
        """Start an activity using `am start`."""
        args = ["shell", "am", "start"]
        if "/" in component_or_intent:
            args.extend(["-n", component_or_intent])
        elif component_or_intent.startswith("android.intent") or component_or_intent.startswith("android.settings"):
            args.extend(["-a", component_or_intent])
        else:
            args.extend(["-a", component_or_intent])

        return await self.adb.execute_raw(args, serial=self.serial, timeout_s=4.0)

    async def open_settings(self) -> AdbResult:
        """Open main device settings."""
        return await self.adb.execute_raw(
            ["shell", "am", "start", "-a", "android.settings.SETTINGS"],
            serial=self.serial,
            timeout_s=4.0,
        )

    async def open_wifi_settings(self) -> AdbResult:
        """Open Wi-Fi settings directly."""
        return await self.adb.execute_raw(
            ["shell", "am", "start", "-a", "android.settings.WIFI_SETTINGS"],
            serial=self.serial,
            timeout_s=4.0,
        )

    async def open_bluetooth_settings(self) -> AdbResult:
        """Open Bluetooth settings directly."""
        return await self.adb.execute_raw(
            ["shell", "am", "start", "-a", "android.settings.BLUETOOTH_SETTINGS"],
            serial=self.serial,
            timeout_s=4.0,
        )

    async def open_app(self, package_name: str) -> AdbResult:
        """Launch an app by package name."""
        # Use monkey to trigger the default launch activity for the package
        res = await self.adb.execute_raw(
            ["shell", "monkey", "-p", package_name, "-c", "android.intent.category.LAUNCHER", "1"],
            serial=self.serial,
            timeout_s=4.0,
        )
        if not res.ok:
            # Fallback to monkey without category
            res = await self.adb.execute_raw(
                ["shell", "monkey", "-p", package_name, "1"],
                serial=self.serial,
                timeout_s=4.0,
            )
        return res
