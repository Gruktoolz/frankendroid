"""Sequence Executor — Deterministic batch execution of actions without intermediate model round-trips."""

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from .engine import ActionEngine
from .models import ActionResult, ExpectedActivity


class SequenceValidationError(Exception):
    """Raised when sequence validation fails before execution."""
    pass


@dataclass
class StepSummary:
    index: int
    action: str
    verified: bool
    verification: str
    total_ms: float
    error: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "index": self.index,
            "action": self.action,
            "verified": self.verified,
            "verification": self.verification,
            "total_ms": round(self.total_ms, 2),
        }
        if self.error:
            d["error"] = self.error
        if self.details:
            d["details"] = self.details
        return d


@dataclass
class SequenceResult:
    success: bool
    completed_steps: int
    total_steps: int
    steps: List[StepSummary] = field(default_factory=list)
    failed_step: Optional[int] = None
    remaining_steps: int = 0
    total_core_ms: float = 0.0
    layout_invocations: int = 0
    screenshots_used: int = 0
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "completed_steps": self.completed_steps,
            "total_steps": self.total_steps,
            "failed_step": self.failed_step,
            "remaining_steps": self.remaining_steps,
            "steps": [s.to_dict() for s in self.steps],
            "metrics": {
                "steps": len(self.steps),
                "core_ms": round(self.total_core_ms, 2),
                "model_round_trips_required": 1,
                "layouts": self.layout_invocations,
                "screenshots": self.screenshots_used,
            },
            "error": self.error,
        }


class SequenceExecutor:
    """Validates and executes ordered sequences of supported actions locally."""

    ALLOWED_ACTIONS = {
        "open_settings",
        "settings",
        "open_wifi_settings",
        "open_wifi",
        "wifi",
        "open_bluetooth_settings",
        "open_bluetooth",
        "bluetooth",
        "open_app",
        "press_key",
        "key",
        "press_back",
        "back",
        "press_home",
        "home",
        "semantic_tap",
        "tap",
    }

    def __init__(self, action_engine: ActionEngine):
        self.action_engine = action_engine
        self.state_engine = action_engine.state

    def validate(self, steps: List[Dict[str, Any]]) -> None:
        """Validate all steps before execution. Reject plan if any step is invalid."""
        if not isinstance(steps, list):
            raise SequenceValidationError(f"Invalid sequence: 'steps' must be a list, got {type(steps).__name__}.")
        if not steps:
            raise SequenceValidationError("Invalid sequence: 'steps' list cannot be empty.")

        for i, step in enumerate(steps):
            if not isinstance(step, dict):
                raise SequenceValidationError(f"Step {i} must be a dictionary, got {type(step).__name__}.")

            action = step.get("action")
            if not action or not isinstance(action, str):
                raise SequenceValidationError(f"Step {i} missing required string field 'action'.")

            act_norm = action.strip().lower()
            if act_norm not in self.ALLOWED_ACTIONS:
                raise SequenceValidationError(
                    f"Step {i} has unrecognized action '{action}'. Allowed: {sorted(list(self.ALLOWED_ACTIONS))}"
                )

            # Specific argument checks
            if act_norm == "open_app":
                pkg = step.get("package") or step.get("target")
                if not pkg or not isinstance(pkg, str):
                    raise SequenceValidationError(f"Step {i} ('open_app') requires non-empty string argument 'package'.")

            elif act_norm in ("press_key", "key"):
                key_name = step.get("key")
                if not key_name or str(key_name).strip().upper() not in ("BACK", "HOME", "ENTER"):
                    raise SequenceValidationError(
                        f"Step {i} ('press_key') requires 'key' to be one of ['BACK', 'HOME', 'ENTER']."
                    )

            elif act_norm in ("semantic_tap", "tap"):
                sel = step.get("selector") or step.get("target")
                if not sel or not isinstance(sel, str):
                    raise SequenceValidationError(
                        f"Step {i} ('semantic_tap') requires non-empty string argument 'selector'."
                    )

    async def _execute_step(self, step: Dict[str, Any]) -> ActionResult:
        act_norm = step["action"].strip().lower()

        if act_norm in ("open_settings", "settings"):
            return await self.action_engine.open_settings()

        elif act_norm in ("open_wifi_settings", "open_wifi", "wifi"):
            return await self.action_engine.open_wifi_settings()

        elif act_norm in ("open_bluetooth_settings", "open_bluetooth", "bluetooth"):
            return await self.action_engine.open_bluetooth_settings()

        elif act_norm in ("press_back", "back"):
            return await self.action_engine.press_back()

        elif act_norm in ("press_home", "home"):
            return await self.action_engine.press_home()

        elif act_norm in ("press_key", "key"):
            key_name = str(step["key"]).strip().upper()
            if key_name == "BACK":
                return await self.action_engine.press_back()
            elif key_name == "HOME":
                return await self.action_engine.press_home()
            elif key_name == "ENTER":
                return await self.action_engine.act_and_observe(
                    action_name="press_enter",
                    action_coro_fn=lambda: self.action_engine.direct.adb.execute_raw(
                        ["shell", "input", "keyevent", "66"],
                        serial=self.action_engine.serial,
                    ),
                    source="adb_direct",
                )
            else:
                raise ValueError(f"Unsupported key: {key_name}")

        elif act_norm in ("semantic_tap", "tap"):
            sel = step.get("selector") or step.get("target")
            match_mode = step.get("match", "single")
            return await self.action_engine.semantic_tap(selector=sel, match=match_mode)

        elif act_norm == "open_app":
            pkg = step.get("package") or step.get("target")
            return await self.action_engine.open_app(package_name=pkg)

        else:
            raise ValueError(f"Unhandled action '{act_norm}'")

    async def execute_sequence(
        self,
        steps: List[Dict[str, Any]],
        stop_on_failure: bool = True,
    ) -> SequenceResult:
        """Execute validated steps sequentially, checking verification and recording events."""
        # 1. Strict pre-validation
        self.validate(steps)

        total_steps = len(steps)
        step_summaries: List[StepSummary] = []
        total_core_ms: float = 0.0
        total_layouts: int = 0
        total_screenshots: int = 0

        # Record sequence_started in journal
        curr_rev = (await self.state_engine.get_state(mode="fast")).revision
        if hasattr(self.state_engine, "journal"):
            self.state_engine.journal.record(
                "sequence_started",
                curr_rev,
                source="sequence_executor",
                details={"total_steps": total_steps, "stop_on_failure": stop_on_failure},
            )

        failed_index: Optional[int] = None
        seq_success: bool = True
        err_msg: Optional[str] = None

        t_seq0 = time.monotonic_ns()

        for idx, step in enumerate(steps):
            act_name = step.get("action", f"step_{idx}")
            step_rev = (await self.state_engine.get_state(mode="fast")).revision

            if hasattr(self.state_engine, "journal"):
                self.state_engine.journal.record(
                    "step_started",
                    step_rev,
                    source="sequence_executor",
                    details={"index": idx, "action": act_name, "params": step},
                )

            try:
                res = await self._execute_step(step)
                step_core_ms = res.metrics.total_ms if res.metrics else 0.0
                total_core_ms += step_core_ms
                total_layouts += res.layout_invocations
                total_screenshots += res.screenshots_used

                summary = StepSummary(
                    index=idx,
                    action=act_name,
                    verified=res.verified,
                    verification=res.verification,
                    total_ms=step_core_ms,
                    error=res.error,
                    details=res.details,
                )
                step_summaries.append(summary)

                if hasattr(self.state_engine, "journal"):
                    ev_type = "step_completed" if res.verified else "step_failed"
                    self.state_engine.journal.record(
                        ev_type,
                        res.after_revision,
                        source="sequence_executor",
                        details={"index": idx, "action": act_name, "verified": res.verified},
                    )

                if not res.verified or not res.execution_ok:
                    seq_success = False
                    failed_index = idx
                    err_msg = res.error or f"Step {idx} ({act_name}) failed verification ({res.verification})."
                    if stop_on_failure:
                        break

            except Exception as exc:
                seq_success = False
                failed_index = idx
                err_msg = str(exc)
                summary = StepSummary(
                    index=idx,
                    action=act_name,
                    verified=False,
                    verification="FAILED",
                    total_ms=0.0,
                    error=err_msg,
                )
                step_summaries.append(summary)

                if hasattr(self.state_engine, "journal"):
                    self.state_engine.journal.record(
                        "step_failed",
                        step_rev,
                        source="sequence_executor",
                        details={"index": idx, "action": act_name, "error": err_msg},
                    )
                if stop_on_failure:
                    break

        completed_count = len([s for s in step_summaries if s.verified])
        remaining_count = total_steps - len(step_summaries)

        final_rev = (await self.state_engine.get_state(mode="fast")).revision
        if hasattr(self.state_engine, "journal"):
            self.state_engine.journal.record(
                "sequence_completed",
                final_rev,
                source="sequence_executor",
                details={
                    "success": seq_success,
                    "completed_steps": completed_count,
                    "total_steps": total_steps,
                    "total_ms": round((time.monotonic_ns() - t_seq0) / 1_000_000, 2),
                },
            )

        return SequenceResult(
            success=seq_success,
            completed_steps=completed_count,
            total_steps=total_steps,
            steps=step_summaries,
            failed_step=failed_index,
            remaining_steps=remaining_count,
            total_core_ms=total_core_ms,
            layout_invocations=total_layouts,
            screenshots_used=total_screenshots,
            error=err_msg if not seq_success else None,
        )
