"""Semantic Resolver matching selectors against cached UiState into exact on-screen coordinates."""

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Tuple, Union

from ..state.models import UiState, UiNode
from .selector import ParsedSelector, parse_selector


class MatchStatus(str, Enum):
    MATCH_UNIQUE = "MATCH_UNIQUE"
    MATCH_NONE = "MATCH_NONE"
    MATCH_MULTIPLE = "MATCH_MULTIPLE"
    MATCH_HIDDEN = "MATCH_HIDDEN"
    MATCH_OFFSCREEN = "MATCH_OFFSCREEN"
    MATCH_NOT_INTERACTABLE = "MATCH_NOT_INTERACTABLE"
    UI_STALE = "UI_STALE"


@dataclass
class ResolveResult:
    status: MatchStatus
    node: Optional[UiNode] = None
    coordinates: Optional[Tuple[int, int]] = None
    matched_nodes: List[UiNode] = field(default_factory=list)
    candidates_count: int = 0
    duration_ms: float = 0.0
    error: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.status == MatchStatus.MATCH_UNIQUE and self.coordinates is not None


class SemanticResolver:
    """Resolves semantic selectors to cached UI nodes and safe coordinates."""

    @classmethod
    def matches_node(cls, selector: ParsedSelector, node: UiNode) -> bool:
        """Check if a node satisfies all criteria in parsed selector (case-insensitive substring)."""
        # 1. Text substring
        if selector.text:
            node_text = (node.text or "").lower()
            if selector.text.lower() not in node_text:
                return False

        # 2. Resource ID substring
        if selector.resource_id:
            node_res = (node.resource_id or "").lower()
            if selector.resource_id.lower() not in node_res:
                return False

        # 3. Class name substring
        if selector.class_name:
            node_clz = (node.class_name or "").lower()
            if selector.class_name.lower() not in node_clz:
                return False

        # 4. Content description substring
        if selector.content_desc:
            node_desc = (node.content_desc or "").lower()
            if selector.content_desc.lower() not in node_desc:
                return False

        # 5. Boolean flags
        for flag_name, expected_val in selector.booleans.items():
            if flag_name == "clickable":
                has_flag = "CLICKABLE" in node.interactions
            elif flag_name == "scrollable":
                has_flag = "SCROLLABLE" in node.interactions
            elif flag_name == "focusable":
                has_flag = "FOCUSABLE" in node.interactions
            elif flag_name == "longclickable":
                has_flag = "LONG_CLICKABLE" in node.interactions
            elif flag_name == "checked":
                has_flag = "CHECKED" in node.state
            elif flag_name == "focused":
                has_flag = "FOCUSED" in node.state
            elif flag_name == "selected":
                has_flag = "SELECTED" in node.state
            else:
                has_flag = flag_name.upper() in node.state or flag_name.upper() in node.interactions

            if has_flag != expected_val:
                return False

        return True

    @classmethod
    def resolve(
        cls,
        ui_state: Optional[UiState],
        selector: Union[str, ParsedSelector],
        display_width: int,
        display_height: int,
        match: str = "single",
        require_clickable: bool = False,
    ) -> ResolveResult:
        """Resolve a selector against current UI state in RAM."""
        t0 = time.monotonic_ns()

        if ui_state is None or ui_state.stale:
            t1 = time.monotonic_ns()
            return ResolveResult(
                status=MatchStatus.UI_STALE,
                duration_ms=(t1 - t0) / 1_000_000,
                error="UI State is stale or missing. Fresh layout required.",
            )

        if isinstance(selector, str):
            parsed = parse_selector(selector)
        else:
            parsed = selector

        if parsed.is_empty():
            t1 = time.monotonic_ns()
            return ResolveResult(
                status=MatchStatus.MATCH_NONE,
                duration_ms=(t1 - t0) / 1_000_000,
                error="Selector is empty",
            )

        # Filter candidates from cached nodes
        candidates: List[UiNode] = []
        for node in ui_state.nodes:
            if cls.matches_node(parsed, node):
                candidates.append(node)

        # 1. No matches found
        if not candidates:
            t1 = time.monotonic_ns()
            return ResolveResult(
                status=MatchStatus.MATCH_NONE,
                candidates_count=0,
                duration_ms=(t1 - t0) / 1_000_000,
                error=f"No element matching '{parsed.raw}' found in cached layout.",
            )

        # 2. Multiple matches found
        if len(candidates) > 1 and match != "first":
            t1 = time.monotonic_ns()
            return ResolveResult(
                status=MatchStatus.MATCH_MULTIPLE,
                matched_nodes=candidates,
                candidates_count=len(candidates),
                duration_ms=(t1 - t0) / 1_000_000,
                error=f"Multiple elements ({len(candidates)}) matched '{parsed.raw}'. Specify match='first' or refine selector.",
            )

        target_node = candidates[0]

        # 3. Check visibility & interactability
        if target_node.hidden:
            t1 = time.monotonic_ns()
            return ResolveResult(
                status=MatchStatus.MATCH_HIDDEN,
                node=target_node,
                candidates_count=len(candidates),
                duration_ms=(t1 - t0) / 1_000_000,
                error="Target element is marked hidden.",
            )

        if target_node.off_screen:
            t1 = time.monotonic_ns()
            return ResolveResult(
                status=MatchStatus.MATCH_OFFSCREEN,
                node=target_node,
                candidates_count=len(candidates),
                duration_ms=(t1 - t0) / 1_000_000,
                error="Target element is off-screen. Scroll container first.",
            )

        if require_clickable and "CLICKABLE" not in target_node.interactions:
            t1 = time.monotonic_ns()
            return ResolveResult(
                status=MatchStatus.MATCH_NOT_INTERACTABLE,
                node=target_node,
                candidates_count=len(candidates),
                duration_ms=(t1 - t0) / 1_000_000,
                error="Target element is not clickable.",
            )

        # 4. Resolve coordinates from center or bounds
        coords = target_node.get_coordinates(display_width, display_height)
        t1 = time.monotonic_ns()

        if coords is None:
            return ResolveResult(
                status=MatchStatus.MATCH_OFFSCREEN,
                node=target_node,
                candidates_count=len(candidates),
                duration_ms=(t1 - t0) / 1_000_000,
                error="Target element coordinates could not be computed or are outside display.",
            )

        return ResolveResult(
            status=MatchStatus.MATCH_UNIQUE,
            node=target_node,
            coordinates=coords,
            matched_nodes=candidates,
            candidates_count=len(candidates),
            duration_ms=(t1 - t0) / 1_000_000,
        )
