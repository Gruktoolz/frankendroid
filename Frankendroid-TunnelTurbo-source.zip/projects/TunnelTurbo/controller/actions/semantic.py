"""Semantic UI interactions executed via Android CLI."""

import asyncio
import shutil
import time
from dataclasses import dataclass
from typing import Optional, List


@dataclass
class SemanticResult:
    ok: bool
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: float
    error: Optional[str] = None


class SemanticActions:
    """Executes semantic input actions via Android CLI (tap, text, swipe)."""

    def __init__(self, cli_bin: Optional[str] = None, serial: Optional[str] = None):
        self.cli_bin = cli_bin or shutil.which("android") or "android"
        self.serial = serial

    async def _execute_cli(self, subcommand: str, args: List[str], timeout_s: float = 6.0) -> SemanticResult:
        cmd = [self.cli_bin, "input"]
        if self.serial:
            cmd.append(f"--device={self.serial}")
        cmd.append(subcommand)
        cmd.extend(args)

        t0 = time.monotonic_ns()
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_s
            )
            t1 = time.monotonic_ns()
            duration_ms = (t1 - t0) / 1_000_000

            stdout_str = stdout_bytes.decode("utf-8", errors="replace").strip()
            stderr_str = stderr_bytes.decode("utf-8", errors="replace").strip()

            return SemanticResult(
                ok=(proc.returncode == 0),
                exit_code=proc.returncode or 0,
                stdout=stdout_str,
                stderr=stderr_str,
                duration_ms=duration_ms,
                error=stderr_str if proc.returncode != 0 else None,
            )
        except asyncio.TimeoutError:
            t1 = time.monotonic_ns()
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            return SemanticResult(
                ok=False,
                exit_code=-1,
                stdout="",
                stderr="Timed out",
                duration_ms=(t1 - t0) / 1_000_000,
                error=f"Semantic action timed out after {timeout_s}s",
            )
        except Exception as exc:
            t1 = time.monotonic_ns()
            return SemanticResult(
                ok=False,
                exit_code=-1,
                stdout="",
                stderr=str(exc),
                duration_ms=(t1 - t0) / 1_000_000,
                error=str(exc),
            )

    async def tap(self, selector: str, match: str = "first", wait_ms: int = 1000) -> SemanticResult:
        """Tap a UI element matching selector."""
        args = [f"--match={match}", f"--wait={wait_ms}", selector]
        return await self._execute_cli("tap", args, timeout_s=(wait_ms / 1000.0) + 4.0)

    async def type_text(
        self,
        selector: str,
        text: str,
        submit: bool = False,
        match: str = "first",
    ) -> SemanticResult:
        """Type text into a UI element matching selector."""
        args = [f"--match={match}"]
        if submit:
            args.append("--submit")
        args.extend([text, selector])
        return await self._execute_cli("text", args, timeout_s=5.0)

    async def swipe(
        self,
        selector: str,
        direction: str = "up",
        distance: Optional[float] = None,
        match: str = "first",
    ) -> SemanticResult:
        """Swipe on a UI element matching selector."""
        args = [f"--dir={direction}", f"--match={match}"]
        if distance is not None:
            args.append(f"--distance={distance}")
        args.append(selector)
        return await self._execute_cli("swipe", args, timeout_s=5.0)
