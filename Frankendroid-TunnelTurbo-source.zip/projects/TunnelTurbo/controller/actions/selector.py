"""Semantic selector parsing compatible with Android CLI selector syntax."""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List


# Key aliases matching Android CLI specifications
ALIAS_MAP = {
    "txt": "text",
    "text": "text",
    "id": "resource_id",
    "res": "resource_id",
    "resource-id": "resource_id",
    "clz": "class_name",
    "class": "class_name",
    "content": "content_desc",
    "desc": "content_desc",
    "content-desc": "content_desc",
}

BOOLEAN_KEYS = {
    "clickable",
    "scrollable",
    "checkable",
    "focusable",
    "longclickable",
    "checked",
    "focused",
    "selected",
}


@dataclass(frozen=True)
class ParsedSelector:
    raw: str
    text: Optional[str] = None
    resource_id: Optional[str] = None
    class_name: Optional[str] = None
    content_desc: Optional[str] = None
    booleans: Dict[str, bool] = field(default_factory=dict)

    def is_empty(self) -> bool:
        return (
            self.text is None
            and self.resource_id is None
            and self.class_name is None
            and self.content_desc is None
            and not self.booleans
        )


def parse_selector(raw_selector: str) -> ParsedSelector:
    """Parse comma-separated key=value pairs into a structured ParsedSelector.

    Examples:
        "text=Bluetooth"
        "res=android:id/title,clickable=true"
        "Bluetooth" -> defaults to text="Bluetooth"
    """
    raw = raw_selector.strip()
    if not raw:
        return ParsedSelector(raw=raw_selector)

    # If no '=' in selector, treat entire string as text substring
    if "=" not in raw:
        return ParsedSelector(raw=raw_selector, text=raw)

    parts = [p.strip() for p in raw.split(",") if p.strip()]
    fields: Dict[str, Any] = {}
    booleans: Dict[str, bool] = {}

    for part in parts:
        if "=" not in part:
            continue
        k, v = part.split("=", 1)
        k = k.strip().lower()
        v = v.strip()

        # Check aliases
        normalized_key = ALIAS_MAP.get(k, k)

        if normalized_key in ("text", "resource_id", "class_name", "content_desc"):
            fields[normalized_key] = v
        elif k in BOOLEAN_KEYS:
            booleans[k] = v.lower() in ("true", "1", "yes")

    return ParsedSelector(
        raw=raw_selector,
        text=fields.get("text"),
        resource_id=fields.get("resource_id"),
        class_name=fields.get("class_name"),
        content_desc=fields.get("content_desc"),
        booleans=booleans,
    )
