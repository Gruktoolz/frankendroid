"""Models and condition definitions for Action Engine and act_and_observe."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any, Union
import re


class VerificationLevel(str, Enum):
    SUCCESS_VERIFIED_FAST = "SUCCESS_VERIFIED_FAST"
    SUCCESS_VERIFIED_UI = "SUCCESS_VERIFIED_UI"
    EXECUTED_UNVERIFIED = "EXECUTED_UNVERIFIED"
    FAILED = "FAILED"


class ActionBackend(str, Enum):
    DIRECT_INTENT = "DIRECT_INTENT"
    ADB_INPUT = "ADB_INPUT"
    ANDROID_INPUT = "ANDROID_INPUT"
    ANDROID_LAYOUT = "ANDROID_LAYOUT"
    CACHE = "CACHE"
    VISUAL_FALLBACK = "VISUAL_FALLBACK"


@dataclass
class ActionMetrics:
    dispatch_ms: float = 0.0
    detection_ms: float = 0.0
    verification_ms: float = 0.0
    total_ms: float = 0.0
    selector_resolution_ms: float = 0.0


@dataclass
class ActionResult:
    action: str
    execution_ok: bool
    verified: bool
    verification: str  # Value from VerificationLevel
    before_revision: int
    after_revision: int
    before_activity: Optional[str] = None
    after_activity: Optional[str] = None
    changes: List[Dict[str, Any]] = field(default_factory=list)
    source: str = "direct"
    resolver: str = "NONE"  # "CACHE", "ANDROID_CLI", "NONE"
    backend: str = ActionBackend.DIRECT_INTENT.value
    coordinates_hidden_from_caller: bool = True
    metrics: ActionMetrics = field(default_factory=ActionMetrics)
    layout_invocations: int = 0
    fast_queries: int = 0
    screenshots_used: int = 0
    model_round_trips_required: int = 1
    details: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action": self.action,
            "execution_ok": self.execution_ok,
            "verified": self.verified,
            "verification": self.verification,
            "resolver": self.resolver,
            "backend": self.backend,
            "before_revision": self.before_revision,
            "after_revision": self.after_revision,
            "before_activity": self.before_activity,
            "after_activity": self.after_activity,
            "changes_count": len(self.changes),
            "changes": self.changes,
            "source": self.source,
            "metrics": {
                "selector_resolution_ms": round(self.metrics.selector_resolution_ms, 2),
                "dispatch_ms": round(self.metrics.dispatch_ms, 2),
                "detection_ms": round(self.metrics.detection_ms, 2),
                "verification_ms": round(self.metrics.verification_ms, 2),
                "total_ms": round(self.metrics.total_ms, 2),
            },
            "layout_invocations": self.layout_invocations,
            "fast_queries": self.fast_queries,
            "screenshots_used": self.screenshots_used,
            "model_round_trips_required": self.model_round_trips_required,
            "details": self.details,
            "error": self.error,
        }


# ======================================================================
# EXPECTED CONDITIONS
# ======================================================================

class ExpectedCondition:
    """Base class for verifiable conditions."""
    def requires_ui(self) -> bool:
        """True if condition cannot be verified with Fast State alone."""
        return False

    def is_satisfied_fast(self, initial_fast: Any, current_fast: Any) -> bool:
        return False

    def is_satisfied_ui(self, ui_state: Any) -> bool:
        return False


class ExpectedActivity(ExpectedCondition):
    """Verifies that the foreground activity matches a given pattern/name."""
    def __init__(self, activity_pattern: str):
        self.pattern = activity_pattern

    def is_satisfied_fast(self, initial_fast: Any, current_fast: Any) -> bool:
        act = current_fast.activity or ""
        return self.pattern in act or bool(re.search(self.pattern, act))

    def __repr__(self):
        return f"ExpectedActivity({self.pattern!r})"


class ExpectedPackage(ExpectedCondition):
    """Verifies that the foreground package matches."""
    def __init__(self, package_name: str):
        self.package_name = package_name

    def is_satisfied_fast(self, initial_fast: Any, current_fast: Any) -> bool:
        return current_fast.package == self.package_name

    def __repr__(self):
        return f"ExpectedPackage({self.package_name!r})"


class ActivityChanged(ExpectedCondition):
    """Verifies that the foreground activity changed from initial."""
    def is_satisfied_fast(self, initial_fast: Any, current_fast: Any) -> bool:
        return current_fast.activity != initial_fast.activity

    def __repr__(self):
        return "ActivityChanged()"


class PackageChanged(ExpectedCondition):
    """Verifies that the foreground package changed from initial."""
    def is_satisfied_fast(self, initial_fast: Any, current_fast: Any) -> bool:
        return current_fast.package != initial_fast.package

    def __repr__(self):
        return "PackageChanged()"


class StateChanged(ExpectedCondition):
    """Verifies that any fast signal (activity, package, orientation) changed."""
    def is_satisfied_fast(self, initial_fast: Any, current_fast: Any) -> bool:
        return (
            current_fast.activity != initial_fast.activity
            or current_fast.package != initial_fast.package
            or current_fast.orientation != initial_fast.orientation
            or current_fast.screen_state != initial_fast.screen_state
        )

    def __repr__(self):
        return "StateChanged()"


class ExpectedUiNode(ExpectedCondition):
    """Verifies that a UI node with selector exists or has a specific state/text."""
    def __init__(
        self,
        selector: str,
        expected_text: Optional[str] = None,
        expected_state: Optional[str] = None,
    ):
        self.selector = selector
        self.expected_text = expected_text
        self.expected_state = expected_state

    def requires_ui(self) -> bool:
        return True

    def is_satisfied_fast(self, initial_fast: Any, current_fast: Any) -> bool:
        # Cannot be verified solely via Fast State
        return False

    def is_satisfied_ui(self, ui_state: Any) -> bool:
        # Match selector against nodes
        for node in ui_state.nodes:
            matches = False
            # Check key or resource_id or text
            if self.selector in (node.resource_id or "") or self.selector in (node.text or ""):
                matches = True
            elif node.key and self.selector in node.key:
                matches = True

            if matches:
                if self.expected_text and self.expected_text not in (node.text or ""):
                    continue
                if self.expected_state and self.expected_state not in node.state:
                    continue
                return True
        return False

    def __repr__(self):
        return f"ExpectedUiNode({self.selector!r})"
