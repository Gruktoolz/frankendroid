"""Strict Plan Schemas and Allowlist for Intent Models."""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field


ALLOWED_ACTIONS = {
    "open_settings": {"required": [], "optional": []},
    "open_wifi_settings": {"required": [], "optional": []},
    "open_bluetooth_settings": {"required": [], "optional": []},
    "open_app": {"required": ["package"], "optional": []},
    "press_key": {"required": ["key"], "optional": []},
    "press_back": {"required": [], "optional": []},
    "press_home": {"required": [], "optional": []},
    "semantic_tap": {"required": ["selector"], "optional": ["match"]},
}

ALLOWED_KEYS = {"BACK", "HOME", "ENTER"}
MAX_SEQUENCE_STEPS = 8

# JSON Schema for Ollama structured output enforcement
PLAN_JSON_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "type": {
            "type": "string",
            "enum": ["action", "sequence", "needs_observation", "unsupported"]
        },
        "action": {
            "type": "string",
            "enum": list(ALLOWED_ACTIONS.keys())
        },
        "arguments": {
            "type": "object"
        },
        "steps": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": list(ALLOWED_ACTIONS.keys())
                    },
                    "arguments": {
                        "type": "object"
                    }
                },
                "required": ["action", "arguments"]
            }
        },
        "reason": {
            "type": "string"
        }
    },
    "required": ["type"]
}


@dataclass
class PlanStep:
    action: str
    arguments: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"action": self.action, "arguments": self.arguments}


@dataclass
class StructuredPlan:
    type: str  # "action", "sequence", "needs_observation", "unsupported"
    action: Optional[str] = None
    arguments: Optional[Dict[str, Any]] = None
    steps: Optional[List[PlanStep]] = None
    reason: Optional[str] = None
    raw_response: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"type": self.type}
        if self.type == "action":
            d["action"] = self.action
            d["arguments"] = self.arguments or {}
        elif self.type == "sequence":
            d["steps"] = [s.to_dict() for s in (self.steps or [])]
        elif self.type in ("needs_observation", "unsupported"):
            d["reason"] = self.reason or ""
        return d
