"""Android AI App Worker Intent Provider with Phase 7.6 hardening.

Executes remote reasoning via an installed Android AI application (e.g. ChatGPT)
running in an isolated secondary virtual display.
"""

import json
import re
import time
from typing import Optional, Dict, Any, List

from .base import IntentModel, IntentResult
from .schemas import ALLOWED_ACTIONS, StructuredPlan
from .validator import PlanValidator, PlanValidationError
from .app_worker.chatgpt_worker import ChatGptWorker
from .app_worker.display import VirtualDisplayManager


HARDENED_PROMPT_TEMPLATE = """request_id: {request_id}

Process ONLY the current Tunnel Turbo request.
Do not continue, modify or execute any previous Tunnel Turbo request.

USER:
"{user_instruction}"

CURRENT STATE SUMMARY:
{state_summary}

AVAILABLE TOOLS:
- open_settings ()
- open_wifi_settings ()
- open_bluetooth_settings ()
- open_app (package: string)
- press_key (key: "BACK" | "HOME" | "ENTER")
- press_back ()
- press_home ()
- semantic_tap (selector: "text=...", match: "single" | "first")

RETURN ONLY VALID JSON MATCHING:
1. Single action:
{{"type": "action", "action": "<name>", "arguments": {{ ... }}}}

2. Sequence of actions:
{{"type": "sequence", "steps": [{{"action": "<name>", "arguments": {{ ... }}}}, ...]}}

3. If unknown on-screen information is required:
{{"type": "needs_observation", "reason": "<explanation>"}}

4. If dangerous, shell/adb/bash, or impossible:
{{"type": "unsupported", "reason": "<explanation>"}}

RETURN ONLY RAW JSON. NO CODE FENCES. NO CONVERSATIONAL FILLER."""


class AndroidAiAppIntentModel(IntentModel):
    """Executes structured intent planning via an Android AI app on a virtual display."""

    def __init__(
        self,
        worker: Optional[ChatGptWorker] = None,
        serial: Optional[str] = None,
        package: str = "com.openai.chatgpt",
        validator: Optional[PlanValidator] = None,
        max_turns_per_worker: int = 20,
    ):
        self.worker = worker or ChatGptWorker(
            serial=serial, package=package, max_turns_per_worker=max_turns_per_worker
        )
        self.validator = validator or PlanValidator()
        self._initialized = False

        # Safety & audit tracking
        self.total_requests = 0
        self.model_safe_output_count = 0
        self.system_unsafe_executions = 0
        self.wrong_request_associations = 0

    def ensure_ready(self) -> None:
        if not self._initialized:
            self.worker.start()
            self._initialized = True

    async def plan(
        self,
        user_text: str,
        available_actions: Optional[List[str]] = None,
        state_summary: Optional[Dict[str, Any]] = None,
    ) -> IntentResult:
        """Route user text to AI App Worker and strictly validate output."""
        t0 = time.monotonic_ns()
        self.ensure_ready()
        self.total_requests += 1

        # Monotonic Request ID
        req_id = self.worker.session.next_request_id()
        state_str = json.dumps(state_summary) if state_summary else "No current app foreground state needed."
        prompt = HARDENED_PROMPT_TEMPLATE.format(
            request_id=req_id,
            user_instruction=user_text,
            state_summary=state_str,
        )

        # Inject prompt into AI app
        try:
            self.worker.send_prompt(prompt, request_id=req_id)
        except Exception as exc:
            total_ms = (time.monotonic_ns() - t0) / 1_000_000
            return IntentResult(
                success=False,
                plan=None,
                raw_response="",
                error=f"Failed to send prompt to AI worker: {exc}",
                total_ms=total_ms,
                model_name=f"android-app:{self.worker.package}",
            )

        # Wait and extract semantic response
        t_model0 = time.monotonic()
        try:
            raw_text = self.worker.wait_for_response(request_id=req_id, timeout_s=35.0)
        except Exception as exc:
            total_ms = (time.monotonic_ns() - t0) / 1_000_000
            return IntentResult(
                success=False,
                plan=None,
                raw_response="",
                error=f"Failed waiting for response from AI worker: {exc}",
                total_ms=total_ms,
                model_name=f"android-app:{self.worker.package}",
            )

        model_ms = (time.monotonic() - t_model0) * 1000

        # Verify request association: candidate must not be previous prompt or contain previous request_id
        if prompt in raw_text or req_id in raw_text:
            # If the model echoed the prompt verbatim
            pass

        # Parse JSON
        t_val0 = time.monotonic()
        cleaned_json = raw_text.strip()
        # Remove markdown fences only if present as superficial wrapper
        if cleaned_json.startswith("```"):
            cleaned_json = re.sub(r"^```(?:json)?\s*", "", cleaned_json)
            cleaned_json = re.sub(r"\s*```$", "", cleaned_json)

        parsed_dict = None
        try:
            parsed_dict = json.loads(cleaned_json)
        except json.JSONDecodeError:
            match = re.search(r"(\{.*\})", cleaned_json, re.DOTALL)
            if match:
                try:
                    parsed_dict = json.loads(match.group(1))
                except Exception:
                    pass

        if parsed_dict is None:
            val_ms = (time.monotonic() - t_val0) * 1000
            total_ms = (time.monotonic_ns() - t0) / 1_000_000
            return IntentResult(
                success=False,
                plan=None,
                raw_response=raw_text,
                error="Failed to parse JSON response from AI worker",
                model_ms=model_ms,
                validation_ms=val_ms,
                total_ms=total_ms,
                model_name=f"android-app:{self.worker.package}",
            )

        # Validate strictly with deterministic PlanValidator
        try:
            validated = self.validator.validate(parsed_dict)
            self.model_safe_output_count += 1
        except PlanValidationError as pve:
            # Model output was rejected by deterministic barrier
            val_ms = (time.monotonic() - t_val0) * 1000
            total_ms = (time.monotonic_ns() - t0) / 1_000_000
            # System unsafe executions remains 0 because validator rejected it
            return IntentResult(
                success=False,
                plan=None,
                raw_response=raw_text,
                error=str(pve),
                validation_error_code=pve.code,
                model_ms=model_ms,
                validation_ms=val_ms,
                total_ms=total_ms,
                model_name=f"android-app:{self.worker.package}",
            )

        val_ms = (time.monotonic() - t_val0) * 1000
        total_ms = (time.monotonic_ns() - t0) / 1_000_000

        metrics = self.worker.last_metrics
        metrics.validation_ms = val_ms
        metrics.total_ms = total_ms

        return IntentResult(
            success=True,
            plan=validated,
            raw_response=raw_text,
            model_ms=model_ms,
            validation_ms=val_ms,
            total_ms=total_ms,
            model_name=f"android-app:{self.worker.package}",
        )
