"""Virtual display manager for Android AI Worker using scrcpy."""

import re
import subprocess
import time
from typing import Optional, Tuple, Dict, Any


class VirtualDisplayManager:
    """Manages creation, discovery, and lifecycle of Android virtual displays."""

    def __init__(
        self,
        serial: Optional[str] = None,
        width: int = 1080,
        height: int = 1920,
        dpi: int = 420,
        package: str = "com.openai.chatgpt",
        ime_policy: str = "hide",
    ):
        self.serial = serial
        self.width = width
        self.height = height
        self.dpi = dpi
        self.package = package
        self.ime_policy = ime_policy
        self._scrcpy_proc: Optional[subprocess.Popen] = None
        self._display_id: Optional[int] = None
        self._surface_flinger_id: Optional[str] = None

    @property
    def display_id(self) -> Optional[int]:
        return self._display_id

    @property
    def surface_flinger_id(self) -> Optional[str]:
        return self._surface_flinger_id

    def _adb_cmd(self, args: list[str]) -> subprocess.CompletedProcess:
        cmd = ["adb"]
        if self.serial:
            cmd.extend(["-s", self.serial])
        cmd.extend(args)
        return subprocess.run(cmd, capture_output=True, text=True, check=False)

    def discover_existing_display(self) -> Optional[int]:
        """Check dumpsys display for any active scrcpy/virtual display."""
        res = self._adb_cmd(["shell", "dumpsys display"])
        if res.returncode != 0:
            return None

        # Look for DisplayDeviceInfo with "scrcpy"
        output = res.stdout
        if "scrcpy" not in output:
            return None

        # Match mDisplayId=X followed nearby by mPrimaryDisplayDevice=scrcpy
        matches = re.findall(
            r"mDisplayId=(\d+)\s+mPrimaryDisplayDevice=scrcpy", output
        )
        if matches:
            self._display_id = int(matches[0])

            # Also discover SurfaceFlinger ID for screencap -d
            sf_match = re.search(r"uniqueId=\"(virtual:[^\"]+)\"", output)
            if sf_match:
                self._surface_flinger_id = sf_match.group(1)
            return self._display_id

        # Fallback regex
        alt = re.findall(r"Display #(\d+).*?scrcpy", output, re.DOTALL)
        if alt:
            self._display_id = int(alt[0])
            return self._display_id

        return None

    def start_display(self, timeout_s: float = 10.0) -> int:
        """Start or attach to virtual display and launch target package."""
        existing = self.discover_existing_display()
        if existing is not None:
            self._display_id = existing
            # Ensure package is launched on secondary display
            self._adb_cmd([
                "shell",
                f"am start --display {self._display_id} -n {self.package}/.MainActivity",
            ])
            return self._display_id

        # Launch scrcpy --new-display
        cmd = [
            "scrcpy",
            f"--new-display={self.width}x{self.height}/{self.dpi}",
            f"--start-app={self.package}",
            f"--display-ime-policy={self.ime_policy}",
            "--no-audio",
        ]
        if self.serial:
            cmd.extend(["-s", self.serial])

        self._scrcpy_proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        # Wait for display discovery
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            time.sleep(0.5)
            disp_id = self.discover_existing_display()
            if disp_id is not None:
                self._display_id = disp_id
                return disp_id

        raise TimeoutError(f"Virtual display failed to start within {timeout_s}s")

    def get_display_activities(self) -> Dict[str, Any]:
        """Inspect top resumed activities on primary vs secondary display."""
        res = self._adb_cmd(["shell", "dumpsys activity activities"])
        out = res.stdout if res.returncode == 0 else ""

        primary_match = re.search(
            r"Display #0\s*\(activities from top to bottom\):.*?topResumedActivity=ActivityRecord\{[^\s]+ [^\s]+ ([^\s]+)",
            out,
            re.DOTALL,
        )
        primary_app = primary_match.group(1) if primary_match else "unknown"

        worker_app = "unknown"
        if self._display_id is not None:
            worker_match = re.search(
                rf"Display #{self._display_id}\s*\(activities from top to bottom\):.*?topResumedActivity=ActivityRecord\{{[^\s]+ [^\s]+ ([^\s]+)",
                out,
                re.DOTALL,
            )
            if worker_match:
                worker_app = worker_match.group(1)

        return {
            "primary_display": {"id": 0, "top_activity": primary_app},
            "worker_display": {"id": self._display_id, "top_activity": worker_app},
        }

    def stop_display(self) -> None:
        """Terminate scrcpy process if launched by this manager."""
        if self._scrcpy_proc and self._scrcpy_proc.poll() is None:
            self._scrcpy_proc.terminate()
            try:
                self._scrcpy_proc.wait(timeout=3.0)
            except subprocess.TimeoutExpired:
                self._scrcpy_proc.kill()
            self._scrcpy_proc = None
        self._display_id = None
