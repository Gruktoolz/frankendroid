package com.tunnel.worker;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.UiAutomation;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Tunnel Turbo AI Worker Bridge
 * Executes direct Accessibility operations on an isolated Android display:
 * - Keyboardless prompt injection via ACTION_SET_TEXT
 * - Semantic Send via ACTION_CLICK
 * - Combined fast atomic setTextAndSend
 * - Semantic response perception and completion detection
 * - Zero clipboard usage in primary path
 * - Zero display #0 interference
 */
public class TunnelWorkerBridge {

    private final int targetDisplayId;
    private Object shellWrapper;
    private Class<?> wrapperClass;
    private UiAutomation uiAutomation;

    public TunnelWorkerBridge(int targetDisplayId) {
        this.targetDisplayId = targetDisplayId;
    }

    public void connect() throws Exception {
        wrapperClass = Class.forName("com.android.uiautomator.core.UiAutomationShellWrapper");
        shellWrapper = wrapperClass.getConstructor().newInstance();
        wrapperClass.getMethod("connect").invoke(shellWrapper);
        uiAutomation = (UiAutomation) wrapperClass.getMethod("getUiAutomation").invoke(shellWrapper);

        AccessibilityServiceInfo info = uiAutomation.getServiceInfo();
        if (info == null) info = new AccessibilityServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.flags |= AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS;
        info.flags |= AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        uiAutomation.setServiceInfo(info);
        Thread.sleep(120);
    }

    public void disconnect() {
        if (shellWrapper != null && wrapperClass != null) {
            try {
                wrapperClass.getMethod("disconnect").invoke(shellWrapper);
            } catch (Throwable ignored) {}
        }
    }

    private AccessibilityNodeInfo getDisplayRoot() {
        SparseArray<List<AccessibilityWindowInfo>> displays = uiAutomation.getWindowsOnAllDisplays();
        List<AccessibilityWindowInfo> windows = displays.get(targetDisplayId);
        if (windows == null || windows.isEmpty()) {
            return null;
        }
        for (AccessibilityWindowInfo w : windows) {
            if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) {
                AccessibilityNodeInfo r = w.getRoot();
                if (r != null) return r;
            }
        }
        return windows.get(0).getRoot();
    }

    private AccessibilityNodeInfo findEditText(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isEditable() || (node.getClassName() != null && node.getClassName().toString().contains("EditText"))) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo res = findEditText(child);
            if (res != null) {
                if (res != child && child != null) child.recycle();
                return res;
            }
            if (child != null) child.recycle();
        }
        return null;
    }

    private AccessibilityNodeInfo findSendButton(AccessibilityNodeInfo node) {
        if (node == null) return null;
        CharSequence desc = node.getContentDescription();
        if (desc != null) {
            String d = desc.toString().toLowerCase();
            if (d.contains("enviar") || d.contains("send")) {
                AccessibilityNodeInfo curr = node;
                while (curr != null) {
                    if (curr.isClickable()) return curr;
                    AccessibilityNodeInfo parent = curr.getParent();
                    if (parent == null) break;
                    if (curr != node) curr.recycle();
                    curr = parent;
                }
                return node;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo res = findSendButton(child);
            if (res != null) {
                if (res != child && child != null) child.recycle();
                return res;
            }
            if (child != null) child.recycle();
        }
        return null;
    }

    private AccessibilityNodeInfo findNewChatButton(AccessibilityNodeInfo node) {
        if (node == null) return null;
        CharSequence desc = node.getContentDescription();
        if (desc != null) {
            String d = desc.toString().toLowerCase();
            if (d.contains("chat nuevo") || d.contains("new chat")) {
                AccessibilityNodeInfo curr = node;
                while (curr != null) {
                    if (curr.isClickable()) return curr;
                    AccessibilityNodeInfo parent = curr.getParent();
                    if (parent == null) break;
                    if (curr != node) curr.recycle();
                    curr = parent;
                }
                return node;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo res = findNewChatButton(child);
            if (res != null) {
                if (res != child && child != null) child.recycle();
                return res;
            }
            if (child != null) child.recycle();
        }
        return null;
    }

    public String setText(String text) {
        long t0 = System.currentTimeMillis();
        AccessibilityNodeInfo root = getDisplayRoot();
        if (root == null) {
            return "{\"status\":\"error\",\"message\":\"no_root_window\"}";
        }
        AccessibilityNodeInfo edit = findEditText(root);
        if (edit == null) {
            root.recycle();
            return "{\"status\":\"error\",\"message\":\"edit_node_not_found\"}";
        }

        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean ok = edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
        long elapsed = System.currentTimeMillis() - t0;
        Rect bounds = new Rect();
        edit.getBoundsInScreen(bounds);
        edit.recycle();
        root.recycle();

        return String.format(
            "{\"status\":\"%s\",\"action\":\"set_text\",\"backend\":\"ACCESSIBILITY_SET_TEXT\",\"bounds\":\"%s\",\"elapsed_ms\":%d}",
            ok ? "ok" : "failed", bounds.toShortString(), elapsed
        );
    }

    public String clickSend() {
        long t0 = System.currentTimeMillis();
        AccessibilityNodeInfo root = getDisplayRoot();
        if (root == null) {
            return "{\"status\":\"error\",\"message\":\"no_root_window\"}";
        }
        AccessibilityNodeInfo send = findSendButton(root);
        if (send == null) {
            root.recycle();
            return "{\"status\":\"error\",\"message\":\"send_button_not_found\"}";
        }

        Rect bounds = new Rect();
        send.getBoundsInScreen(bounds);
        boolean actionClicked = false;
        if (send.isClickable()) {
            actionClicked = send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        long elapsed = System.currentTimeMillis() - t0;
        send.recycle();
        root.recycle();

        return String.format(
            "{\"status\":\"ok\",\"action\":\"click_send\",\"semantic_click\":%b,\"bounds\":\"%s\",\"center\":[%d,%d],\"elapsed_ms\":%d}",
            actionClicked, bounds.toShortString(), bounds.centerX(), bounds.centerY(), elapsed
        );
    }

    public String setTextAndSend(String text) {
        long t0 = System.currentTimeMillis();
        AccessibilityNodeInfo root = getDisplayRoot();
        if (root == null) {
            return "{\"status\":\"error\",\"message\":\"no_root_window\"}";
        }
        AccessibilityNodeInfo edit = findEditText(root);
        if (edit == null) {
            root.recycle();
            return "{\"status\":\"error\",\"message\":\"edit_node_not_found\"}";
        }

        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean setOk = edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
        edit.recycle();
        root.recycle();

        if (!setOk) {
            return "{\"status\":\"error\",\"message\":\"set_text_failed\"}";
        }

        try { Thread.sleep(80); } catch (Exception ignored) {}

        root = getDisplayRoot();
        if (root == null) {
            return "{\"status\":\"error\",\"message\":\"no_root_after_set_text\"}";
        }
        AccessibilityNodeInfo send = findSendButton(root);
        if (send == null) {
            root.recycle();
            return "{\"status\":\"error\",\"message\":\"send_button_not_found\"}";
        }

        Rect bounds = new Rect();
        send.getBoundsInScreen(bounds);
        boolean clicked = false;
        if (send.isClickable()) {
            clicked = send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        long elapsed = System.currentTimeMillis() - t0;
        send.recycle();
        root.recycle();

        return String.format(
            "{\"status\":\"ok\",\"action\":\"set_text_and_send\",\"backend\":\"ACCESSIBILITY_SET_TEXT\",\"semantic_click\":%b,\"bounds\":\"%s\",\"center\":[%d,%d],\"elapsed_ms\":%d}",
            clicked, bounds.toShortString(), bounds.centerX(), bounds.centerY(), elapsed
        );
    }

    public String clickNewChat() {
        long t0 = System.currentTimeMillis();
        AccessibilityNodeInfo root = getDisplayRoot();
        if (root == null) {
            return "{\"status\":\"error\",\"message\":\"no_root_window\"}";
        }
        AccessibilityNodeInfo newChat = findNewChatButton(root);
        if (newChat == null) {
            root.recycle();
            return "{\"status\":\"error\",\"message\":\"new_chat_button_not_found\"}";
        }

        Rect bounds = new Rect();
        newChat.getBoundsInScreen(bounds);
        boolean actionClicked = false;
        if (newChat.isClickable()) {
            actionClicked = newChat.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        long elapsed = System.currentTimeMillis() - t0;
        newChat.recycle();
        root.recycle();

        return String.format(
            "{\"status\":\"ok\",\"action\":\"click_new_chat\",\"semantic_click\":%b,\"bounds\":\"%s\",\"center\":[%d,%d],\"elapsed_ms\":%d}",
            actionClicked, bounds.toShortString(), bounds.centerX(), bounds.centerY(), elapsed
        );
    }

    private void collectNodes(AccessibilityNodeInfo node, List<String> texts, List<String> signals) {
        if (node == null) return;
        CharSequence desc = node.getContentDescription();
        CharSequence text = node.getText();
        if (desc != null) {
            String d = desc.toString().trim();
            if (d.equals("Copiar") || d.equals("Copy") || d.equals("Buena respuesta") || d.equals("Good response") || d.equals("Detener") || d.equals("Stop")) {
                signals.add(d);
            }
        }
        if (text != null) {
            String t = text.toString().trim();
            if (!t.isEmpty()) {
                texts.add(t);
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            collectNodes(child, texts, signals);
            if (child != null) child.recycle();
        }
    }

    public String inspectState(String requestId) {
        long t0 = System.currentTimeMillis();
        AccessibilityNodeInfo root = getDisplayRoot();
        if (root == null) {
            return "{\"status\":\"error\",\"message\":\"no_root_window\"}";
        }

        List<String> texts = new ArrayList<>();
        List<String> signals = new ArrayList<>();
        collectNodes(root, texts, signals);
        root.recycle();

        boolean hasCopiar = signals.contains("Copiar") || signals.contains("Copy");
        boolean hasBuenaRespuesta = signals.contains("Buena respuesta") || signals.contains("Good response");
        boolean isGenerating = signals.contains("Detener") || signals.contains("Stop");

        // Filter out prompt and system headers
        List<String> candidates = new ArrayList<>();
        for (String t : texts) {
            if (requestId != null && !requestId.isEmpty() && t.contains(requestId)) {
                continue;
            }
            if (t.contains("USER INSTRUCTION") || t.contains("Process ONLY") || t.contains("CURRENT STATE SUMMARY")) {
                continue;
            }
            if (t.equals("ChatGPT") || t.equals("Chat") || t.equals("Work") || t.equals("Preguntar a ChatGPT") || t.equals("Responder a ChatGPT")) {
                continue;
            }
            if (t.length() > 3) {
                candidates.add(t);
            }
        }

        String lastCandidate = candidates.isEmpty() ? "" : candidates.get(candidates.size() - 1);
        boolean complete = (hasCopiar || hasBuenaRespuesta) && !isGenerating && !lastCandidate.isEmpty();

        long elapsed = System.currentTimeMillis() - t0;
        return String.format(
            "{\"status\":\"ok\",\"complete\":%b,\"signals\":%s,\"is_generating\":%b,\"candidate_count\":%d,\"last_text\":%s,\"elapsed_ms\":%d}",
            complete,
            escapeJsonList(signals),
            isGenerating,
            candidates.size(),
            escapeJson(lastCandidate),
            elapsed
        );
    }

    private static String escapeJson(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            if (c == '"') sb.append("\\\"");
            else if (c == '\\') sb.append("\\\\");
            else if (c == '\b') sb.append("\\b");
            else if (c == '\f') sb.append("\\f");
            else if (c == '\n') sb.append("\\n");
            else if (c == '\r') sb.append("\\r");
            else if (c == '\t') sb.append("\\t");
            else if (c < 32) sb.append(String.format("\\u%04x", (int) c));
            else sb.append(c);
        }
        sb.append("\"");
        return sb.toString();
    }

    private static String escapeJsonList(List<String> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(escapeJson(list.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("{\"status\":\"error\",\"message\":\"Usage: TunnelWorkerBridge <disp_id> <action> [args...]\"}");
            return;
        }

        int dispId = Integer.parseInt(args[0]);
        String action = args[1];

        TunnelWorkerBridge bridge = new TunnelWorkerBridge(dispId);
        try {
            bridge.connect();
            switch (action) {
                case "set_text": {
                    if (args.length < 3) {
                        System.out.println("{\"status\":\"error\",\"message\":\"missing_text_argument\"}");
                        return;
                    }
                    String text = args[2];
                    if (text.startsWith("--file=") || text.equals("--file")) {
                        String filePath = text.startsWith("--file=") ? text.substring(7) : args[3];
                        text = new String(Files.readAllBytes(new File(filePath).toPath()), "UTF-8");
                    }
                    System.out.println(bridge.setText(text));
                    break;
                }
                case "click_send": {
                    System.out.println(bridge.clickSend());
                    break;
                }
                case "set_text_and_send": {
                    if (args.length < 3) {
                        System.out.println("{\"status\":\"error\",\"message\":\"missing_text_argument\"}");
                        return;
                    }
                    String text = args[2];
                    if (text.startsWith("--file=") || text.equals("--file")) {
                        String filePath = text.startsWith("--file=") ? text.substring(7) : args[3];
                        text = new String(Files.readAllBytes(new File(filePath).toPath()), "UTF-8");
                    }
                    System.out.println(bridge.setTextAndSend(text));
                    break;
                }
                case "click_new_chat": {
                    System.out.println(bridge.clickNewChat());
                    break;
                }
                case "inspect_state": {
                    String reqId = args.length > 2 ? args[2] : "";
                    System.out.println(bridge.inspectState(reqId));
                    break;
                }
                default:
                    System.out.println("{\"status\":\"error\",\"message\":\"unknown_action_" + action + "\"}");
            }
        } catch (Throwable t) {
            System.out.printf("{\"status\":\"error\",\"exception\":\"%s\",\"message\":%s}\n",
                t.getClass().getName(), escapeJson(t.getMessage()));
        } finally {
            bridge.disconnect();
        }
    }
}
