"""ChatGPT App Worker executing on secondary Android virtual display with Phase 7.6 hardening."""

import json
import os
import subprocess
import time
from typing import Optional, Dict, Any, List, Tuple

from .state import WorkerState, WorkerMetrics
from .display import VirtualDisplayManager
from .session import WorkerSession, WorkerSessionState, CompletionResult
from .buffer import WorkerPromptBuffer


class ChatGptWorker:
    """Controls ChatGPT on a secondary virtual display via native Accessibility actions.
    
    Hardening features (Phase 7.6):
    - Persistent WorkerSession across consecutive requests (1 chat thread).
    - Private WorkerPromptBuffer in Controller memory (0 clipboard in primary path).
    - ACTION_SET_TEXT keyboardless input via TunnelWorkerBridge.dex.
    - Semantic Send via ACTION_CLICK (0 hardcoded coordinates).
    - Display-scoped Accessibility tree isolation (0 Display #0 interference).
    - Scrcpy --display-ime-policy=hide (0 keyboard appearances on Display #0).
    """

    def __init__(
        self,
        serial: Optional[str] = None,
        package: str = "com.openai.chatgpt",
        display_manager: Optional[VirtualDisplayManager] = None,
        max_turns_per_worker: int = 20,
    ):
        self.serial = serial
        self.package = package
        self.display_manager = display_manager or VirtualDisplayManager(
            serial=serial, package=package, ime_policy="hide"
        )
        self.session = WorkerSession(
            provider="chatgpt",
            package=package,
            max_turns_per_worker=max_turns_per_worker
        )
        self.prompt_buffer = WorkerPromptBuffer()
        self.last_metrics = WorkerMetrics()
        self._bridge_dex = os.path.join(os.path.dirname(__file__), "worker_bridge.dex")
        self._clip_dex = os.path.join(os.path.dirname(__file__), "clipsetter.dex")
        self._last_assistant_text: str = ""

    @property
    def state(self) -> WorkerState:
        # Map WorkerSessionState to WorkerState for backward compatibility
        st = self.session.state.value
        try:
            return WorkerState(st)
        except ValueError:
            return WorkerState.READY

    @state.setter
    def state(self, value: WorkerState) -> None:
        try:
            self.session.state = WorkerSessionState(value.value)
        except ValueError:
            self.session.state = WorkerSessionState.READY

    @property
    def display_id(self) -> Optional[int]:
        return self.session.display_id

    def _adb(self, cmd_args: List[str]) -> subprocess.CompletedProcess:
        cmd = ["adb"]
        if self.serial:
            cmd.extend(["-s", self.serial])
        cmd.extend(cmd_args)
        return subprocess.run(cmd, capture_output=True, text=True, check=False)

    def _run_bridge(self, action: str, *args: str) -> Dict[str, Any]:
        """Execute a bridge command via app_process using worker_bridge.dex."""
        if self.session.display_id is None:
            return {"status": "error", "message": "display_not_active"}

        cmd_parts = [
            "shell",
            f"CLASSPATH=/system/framework/uiautomator.jar:/data/local/tmp/worker_bridge.dex "
            f"app_process /data/local/tmp com.tunnel.worker.TunnelWorkerBridge "
            f"{self.session.display_id} {action}"
        ]
        for a in args:
            escaped = a.replace('"', '\\"')
            cmd_parts[-1] += f' "{escaped}"'

        res = self._adb(cmd_parts)
        out = res.stdout.strip()
        try:
            return json.loads(out)
        except Exception as e:
            return {
                "status": "error",
                "message": f"bridge_output_parse_error: {e}",
                "raw": out
            }

    def start(self, timeout_s: float = 12.0) -> None:
        """Start or attach to virtual display and prepare ChatGPT."""
        self.session.state = WorkerSessionState.STARTING
        t0 = time.monotonic()
        disp_id = self.display_manager.start_display(timeout_s=timeout_s)
        self.session.display_id = disp_id

        # Push bridge dex to device
        if os.path.exists(self._bridge_dex):
            self._adb(["push", self._bridge_dex, "/data/local/tmp/worker_bridge.dex"])
        if os.path.exists(self._clip_dex):
            self._adb(["push", self._clip_dex, "/data/local/tmp/clipsetter.dex"])

        # Check top activity on secondary display
        deadline = time.monotonic() + timeout_s
        ready = False
        while time.monotonic() < deadline:
            acts = self.display_manager.get_display_activities()
            worker_act = acts.get("worker_display", {}).get("top_activity", "")
            if self.package in worker_act:
                ready = True
                break
            time.sleep(0.5)

        if not ready:
            self.session.state = WorkerSessionState.ERROR
            raise RuntimeError(f"ChatGPT failed to reach top resumed state on Display #{disp_id}")

        self.session.state = WorkerSessionState.READY
        self.session.record_event("worker_started", {"display_id": disp_id})
        self.session.conversation_created_count = 1
        self.last_metrics.worker_start_ms = (time.monotonic() - t0) * 1000

    def rotate_session_if_needed(self) -> bool:
        """Rotate conversation thread if max_turns_per_worker is reached."""
        if not self.session.needs_rotation():
            return False

        self.session.state = WorkerSessionState.ROTATING
        self.session.record_event("rotation_started", {"turns_used": self.session.turns_used})
        res = self._run_bridge("click_new_chat")
        if res.get("status") != "ok":
            # Fallback tap top right
            if self.session.display_id:
                self._adb(["shell", f"input -d {self.session.display_id} tap 863 90"])
        time.sleep(0.5)
        self.session.rotate_conversation()
        self.session.conversation_created_count += 1
        return True

    def new_chat(self) -> None:
        """Explicitly request a new chat thread."""
        res = self._run_bridge("click_new_chat")
        if res.get("status") != "ok" and self.session.display_id:
            self._adb(["shell", f"input -d {self.session.display_id} tap 863 90"])
        time.sleep(0.4)
        self.session.rotate_conversation()

    def _fallback_clipboard_paste(self, prompt: str) -> bool:
        """Isolated fallback using ClipSetter.dex and KEYCODE_PASTE."""
        self.last_metrics.clipboard_primary_route_uses += 1
        temp_file = "/tmp/tt_prompt_fallback.txt"
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(prompt)
        self._adb(["push", temp_file, "/data/local/tmp/prompt_fallback.txt"])
        res = self._adb([
            "shell",
            "CLASSPATH=/data/local/tmp/clipsetter.dex app_process /data/local/tmp com.tunnel.clip.ClipSetter --file /data/local/tmp/prompt_fallback.txt"
        ])
        if "CLIPBOARD_SET_OK" not in res.stdout:
            return False
        # Tap input field
        self._adb(["shell", f"input -d {self.session.display_id} tap 540 1674"])
        time.sleep(0.15)
        # Paste
        self._adb(["shell", f"input -d {self.session.display_id} keyevent 279"])
        time.sleep(0.15)
        return True

    def send_prompt(self, prompt: str, request_id: str) -> None:
        """Inject prompt via ACCESSIBILITY_SET_TEXT and trigger Send semantically."""
        # Check rotation before sending
        self.rotate_session_if_needed()

        self.session.state = WorkerSessionState.SENDING
        t0 = time.monotonic()

        # Store in private buffer
        self.prompt_buffer.set_prompt(request_id, prompt)
        full_text = f"request_id: {request_id}\n{prompt}"

        # 1. Primary input: atomic setTextAndSend via bridge
        res = self._run_bridge("set_text_and_send", full_text)
        if res.get("status") == "ok":
            self.last_metrics.input_backend_used = "ACCESSIBILITY_SET_TEXT"
            self.last_metrics.send_backend_used = "SEMANTIC_ACTION_CLICK"
            self.last_metrics.coordinate_fallback_used = False
        else:
            # Fallback to separate set_text or clipboard
            res_set = self._run_bridge("set_text", full_text)
            if res_set.get("status") == "ok":
                self.last_metrics.input_backend_used = "ACCESSIBILITY_SET_TEXT"
            else:
                ok = self._fallback_clipboard_paste(full_text)
                if not ok:
                    self.session.state = WorkerSessionState.ERROR
                    raise RuntimeError(f"Both ACCESSIBILITY_SET_TEXT and clipboard fallback failed: {res}")
                self.last_metrics.input_backend_used = "CLIPBOARD_PASTE_RESTORE"

            time.sleep(0.08)
            res_send = self._run_bridge("click_send")
            if res_send.get("status") == "ok":
                self.last_metrics.send_backend_used = "SEMANTIC_ACTION_CLICK"
                self.last_metrics.coordinate_fallback_used = False
            else:
                center = res_send.get("center")
                if center and len(center) == 2:
                    self._adb(["shell", f"input -d {self.session.display_id} tap {center[0]} {center[1]}"])
                    self.last_metrics.coordinate_fallback_used = True
                    self.last_metrics.send_backend_used = "COORDINATE_BOUNDS_CENTER"
                else:
                    self._adb(["shell", f"input -d {self.session.display_id} tap 980 1783"])
                    self.last_metrics.coordinate_fallback_used = True
                    self.last_metrics.send_backend_used = "COORDINATE_HARDCODED"

        self.last_metrics.prompt_injection_ms = (time.monotonic() - t0) * 1000
        self.session.state = WorkerSessionState.WAITING_RESPONSE

    def wait_for_response(self, request_id: str, timeout_s: float = 35.0) -> str:
        """Poll semantic UI tree until assistant response completes."""
        if self.session.state != WorkerSessionState.WAITING_RESPONSE:
            raise RuntimeError(f"Cannot wait for response in state {self.session.state}")

        t0 = time.monotonic()
        deadline = time.monotonic() + timeout_s
        dumps_count = 0
        last_extracted: Optional[str] = None
        stable_count = 0

        while time.monotonic() < deadline:
            time.sleep(0.6)
            dumps_count += 1

            res = self._run_bridge("inspect_state", request_id)
            if res.get("status") != "ok":
                continue

            complete = res.get("complete", False)
            is_generating = res.get("is_generating", False)
            candidate_text = res.get("last_text", "")

            if candidate_text:
                if complete and not is_generating:
                    if candidate_text == last_extracted:
                        stable_count += 1
                        if stable_count >= 1:
                            self.session.state = WorkerSessionState.RESPONSE_READY
                            self._last_assistant_text = candidate_text
                            self.last_metrics.ai_response_ms = (time.monotonic() - t0) * 1000
                            self.last_metrics.ui_dumps_used = dumps_count
                            self.prompt_buffer.clear()
                            return candidate_text
                    else:
                        last_extracted = candidate_text
                        stable_count = 0
                else:
                    last_extracted = candidate_text
                    stable_count = 0

        self.session.state = WorkerSessionState.ERROR
        self.prompt_buffer.clear()
        raise TimeoutError(f"AI response did not complete within {timeout_s}s (last text: {last_extracted!r})")

    def stop(self) -> None:
        """Stop worker and release display."""
        self.session.state = WorkerSessionState.STOPPED
        self.display_manager.stop_display()
        self.session.display_id = None
        self.prompt_buffer.clear()
