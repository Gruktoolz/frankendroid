"""Worker session management for persistent AI App Workers."""

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any


class WorkerSessionState(str, Enum):
    STOPPED = "STOPPED"
    STARTING = "STARTING"
    READY = "READY"
    SENDING = "SENDING"
    WAITING_RESPONSE = "WAITING_RESPONSE"
    RESPONSE_READY = "RESPONSE_READY"
    ERROR = "ERROR"
    ROTATING = "ROTATING"


@dataclass
class CompletionResult:
    complete: bool
    confidence: float
    signals: List[str]
    last_text: str = ""
    is_generating: bool = False
    candidate_count: int = 0
    elapsed_ms: float = 0.0


@dataclass
class WorkerSession:
    provider: str = "chatgpt"
    package: str = "com.openai.chatgpt"
    display_id: Optional[int] = None
    conversation_generation: int = 1
    request_counter: int = 0
    current_request_id: Optional[str] = None
    turns_used: int = 0
    state: WorkerSessionState = WorkerSessionState.STOPPED
    created_at: float = field(default_factory=time.time)
    last_request_at: float = field(default_factory=time.time)
    last_response_revision: int = 0
    conversation_created_count: int = 0
    max_turns_per_worker: int = 20

    # Event tracking
    events: List[Dict[str, Any]] = field(default_factory=list)

    def record_event(self, event_name: str, details: Optional[Dict[str, Any]] = None) -> None:
        self.events.append({
            "timestamp": time.time(),
            "event": event_name,
            "turns_used": self.turns_used,
            "conversation_generation": self.conversation_generation,
            "details": details or {}
        })

    def next_request_id(self) -> str:
        self.request_counter += 1
        self.current_request_id = f"TT_{self.request_counter:06d}"
        self.turns_used += 1
        self.last_request_at = time.time()
        return self.current_request_id

    def needs_rotation(self) -> bool:
        return self.turns_used >= self.max_turns_per_worker

    def rotate_conversation(self) -> None:
        self.conversation_generation += 1
        self.turns_used = 0
        self.state = WorkerSessionState.READY
        self.record_event("conversation_rotated", {
            "new_generation": self.conversation_generation
        })
