"""Private prompt buffer in Controller memory."""

import time
from typing import Optional, Dict, Any


class WorkerPromptBuffer:
    """Stores active prompts in Controller private memory.
    
    Guarantees:
    - Never written to Android global clipboard in primary route.
    - Not logged in plaintext in full logs by default.
    - Cleared immediately upon request completion or cancellation.
    """

    def __init__(self):
        self._request_id: Optional[str] = None
        self._prompt: Optional[str] = None
        self._created_at: float = 0.0

    def set_prompt(self, request_id: str, prompt: str) -> None:
        self._request_id = request_id
        self._prompt = prompt
        self._created_at = time.time()

    def get_prompt(self) -> Optional[str]:
        return self._prompt

    def get_request_id(self) -> Optional[str]:
        return self._request_id

    def clear(self) -> None:
        self._request_id = None
        self._prompt = None
        self._created_at = 0.0

    def get_metadata(self) -> Dict[str, Any]:
        return {
            "has_prompt": self._prompt is not None,
            "request_id": self._request_id,
            "length_chars": len(self._prompt) if self._prompt else 0,
            "created_at": self._created_at
        }
