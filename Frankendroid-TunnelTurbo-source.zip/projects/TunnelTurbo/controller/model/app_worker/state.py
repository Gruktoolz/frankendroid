"""State definitions for AI App Worker."""

from enum import Enum
from dataclasses import dataclass
from typing import Optional, Dict, Any


class WorkerState(str, Enum):
    STOPPED = "STOPPED"
    STARTING = "STARTING"
    READY = "READY"
    SENDING_PROMPT = "SENDING_PROMPT"
    WAITING_RESPONSE = "WAITING_RESPONSE"
    RESPONSE_READY = "RESPONSE_READY"
    ERROR = "ERROR"
    ROTATING = "ROTATING"


@dataclass
class WorkerMetrics:
    worker_start_ms: float = 0.0
    prompt_injection_ms: float = 0.0
    ai_response_ms: float = 0.0
    response_extraction_ms: float = 0.0
    validation_ms: float = 0.0
    core_ms: float = 0.0
    total_ms: float = 0.0
    screenshots_used: int = 0
    ui_dumps_used: int = 0
    # Phase 7.6 metrics
    input_backend_used: str = "ACCESSIBILITY_SET_TEXT"
    send_backend_used: str = "SEMANTIC_ACTION_CLICK"
    coordinate_fallback_used: bool = False
    wrong_request_associations: int = 0
    keyboard_display_0_appearances: int = 0
    clipboard_primary_route_uses: int = 0
