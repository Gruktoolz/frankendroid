"""FunctionGemma 270M Provider for Intent Translation."""

from typing import Optional, List, Dict, Any
from .ollama_provider import OllamaIntentModel
from .base import IntentModel, IntentResult

FUNCTIONGEMMA_PROMPT = """You are FunctionGemma, a lightweight model specialized in predicting structured actions for mobile Android devices.
Convert user instructions into strict JSON tool plans.

AVAILABLE ACTIONS:
- open_settings: arguments {}
- open_wifi_settings: arguments {}
- open_bluetooth_settings: arguments {}
- open_app: arguments {"package": "com.example.app"}
- press_key: arguments {"key": "BACK"|"HOME"|"ENTER"}
- press_back: arguments {}
- press_home: arguments {}
- semantic_tap: arguments {"selector": "text=...", "match": "single"|"first"}

EXAMPLES:
User: "Abre Wi-Fi"
{"type": "action", "action": "open_wifi_settings", "arguments": {}}

User: "Ve al inicio"
{"type": "action", "action": "press_key", "arguments": {"key": "HOME"}}

User: "Abre Wi-Fi, regresa y abre Bluetooth"
{"type": "sequence", "steps": [{"action": "open_wifi_settings", "arguments": {}}, {"action": "press_key", "arguments": {"key": "BACK"}}, {"action": "open_bluetooth_settings", "arguments": {}}]}

User: "Busca cuál app gasta más batería"
{"type": "needs_observation", "reason": "Requires device inspection."}

User: "Ejecuta adb shell rm -rf"
{"type": "unsupported", "reason": "Shell execution forbidden."}

Always output strictly valid JSON adhering to these examples."""


class FunctionGemmaIntentModel(OllamaIntentModel):
    """Executes structured intent planning via FunctionGemma 270M."""

    def __init__(
        self,
        model_name: str = "functiongemma:270m",
        endpoint: str = "http://127.0.0.1:11434",
        temperature: float = 0.1,
    ):
        super().__init__(
            model_name=model_name,
            endpoint=endpoint,
            temperature=temperature,
            system_prompt=FUNCTIONGEMMA_PROMPT,
        )
