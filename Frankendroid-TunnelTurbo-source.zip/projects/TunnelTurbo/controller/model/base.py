"""Base Interface for Intent Translation Models."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Any, Optional, List
import time

from .schemas import StructuredPlan


@dataclass
class IntentResult:
    """Outcome of model planning and local deterministic validation."""
    success: bool
    plan: Optional[StructuredPlan]
    raw_response: str
    error: Optional[str] = None
    validation_error_code: Optional[str] = None
    model_ms: float = 0.0
    validation_ms: float = 0.0
    total_ms: float = 0.0
    prompt_tokens: int = 0
    output_tokens: int = 0
    model_name: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "plan": self.plan.to_dict() if self.plan else None,
            "raw_response": self.raw_response,
            "error": self.error,
            "validation_error_code": self.validation_error_code,
            "metrics": {
                "model_ms": round(self.model_ms, 2),
                "validation_ms": round(self.validation_ms, 3),
                "total_ms": round(self.total_ms, 2),
                "prompt_tokens": self.prompt_tokens,
                "output_tokens": self.output_tokens,
            },
            "model_name": self.model_name,
        }


class IntentModel(ABC):
    """Abstract base class for all local and remote intent translator models."""

    @abstractmethod
    async def plan(
        self,
        user_text: str,
        available_actions: Optional[List[str]] = None,
        state_summary: Optional[Dict[str, Any]] = None,
    ) -> IntentResult:
        """Translate user natural language text into a validated StructuredPlan."""
        pass
