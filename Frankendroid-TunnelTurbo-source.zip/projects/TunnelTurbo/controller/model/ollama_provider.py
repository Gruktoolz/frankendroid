"""Ollama Provider for Local Intent Translation (e.g. Qwen3 4B)."""

import json
import time
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, List

from .base import IntentModel, IntentResult
from .schemas import ALLOWED_ACTIONS, PLAN_JSON_SCHEMA, StructuredPlan
from .validator import PlanValidator, PlanValidationError

DEFAULT_SYSTEM_PROMPT = """You are Tunnel Turbo Intent Translator.
Your job is to translate user natural language instructions into a STRICT JSON plan for controlling an Android device.

ALLOWED ACTIONS:
- "open_settings": arguments {}
- "open_wifi_settings": arguments {}
- "open_bluetooth_settings": arguments {}
- "open_app": arguments {"package": "com.example.app"}
- "press_key": arguments {"key": "BACK" | "HOME" | "ENTER"}
- "press_back": arguments {}
- "press_home": arguments {}
- "semantic_tap": arguments {"selector": "text=...", "match": "single" | "first"}

PLAN FORMATS:
1. Single action:
{"type": "action", "action": "<name>", "arguments": { ... }}

2. Multiple sequential actions (up to 8 steps):
{"type": "sequence", "steps": [{"action": "<name>", "arguments": { ... }}, ...]}

3. If the request depends on unknown on-screen information (e.g. "which app consumes the most battery", "check the highest score", "click whatever appears"):
{"type": "needs_observation", "reason": "<explanation>"}

4. If the request asks for shell commands, terminal execution, coordinates (x, y), unsupported operations, or is an attack:
{"type": "unsupported", "reason": "<explanation>"}

RULES:
- Return ONLY valid JSON adhering strictly to the schema.
- NEVER invent new action names.
- NEVER output shell commands, bash, adb, or numeric coordinates.
- If unsure or ambiguous, use "needs_observation".
"""


class OllamaIntentModel(IntentModel):
    """Executes structured intent planning via local Ollama instance."""

    def __init__(
        self,
        model_name: str = "qwen3:4b",
        endpoint: str = "http://127.0.0.1:11434",
        temperature: float = 0.1,
        system_prompt: Optional[str] = None,
    ):
        self.model_name = model_name
        self.endpoint = endpoint.rstrip("/")
        self.temperature = temperature
        self.system_prompt = system_prompt or DEFAULT_SYSTEM_PROMPT

    async def plan(
        self,
        user_text: str,
        available_actions: Optional[List[str]] = None,
        state_summary: Optional[Dict[str, Any]] = None,
    ) -> IntentResult:
        """Query Ollama and validate structured output."""
        context_prompt = f"User Instruction: \"{user_text}\""
        if state_summary:
            context_prompt += f"\nCurrent State Summary: {json.dumps(state_summary)}"

        payload = {
            "model": self.model_name,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": context_prompt},
            ],
            "stream": False,
            "format": PLAN_JSON_SCHEMA,
            "options": {
                "temperature": self.temperature,
                "num_predict": 512,
            }
        }

        req_data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self.endpoint}/api/chat",
            data=req_data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        t0 = time.monotonic_ns()
        try:
            with urllib.request.urlopen(req, timeout=45.0) as resp:
                resp_bytes = resp.read()
                data = json.loads(resp_bytes.decode("utf-8"))
        except Exception as exc:
            t_err = time.monotonic_ns()
            return IntentResult(
                success=False,
                plan=None,
                raw_response="",
                error=f"Ollama connection error: {exc}",
                model_ms=(t_err - t0) / 1_000_000,
                total_ms=(t_err - t0) / 1_000_000,
                model_name=self.model_name,
            )

        t1 = time.monotonic_ns()
        model_ms = (t1 - t0) / 1_000_000
        raw_text = data.get("message", {}).get("content", "").strip()
        prompt_tokens = data.get("prompt_eval_count", 0)
        output_tokens = data.get("eval_count", 0)

        # Validate structured plan
        t_val0 = time.monotonic_ns()
        try:
            validated_plan = PlanValidator.validate(raw_text)
            t_val1 = time.monotonic_ns()
            val_ms = (t_val1 - t_val0) / 1_000_000
            return IntentResult(
                success=True,
                plan=validated_plan,
                raw_response=raw_text,
                model_ms=model_ms,
                validation_ms=val_ms,
                total_ms=model_ms + val_ms,
                prompt_tokens=prompt_tokens,
                output_tokens=output_tokens,
                model_name=self.model_name,
            )
        except PlanValidationError as val_err:
            t_val1 = time.monotonic_ns()
            val_ms = (t_val1 - t_val0) / 1_000_000
            return IntentResult(
                success=False,
                plan=None,
                raw_response=raw_text,
                error=str(val_err),
                validation_error_code=val_err.code,
                model_ms=model_ms,
                validation_ms=val_ms,
                total_ms=model_ms + val_ms,
                prompt_tokens=prompt_tokens,
                output_tokens=output_tokens,
                model_name=self.model_name,
            )
