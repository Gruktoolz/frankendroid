"""Event Journal — In-memory ring buffer recording state transitions and action lifecycle."""

import time
from collections import deque
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class JournalEvent:
    revision: int
    timestamp_ns: int
    type: str
    before: Any = None
    after: Any = None
    source: str = "persistent_observer"
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "revision": self.revision,
            "timestamp_ns": self.timestamp_ns,
            "type": self.type,
            "before": self.before,
            "after": self.after,
            "source": self.source,
            "details": self.details,
        }


class EventJournal:
    """Bounded, thread-safe in-memory event journal for state changes and actions."""

    def __init__(self, capacity: int = 1000):
        self.capacity = capacity
        self._buffer: deque[JournalEvent] = deque(maxlen=capacity)
        self._total_recorded: int = 0

    def record(
        self,
        event_type: str,
        revision: int,
        before: Any = None,
        after: Any = None,
        source: str = "persistent_observer",
        details: Optional[Dict[str, Any]] = None,
    ) -> JournalEvent:
        """Create and append an event to the ring buffer."""
        ev = JournalEvent(
            revision=revision,
            timestamp_ns=time.monotonic_ns(),
            type=event_type,
            before=before,
            after=after,
            source=source,
            details=details or {},
        )
        self._buffer.append(ev)
        self._total_recorded += 1
        return ev

    def get_events(self, since_revision: int = 0) -> List[JournalEvent]:
        """Return all events recorded with revision > since_revision."""
        return [ev for ev in self._buffer if ev.revision > since_revision]

    def get_changes_dicts(self, since_revision: int = 0) -> List[Dict[str, Any]]:
        """Return JSON-serializable event dictionaries recorded since given revision."""
        return [ev.to_dict() for ev in self._buffer if ev.revision > since_revision]

    def query_changes(
        self,
        since_revision: int = 0,
        limit: int = 100,
    ) -> Dict[str, Any]:
        """Query events recorded after since_revision with explicit limit and pagination metadata.

        Guarantees zero silent truncation by reporting events_available, events_returned,
        and remaining count alongside pagination cursors.
        """
        matching = [ev for ev in self._buffer if ev.revision > since_revision]
        total_available = len(matching)

        returned_events = matching[:limit] if limit > 0 else matching
        returned_count = len(returned_events)
        remaining = total_available - returned_count
        truncated = remaining > 0

        oldest_rev = matching[0].revision if matching else since_revision
        newest_rev = returned_events[-1].revision if returned_events else since_revision
        next_rev = returned_events[-1].revision if truncated else None

        return {
            "events_available": total_available,
            "events_returned": returned_count,
            "returned": returned_count,
            "remaining": remaining,
            "truncated": truncated,
            "oldest_revision": oldest_rev,
            "newest_revision": newest_rev,
            "next_revision": next_rev,
            "events": [ev.to_dict() for ev in returned_events],
        }

    def latest_event(self) -> Optional[JournalEvent]:
        """Return the most recent recorded event, if any."""
        return self._buffer[-1] if self._buffer else None

    def __len__(self) -> int:
        return len(self._buffer)

    @property
    def total_recorded(self) -> int:
        return self._total_recorded

    def clear(self) -> None:
        """Clear all events in the journal."""
        self._buffer.clear()
        self._total_recorded = 0
