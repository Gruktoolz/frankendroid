"""State Engine for managing Static, Fast, and UI states with monotonic revisions and caching."""

import asyncio
import re
import time
from typing import Optional, Dict, Any, List

from ..adb.client import AdbClient
from ..android_cli.client import AndroidCliClient
from .models import DeviceState, StaticDeviceState, FastDeviceState, UiState, UiNode
from .diff import DiffEngine, StateDiff
from .events import EventJournal, JournalEvent


class StateEngine:
    """Core state engine maintaining in-memory state, revisions, event journal, and caching."""

    def __init__(
        self,
        serial: str,
        adb_client: Optional[AdbClient] = None,
        cli_client: Optional[AndroidCliClient] = None,
        event_journal: Optional[EventJournal] = None,
    ):
        self.serial = serial
        self.adb = adb_client or AdbClient()
        self.cli = cli_client or AndroidCliClient()
        self.journal = event_journal or EventJournal()

        self._lock = asyncio.Lock()
        self._current_state: Optional[DeviceState] = None
        self._static: Optional[StaticDeviceState] = None
        self._history: Dict[int, DeviceState] = {}
        self._ui_invocations: int = 0
        self._fast_invocations: int = 0

    @property
    def ui_invocations(self) -> int:
        return self._ui_invocations

    @property
    def fast_invocations(self) -> int:
        return self._fast_invocations

    async def initialize(self) -> DeviceState:
        """Fetch static device properties once and build initial state."""
        async with self._lock:
            # 1. Static state (cached permanently for this device connection)
            props = await self.adb.get_device_props(self.serial)
            dims = await self.adb.get_display_size(self.serial)

            self._static = StaticDeviceState(
                serial=self.serial,
                manufacturer=props.manufacturer,
                model=props.model,
                android_version=props.android_version,
                api_level=props.api_level,
                display_width=dims.get("width", 0),
                display_height=dims.get("height", 0),
            )

            # 2. Fast state
            fast = await self._fetch_fast_state_unlocked()

            # 3. Initial UI state (stale by default until requested)
            ui = UiState(
                revision=0,
                captured_at=time.monotonic_ns(),
                stale=True,
                source="none",
                windows_count=0,
                nodes_count=0,
                nodes=[],
                raw_data=[],
            )

            self._current_state = DeviceState(
                revision=1,
                updated_at=time.monotonic_ns(),
                static=self._static,
                fast=fast,
                ui=ui,
            )
            self._history[1] = self._current_state
            self.journal.record(
                "device_connected",
                1,
                after=self.serial,
                source="state_engine",
                details={"manufacturer": self._static.manufacturer, "model": self._static.model},
            )
            return self._current_state

    async def _fetch_fast_state_unlocked(self, check_display: bool = False) -> FastDeviceState:
        """Fetch fast signals directly via ADB. Foreground is primary; display signals are occasional."""
        self._fast_invocations += 1
        fg = await self.adb.get_foreground_app(self.serial)
        t_capture = time.monotonic_ns()

        orientation = self._current_state.fast.orientation if self._current_state else 0
        screen_state = self._current_state.fast.screen_state if self._current_state else "Awake"

        if check_display:
            try:
                res = await self.adb.execute_raw(
                    ["shell", "dumpsys display | grep 'mCurrentOrientation='; dumpsys power | grep 'mWakefulness='"],
                    serial=self.serial,
                    timeout_s=3.0,
                )
                if res.ok:
                    m_ori = re.search(r"mCurrentOrientation=(\d+)", res.stdout)
                    if m_ori:
                        orientation = int(m_ori.group(1))
                    m_wake = re.search(r"mWakefulness=(\w+)", res.stdout)
                    if m_wake:
                        screen_state = m_wake.group(1)
                self._last_display_check_s = time.monotonic()
            except Exception:
                pass

        return FastDeviceState(
            connected=True,
            package=fg.package,
            activity=fg.activity,
            orientation=orientation,
            screen_state=screen_state,
            captured_at=t_capture,
        )

    async def refresh_fast_state(self, include_display: bool = False) -> FastDeviceState:
        """Check for fast signals. If foreground changed, increment revision & mark UI stale."""
        async with self._lock:
            if not self._current_state:
                raise RuntimeError("StateEngine not initialized. Call initialize() first.")

            now = time.monotonic()
            do_display = include_display or (now - getattr(self, "_last_display_check_s", 0.0) > 60.0)
            new_fast = await self._fetch_fast_state_unlocked(check_display=do_display)
            prev_fast = self._current_state.fast

            # Detect meaningful changes
            changed = (
                new_fast.connected != prev_fast.connected
                or new_fast.package != prev_fast.package
                or new_fast.activity != prev_fast.activity
                or new_fast.orientation != prev_fast.orientation
            )

            if changed:
                new_revision = self._current_state.revision + 1
                # Record specific events into Event Journal
                if new_fast.connected != prev_fast.connected:
                    ev_type = "device_connected" if new_fast.connected else "device_disconnected"
                    self.journal.record(ev_type, new_revision, before=prev_fast.connected, after=new_fast.connected)

                if new_fast.package != prev_fast.package:
                    self.journal.record("package_changed", new_revision, before=prev_fast.package, after=new_fast.package)

                if new_fast.activity != prev_fast.activity:
                    self.journal.record("activity_changed", new_revision, before=prev_fast.activity, after=new_fast.activity)

                if new_fast.orientation != prev_fast.orientation:
                    self.journal.record("orientation_changed", new_revision, before=prev_fast.orientation, after=new_fast.orientation)

                self.journal.record("ui_invalidated", new_revision, details={"reason": "foreground_changed"})

                # Mark UI stale because foreground app/activity changed!
                new_ui = UiState(
                    revision=self._current_state.ui.revision,
                    captured_at=self._current_state.ui.captured_at,
                    stale=True,
                    source=self._current_state.ui.source,
                    windows_count=self._current_state.ui.windows_count,
                    nodes_count=self._current_state.ui.nodes_count,
                    nodes=self._current_state.ui.nodes,
                    raw_data=self._current_state.ui.raw_data,
                )
                self._current_state = DeviceState(
                    revision=new_revision,
                    updated_at=time.monotonic_ns(),
                    static=self._static,
                    fast=new_fast,
                    ui=new_ui,
                )
                self._history[new_revision] = self._current_state

            return self._current_state.fast

    async def refresh_ui_state(self, full: bool = False) -> UiState:
        """Capture fresh UI layout via Android CLI, update nodes, and mark stale=False."""
        async with self._lock:
            if not self._current_state:
                raise RuntimeError("StateEngine not initialized.")

            self._ui_invocations += 1
            layout_res = await self.cli.get_layout(
                serial=self.serial,
                flat=True,
                no_idle=True,
                full=full,
            )

            if not layout_res.ok:
                raise RuntimeError(f"Failed to fetch UI layout: {layout_res.error}")

            parsed_nodes: List[UiNode] = []
            for w_idx, win in enumerate(layout_res.raw_data):
                content = win.get("content", [])
                for n_idx, raw_node in enumerate(content):
                    if isinstance(raw_node, dict):
                        parsed_nodes.append(UiNode.from_dict(raw_node, w_idx, n_idx))

            new_ui_rev = self._current_state.ui.revision + 1
            new_ui = UiState(
                revision=new_ui_rev,
                captured_at=time.monotonic_ns(),
                stale=False,
                source="android_cli",
                windows_count=layout_res.windows_count,
                nodes_count=len(parsed_nodes),
                nodes=parsed_nodes,
                raw_data=layout_res.raw_data,
            )

            new_revision = self._current_state.revision + 1
            self._current_state = DeviceState(
                revision=new_revision,
                updated_at=time.monotonic_ns(),
                static=self._static,
                fast=self._current_state.fast,
                ui=new_ui,
            )
            self._history[new_revision] = self._current_state
            return self._current_state.ui

    async def get_state(self, mode: str = "fast") -> DeviceState:
        """Retrieve state in one of three modes: 'fast', 'ui', or 'fresh_ui'."""
        if not self._current_state:
            await self.initialize()

        mode = mode.lower()
        if mode == "fast":
            # Return current state without querying UI layout
            return self._current_state

        elif mode == "ui":
            # Re-use cached UI if valid and populated; otherwise fetch fresh UI
            if self._current_state.ui.stale or not self._current_state.ui.nodes:
                await self.refresh_ui_state()
            return self._current_state

        elif mode == "fresh_ui":
            # Explicitly force a fresh layout acquisition
            await self.refresh_ui_state()
            return self._current_state

        else:
            raise ValueError(f"Unknown mode '{mode}'. Use 'fast', 'ui', or 'fresh_ui'.")

    def invalidate_ui(self, reason: str = "manual_invalidation", dirty_only: bool = False):
        """Invalidate UI cache: stale (full invalidation) or dirty (content might have changed)."""
        if self._current_state:
            if dirty_only:
                self._current_state.ui.dirty = True
            else:
                self._current_state.ui.stale = True
                self._current_state.ui.dirty = False
            self.journal.record(
                "ui_invalidated",
                self._current_state.revision,
                source="state_engine",
                details={"reason": reason, "dirty_only": dirty_only},
            )

    def get_changes(self, since_revision: int, limit: int = 100) -> Dict[str, Any]:
        """Query Event Journal changes since given revision with pagination, plus structural diff."""
        if not self._current_state:
            raise RuntimeError("StateEngine not initialized.")

        query_res = self.journal.query_changes(since_revision=since_revision, limit=limit)
        prev_state = self._history.get(since_revision)
        diff = DiffEngine.compute(prev_state, self._current_state) if prev_state else None

        return {
            "since_revision": since_revision,
            "current_revision": self._current_state.revision,
            "events_available": query_res["events_available"],
            "events_returned": query_res["events_returned"],
            "returned": query_res["returned"],
            "remaining": query_res["remaining"],
            "truncated": query_res["truncated"],
            "oldest_revision": query_res["oldest_revision"],
            "newest_revision": query_res["newest_revision"],
            "next_revision": query_res["next_revision"],
            "events": query_res["events"],
            "diff": diff.to_dict() if diff else {},
        }
