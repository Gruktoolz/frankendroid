"""Diff engine for detecting fast state and UI node changes across revisions."""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .models import DeviceState, UiNode


@dataclass(frozen=True)
class StateChange:
    type: str
    target: str
    from_val: Any
    to_val: Any

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "target": self.target,
            "from": self.from_val,
            "to": self.to_val,
        }


@dataclass
class StateDiff:
    before_revision: int
    after_revision: int
    changes: List[StateChange]

    @property
    def has_changes(self) -> bool:
        return len(self.changes) > 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "before_revision": self.before_revision,
            "after_revision": self.after_revision,
            "changes_count": len(self.changes),
            "changes": [c.to_dict() for c in self.changes],
        }


class DiffEngine:
    """Computes minimal structural diffs between DeviceStates."""

    @staticmethod
    def diff_fast(prev: DeviceState, curr: DeviceState) -> List[StateChange]:
        changes: List[StateChange] = []

        if prev.fast.connected != curr.fast.connected:
            changes.append(
                StateChange(
                    type="device_connected" if curr.fast.connected else "device_disconnected",
                    target="device",
                    from_val=prev.fast.connected,
                    to_val=curr.fast.connected,
                )
            )

        if prev.fast.package != curr.fast.package:
            changes.append(
                StateChange(
                    type="package_changed",
                    target="foreground.package",
                    from_val=prev.fast.package,
                    to_val=curr.fast.package,
                )
            )

        if prev.fast.activity != curr.fast.activity:
            changes.append(
                StateChange(
                    type="activity_changed",
                    target="foreground.activity",
                    from_val=prev.fast.activity,
                    to_val=curr.fast.activity,
                )
            )

        if prev.fast.orientation != curr.fast.orientation:
            changes.append(
                StateChange(
                    type="orientation_changed",
                    target="display.orientation",
                    from_val=prev.fast.orientation,
                    to_val=curr.fast.orientation,
                )
            )

        if prev.fast.screen_state != curr.fast.screen_state:
            changes.append(
                StateChange(
                    type="screen_state_changed",
                    target="display.power",
                    from_val=prev.fast.screen_state,
                    to_val=curr.fast.screen_state,
                )
            )

        return changes

    @staticmethod
    def diff_ui(prev_nodes: List[UiNode], curr_nodes: List[UiNode]) -> List[StateChange]:
        changes: List[StateChange] = []
        prev_map = {n.key: n for n in prev_nodes}
        curr_map = {n.key: n for n in curr_nodes}

        # Check removed nodes
        for key, p_node in prev_map.items():
            if key not in curr_map:
                changes.append(
                    StateChange(
                        type="node_removed",
                        target=key,
                        from_val=p_node.text or p_node.resource_id or p_node.class_name,
                        to_val=None,
                    )
                )

        # Check added and modified nodes
        for key, c_node in curr_map.items():
            if key not in prev_map:
                changes.append(
                    StateChange(
                        type="node_added",
                        target=key,
                        from_val=None,
                        to_val=c_node.text or c_node.resource_id or c_node.class_name,
                    )
                )
            else:
                p_node = prev_map[key]
                if p_node.text != c_node.text:
                    changes.append(
                        StateChange(
                            type="text_changed",
                            target=key,
                            from_val=p_node.text,
                            to_val=c_node.text,
                        )
                    )
                if p_node.bounds != c_node.bounds:
                    changes.append(
                        StateChange(
                            type="bounds_changed",
                            target=key,
                            from_val=p_node.bounds,
                            to_val=c_node.bounds,
                        )
                    )

                # Interactions / State changes
                p_state_set = set(p_node.state)
                c_state_set = set(c_node.state)

                for flag in ("CHECKED", "FOCUSED", "SELECTED"):
                    p_has = flag in p_state_set
                    c_has = flag in c_state_set
                    if p_has != c_has:
                        changes.append(
                            StateChange(
                                type=f"{flag.lower()}_changed",
                                target=key,
                                from_val=p_has,
                                to_val=c_has,
                            )
                        )

        return changes

    @classmethod
    def compute(cls, prev: Optional[DeviceState], curr: DeviceState) -> StateDiff:
        if prev is None:
            return StateDiff(
                before_revision=0,
                after_revision=curr.revision,
                changes=[
                    StateChange(
                        type="initial_state",
                        target="device",
                        from_val=None,
                        to_val=curr.fast.package,
                    )
                ],
            )

        changes = cls.diff_fast(prev, curr)

        # Only diff UI if both states have UI nodes populated
        if prev.ui.revision != curr.ui.revision and curr.ui.nodes:
            ui_changes = cls.diff_ui(prev.ui.nodes, curr.ui.nodes)
            changes.extend(ui_changes)

        return StateDiff(
            before_revision=prev.revision,
            after_revision=curr.revision,
            changes=changes,
        )
