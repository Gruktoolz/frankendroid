"""State models for Tunnel Turbo Controller: Static, Fast, and UI state."""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
import time


@dataclass(frozen=True)
class StaticDeviceState:
    serial: str
    manufacturer: str
    model: str
    android_version: str
    api_level: int
    display_width: int
    display_height: int


@dataclass(frozen=True)
class FastDeviceState:
    connected: bool = True
    package: Optional[str] = None
    activity: Optional[str] = None
    orientation: int = 0
    screen_state: str = "Awake"
    captured_at: float = 0.0
    display_id: int = 0
    role: str = "PRIMARY_DISPLAY"


@dataclass(frozen=True)
class UiNode:
    key: str
    resource_id: Optional[str] = None
    class_name: Optional[str] = None
    text: Optional[str] = None
    content_desc: Optional[str] = None
    bounds: Optional[str] = None
    center: Optional[str] = None
    interactions: List[str] = field(default_factory=list)
    state: List[str] = field(default_factory=list)
    hidden: bool = False
    off_screen: bool = False

    @classmethod
    def from_dict(cls, data: Dict[str, Any], window_idx: int, node_idx: int) -> "UiNode":
        res_id = data.get("resource-id")
        desc = data.get("content-desc")
        clz = data.get("class")
        text = data.get("text")
        bounds = data.get("bounds")
        center = data.get("center")
        interactions = list(data.get("interactions", []))
        state = list(data.get("state", []))
        hidden = bool(data.get("hidden", False))
        off_screen = bool(data.get("off-screen", False))

        # Generate a stable key for matching:
        # Priority: resource_id -> desc -> class+text -> text -> bounds -> window/idx
        if res_id:
            key = f"res:{res_id}"
        elif desc:
            key = f"desc:{desc}"
        elif clz and text:
            key = f"clz_text:{clz}|{text}"
        elif text:
            key = f"text:{text}"
        elif bounds:
            key = f"bounds:{bounds}"
        else:
            key = f"idx:{window_idx}:{node_idx}"

        return cls(
            key=key,
            resource_id=res_id,
            class_name=clz,
            text=text,
            content_desc=desc,
            bounds=bounds,
            center=center,
            interactions=interactions,
            state=state,
            hidden=hidden,
            off_screen=off_screen,
        )

    def get_coordinates(self, display_width: int, display_height: int) -> Optional[tuple[int, int]]:
        """Extract (x, y) coordinates from center or bounds, validating against display."""
        import re

        # 1. Try parsing center: e.g. "[128,63]"
        if self.center:
            match = re.search(r"\[(\d+),\s*(\d+)\]", self.center)
            if match:
                x, y = int(match.group(1)), int(match.group(2))
                if 0 <= x < display_width and 0 <= y < display_height:
                    return (x, y)

        # 2. Fallback to bounds: e.g. "[83,16][173,110]"
        if self.bounds:
            matches = re.findall(r"\[(\d+),\s*(\d+)\]", self.bounds)
            if len(matches) >= 2:
                x1, y1 = int(matches[0][0]), int(matches[0][1])
                x2, y2 = int(matches[1][0]), int(matches[1][1])
                x = (x1 + x2) // 2
                y = (y1 + y2) // 2
                if 0 <= x < display_width and 0 <= y < display_height:
                    return (x, y)

        return None


@dataclass
class UiState:
    revision: int = 0
    captured_at: float = 0.0
    stale: bool = True
    dirty: bool = False
    source: str = "none"
    display_id: int = 0
    role: str = "PRIMARY_DISPLAY"
    windows_count: int = 0
    nodes_count: int = 0
    nodes: List[UiNode] = field(default_factory=list)
    raw_data: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class DeviceState:
    revision: int
    updated_at: float
    static: StaticDeviceState
    fast: FastDeviceState
    ui: UiState
    display_id: int = 0
    role: str = "PRIMARY_DISPLAY"

    def to_dict(self, include_ui: bool = False) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "revision": self.revision,
            "updated_at": self.updated_at,
            "display_id": self.display_id,
            "role": self.role,
            "static": {
                "serial": self.static.serial,
                "manufacturer": self.static.manufacturer,
                "model": self.static.model,
                "android_version": self.static.android_version,
                "api_level": self.static.api_level,
                "display": f"{self.static.display_width}x{self.static.display_height}",
            },
            "fast": {
                "connected": self.fast.connected,
                "package": self.fast.package,
                "activity": self.fast.activity,
                "orientation": self.fast.orientation,
                "screen_state": self.fast.screen_state,
            },
            "ui": {
                "revision": self.ui.revision,
                "captured_at": self.ui.captured_at,
                "stale": self.ui.stale,
                "source": self.ui.source,
                "windows_count": self.ui.windows_count,
                "nodes_count": self.ui.nodes_count,
            },
        }
        if include_ui:
            data["ui"]["nodes"] = [
                {
                    "key": n.key,
                    "resource_id": n.resource_id,
                    "class": n.class_name,
                    "text": n.text,
                    "desc": n.content_desc,
                    "bounds": n.bounds,
                    "center": n.center,
                    "interactions": n.interactions,
                    "state": n.state,
                }
                for n in self.ui.nodes
            ]
        return data
