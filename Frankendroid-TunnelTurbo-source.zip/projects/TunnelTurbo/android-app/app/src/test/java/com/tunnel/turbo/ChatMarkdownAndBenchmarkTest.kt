package com.tunnel.turbo

import com.tunnel.turbo.chat.ChatMarkdown
import com.tunnel.turbo.chat.LocalBenchmarkSample
import com.tunnel.turbo.chat.LocalBenchmarkStatistics
import com.tunnel.turbo.chat.LocalModelCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ChatMarkdownAndBenchmarkTest {
    @Test fun markdownEscapesHtmlAndConvertsCommonFormatting() {
        val html = ChatMarkdown.toHtml("**Hola**\n- elemento\n`código`\n<script>")
        assertTrue(html.contains("<b>Hola</b>"))
        assertTrue(html.contains("<li>elemento</li>"))
        assertTrue(html.contains("<tt>código</tt>"))
        assertTrue(html.contains("&lt;script&gt;"))
        assertTrue(!html.contains("<script>"))
    }

    @Test fun benchmarkSummaryUsesMedianAndExcludesFailedRuns() {
        fun row(ms: Long, ok: Boolean = true) = LocalBenchmarkSample("m", "CPU", ms, 10, null, null, 100, 20, null, null, null, ok)
        val summary = LocalBenchmarkStatistics.summarize(listOf(row(100), row(300), row(200), row(1, false))).single()
        assertEquals(3, summary.successfulRuns)
        assertEquals(4, summary.totalRuns)
        assertEquals(200L, summary.medianTotalMs)
    }

    @Test fun modelDiscoveryIgnoresRuntimeCachesAndOnlyAcceptsLitertlmFiles() {
        val directory = java.nio.file.Files.createTempDirectory("model-catalog-test").toFile()
        val model = File(directory, "Qwen.litertlm").apply { writeText("x") }
        val cache = File(directory, "Qwen.litertlm_123.xnnpack_cache").apply { writeText("x") }
        val other = File(directory, "model.bin").apply { writeText("x") }
        assertTrue(LocalModelCatalog.isModelArtifact(model))
        assertTrue(!LocalModelCatalog.isModelArtifact(cache))
        assertTrue(!LocalModelCatalog.isModelArtifact(other))
        directory.deleteRecursively()
    }
}
