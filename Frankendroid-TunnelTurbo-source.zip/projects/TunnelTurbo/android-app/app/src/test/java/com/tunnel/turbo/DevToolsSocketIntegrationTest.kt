package com.tunnel.turbo

import com.tunnel.turbo.devtools.TunnelDevToolsBridge
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Real Socket Integration Tests for TunnelDevToolsBridge (Phase 13B-1.2a.4, Sections 10-13)
 *
 * Exercises real loopback TCP sockets:
 * 1. Real socket request / auth / dispatch / response lifecycle
 * 2. Socket read deadline (SO_TIMEOUT) on slow/hanging clients
 * 3. Truncated body rejection (Content-Length mismatch)
 * 4. Malformed / negative Content-Length rejection
 * 5. Bounded concurrent client capacity (Semaphore)
 */
class DevToolsSocketIntegrationTest {

    private fun findAvailablePort(): Int {
        val ss = java.net.ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val port = ss.localPort
        ss.close()
        return port
    }

    @Test
    fun realSocketBasicRequestAndAuth() {
        val port = findAvailablePort()
        val bridge = TunnelDevToolsBridge(port = port, isDebug = true)
        assertTrue("Bridge must start successfully", bridge.start())

        try {
            // Case 1: Connect via raw Socket and request public diagnostic "/"
            val socket = Socket("127.0.0.1", port)
            socket.soTimeout = 3000
            val out = socket.getOutputStream()
            val request = "GET / HTTP/1.1\r\nHost: 127.0.0.1:$port\r\nConnection: close\r\n\r\n"
            out.write(request.toByteArray(Charsets.UTF_8))
            out.flush()

            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val statusLine = reader.readLine()
            assertNotNull("Status line must not be null", statusLine)
            assertTrue("Expected 200 OK for public / but got '$statusLine'", statusLine.contains("200 OK"))

            socket.close()
        } finally {
            bridge.stop()
        }
    }

    @Test
    fun slowHeaderClientIsClosedWithinConfiguredDeadline() {
        val port = findAvailablePort()
        val bridge = TunnelDevToolsBridge(port = port, isDebug = true)
        assertTrue("Bridge must start successfully", bridge.start())

        try {
            val socket = Socket("127.0.0.1", port)
            socket.soTimeout = 4000
            val out = socket.getOutputStream()
            // Send partial header and stall
            out.write("GET /debug_get_metrics HTTP/1.1\r\n".toByteArray(Charsets.UTF_8))
            out.flush()

            val startMs = System.currentTimeMillis()
            val input = socket.getInputStream()
            // The server's socket.soTimeout (configured as SOCKET_READ_TIMEOUT_MS) must fire and close the connection
            val readResult = input.read()
            val elapsedMs = System.currentTimeMillis() - startMs

            // Either EOF (-1) because server closed connection upon read timeout, or readResult == -1
            assertEquals("Slow client must be disconnected by server with EOF (-1)", -1, readResult)
            assertTrue(
                "Disconnection must occur around configured timeout (${TunnelDevToolsBridge.SOCKET_READ_TIMEOUT_MS}ms), took ${elapsedMs}ms",
                elapsedMs < 3500
            )
            socket.close()
        } finally {
            bridge.stop()
        }
    }

    @Test
    fun truncatedBodyIsRejected() {
        val port = findAvailablePort()
        val bridge = TunnelDevToolsBridge(port = port, isDebug = true)
        assertTrue("Bridge must start successfully", bridge.start())

        try {
            val socket = Socket("127.0.0.1", port)
            socket.soTimeout = 3000
            val out = socket.getOutputStream()
            // Declare Content-Length: 100, but only provide 15 bytes and shutdown output
            val payload = "{\"userMessage\":"
            val request = "POST /debug_assess_turn HTTP/1.1\r\n" +
                    "Host: 127.0.0.1:$port\r\n" +
                    "x-dev-session-token: ${bridge.sessionToken}\r\n" +
                    "Content-Type: application/json\r\n" +
                    "Content-Length: 100\r\n" +
                    "Connection: close\r\n\r\n" +
                    payload
            out.write(request.toByteArray(Charsets.UTF_8))
            out.flush()
            socket.shutdownOutput() // Signal no more data will arrive

            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val statusLine = reader.readLine()
            assertNotNull("Status line must be returned", statusLine)
            assertTrue(
                "Truncated body must be rejected with 400 Bad Request, got '$statusLine'",
                statusLine.contains("400 Bad Request")
            )
            socket.close()
        } finally {
            bridge.stop()
        }
    }

    @Test
    fun malformedContentLengthIsRejected() {
        val port = findAvailablePort()
        val bridge = TunnelDevToolsBridge(port = port, isDebug = true)
        assertTrue("Bridge must start successfully", bridge.start())

        try {
            val socket = Socket("127.0.0.1", port)
            socket.soTimeout = 3000
            val out = socket.getOutputStream()
            val request = "POST /debug_assess_turn HTTP/1.1\r\n" +
                    "Host: 127.0.0.1:$port\r\n" +
                    "x-dev-session-token: ${bridge.sessionToken}\r\n" +
                    "Content-Type: application/json\r\n" +
                    "Content-Length: -42\r\n" +
                    "Connection: close\r\n\r\n"
            out.write(request.toByteArray(Charsets.UTF_8))
            out.flush()

            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val statusLine = reader.readLine()
            assertNotNull("Status line must be returned", statusLine)
            assertTrue(
                "Negative Content-Length must be rejected with 400 Bad Request, got '$statusLine'",
                statusLine.contains("400 Bad Request")
            )
            socket.close()
        } finally {
            bridge.stop()
        }
    }

    @Test
    fun devtoolsConcurrentClientsAreBounded() {
        val port = findAvailablePort()
        val bridge = TunnelDevToolsBridge(port = port, isDebug = true)
        assertTrue("Bridge must start successfully", bridge.start())

        val limit = TunnelDevToolsBridge.MAX_CONCURRENT_CLIENTS
        val activeClients = mutableListOf<Socket>()
        val rejected503Count = AtomicInteger(0)

        try {
            // Fill up the concurrent capacity with hanging connections
            for (i in 0 until limit) {
                val s = Socket("127.0.0.1", port)
                s.soTimeout = 4000
                // Send partial request to keep connection active in handleClient
                val out = s.getOutputStream()
                out.write("GET /debug_get_metrics HTTP/1.1\r\n".toByteArray(Charsets.UTF_8))
                out.flush()
                activeClients.add(s)
            }

            // Brief pause to ensure all connections are accepted and in-flight
            Thread.sleep(100)

            // Now attempt an extra connection exceeding capacity
            val extraSocket = Socket("127.0.0.1", port)
            extraSocket.soTimeout = 3000
            val extraOut = extraSocket.getOutputStream()
            extraOut.write("GET / HTTP/1.1\r\nHost: 127.0.0.1:$port\r\nConnection: close\r\n\r\n".toByteArray(Charsets.UTF_8))
            extraOut.flush()

            val reader = BufferedReader(InputStreamReader(extraSocket.getInputStream(), Charsets.UTF_8))
            val statusLine = reader.readLine()
            if (statusLine != null && statusLine.contains("503 Service Unavailable")) {
                rejected503Count.incrementAndGet()
            }
            extraSocket.close()

            assertEquals("Extra client exceeding limit must be rejected with 503", 1, rejected503Count.get())
        } finally {
            for (s in activeClients) {
                try { s.close() } catch (_: Throwable) {}
            }
            bridge.stop()
        }
    }

    @Test
    fun slowDripClientExceedingAbsoluteDeadlineIsTerminated() {
        val port = findAvailablePort()
        val tempDir = java.io.File(System.getProperty("java.io.tmpdir"), "test_dt_slow_${System.currentTimeMillis()}")
        tempDir.mkdirs()
        // Configure 1500ms idle timeout, but 400ms absolute request deadline
        val bridge = TunnelDevToolsBridge(
            port = port,
            isDebug = true,
            idleTimeoutMs = 1500,
            maxRequestDurationMs = 400L,
            tokenStorageDir = tempDir
        )
        assertTrue(bridge.start())

        try {
            val s = Socket("127.0.0.1", port)
            s.soTimeout = 2000
            val out = s.getOutputStream()

            val t0 = System.currentTimeMillis()
            out.write("GET ".toByteArray(Charsets.UTF_8))
            out.flush()
            Thread.sleep(250) // within 1500ms idle timeout

            out.write("/ ".toByteArray(Charsets.UTF_8))
            out.flush()
            Thread.sleep(250) // total 500ms > 400ms absolute deadline!

            // Attempting to send remaining header or read response should encounter closed/terminated connection
            var terminated = false
            try {
                out.write("HTTP/1.1\r\n\r\n".toByteArray(Charsets.UTF_8))
                out.flush()
                val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                val line = reader.readLine()
                if (line == null) {
                    terminated = true
                }
            } catch (e: Exception) {
                terminated = true
            }

            val elapsed = System.currentTimeMillis() - t0
            assertTrue("Slow drip client must be terminated when exceeding absolute deadline", terminated)
            assertTrue("Termination must happen in bounded time (<1000ms), took ${elapsed}ms", elapsed < 1000L)
            s.close()
        } finally {
            bridge.stop()
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun connectionBurstRejectionDoesNotAccumulateUnboundedCoroutines() {
        val port = findAvailablePort()
        val tempDir = java.io.File(System.getProperty("java.io.tmpdir"), "test_dt_burst_${System.currentTimeMillis()}")
        tempDir.mkdirs()
        val bridge = TunnelDevToolsBridge(port = port, isDebug = true, tokenStorageDir = tempDir)
        assertTrue(bridge.start())

        val burstSize = 20
        val sockets = mutableListOf<Socket>()
        val responses503 = AtomicInteger(0)
        val responses200 = AtomicInteger(0)
        val errors = AtomicInteger(0)

        try {
            val threads = (0 until burstSize).map {
                Thread {
                    try {
                        val s = Socket("127.0.0.1", port)
                        s.soTimeout = 2000
                        synchronized(sockets) { sockets.add(s) }
                        val out = s.getOutputStream()
                        out.write("GET / HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n".toByteArray(Charsets.UTF_8))
                        out.flush()
                        val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                        val status = reader.readLine()
                        if (status != null) {
                            if (status.contains("200 OK")) responses200.incrementAndGet()
                            else if (status.contains("503 Service Unavailable")) responses503.incrementAndGet()
                        }
                    } catch (e: Exception) {
                        errors.incrementAndGet()
                    }
                }
            }
            threads.forEach { it.start() }
            threads.forEach { it.join(3000) }

            assertEquals("Total responses + handled errors must equal burst size", burstSize, responses200.get() + responses503.get() + errors.get())
            assertTrue("At least one connection was handled successfully", responses200.get() > 0)
            assertTrue("No sockets leaked or hung", responses200.get() + responses503.get() + errors.get() == burstSize)
        } finally {
            for (s in sockets) {
                try { s.close() } catch (_: Throwable) {}
            }
            bridge.stop()
            tempDir.deleteRecursively()
        }
    }
}
