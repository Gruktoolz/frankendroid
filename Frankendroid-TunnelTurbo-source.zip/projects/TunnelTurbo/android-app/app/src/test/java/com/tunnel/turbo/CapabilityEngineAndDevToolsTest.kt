package com.tunnel.turbo

import com.tunnel.turbo.accessibility.SemanticSelector
import com.tunnel.turbo.accessibility.UiNodeInfo
import com.tunnel.turbo.capability.CapabilityCategory
import com.tunnel.turbo.capability.CapabilityRegistry
import com.tunnel.turbo.capability.RiskLevel
import com.tunnel.turbo.devtools.FailureDiagnostic
import com.tunnel.turbo.devtools.RequestTrace
import com.tunnel.turbo.devtools.TunnelDevToolsBridge
import com.tunnel.turbo.model.PlanValidationError
import com.tunnel.turbo.model.PlanValidator
import com.tunnel.turbo.model.TaskPlan
import com.tunnel.turbo.model.ToolStep
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class CapabilityEngineAndDevToolsTest {

    @Test
    fun testCapabilityRegistryCatalogAndAvailability() {
        val registry = CapabilityRegistry()
        val all = registry.getAllCapabilities()

        assertTrue("Catalog must contain at least 15 capabilities", all.size >= 15)

        // Categories check
        val categories = all.map { it.category }.toSet()
        assertTrue(categories.contains(CapabilityCategory.OBSERVATION))
        assertTrue(categories.contains(CapabilityCategory.NAVIGATION))
        assertTrue(categories.contains(CapabilityCategory.APP))
        assertTrue(categories.contains(CapabilityCategory.UI))
        assertTrue(categories.contains(CapabilityCategory.SYSTEM))

        // Check availability when services are disabled
        val degraded = registry.getCapabilities(shizukuReady = false, accessibilityReady = false)
        val clickCap = degraded.first { it.id == "click_node" }
        assertFalse("click_node must be unavailable without Accessibility", clickCap.available)

        val brightCap = degraded.first { it.id == "set_brightness" }
        assertFalse("set_brightness must be unavailable without Shizuku", brightCap.available)

        val settingsCap = degraded.first { it.id == "open_settings" }
        assertTrue("open_settings must be available without special services", settingsCap.available)

        // Check availability when services are enabled
        val active = registry.getCapabilities(shizukuReady = true, accessibilityReady = true)
        assertTrue(active.first { it.id == "click_node" }.available)
        assertTrue(active.first { it.id == "set_brightness" }.available)
    }

    @Test
    fun testSemanticSelectorMatching() {
        val sel1 = SemanticSelector.fromString("text=Buscar,clickable=true")
        assertEquals("Buscar", sel1.text)
        assertEquals(true, sel1.clickable)

        val dummyNode = UiNodeInfo(
            nodeId = "node_1",
            className = "android.widget.TextView",
            text = "Buscar en biblioteca",
            contentDescription = "",
            resourceId = "com.spotify.music:id/search",
            clickable = true,
            editable = false,
            scrollable = false,
            enabled = true,
            checked = false,
            selected = false,
            bounds = listOf(10, 20, 100, 200),
            displayId = 0
        )

        assertTrue(sel1.matchesUiNode(dummyNode))

        val sel2 = SemanticSelector.fromMap(mapOf("resourceId" to "com.spotify.music:id/search"))
        assertTrue(sel2.matchesUiNode(dummyNode))

        val sel3 = SemanticSelector.fromMap(mapOf("editable" to true))
        assertFalse(sel3.matchesUiNode(dummyNode))
    }

    @Test
    fun testPlanValidatorTaskPlan() {
        val validator = PlanValidator()

        // Valid Task Plan
        val validJson = JSONObject("""
            {
                "type": "task",
                "steps": [
                    {
                        "tool": "open_app",
                        "arguments": {"package": "com.spotify.music"}
                    },
                    {
                        "tool": "wait_for",
                        "arguments": {"condition": "foreground_package", "value": "com.spotify.music"}
                    },
                    {
                        "tool": "click_node",
                        "arguments": {"selector": {"text": "Buscar"}}
                    }
                ]
            }
        """.trimIndent())

        val plan = validator.validate(validJson)
        assertTrue(plan is TaskPlan)
        val taskPlan = plan as TaskPlan
        assertEquals(3, taskPlan.steps.size)
        assertEquals("open_app", taskPlan.steps[0].tool)
        assertEquals("com.spotify.music", taskPlan.steps[0].arguments["package"])

        // Task with coordinates strictly forbidden
        val badCoordJson = JSONObject("""
            {
                "type": "task",
                "steps": [
                    {
                        "tool": "click_node",
                        "arguments": {"selector": {"text": "x: 100, y: 200"}}
                    }
                ]
            }
        """.trimIndent())

        try {
            validator.validate(badCoordJson)
            fail("Expected PlanValidationError for coordinates")
        } catch (e: PlanValidationError) {
            assertEquals("COORDINATES_FORBIDDEN", e.code)
        }

        // Task with shell injection strictly forbidden
        val badShellJson = JSONObject("""
            {
                "type": "task",
                "steps": [
                    {
                        "tool": "click_node",
                        "arguments": {"selector": {"text": "test; rm -rf /"}}
                    }
                ]
            }
        """.trimIndent())

        try {
            validator.validate(badShellJson)
            fail("Expected PlanValidationError for shell injection")
        } catch (e: PlanValidationError) {
            assertEquals("SHELL_INJECTION_DETECTED", e.code)
        }

        // Empty task rejected
        val emptyJson = JSONObject("""{"type": "task", "steps": []}""")
        try {
            validator.validate(emptyJson)
            fail("Expected PlanValidationError for empty task")
        } catch (e: PlanValidationError) {
            assertEquals("EMPTY_TASK", e.code)
        }
    }

    @Test
    fun testFailureDiagnosticAndRequestTraceSerialization() {
        val diagnostic = FailureDiagnostic(
            failureType = "STEP_TIMEOUT",
            failedStepIndex = 1,
            failedTool = "click_node",
            expectedCondition = "Node 'Buscar' visible and clicked",
            actualCondition = "Node not found after 2000ms",
            foregroundPackage = "com.spotify.music",
            foregroundActivity = "com.spotify.music.MainActivity",
            displayId = 0
        )

        val dJson = diagnostic.toJson()
        assertEquals("STEP_TIMEOUT", dJson.getString("failureType"))
        assertEquals("click_node", dJson.getString("failedTool"))
        assertEquals(1, dJson.getInt("failedStepIndex"))

        val trace = RequestTrace(
            requestId = "REQ_TEST_01",
            input = "Abre Spotify y busca",
            route = "DIRECT",
            provider = "LOCAL_ROUTER",
            planType = "task",
            capabilitiesUsed = listOf("open_app", "click_node"),
            verification = "SUCCESS",
            totalMs = 150.5,
            diagnostic = diagnostic
        )

        val tJson = trace.toJson()
        assertEquals("REQ_TEST_01", tJson.getString("requestId"))
        assertEquals("task", tJson.getString("planType"))
        assertEquals(2, tJson.getJSONArray("capabilitiesUsed").length())
        assertTrue(tJson.has("diagnostic"))
    }
}
