package com.tunnel.turbo

import com.tunnel.turbo.chat.LocalModelCatalog
import com.tunnel.turbo.chat.LocalModelRole
import com.tunnel.turbo.chat.LocalModelSpec
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalModelCatalogAvailabilityTest {
    private fun model(
        role: LocalModelRole = LocalModelRole.CHAT,
        repository: String = "litert-community/Qwen3-0.6B",
        fileName: String = "Qwen3-0.6B.litertlm",
        sha256: String = "a".repeat(64),
        bytes: Long = 500_000_000L
    ) = LocalModelSpec(
        id = "test-model",
        displayName = "Test model",
        repository = repository,
        fileName = fileName,
        bytes = bytes,
        sha256 = sha256,
        role = role,
        downloadUrl = "https://example.invalid/model"
    )

    @Test
    fun `only catalogued chat model with a complete readable artifact is offered`() {
        assertTrue(LocalModelCatalog.isSelectableChatModel(model(), hasReadableArtifact = true))
        assertFalse(LocalModelCatalog.isSelectableChatModel(model(), hasReadableArtifact = false))
        assertFalse(LocalModelCatalog.isSelectableChatModel(model(role = LocalModelRole.TOOL_ROUTING_SPECIALIST), true))
        assertFalse(LocalModelCatalog.isSelectableChatModel(model(repository = "local-file-unverified"), true))
        assertFalse(LocalModelCatalog.isSelectableChatModel(model(fileName = "model.bin"), true))
        assertFalse(LocalModelCatalog.isSelectableChatModel(model(sha256 = "UNAVAILABLE"), true))
        assertFalse(LocalModelCatalog.isSelectableChatModel(model(bytes = 0L), true))
    }
}
