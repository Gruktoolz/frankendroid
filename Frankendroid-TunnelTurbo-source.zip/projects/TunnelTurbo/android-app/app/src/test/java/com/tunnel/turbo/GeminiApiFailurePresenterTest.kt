package com.tunnel.turbo

import com.tunnel.turbo.chat.GeminiApiFailurePresenter
import com.tunnel.turbo.chat.GeminiSseChunkParser
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class GeminiApiFailurePresenterTest {
    @Test fun reportsCommonKeyQuotaAndRegionFailuresInPlainLanguage() {
        assertEquals("Google rechazó la clave o el acceso del proyecto (HTTP 403). Revisa la clave y sus restricciones en AI Studio.", GeminiApiFailurePresenter.describe(403, "PERMISSION_DENIED", "secret"))
        assertEquals("Google rechazó la solicitud por un requisito del proyecto o la región (HTTP 400). Revisa el estado del proyecto en AI Studio.", GeminiApiFailurePresenter.describe(400, "FAILED_PRECONDITION", "secret"))
        assertEquals("Se alcanzó una cuota o límite temporal de Gemini (HTTP 429). Revisa la cuota en AI Studio y vuelve a intentarlo más tarde.", GeminiApiFailurePresenter.describe(429, "RESOURCE_EXHAUSTED", "secret"))
    }

    @Test fun neverEchoesRawServerDetailsOrPotentialKeys() {
        val visible = GeminiApiFailurePresenter.describe(400, "INVALID_ARGUMENT", "API key abc123 leaked in server detail")
        assertFalse(visible.contains("abc123"))
        assertFalse(visible.contains("server detail"))
    }

    @Test fun extractsIncrementalTextAndGroundedSourcesFromStreamChunk() {
        val chunk = JSONObject("""
            {"candidates":[{"content":{"parts":[{"text":"El clima "},{"text":"está fresco."}]},"groundingMetadata":{"groundingChunks":[{"web":{"title":"Pronóstico","uri":"https://weather.example/forecast"}},{"web":{"title":"No segura","uri":"http://invalid.example"}}]}}]}
        """.trimIndent())

        assertEquals("El clima está fresco.", GeminiSseChunkParser.text(chunk))
        assertEquals(listOf("Pronóstico" to "https://weather.example/forecast"), GeminiSseChunkParser.sources(chunk))
        assertEquals("", GeminiSseChunkParser.text(JSONObject("{}")))
    }

    @Test fun detectsWhenGeminiStoppedAtItsOutputTokenLimit() {
        assertEquals("MAX_TOKENS", GeminiSseChunkParser.finishReason(JSONObject("""{"candidates":[{"finishReason":"MAX_TOKENS"}]}""")))
        assertEquals(null, GeminiSseChunkParser.finishReason(JSONObject("{}")))
    }
}
