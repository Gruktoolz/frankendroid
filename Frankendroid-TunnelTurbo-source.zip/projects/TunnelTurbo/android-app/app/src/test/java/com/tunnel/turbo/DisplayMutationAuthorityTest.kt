package com.tunnel.turbo

import com.tunnel.turbo.agent.*
import com.tunnel.turbo.core.*
import com.tunnel.turbo.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * TDD Regression Tests for Central Main-Display Mutation Authority & Cancellation (Phase 13B-1.2a.3, Section 9-14)
 *
 * Verifies:
 * 1. Mutations on Display 0 are serialized: maxConcurrentMutations(display 0) == 1.
 * 2. Independent requests do not interleave mutating actions or cross-contaminate leases.
 * 3. Cancelled mutation owner releases display lease cleanly and unblocks subsequent requests.
 * 4. CancellationException is preserved (not converted to generic task failure) with truthful state cleanup.
 * 5. Distinct displays (e.g. Display 0 vs Display 1) are independently scoped, not globally locked.
 */
class DisplayMutationAuthorityTest {

    @Test
    fun mainDisplayMutationsAreSerializedAcrossSubmissions() = runBlocking {
        val arbiter = DisplayMutationArbiter()
        val maxConcurrentD0 = AtomicInteger(0)
        val activeConcurrentD0 = AtomicInteger(0)
        val executionOrder = ConcurrentLinkedQueue<String>()

        val firstStarted = CompletableDeferred<Unit>()
        val firstReleaseSignal = CompletableDeferred<Unit>()

        // Request 1: Targets Display 0
        val job1 = launch(Dispatchers.Default) {
            arbiter.withMutationLease(
                displayId = 0,
                ownerSessionId = "session_1",
                ownerGoalId = "goal_1",
                requestId = "req_1"
            ) { lease ->
                assertEquals(0, lease.displayId)
                assertEquals("session_1", lease.ownerSessionId)

                val cur = activeConcurrentD0.incrementAndGet()
                maxConcurrentD0.updateAndGet { maxOf(it, cur) }
                executionOrder.add("req_1_acquired")
                firstStarted.complete(Unit)

                firstReleaseSignal.await() // Block inside mutation
                activeConcurrentD0.decrementAndGet()
                executionOrder.add("req_1_released")
            }
        }

        // Wait until Request 1 holds the lease
        firstStarted.await()

        // Request 2: Also targets Display 0 while Request 1 is still mutating
        val job2 = launch(Dispatchers.Default) {
            arbiter.withMutationLease(
                displayId = 0,
                ownerSessionId = "session_2",
                ownerGoalId = "goal_2",
                requestId = "req_2"
            ) { lease ->
                assertEquals(0, lease.displayId)
                assertEquals("session_2", lease.ownerSessionId)

                val cur = activeConcurrentD0.incrementAndGet()
                maxConcurrentD0.updateAndGet { maxOf(it, cur) }
                executionOrder.add("req_2_acquired")

                activeConcurrentD0.decrementAndGet()
                executionOrder.add("req_2_released")
            }
        }

        // Give Request 2 time to reach the mutation boundary
        delay(100)

        // Request 2 must NOT have acquired the lease yet while Request 1 is still inside
        assertFalse("req_2 must not acquire while req_1 owns Display 0", executionOrder.contains("req_2_acquired"))
        assertEquals("Display 0 must have exactly 1 active mutator", 1, activeConcurrentD0.get())

        // Release Request 1
        firstReleaseSignal.complete(Unit)
        job1.join()
        job2.join()

        // Invariants:
        assertEquals("Max concurrent mutations on Display 0 must be 1", 1, maxConcurrentD0.get())
        val orderList = executionOrder.toList()
        assertEquals(listOf("req_1_acquired", "req_1_released", "req_2_acquired", "req_2_released"), orderList)
        assertNull("Lease must be completely released after completion", arbiter.getActiveLease(0))
    }

    @Test
    fun cancelledMutationOwnerReleasesDisplayLease() = runBlocking {
        val arbiter = DisplayMutationArbiter()
        val firstStarted = CompletableDeferred<Unit>()
        val secondAcquired = CompletableDeferred<Unit>()

        val job1 = launch(Dispatchers.Default) {
            arbiter.withMutationLease(
                displayId = 0,
                ownerSessionId = "session_cancel",
                ownerGoalId = "goal_cancel",
                requestId = "req_cancel"
            ) {
                firstStarted.complete(Unit)
                // Hang indefinitely until cancelled
                awaitCancellation()
            }
        }

        firstStarted.await()
        assertNotNull("Lease must be held by session_cancel", arbiter.getActiveLease(0))
        assertEquals("session_cancel", arbiter.getActiveLease(0)?.ownerSessionId)

        // Launch Request 2 waiting for Display 0
        val job2 = launch(Dispatchers.Default) {
            arbiter.withMutationLease(
                displayId = 0,
                ownerSessionId = "session_after_cancel",
                ownerGoalId = "goal_after_cancel",
                requestId = "req_after_cancel"
            ) { lease ->
                assertEquals("session_after_cancel", lease.ownerSessionId)
                secondAcquired.complete(Unit)
            }
        }

        delay(50)
        assertFalse("Request 2 must wait while Request 1 is active", secondAcquired.isCompleted)

        // Cancel Request 1
        job1.cancel()
        job1.join()

        // Request 2 must now acquire and succeed
        withTimeout(2000) {
            secondAcquired.await()
        }
        job2.join()

        assertNull("Display 0 lease must be cleared after all jobs complete", arbiter.getActiveLease(0))
    }

    @Test
    fun differentDisplaysCanMutateConcurrently() = runBlocking {
        val arbiter = DisplayMutationArbiter()
        val d0Started = CompletableDeferred<Unit>()
        val d1Started = CompletableDeferred<Unit>()
        val releaseAll = CompletableDeferred<Unit>()

        val jobD0 = launch(Dispatchers.Default) {
            arbiter.withMutationLease(displayId = 0, ownerSessionId = "sess_d0") {
                d0Started.complete(Unit)
                releaseAll.await()
            }
        }

        val jobD1 = launch(Dispatchers.Default) {
            arbiter.withMutationLease(displayId = 1, ownerSessionId = "sess_d1") {
                d1Started.complete(Unit)
                releaseAll.await()
            }
        }

        // Both displays must be able to acquire their respective leases simultaneously
        withTimeout(2000) {
            d0Started.await()
            d1Started.await()
        }

        releaseAll.complete(Unit)
        jobD0.join()
        jobD1.join()

        assertNull(arbiter.getActiveLease(0))
        assertNull(arbiter.getActiveLease(1))
    }

    @Test
    fun cancelAgentSessionPreservesCancellationAndCleansState() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val provider = object : ReasoningProvider {
            override val name = "HangingProvider"
            override suspend fun health() = com.tunnel.turbo.worker.ProviderHealthReport(com.tunnel.turbo.worker.ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: com.tunnel.turbo.agent.WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<com.tunnel.turbo.capability.Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                started.complete(Unit)
                awaitCancellation()
            }
        }

        val core = com.tunnel.turbo.core.NativeTunnelCore(context = null)
        val runtime = com.tunnel.turbo.agent.GeneralAgentRuntime(
            core = core,
            appManager = com.tunnel.turbo.app.AppManager(null),
            capabilityRegistry = com.tunnel.turbo.capability.CapabilityRegistry(),
            accessibilityBridge = core.accessibilityBridge,
            stateEngine = core.stateEngine,
            reasoningProvider = provider
        )

        val deferred = async(Dispatchers.Default) {
            runtime.executeUserGoal("reproduce algo")
        }

        started.await()
        assertTrue("Runtime must be busy while executing goal", runtime.runtimeState.value.isBusy)

        // Cancel the executing coroutine
        deferred.cancel()

        var caughtCancellation = false
        try {
            val result = deferred.await()
            // If it returns an AgentTaskResult instead of throwing CancellationException, that's a bug!
            fail("Expected CancellationException, but runtime swallowed it and returned: outcome=${result.outcome}, reason=${result.failureReason}")
        } catch (ce: CancellationException) {
            caughtCancellation = true
        }

        assertTrue("CancellationException must be preserved and rethrown", caughtCancellation)
        assertFalse("Runtime state must clean isBusy=false in finally", runtime.runtimeState.value.isBusy)
        assertNull("Display 0 lease must not remain held after cancellation", core.displayMutationArbiter.getActiveLease(0))
    }

    @Test
    fun innerCancellationIsPreservedAndNotConvertedToStepFailed() = runBlocking {
        val provider = object : ReasoningProvider {
            override val name = "CancellingProvider"
            override suspend fun health() = com.tunnel.turbo.worker.ProviderHealthReport(com.tunnel.turbo.worker.ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: com.tunnel.turbo.agent.WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<com.tunnel.turbo.capability.Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                throw CancellationException("Simulated inner cancellation")
            }
        }

        val core = com.tunnel.turbo.core.NativeTunnelCore(context = null)
        val runtime = com.tunnel.turbo.agent.GeneralAgentRuntime(
            core = core,
            appManager = com.tunnel.turbo.app.AppManager(null),
            capabilityRegistry = com.tunnel.turbo.capability.CapabilityRegistry(),
            accessibilityBridge = core.accessibilityBridge,
            stateEngine = core.stateEngine,
            reasoningProvider = provider
        )

        var caught = false
        try {
            val res = runtime.executeUserGoal("reproduce algo")
            fail("Expected CancellationException to be rethrown, but got task result with failureReason=${res.failureReason}, message=${res.message}")
        } catch (ce: CancellationException) {
            caught = true
        }

        assertTrue("CancellationException must be preserved", caught)
        assertFalse("Runtime state must clean isBusy=false in finally", runtime.runtimeState.value.isBusy)
    }

    @Test
    fun parallelChildMutationCannotReuseParentLeaseConcurrently() = runBlocking {
        val arbiter = DisplayMutationArbiter()
        val activeConcurrent = AtomicInteger(0)
        val maxConcurrent = AtomicInteger(0)

        withTimeout(5000) {
            arbiter.withMutationLease(displayId = 0, ownerSessionId = "parent_session") {
                coroutineScope {
                    val child1 = launch(Dispatchers.Default) {
                        arbiter.withMutationLease(displayId = 0) {
                            val count = activeConcurrent.incrementAndGet()
                            maxConcurrent.updateAndGet { maxOf(it, count) }
                            delay(50)
                            activeConcurrent.decrementAndGet()
                        }
                    }
                    val child2 = launch(Dispatchers.Default) {
                        arbiter.withMutationLease(displayId = 0) {
                            val count = activeConcurrent.incrementAndGet()
                            maxConcurrent.updateAndGet { maxOf(it, count) }
                            delay(50)
                            activeConcurrent.decrementAndGet()
                        }
                    }
                    child1.join()
                    child2.join()
                }
            }
        }

        assertEquals("Parallel child mutations must not execute concurrently on the same display", 1, maxConcurrent.get())
    }

    @Test
    fun workerOperationWithoutOwnedDisplayFailsClosed() {
        val policy = DisplayTargetPolicy(primaryDisplayId = 0, workerDisplayId = null)
        assertFalse("Worker cannot access Primary Display 0", policy.canWorkerActionAccess(0))
        assertFalse("Worker cannot access arbitrary display 8 when no worker display owned", policy.canWorkerActionAccess(8))
        try {
            policy.resolveTargetDisplay(isWorkerOperation = true)
            fail("Expected exception when worker operation has no owned worker display")
        } catch (e: Exception) {
            assertTrue("Expected IllegalStateException or SecurityException, got ${e::class.simpleName}", e is IllegalStateException || e is SecurityException)
        }
    }

    @Test
    fun leasedDisplayAlwaysEqualsExecutedDisplay() = runBlocking {
        val policy = DisplayTargetPolicy(primaryDisplayId = 0, workerDisplayId = 2)
        val arbiter = DisplayMutationArbiter()

        val engine = NativeActionEngine(
            context = null,
            stateEngine = NativeStateEngine(),
            verifier = NativeVerifier(NativeStateEngine()),
            displayPolicy = policy,
            arbiter = arbiter
        )

        // Action plan with no displayId specified, but isWorkerOperation = true
        // It must resolve target display 2 once, lease display 2, and execute on display 2!
        val plan = ActionPlan(action = "semantic_tap", arguments = mapOf("selector" to "text=Done"))
        val res = engine.executeAction(plan, isWorkerOperation = true, verify = false)
        assertTrue("Headless semantic_tap must succeed", res.success)
        assertTrue("Details must reflect execution on display 2, got: ${res.details}", res.details.contains("display 2"))
    }

    @Test
    fun unsupportedWorkerActionCannotTargetSecondaryDisplay() = runBlocking {
        val policy = DisplayTargetPolicy(primaryDisplayId = 0, workerDisplayId = 2)
        val engine = NativeActionEngine(
            context = null,
            stateEngine = NativeStateEngine(),
            verifier = NativeVerifier(NativeStateEngine()),
            displayPolicy = policy
        )

        // Attempt to run open_wifi_settings on secondary worker display
        val plan = ActionPlan(action = "open_wifi_settings")
        val res = engine.executeAction(plan, isWorkerOperation = true, verify = false)
        assertFalse("Action that cannot target secondary display must fail before side effect", res.success)
        assertTrue("Details must explain that action cannot target secondary display: ${res.details}", res.details.contains("cannot target secondary worker display"))
    }
}
