package com.tunnel.turbo

import com.tunnel.turbo.chat.ConversationMemory
import com.tunnel.turbo.chat.LocalChatContextBuilder
import com.tunnel.turbo.chat.MemoryCommandParser
import com.tunnel.turbo.chat.MemoryCommandType
import com.tunnel.turbo.chat.ResearchIntentPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationMemoryAndRoutingTest {
    @Test fun explicitMemoryCommandsAreParsedAndNormalTextIsNotSaved() {
        assertEquals(MemoryCommandType.REMEMBER, MemoryCommandParser.parse("Recuerda que prefiero respuestas breves")?.type)
        assertEquals("prefiero respuestas breves", MemoryCommandParser.parse("Recuerda que prefiero respuestas breves")?.value)
        assertEquals(MemoryCommandType.FORGET, MemoryCommandParser.parse("Olvida que prefiero respuestas breves")?.type)
        assertEquals(MemoryCommandType.CLEAR, MemoryCommandParser.parse("Olvida todo lo que recuerdas")?.type)
        assertNull(MemoryCommandParser.parse("Hoy prefiero respuestas breves"))
    }

    @Test fun webRoutingRecognizesExplicitResearchAndVolatileQuestionsButKeepsStableQuestionsLocal() {
        assertTrue(ResearchIntentPolicy.requiresWeb("Investiga las opciones más recientes"))
        assertTrue(ResearchIntentPolicy.requiresWeb("Oye dime el clima próximo en Tijuana"))
        assertTrue(ResearchIntentPolicy.requiresWeb("Busca en Google el horario de hoy"))
        assertTrue(ResearchIntentPolicy.requiresWeb("Who is the current CEO of this company?"))
        assertFalse(ResearchIntentPolicy.requiresWeb("Explícame qué es la fotosíntesis"))
    }

    @Test fun localContextCarriesMasterMemoryRecentTurnsAndRequestedOutputContract() {
        val prompt = LocalChatContextBuilder.build(
            memory = ConversationMemory("Respóndeme en español", listOf("Trabajo con Android")),
            previousTurns = listOf("user" to "Estoy creando Tunnel Turbo"),
            currentRequest = "Convierte estos datos a JSON y HTML: nombre Ana"
        )
        assertTrue(prompt.contains("Respóndeme en español"))
        assertTrue(prompt.contains("Trabajo con Android"))
        assertTrue(prompt.contains("JSON"))
        assertTrue(prompt.contains("HTML"))
        assertTrue(prompt.contains("Estoy creando Tunnel Turbo"))
        assertTrue(prompt.contains("Responde directamente"))
    }
}
