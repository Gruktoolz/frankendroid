package com.tunnel.turbo

import com.tunnel.turbo.agent.DecisionSource
import com.tunnel.turbo.agent.DecisionType
import com.tunnel.turbo.agent.LocalModelDecisionParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LocalModelDecisionParserTest {
    @Test fun acceptsOnlyARegisteredCapabilityAndPreservesArguments() {
        val decision = LocalModelDecisionParser.parse(
            "```json\n{\"type\":\"USE_CAPABILITY\",\"capabilityId\":\"open_app\",\"arguments\":{\"packageName\":\"com.example\"},\"reason\":\"La app solicitada no está abierta\"}\n```",
            setOf("open_app")
        )
        assertEquals(DecisionType.USE_CAPABILITY, decision?.type)
        assertEquals("com.example", decision?.arguments?.get("packageName"))
        assertEquals(DecisionSource.LOCAL_MODEL, decision?.decisionSource)
    }

    @Test fun rejectsUnknownCapabilityAndMalformedOutput() {
        assertNull(LocalModelDecisionParser.parse("{\"type\":\"USE_CAPABILITY\",\"capabilityId\":\"delete_everything\"}", setOf("open_app")))
        assertNull(LocalModelDecisionParser.parse("not json", setOf("open_app")))
    }
}
