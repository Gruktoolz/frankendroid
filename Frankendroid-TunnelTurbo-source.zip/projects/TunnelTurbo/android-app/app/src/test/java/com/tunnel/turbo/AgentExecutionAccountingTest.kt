package com.tunnel.turbo

import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.accessibility.UiNodeInfo
import com.tunnel.turbo.agent.*
import com.tunnel.turbo.capability.Capability
import com.tunnel.turbo.core.NativeTunnelCore
import com.tunnel.turbo.worker.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

class AgentExecutionAccountingTest {

    class FakeBridgeForAccounting : AccessibilityBridge() {
        var pkg = "com.example.target"
        var act = "MainActivity"
        var text = "Initial Screen Content"
        var nodes = mutableListOf(
            UiNodeInfo(
                nodeId = "node_target_1",
                className = "android.widget.TextView",
                text = "Target Text",
                contentDescription = "Target Content",
                resourceId = "tv_target",
                clickable = false,
                editable = false,
                scrollable = false,
                enabled = true,
                checked = false,
                selected = false,
                bounds = listOf(10, 10, 200, 50),
                displayId = 0
            )
        )

        override fun isEnabled(): Boolean = true
        override fun getForegroundPackage(displayId: Int): String = if (displayId == 0) pkg else ""
        override fun getForegroundActivity(displayId: Int): String = if (displayId == 0) act else ""
        override fun getVisibleText(displayId: Int): String = if (displayId == 0) text else ""
        override fun getUiNodes(displayId: Int): List<UiNodeInfo> = if (displayId == 0) nodes else emptyList()
        override fun findUiNodes(selector: com.tunnel.turbo.accessibility.SemanticSelector, displayId: Int, match: String): List<UiNodeInfo> {
            if (displayId != 0) return emptyList()
            return nodes.filter { node ->
                (selector.text == null || node.text.contains(selector.text!!, ignoreCase = true)) &&
                (selector.resourceId == null || node.resourceId.contains(selector.resourceId!!, ignoreCase = true))
            }
        }
    }

    private fun createCore(bridge: FakeBridgeForAccounting = FakeBridgeForAccounting()): NativeTunnelCore {
        return NativeTunnelCore(
            context = null,
            workerBridge = null,
            customAccessibilityBridge = bridge
        )
    }

    private fun dummySnapshot(goalId: String = "test-goal", rev: Long = 1L) = WorldSnapshot(
        goalId = goalId,
        foregroundPackage = "com.test",
        foregroundActivity = "MainActivity",
        candidateApps = emptyList(),
        reducedObservation = ReducedObservation(
            foregroundPackage = "com.test",
            foregroundActivity = "MainActivity",
            interactiveNodes = emptyList(),
            informativeText = "Screen at rev $rev",
            metrics = ReductionMetrics(0, 0, 0, 0, 0.0)
        ),
        availableCapabilities = listOf("open_settings", "press_back"),
        relevantSkills = emptyList(),
        revision = rev
    )

    @Test
    fun testScenarioA_StateChangingAccounting() = runBlocking {
        val bridge = FakeBridgeForAccounting()
        val core = createCore(bridge)
        val goal = Goal(goalId = "g-a", originalText = "mutate state", objective = "mutate")

        var turn = 0
        val provider = object : ReasoningProvider {
            override val name = "MutatingProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                turn++
                budget.providerRounds++
                return when (turn) {
                    1 -> NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "open_settings", reason = "Mutate 1")
                    2 -> NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "press_back", reason = "Mutate 2")
                    else -> NextDecision(type = DecisionType.TASK_FAILED, reason = "Finish")
                }
            }
        }

        val budget = AgentBudget(
            maxStateChangingActions = 10,
            maxObservationToolCalls = 10,
            maxCapabilityCalls = 20,
            maxProviderRounds = 5
        )

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            budget = budget
        )

        session.execute()

        assertEquals("stateChangingActionsExecuted must be 2", 2, budget.stateChangingActionsExecuted)
        assertEquals("observationToolCalls must be 0", 0, budget.observationToolCalls)
        assertEquals("capabilityCallsExecuted must be 2", 2, budget.capabilityCallsExecuted)
        assertEquals("canonical actionsExecuted must equal stateChangingActionsExecuted", 2, budget.actionsExecuted)
        assertEquals("canonical stepsUsed must equal stateChangingActionsExecuted", 2, budget.stepsUsed)
        assertEquals("remainingActions must decrease correctly", 8, budget.remainingActions)
        assertEquals("remainingCapabilityCalls must decrease correctly", 18, budget.remainingCapabilityCalls)
    }

    @Test
    fun testScenarioB_ObservationAccounting() = runBlocking {
        val bridge = FakeBridgeForAccounting()
        val core = createCore(bridge)
        val goal = Goal(goalId = "g-b", originalText = "observe state", objective = "observe")

        var turn = 0
        val provider = object : ReasoningProvider {
            override val name = "ObservationalProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                turn++
                budget.providerRounds++
                return when (turn) {
                    1 -> NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "get_ui_nodes", reason = "Obs 1")
                    2 -> NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "find_ui_nodes", arguments = mapOf("selector" to mapOf("text" to "Target")), reason = "Obs 2")
                    else -> NextDecision(type = DecisionType.TASK_FAILED, reason = "Finish")
                }
            }
        }

        val budget = AgentBudget(
            maxStateChangingActions = 10,
            maxObservationToolCalls = 10,
            maxCapabilityCalls = 20,
            maxProviderRounds = 5
        )

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            budget = budget
        )

        session.execute()

        assertEquals("observationToolCalls must be 2", 2, budget.observationToolCalls)
        assertEquals("stateChangingActionsExecuted must be 0", 0, budget.stateChangingActionsExecuted)
        assertEquals("capabilityCallsExecuted must be 2", 2, budget.capabilityCallsExecuted)
        assertEquals("actionsExecuted must be 0", 0, budget.actionsExecuted)
        assertEquals("remainingObservationCalls must decrease to 8", 8, budget.remainingObservationCalls)
        assertEquals("remainingActions must stay 10", 10, budget.remainingActions)
    }

    @Test
    fun testScenarioC_MixedAccountingNoDrift() = runBlocking {
        val bridge = FakeBridgeForAccounting()
        val core = createCore(bridge)
        val goal = Goal(goalId = "g-c", originalText = "mixed actions", objective = "mixed")

        var turn = 0
        val provider = object : ReasoningProvider {
            override val name = "MixedProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                turn++
                budget.providerRounds++
                return when (turn) {
                    1 -> NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "open_settings", reason = "Mutate 1")
                    2 -> NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "get_ui_nodes", reason = "Obs 1")
                    3 -> NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "find_ui_nodes", arguments = mapOf("selector" to mapOf("text" to "Target")), reason = "Obs 2")
                    else -> NextDecision(type = DecisionType.TASK_FAILED, reason = "Finish")
                }
            }
        }

        val budget = AgentBudget()

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            budget = budget
        )

        session.execute()

        assertEquals("stateChangingActionsExecuted must be 1", 1, budget.stateChangingActionsExecuted)
        assertEquals("observationToolCalls must be 2", 2, budget.observationToolCalls)
        assertEquals("capabilityCallsExecuted must strictly equal sum", 3, budget.capabilityCallsExecuted)
        assertEquals(budget.capabilityCallsExecuted, budget.stateChangingActionsExecuted + budget.observationToolCalls)
    }

    @Test
    fun testScenarioD_ObservationSendSingleOwnership() = runBlocking {
        ProviderCallRepository.clear()
        try {
            val mockBridge = object : AiWorkerBridge() {
                override fun checkOperationalHealth() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
                override fun preflight(timeoutMs: Long) = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
                override fun countConversationTurns(dispId: Int): Int = 0
                override fun sendRequest(prompt: String, requestId: String, proofNonce: String): Boolean = true
                override fun readResponse(requestId: String, proofNonce: String, turnBefore: Int, timeoutMs: Long): BridgeResponse {
                    val json = """{"type":"USE_CAPABILITY","capabilityId":"open_settings","arguments":{},"reason":"ok","request_id":"$requestId","proof_nonce":"$proofNonce"}"""
                    return BridgeResponse(success = true, rawText = json, requestId = requestId, proofNonce = proofNonce, turnAfter = 1)
                }
            }

            val provider = AndroidAiAppReasoningProvider(workerBridge = mockBridge)
            val budget = AgentBudget()
            val goal = Goal(goalId = "g-d", originalText = "single ownership test", objective = "test")
            val snapshot = dummySnapshot("g-d", 1L)

            // Simulate AgentSession closed loop request
            budget.providerRequestsAttempted++
            val decision = provider.decideNext(
                goal = goal,
                snapshot = snapshot,
                skills = emptyList(),
                capabilities = emptyList(),
                recentSteps = emptyList(),
                budget = budget,
                reason = AiRoundReason.INITIAL_PLAN
            )

            assertEquals("Decision must be USE_CAPABILITY", DecisionType.USE_CAPABILITY, decision.type)
            assertEquals("providerRequestsAttempted must be 1", 1, budget.providerRequestsAttempted)
            assertEquals("providerPromptsInjected must be 1", 1, budget.providerPromptsInjected)
            assertEquals("observationsSentToProvider must be 1 (never double-counted)", 1, budget.observationsSentToProvider)
            assertEquals("providerRounds must be 1", 1, budget.providerRounds)
        } finally {
            ProviderCallRepository.clear()
        }
    }

    @Test
    fun testScenarioE_ProviderResponseTimeoutAfterInjection() = runBlocking {
        ProviderCallRepository.clear()
        GeneralAgentRuntime.strictRealProviderMode = false
        try {
            val mockBridge = object : AiWorkerBridge() {
                override fun checkOperationalHealth() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
                override fun preflight(timeoutMs: Long) = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
                override fun countConversationTurns(dispId: Int): Int = 0
                override fun sendRequest(prompt: String, requestId: String, proofNonce: String): Boolean = true
                override fun readResponse(requestId: String, proofNonce: String, turnBefore: Int, timeoutMs: Long): BridgeResponse {
                    // Simulates timeout after successful prompt injection
                    return BridgeResponse(success = false, error = "RESPONSE_TIMEOUT", failureClass = ProviderFailureClass.PROVIDER_RESPONSE_TIMEOUT.name)
                }
            }

            val provider = AndroidAiAppReasoningProvider(workerBridge = mockBridge)
            val budget = AgentBudget()
            val goal = Goal(goalId = "g-e", originalText = "timeout test", objective = "timeout")
            val snapshot = dummySnapshot("g-e", 1L)

            budget.providerRequestsAttempted++
            provider.decideNext(
                goal = goal,
                snapshot = snapshot,
                skills = emptyList(),
                capabilities = emptyList(),
                recentSteps = emptyList(),
                budget = budget,
                reason = AiRoundReason.INITIAL_PLAN
            )

            assertEquals("providerRequestsAttempted must be 1", 1, budget.providerRequestsAttempted)
            assertEquals("providerPromptsInjected must be 1", 1, budget.providerPromptsInjected)
            assertEquals("observationsSentToProvider must be 1", 1, budget.observationsSentToProvider)
            assertEquals("providerRounds must remain 0 on response timeout", 0, budget.providerRounds)
        } finally {
            ProviderCallRepository.clear()
        }
    }

    @Test
    fun testScenarioF_InformationProgressOnNewObservation() {
        val detector = ProgressDetector()
        val goal = Goal(goalId = "g-f", originalText = "find nodes", objective = "find")
        val before = dummySnapshot("g-f", 1L)
        val after = dummySnapshot("g-f", 2L)

        val actionRes = ActionResult(
            goalId = "g-f",
            sessionId = "s-f",
            capabilityId = "find_ui_nodes",
            arguments = mapOf("selector" to mapOf("text" to "Nuevo chat")),
            executorSuccess = true,
            isObservational = true,
            resultFingerprint = "fp_nodes_123",
            resultCount = 1,
            resultSummary = "Found 1 matching nodes"
        )

        val eval = detector.evaluate(before, after, actionRes, goal)

        assertEquals("New useful observation must yield INFORMATION_PROGRESS", ProgressState.INFORMATION_PROGRESS, eval.state)
        assertTrue("Reason should mention initial/new information", eval.reason.contains("yielded initial information"))
        assertEquals("fp_nodes_123", eval.resultFingerprint)
    }

    @Test
    fun testScenarioG_RepeatedInformationYieldsNoProgressAndStuck() {
        val detector = ProgressDetector()
        val stuckDetector = StuckDetector(maxNoProgressCycles = 2, maxEquivalentCycles = 3)
        val goal = Goal(goalId = "g-g", originalText = "find nodes repeatedly", objective = "find")
        val snap = dummySnapshot("g-g", 1L)

        val actionRes1 = ActionResult(
            goalId = "g-g",
            sessionId = "s-g",
            capabilityId = "find_ui_nodes",
            arguments = mapOf("selector" to mapOf("text" to "Search")),
            executorSuccess = true,
            isObservational = true,
            resultFingerprint = "fp_same_456",
            resultCount = 2,
            resultSummary = "Found 2 matching nodes"
        )

        // First call yields INFORMATION_PROGRESS
        val eval1 = detector.evaluate(snap, snap, actionRes1, goal)
        assertEquals(ProgressState.INFORMATION_PROGRESS, eval1.state)
        val stuckAfter1 = stuckDetector.recordCycle(eval1, "find_ui_nodes", snap)
        assertFalse(stuckAfter1)
        assertEquals(0, stuckDetector.consecutiveNoProgressCount)

        // Exact same query with exact same result fingerprint yields NO_PROGRESS
        val eval2 = detector.evaluate(snap, snap, actionRes1, goal)
        assertEquals(ProgressState.NO_PROGRESS, eval2.state)
        assertTrue(eval2.reason.contains("unchanged result fingerprint"))

        val stuckAfter2 = stuckDetector.recordCycle(eval2, "find_ui_nodes", snap)
        assertEquals("Stuck detector must increment on NO_PROGRESS from repeated observation", 1, stuckDetector.consecutiveNoProgressCount)

        // Third call with same fingerprint
        val eval3 = detector.evaluate(snap, snap, actionRes1, goal)
        assertEquals(ProgressState.NO_PROGRESS, eval3.state)
        val stuckAfter3 = stuckDetector.recordCycle(eval3, "find_ui_nodes", snap)
        assertEquals(2, stuckDetector.consecutiveNoProgressCount)
        assertTrue("Two consecutive NO_PROGRESS cycles must trigger stuck condition", stuckAfter3)
    }

    @Test
    fun testScenarioH_AsyncStateChangeDuringSettle() = runBlocking {
        val bridge = FakeBridgeForAccounting()
        val core = createCore(bridge)
        val goal = Goal(goalId = "g-h", originalText = "open app async", objective = "open app")

        var turn = 0
        val provider = object : ReasoningProvider {
            override val name = "AsyncProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                turn++
                budget.providerRounds++
                return if (turn == 1) {
                    // Launch background job that simulates delayed Android window transition after 300ms
                    launch {
                        delay(300)
                        bridge.pkg = "com.example.newapp"
                        bridge.text = "New App Screen Content"
                    }
                    NextDecision(
                        type = DecisionType.USE_CAPABILITY,
                        capabilityId = "open_settings",
                        reason = "Open settings with delayed transition"
                    )
                } else {
                    NextDecision(type = DecisionType.TASK_FAILED, reason = "Finish")
                }
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider
        )

        session.execute()

        val actionRes = session.recordedActionResults.firstOrNull()
        assertNotNull("Must record action result", actionRes)
        assertTrue("finalStateChanged must be true", actionRes!!.finalStateChanged)
        assertFalse("immediate change should be false before settle", actionRes.stateChangeObservedImmediately)
        assertTrue("stateChangeObservedDuringSettle must be true", actionRes.stateChangeObservedDuringSettle)
        assertTrue("settleWaitMs must be > 0", actionRes.settleWaitMs > 0)
    }

    @Test
    fun testScenarioI_BudgetExhaustionEnforcement() = runBlocking {
        // 1. maxStateChangingActions exhaustion
        val b1 = AgentBudget(maxStateChangingActions = 2)
        b1.stateChangingActionsExecuted = 2
        assertTrue("Must be exhausted when stateChangingActionsExecuted >= maxStateChangingActions", b1.isExhausted())

        // 2. maxObservationToolCalls exhaustion
        val b2 = AgentBudget(maxObservationToolCalls = 3)
        b2.observationToolCalls = 3
        assertTrue("Must be exhausted when observationToolCalls >= maxObservationToolCalls", b2.isExhausted())

        // 3. maxCapabilityCalls aggregate exhaustion
        val b3 = AgentBudget(maxCapabilityCalls = 4)
        b3.stateChangingActionsExecuted = 2
        b3.observationToolCalls = 2
        assertEquals(4, b3.capabilityCallsExecuted)
        assertTrue("Must be exhausted when capabilityCallsExecuted >= maxCapabilityCalls", b3.isExhausted())

        // 4. maxProviderRounds exhaustion
        val b4 = AgentBudget(maxProviderRounds = 2)
        b4.providerRounds = 2
        assertTrue("Must be exhausted when providerRounds >= maxProviderRounds", b4.isExhausted())

        // 5. maxObservationsSentToProvider exhaustion
        val b5 = AgentBudget(maxObservationsSentToProvider = 3)
        b5.observationsSentToProvider = 3
        assertTrue("Must be exhausted when observationsSentToProvider >= maxObservationsSentToProvider", b5.isExhausted())

        // 6. Test actual session termination on budget exhaustion
        val bridge = FakeBridgeForAccounting()
        val core = createCore(bridge)
        val goal = Goal(goalId = "g-exhaust", originalText = "test exhaust", objective = "exhaust")

        val provider = object : ReasoningProvider {
            override val name = "LoopingProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                return NextDecision(type = DecisionType.USE_CAPABILITY, capabilityId = "open_settings", reason = "loop")
            }
        }

        // Limit strictly to 2 state changing actions
        val budget = AgentBudget(maxStateChangingActions = 2, maxProviderRounds = 10)
        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            budget = budget
        )

        val result = session.execute()
        assertFalse(result.success)
        assertEquals(FailureReason.BUDGET_EXCEEDED, result.failureReason)
        assertEquals(2, budget.stateChangingActionsExecuted)
        assertTrue(budget.isExhausted())
    }
}
