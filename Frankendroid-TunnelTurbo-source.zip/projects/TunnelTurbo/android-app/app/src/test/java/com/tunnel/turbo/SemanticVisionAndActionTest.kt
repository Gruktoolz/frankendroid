package com.tunnel.turbo

import com.tunnel.turbo.accessibility.AccessibilityServiceState
import com.tunnel.turbo.accessibility.AccessibilitySnapshot
import com.tunnel.turbo.accessibility.UiNodeInfo
import com.tunnel.turbo.agent.*
import com.tunnel.turbo.worker.AiWorkerBridge
import com.tunnel.turbo.worker.DisplayBackendType
import com.tunnel.turbo.worker.WorkerDisplayManager
import com.tunnel.turbo.worker.WorkerLifecycle
import org.junit.Assert.*
import org.junit.Test

/**
 * Targeted Unit Tests for Gate A, B, C, D, E, F Acceptance Contracts:
 * - Gate A: Service health distinction (enabled vs connected vs crashed/blocked).
 * - Gate B & C: Single snapshot truth, consistency, and age.
 * - Gate D: Stable observation mapping and hit-testing semantics.
 * - Gate E: Semantic node action verification authority in GoalVerifier (no completion without evidence).
 * - Gate F: Worker launch truthfulness (fails closed on launch failure; no false READY state).
 */
class SemanticVisionAndActionTest {

    private val verifier = GoalVerifier()

    @Test
    fun gateA_serviceHealthDistinguishesConnectedFromEnabledOrCrashed() {
        // Connected state
        val connectedState = AccessibilityServiceState(
            isEnabled = true,
            isConnected = true,
            status = "CONNECTED",
            connectionCount = 1
        )
        assertTrue(connectedState.isConnected)
        assertEquals("CONNECTED", connectedState.status)

        // Crashed / Blocked state
        val crashedState = AccessibilityServiceState(
            isEnabled = true,
            isConnected = false,
            exitReason = "CRASH: SIGSEGV",
            status = "CRASHED/BLOCKED"
        )
        assertFalse(crashedState.isConnected)
        assertEquals("CRASHED/BLOCKED", crashedState.status)
        assertEquals("CRASH: SIGSEGV", crashedState.exitReason)

        // Enabled but not bound
        val unboundState = AccessibilityServiceState(
            isEnabled = true,
            isConnected = false,
            status = "ENABLED_NOT_BOUND"
        )
        assertFalse(unboundState.isConnected)
        assertEquals("ENABLED_NOT_BOUND", unboundState.status)
    }

    @Test
    fun gateB_singleSnapshotContainsConsistentMetricsAndDimensions() {
        val node1 = UiNodeInfo(
            nodeId = "node_0_1",
            className = "android.widget.Button",
            text = "Conectar",
            contentDescription = "",
            resourceId = "com.example:id/btn_connect",
            clickable = true,
            editable = false,
            scrollable = false,
            enabled = true,
            checked = false,
            selected = false,
            bounds = listOf(100, 200, 400, 300),
            displayId = 0
        )

        val snapshot = AccessibilitySnapshot(
            snapshotId = "snap_1001",
            capturedAtMs = System.currentTimeMillis() - 50,
            displayId = 0,
            displayWidth = 1220,
            displayHeight = 2712,
            displayRotation = 0,
            foregroundPackage = "com.android.settings",
            foregroundActivity = "com.android.settings.SettingsActivity",
            nodes = listOf(node1),
            actionableCount = 1
        )

        assertEquals("snap_1001", snapshot.snapshotId)
        assertEquals(1220, snapshot.displayWidth)
        assertEquals(2712, snapshot.displayHeight)
        assertEquals(1, snapshot.actionableCount)
        assertFalse("Snapshot under 50ms must not be stale", snapshot.isStale(10_000L))
        assertTrue(snapshot.getSnapshotAgeMs() >= 0)
    }

    @Test
    fun gateE_goalVerifierApprovesActionWithVerifiedReceipt() {
        val goal = Goal(
            goalId = "demo_act_1",
            originalText = "Tocar Conectar",
            objective = "Tocar botón Conectar",
            desiredState = "NODE_ACTION_COMPLETED",
            categoryHint = "SEMANTIC_NODE_ACTION"
        )

        val step = AgentStep(
            stepId = "step_1",
            goalId = goal.goalId,
            stepIndex = 1,
            decisionSource = DecisionSource.LOCAL_HEURISTIC,
            capability = "click_node",
            arguments = mapOf("selector" to mapOf("text" to "Conectar")),
            executionResult = mapOf("status" to "SUCCESS", "success" to true),
            observationBefore = "Conectar",
            observationAfter = "Conectado",
            verification = "Clic ejecutado con éxito",
            durationMs = 15.0
        )

        val evidence = GoalEvidence(
            foregroundPackage = "com.android.settings",
            visibleTexts = listOf("Conectado")
        )

        val result = verifier.verify(goal, evidence, listOf(step))

        assertEquals(GoalOutcome.COMPLETED_VERIFIED, result.outcome)
        assertTrue(result.satisfied)
        assertEquals(1.0, result.confidence, 0.01)
    }

    @Test
    fun gateE_goalVerifierRejectsActionWhenExecutionFailed() {
        val goal = Goal(
            goalId = "demo_act_2",
            originalText = "Tocar Conectar",
            objective = "Tocar botón Conectar",
            desiredState = "NODE_ACTION_COMPLETED",
            categoryHint = "SEMANTIC_NODE_ACTION"
        )

        val step = AgentStep(
            stepId = "step_1",
            goalId = goal.goalId,
            stepIndex = 1,
            decisionSource = DecisionSource.LOCAL_HEURISTIC,
            capability = "click_node",
            arguments = mapOf("selector" to mapOf("text" to "Conectar")),
            executionResult = mapOf("status" to "FAILED", "success" to false, "error" to "Node not found"),
            observationBefore = "",
            observationAfter = "",
            verification = "Fallo",
            durationMs = 12.0
        )

        val evidence = GoalEvidence()
        val result = verifier.verify(goal, evidence, listOf(step))

        assertEquals(GoalOutcome.FAILED, result.outcome)
        assertFalse(result.satisfied)
        assertEquals(0.0, result.confidence, 0.01)
    }

    @Test
    fun gateE_goalVerifierRejectsActionWhenNoStepsExecuted() {
        val goal = Goal(
            goalId = "demo_act_3",
            originalText = "Tocar Conectar",
            objective = "Tocar botón Conectar",
            desiredState = "NODE_ACTION_COMPLETED",
            categoryHint = "SEMANTIC_NODE_ACTION"
        )

        val evidence = GoalEvidence()
        val result = verifier.verify(goal, evidence, emptyList())

        assertEquals(GoalOutcome.FAILED, result.outcome)
        assertFalse(result.satisfied)
    }

    @Test
    fun gateF_workerBridgeFailsClosedOnLaunchFailure() {
        val mockDisplayManager = object : WorkerDisplayManager {
            override val backendType: DisplayBackendType = DisplayBackendType.PC_BACKEND
            override fun createWorkerDisplay(width: Int, height: Int, dpi: Int): Int? = 28
            override fun destroyWorkerDisplay() = Unit
            override fun getDisplayId(): Int? = 28
            override fun launchProviderApp(packageId: String): Boolean = false
            override fun healthCheck(): Boolean = true
        }

        val bridge = AiWorkerBridge(displayManager = mockDisplayManager)
        val started = bridge.start()
        assertFalse("Bridge start must return false when launcher fails", started)
        assertEquals("Bridge lifecycle must be STOPPED on failure", WorkerLifecycle.STOPPED, bridge.lifecycle)

        val health = bridge.checkOperationalHealth()
        assertFalse("Bridge must not report ready", health.isReady)
    }
}
