package com.tunnel.turbo

import com.tunnel.turbo.agent.Goal
import com.tunnel.turbo.agent.GoalRisk
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.fail
import org.junit.Test

class TrustBoundaryParsingTest {

    @Test
    fun unknownRiskDoesNotBecomeLowRisk() {
        val json = JSONObject().apply {
            put("goalId", "goal_test_1")
            put("originalText", "Format disk and wipe all data")
            put("objective", "WIPE_DATA")
            put("risk", "POTENTIALLY_CATASTROPHIC_UNKNOWN")
        }

        try {
            val goal = Goal.fromJson(json)
            // If it didn't throw, it MUST NOT be LOW_RISK
            assertNotEquals("Unknown risk must never default to LOW_RISK", GoalRisk.LOW_RISK, goal.risk)
            fail("Expected IllegalArgumentException for unknown risk at trust boundary, but got risk: ${goal.risk}")
        } catch (expected: IllegalArgumentException) {
            // Expected fail-closed behavior
        }
    }

    @Test
    fun missingRiskAtTrustBoundaryFailsClosed() {
        val json = JSONObject().apply {
            put("goalId", "goal_test_2")
            put("originalText", "Execute unknown command")
            put("objective", "EXECUTE_UNKNOWN")
            // Note: "risk" is missing
        }

        try {
            val goal = Goal.fromJson(json)
            assertNotEquals("Missing risk at trust boundary must not default to LOW_RISK", GoalRisk.LOW_RISK, goal.risk)
            fail("Expected IllegalArgumentException for missing risk at trust boundary, but got risk: ${goal.risk}")
        } catch (expected: IllegalArgumentException) {
            // Expected fail-closed behavior
        }
    }

    @Test
    fun validRiskIsPreservedExplicitly() {
        for (risk in GoalRisk.values()) {
            val json = JSONObject().apply {
                put("goalId", "goal_${risk.name}")
                put("originalText", "Sample test")
                put("objective", "SAMPLE")
                put("risk", risk.name)
            }
            val goal = Goal.fromJson(json)
            assertEquals("Valid risk ${risk.name} must be preserved", risk, goal.risk)
        }
    }
}
