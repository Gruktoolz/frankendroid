package com.tunnel.turbo

import com.tunnel.turbo.devtools.TunnelDevToolsBridge
import com.tunnel.turbo.local.CapabilityClass
import com.tunnel.turbo.local.CapturingLocalCognitiveEngine
import com.tunnel.turbo.local.LocalCognitiveEngineRegistry
import com.tunnel.turbo.local.LocalCognitiveInput
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class DevToolsCognitiveBridgeTest {

    private lateinit var bridge: TunnelDevToolsBridge

    @Before
    fun setUp() {
        LocalCognitiveEngineRegistry.resetToDefault()
        bridge = TunnelDevToolsBridge()
    }

    @After
    fun tearDown() {
        LocalCognitiveEngineRegistry.resetToDefault()
    }

    @Test
    fun testMalformedJsonBodyFailsClosed() {
        // Section 29 & 30: Malformed non-empty body MUST reject, not fall back to query param
        val malformedBody = "{\"userMessage\": \"incomplete JSON"
        val params = mapOf("userMessage" to "fallback should not happen")

        val res = bridge.handleEndpoint(
            method = "POST",
            path = "/debug_assess_turn",
            params = params,
            body = malformedBody,
            headers = mapOf("x-dev-session-token" to bridge.sessionToken)
        )

        assertEquals("error", res.optString("status"))
        assertEquals(400, res.optInt("httpStatusCode"))
        assertTrue(
            "Error must identify malformed JSON body",
            res.optString("error").contains("MALFORMED_JSON_BODY")
        )
    }

    @Test
    fun testEmptyBodyWithQueryParamWorks() {
        // Section 30: Backward compatibility for legacy query param when body is empty
        val params = mapOf("userMessage" to "abre los ajustes")

        val res = bridge.handleEndpoint(
            method = "GET",
            path = "/debug_assess_turn",
            params = params,
            body = "",
            headers = mapOf("x-dev-session-token" to bridge.sessionToken)
        )

        assertEquals("ok", res.optString("status"))
        assertTrue(res.has("assessment"))
        assertEquals("ACTION", res.getJSONObject("assessment").optString("interactionMode"))
    }

    @Test
    fun testEmptyBodyWithoutQueryParamFailsClosed() {
        // Missing both body and query param must return 400 Bad Request
        val res = bridge.handleEndpoint(
            method = "POST",
            path = "/debug_assess_turn",
            params = emptyMap(),
            body = "",
            headers = mapOf("x-dev-session-token" to bridge.sessionToken)
        )

        assertEquals("error", res.optString("status"))
        assertEquals(400, res.optInt("httpStatusCode"))
    }

    @Test
    fun testAllNineFieldsPassThroughToCapturingEngine() {
        // Section 18-24: 9-field sentinel pass-through to Capturing engine
        val capturingEngine = CapturingLocalCognitiveEngine()
        LocalCognitiveEngineRegistry.setEngine(capturingEngine)

        val sentinelBody = JSONObject().apply {
            put("userMessage", "SENTINEL_MSG_8842")
            put("conversationContextSummary", "SENTINEL_CONTEXT_8842")
            put("activeGoalSummary", "SENTINEL_GOAL_8842")
            put("activeWorkSummary", "SENTINEL_WORK_8842")
            put("currentForegroundPackage", "com.example.sentinel")
            put("availableCapabilityClasses", JSONArray(listOf("SYSTEM_SETTINGS", "GENERAL_CHAT")))
            put("recentProgressState", "PROGRESSING_NORMAL")
            put("unresolvedReferences", JSONArray(listOf("SENTINEL_REF_1", "SENTINEL_REF_2")))
            put("locale", "en-US")
        }

        val res = bridge.handleEndpoint(
            method = "POST",
            path = "/debug_assess_turn",
            params = emptyMap(),
            body = sentinelBody.toString(),
            headers = mapOf("x-dev-session-token" to bridge.sessionToken)
        )

        assertEquals("ok", res.optString("status"))
        assertTrue("Response must include receivedInput", res.has("receivedInput"))

        val captured = capturingEngine.lastCapturedInput
        assertNotNull("Capturing engine must have received an input", captured)

        assertEquals("SENTINEL_MSG_8842", captured!!.userMessage)
        assertEquals("SENTINEL_CONTEXT_8842", captured.conversationContextSummary)
        assertEquals("SENTINEL_GOAL_8842", captured.activeGoalSummary)
        assertEquals("SENTINEL_WORK_8842", captured.activeWorkSummary)
        assertEquals("com.example.sentinel", captured.currentForegroundPackage)
        assertEquals(listOf(CapabilityClass.SYSTEM_SETTINGS, CapabilityClass.GENERAL_CHAT), captured.availableCapabilityClasses)
        assertEquals("PROGRESSING_NORMAL", captured.recentProgressState)
        assertEquals(listOf("SENTINEL_REF_1", "SENTINEL_REF_2"), captured.unresolvedReferences)
        assertEquals("en-US", captured.locale)
    }
}
