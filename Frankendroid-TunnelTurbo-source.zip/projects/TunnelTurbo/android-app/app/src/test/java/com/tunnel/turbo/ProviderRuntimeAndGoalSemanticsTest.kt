package com.tunnel.turbo

import com.tunnel.turbo.agent.*
import com.tunnel.turbo.capability.Capability
import com.tunnel.turbo.worker.AiWorkerBridge
import com.tunnel.turbo.worker.ProviderFailureClass
import com.tunnel.turbo.worker.ProviderHealthReport
import com.tunnel.turbo.worker.ProviderHealthState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ProviderRuntimeAndGoalSemanticsTest {

    private val interpreter = GoalInterpreter()

    private fun dummySnapshot(goalId: String = "test-goal") = WorldSnapshot(
        goalId = goalId,
        foregroundPackage = "com.test",
        foregroundActivity = "MainActivity",
        candidateApps = emptyList(),
        reducedObservation = ReducedObservation(
            foregroundPackage = "com.test",
            foregroundActivity = "MainActivity",
            interactiveNodes = emptyList(),
            informativeText = "",
            metrics = ReductionMetrics(0, 0, 0, 0, 0.0)
        ),
        availableCapabilities = emptyList(),
        relevantSkills = emptyList()
    )

    @Test
    fun testGoalInterpreterPreservesClaudeGoalWithoutCorruption() {
        val originalGoal = "abre Claude y localiza cómo iniciar una conversación nueva, sin escribir ni enviar ningún mensaje"
        val interpreted = interpreter.interpret(originalGoal)

        // Must NOT invent "Tomar notas" or notes desired state
        assertNotEquals("Tomar notas", interpreted.objective)
        assertNotEquals("Aplicación de notas lista para escribir", interpreted.desiredState)

        // Preserves original human goal as objective
        assertEquals(originalGoal, interpreted.objective)

        // Recognizes negative constraints
        assertTrue("Expected negative constraint 'sin escribir' extracted in constraints",
            interpreted.constraints.any { it.contains("sin escribir", ignoreCase = true) }
        )

        // Target app entity extracted as Claude
        assertTrue("Expected app entity Claude",
            interpreted.entities.any { it.type == "app" && it.value.contains("Claude", ignoreCase = true) }
        )
    }

    @Test
    fun testGoalInterpreterPreservesUnfamiliarGoals() {
        val soundcoreGoal = "abre Soundcore y revisa el estado de conexión de los auriculares"
        val g1 = interpreter.interpret(soundcoreGoal)
        assertEquals(soundcoreGoal, g1.objective)
        assertTrue(g1.entities.any { it.type == "app" && it.value.contains("Soundcore", ignoreCase = true) })

        val zohoGoal = "abre Zoho CRM y revisa la lista de contactos recientes"
        val g2 = interpreter.interpret(zohoGoal)
        assertEquals(zohoGoal, g2.objective)
        assertTrue(g2.entities.any { it.type == "app" && it.value.contains("Zoho", ignoreCase = true) })

        val filesGoal = "abre Files y navega a la carpeta Descargas"
        val g3 = interpreter.interpret(filesGoal)
        assertEquals(filesGoal, g3.objective)
        assertTrue(g3.entities.any { it.type == "app" && it.value.contains("Files", ignoreCase = true) })
    }

    @Test
    fun testGoalInterpreterExplicitNotesImperative() {
        val notesGoal = "toma una nota: comprar leche y pan"
        val g = interpreter.interpret(notesGoal)
        assertEquals("Tomar notas", g.objective)
        assertEquals("PRODUCTIVITY", g.categoryHint)
    }

    @Test
    fun testProviderHealthReportReadySemantics() {
        val readyReport = ProviderHealthReport(
            state = ProviderHealthState.READY,
            isReady = true,
            displayId = 30,
            inputNodeAvailable = true,
            message = "Operational"
        )
        assertTrue(readyReport.isReady)
        assertEquals(ProviderHealthState.READY, readyReport.state)

        val unavailReport = ProviderHealthReport(
            state = ProviderHealthState.UI_UNAVAILABLE,
            isReady = false,
            message = "Input edit node not found"
        )
        assertFalse(unavailReport.isReady)
        assertNotEquals(ProviderHealthState.READY, unavailReport.state)
    }

    @Test
    fun testProviderRouterPrimarySuccess() = runBlocking {
        var primaryCalled = 0
        var fallbackCalled = 0

        val primary = object : ReasoningProvider {
            override val name = "PrimaryProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                primaryCalled++
                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "press_back",
                    reason = "Primary decided",
                    proofNonce = "nonce123"
                )
            }
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
        }

        val fallback = object : ReasoningProvider {
            override val name = "FallbackProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                fallbackCalled++
                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "press_home",
                    reason = "Fallback decided",
                    proofNonce = "nonce456"
                )
            }
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
        }

        val router = ProviderRouter(primaryProvider = primary, fallbackProvider = fallback)
        val goal = Goal(goalId = "test-goal-1", originalText = "Test goal", objective = "Test goal")
        val snapshot = dummySnapshot("test-goal-1")
        val budget = AgentBudget()

        val decision = router.decideNext(
            goal = goal,
            snapshot = snapshot,
            skills = emptyList(),
            capabilities = emptyList(),
            recentSteps = emptyList(),
            budget = budget,
            reason = AiRoundReason.INITIAL_PLAN
        )

        assertEquals(1, primaryCalled)
        assertEquals(0, fallbackCalled)
        assertEquals(DecisionType.USE_CAPABILITY, decision.type)
        assertEquals("press_back", decision.capabilityId)
    }

    @Test
    fun testProviderRouterFailoverToFallback() = runBlocking {
        var primaryHealthChecked = 0
        var fallbackCalled = 0

        val primary = object : ReasoningProvider {
            override val name = "UnhealthyPrimary"
            override suspend fun health(): ProviderHealthReport {
                primaryHealthChecked++
                return ProviderHealthReport(
                    state = ProviderHealthState.UI_UNAVAILABLE,
                    isReady = false,
                    message = "Worker UI missing"
                )
            }
            override suspend fun prepare() = false
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                throw IllegalStateException("Primary should not be called when unhealthy")
            }
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
        }

        val fallback = object : ReasoningProvider {
            override val name = "HealthyFallback"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                fallbackCalled++
                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "press_home",
                    reason = "Fallback executed safely",
                    proofNonce = "nonce_fallback"
                )
            }
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
        }

        val router = ProviderRouter(primaryProvider = primary, fallbackProvider = fallback)
        val goal = Goal(goalId = "test-failover-goal", originalText = "Failover goal", objective = "Failover goal")
        val snapshot = dummySnapshot("test-failover-goal")
        val budget = AgentBudget()

        // Disable strict mode so failover is exercised
        GeneralAgentRuntime.strictRealProviderMode = false

        val decision = router.decideNext(
            goal = goal,
            snapshot = snapshot,
            skills = emptyList(),
            capabilities = emptyList(),
            recentSteps = emptyList(),
            budget = budget,
            reason = AiRoundReason.INITIAL_PLAN
        )

        assertEquals(1, primaryHealthChecked)
        assertEquals(1, fallbackCalled)
        assertEquals(DecisionType.USE_CAPABILITY, decision.type)
        assertEquals("press_home", decision.capabilityId)
    }

    @Test
    fun testPromptInjectionMilestoneFailureDoesNotIncrementAiRounds() = runBlocking {
        ProviderCallRepository.clear()

        // Create an AndroidAiAppReasoningProvider with mock bridge that fails preflight
        val mockBridge = object : AiWorkerBridge() {
            override fun checkOperationalHealth(): ProviderHealthReport {
                return ProviderHealthReport(
                    state = ProviderHealthState.UI_UNAVAILABLE,
                    isReady = false,
                    message = "Synthetic UI not ready"
                )
            }
            override fun preflight(timeoutMs: Long): ProviderHealthReport {
                return ProviderHealthReport(
                    state = ProviderHealthState.UI_UNAVAILABLE,
                    isReady = false,
                    message = "Synthetic preflight failed"
                )
            }
        }

        val provider = AndroidAiAppReasoningProvider(
            workerBridge = mockBridge
        )

        val goal = Goal(goalId = "goal-milestone", originalText = "Milestone test", objective = "Milestone test")
        val snapshot = dummySnapshot("goal-milestone")
        val budget = AgentBudget()
        assertEquals(0, budget.aiRoundsUsed)

        provider.decideNext(
            goal = goal,
            snapshot = snapshot,
            skills = emptyList(),
            capabilities = emptyList(),
            recentSteps = emptyList(),
            budget = budget,
            reason = AiRoundReason.INITIAL_PLAN
        )

        assertEquals("AI rounds must NOT be incremented when prompt was not injected", 0, budget.aiRoundsUsed)

        val trace = ProviderCallRepository.getLastTrace()
        assertNotNull(trace)
        assertFalse(trace!!.promptInjected)
        assertFalse(trace.responseDetected)
        assertEquals(ProviderFailureClass.PROVIDER_UI_NOT_READY.name, trace.failureClass)
    }
}
