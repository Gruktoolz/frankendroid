package com.tunnel.turbo

import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.accessibility.UiNodeInfo
import com.tunnel.turbo.agent.*
import com.tunnel.turbo.capability.Capability
import com.tunnel.turbo.core.NativeTunnelCore
import com.tunnel.turbo.worker.ProviderHealthReport
import com.tunnel.turbo.worker.ProviderHealthState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class AgentSessionHardeningTest {

    class FakeAccessibilityBridge : AccessibilityBridge() {
        var display0Package = "com.example.target"
        var display0Activity = "TargetActivity"
        var display0Text = "Target Screen Content"
        var display0Nodes = listOf(
            UiNodeInfo(
                nodeId = "node_0",
                className = "android.widget.Button",
                text = "Target Button",
                contentDescription = "Target Button",
                resourceId = "btn_target",
                clickable = true,
                editable = false,
                scrollable = false,
                enabled = true,
                checked = false,
                selected = false,
                bounds = listOf(0, 0, 100, 100),
                displayId = 0
            )
        )

        var display30Package = "com.openai.chatgpt"
        var display30Activity = "ChatGPTActivity"
        var display30Text = "ChatGPT Conversation Content"
        var display30Nodes = listOf(
            UiNodeInfo(
                nodeId = "node_30",
                className = "android.widget.Button",
                text = "Send Message",
                contentDescription = "Send Message",
                resourceId = "btn_send",
                clickable = true,
                editable = false,
                scrollable = false,
                enabled = true,
                checked = false,
                selected = false,
                bounds = listOf(0, 0, 100, 100),
                displayId = 30
            )
        )

        override fun isEnabled(): Boolean = true

        override fun getForegroundPackage(displayId: Int): String {
            return if (displayId == 0) display0Package else if (displayId == 30) display30Package else ""
        }

        override fun getForegroundActivity(displayId: Int): String {
            return if (displayId == 0) display0Activity else if (displayId == 30) display30Activity else ""
        }

        override fun getVisibleText(displayId: Int): String {
            return if (displayId == 0) display0Text else if (displayId == 30) display30Text else ""
        }

        override fun getUiNodes(displayId: Int): List<UiNodeInfo> {
            return if (displayId == 0) display0Nodes else if (displayId == 30) display30Nodes else emptyList()
        }
    }

    private fun createTestCore(fakeBridge: FakeAccessibilityBridge): NativeTunnelCore {
        return NativeTunnelCore(
            context = null,
            workerBridge = null,
            customAccessibilityBridge = fakeBridge
        )
    }

    @Test
    fun testScenarioA_Display0SnapshotIsolation() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(
            pkg = "com.example.target",
            activity = "TargetActivity",
            displayId = 0
        )
        core.stateEngine.updateManualState(
            pkg = "com.openai.chatgpt",
            activity = "ChatGPTActivity",
            displayId = 30
        )

        val goal = Goal(goalId = "goal-iso-0", originalText = "interact target", objective = "target")
        val snapshot = core.agentRuntime.worldModel.createSnapshot(goal = goal, displayId = 0)

        assertEquals("Snapshot must belong to display 0", 0, snapshot.displayId)
        assertEquals("com.example.target", snapshot.foregroundPackage)
        assertEquals("TargetActivity", snapshot.foregroundActivity)
        assertNotEquals("Snapshot must never borrow package from display 30", "com.openai.chatgpt", snapshot.foregroundPackage)
    }

    @Test
    fun testScenarioB_WorkerDisplaySnapshotIsolation() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(
            pkg = "com.example.target",
            activity = "TargetActivity",
            displayId = 0
        )
        core.stateEngine.updateManualState(
            pkg = "com.openai.chatgpt",
            activity = "ChatGPTActivity",
            displayId = 30
        )

        val goal = Goal(goalId = "goal-iso-30", originalText = "check worker", objective = "worker")
        val snapshot = core.agentRuntime.worldModel.createSnapshot(goal = goal, displayId = 30)

        assertEquals("Snapshot must belong to display 30", 30, snapshot.displayId)
        assertEquals("com.openai.chatgpt", snapshot.foregroundPackage)
        assertEquals("ChatGPTActivity", snapshot.foregroundActivity)
        assertNotEquals("Worker display snapshot must never borrow package from display 0", "com.example.target", snapshot.foregroundPackage)
    }

    @Test
    fun testScenarioC_GlobalLatestEventContamination() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(
            pkg = "com.example.target",
            activity = "TargetActivity",
            displayId = 0
        )

        // Simulate latest stateEngine event arriving from Display 30 immediately before Display 0 snapshot
        core.stateEngine.updateManualState(
            pkg = "com.openai.chatgpt",
            activity = "ChatGPTActivity",
            displayId = 30
        )

        val goal = Goal(goalId = "goal-event-contam", originalText = "test contam", objective = "contam")
        val snapshot = core.agentRuntime.worldModel.createSnapshot(goal = goal, displayId = 0)

        assertEquals("Display 0 snapshot displayId must be 0", 0, snapshot.displayId)
        assertEquals("Display 0 snapshot must remain com.example.target", "com.example.target", snapshot.foregroundPackage)
        assertNotEquals("Display 0 snapshot must not be contaminated by latest Display 30 event", "com.openai.chatgpt", snapshot.foregroundPackage)
    }

    @Test
    fun testScenarioD_StateChangedDisplayIsolation() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(
            pkg = "com.example.target",
            activity = "TargetActivity",
            displayId = 0
        )
        core.stateEngine.updateManualState(
            pkg = "com.openai.chatgpt",
            activity = "ChatGPTActivity",
            displayId = 30
        )

        val goal = Goal(goalId = "goal-state-changed", originalText = "do something", objective = "target")

        var turn = 0
        val provider = object : ReasoningProvider {
            override val name = "IsolationTestProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                turn++
                budget.providerRounds++
                return if (turn == 1) {
                    NextDecision(
                        type = DecisionType.USE_CAPABILITY,
                        capabilityId = "press_back",
                        arguments = emptyMap(),
                        reason = "Press back on display 0",
                        decisionSource = DecisionSource.REAL_PROVIDER
                    )
                } else {
                    NextDecision(
                        type = DecisionType.TASK_FAILED,
                        reason = "Done test",
                        decisionSource = DecisionSource.REAL_PROVIDER
                    )
                }
            }
        }

        // When press_back executes on display 0, simulate worker display 30 mutating while display 0 is completely unchanged
        fakeBridge.display30Text = "ChatGPT mutated text during action"
        fakeBridge.display30Package = "com.openai.chatgpt.updated"

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            displayId = 0
        )

        session.execute()

        val actionResult = session.recordedActionResults.firstOrNull()
        assertNotNull("Expected actionResult recorded", actionResult)
        assertFalse("Display 0 ActionResult.stateChanged must be false when only display 30 changed", actionResult!!.stateChanged)
    }

    @Test
    fun testScenarioE_ProgressUnknown() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(
            pkg = "com.example.target",
            activity = "TargetActivity",
            displayId = 0
        )

        val goal = Goal(goalId = "goal-progress-unknown", originalText = "check unknown progress", objective = "target")

        val provider = object : ReasoningProvider {
            override val name = "ProgressUnknownProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                return NextDecision(
                    type = DecisionType.TASK_FAILED,
                    reason = "Stop immediately after initial observation",
                    decisionSource = DecisionSource.REAL_PROVIDER
                )
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            displayId = 0
        )

        session.execute()

        // Verify PROGRESS_UNKNOWN was logged for initial observation
        val unknownEvents = session.events.filter { it.type == SessionEventType.PROGRESS_UNKNOWN }
        val noProgressEvents = session.events.filter { it.type == SessionEventType.NO_PROGRESS }

        assertTrue("Initial observation must log PROGRESS_UNKNOWN", unknownEvents.isNotEmpty())
        assertEquals("Initial observation must NOT log NO_PROGRESS", 0, noProgressEvents.size)
        assertEquals("Stuck detector consecutiveNoProgressCount must NOT increment on initial observation", 0, session.stuckDetector.consecutiveNoProgressCount)
    }

    @Test
    fun testScenarioF_AskUserResume() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        fakeBridge.display0Package = "com.android.launcher"
        fakeBridge.display0Activity = "LauncherActivity"
        fakeBridge.display0Text = "Home Screen"

        core.stateEngine.updateManualState(
            pkg = "com.android.launcher",
            activity = "LauncherActivity",
            displayId = 0
        )

        val goal = Goal(
            goalId = "goal-resume-test",
            originalText = "abre fotos",
            objective = "Abrir galería de fotos",
            categoryHint = "PHOTOS_GALLERY",
            desiredState = "foto"
        )

        var turn = 0
        var receivedClarification: String? = null

        val provider = object : ReasoningProvider {
            override val name = "ResumableProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                turn++
                budget.providerRounds++
                return when (turn) {
                    1 -> NextDecision(
                        type = DecisionType.ASK_USER,
                        userQuestion = "Which option do you prefer?",
                        reason = "Need clarification from user",
                        decisionSource = DecisionSource.REAL_PROVIDER
                    )
                    2 -> {
                        // Extract clarification from recentSteps
                        val userStep = recentSteps.lastOrNull { it.capability == "user_clarification" }
                        receivedClarification = userStep?.arguments?.get("response")?.toString()

                        // Simulate target state reached after user clarification action
                        fakeBridge.display0Package = "com.google.android.apps.photos"
                        fakeBridge.display0Activity = "PhotosActivity"
                        fakeBridge.display0Text = "Photos and Albums"
                        core.stateEngine.updateManualState(
                            pkg = "com.google.android.apps.photos",
                            activity = "PhotosActivity",
                            displayId = 0
                        )

                        NextDecision(
                            type = DecisionType.USE_CAPABILITY,
                            capabilityId = "press_back",
                            arguments = emptyMap(),
                            reason = "Navigate following clarification: $receivedClarification",
                            decisionSource = DecisionSource.REAL_PROVIDER
                        )
                    }
                    else -> NextDecision(
                        type = DecisionType.TASK_COMPLETE,
                        reason = "Target reached following clarification",
                        decisionSource = DecisionSource.REAL_PROVIDER,
                        proofNonce = "resume_nonce"
                    )
                }
            }
        }

        val budget = AgentBudget.forProfile(BudgetProfile.STANDARD_INTERACTIVE)
        val initialMaxRounds = budget.maxAiRounds

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            displayId = 0,
            budget = budget
        )

        // Register session in runtime
        core.agentRuntime.sessionsById[session.sessionId] = session

        // Phase 1: Execute initial run -> should pause on ASK_USER
        val pauseResult = session.execute()
        assertEquals(GoalOutcome.NEEDS_USER, pauseResult.outcome)
        assertEquals(FailureReason.USER_INPUT_REQUIRED, pauseResult.failureReason)
        val originalSessionId = session.sessionId
        val originalGoalId = session.goal.goalId
        assertEquals(1, session.budget.providerRounds)
        assertEquals(1, turn)

        // Phase 2: Resume SAME session using runtime.resumeSession
        val resumeResult = core.agentRuntime.resumeSession(originalSessionId, "Option B selected")

        assertTrue("Resume result must succeed", resumeResult.success)
        assertEquals("Session ID must be identical after resumption", originalSessionId, resumeResult.sessionId)
        assertEquals("Goal ID must be identical after resumption", originalGoalId, resumeResult.goalId)
        assertTrue("Provider rounds must continue rather than reset (expected >= 2, got ${session.budget.providerRounds})", session.budget.providerRounds >= 2)
        assertEquals("Budget profile limits must be preserved", initialMaxRounds, session.budget.maxAiRounds)
        assertEquals("Clarification must reach provider", "Option B selected", receivedClarification)
        assertTrue("Session must contain recorded steps from both turns", session.recordedSteps.size >= 2)

        val clarificationStep = session.recordedSteps.firstOrNull { it.capability == "user_clarification" }
        assertNotNull("Must record clarification step", clarificationStep)
        assertEquals("User clarification step must have DecisionSource.USER provenance", DecisionSource.USER, clarificationStep!!.decisionSource)
    }

    // ======================================================================
    // PHASE 13B-1.1a HARDENING TESTS
    // ======================================================================

    @Test
    fun testHardenA_Display0WindowFallback() {
        val window31 = org.mockito.Mockito.mock(android.view.accessibility.AccessibilityWindowInfo::class.java)
        org.mockito.Mockito.`when`(window31.displayId).thenReturn(31)

        val allWindows = listOf(window31)
        val filtered = com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.filterWindowsForDisplay(allWindows, 0)

        assertTrue("Display 0 window lookup must return empty list when no display 0 windows exist", filtered.isEmpty())
        assertFalse("Display 0 must NEVER return window belonging to display 31", filtered.contains(window31))
    }

    @Test
    fun testHardenB_GlobalCurrentStateStability() {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(
            pkg = "com.example.target",
            activity = "TargetActivity",
            displayId = 0
        )
        assertEquals("com.example.target", core.stateEngine.currentState.foregroundPackage)
        assertEquals(0, core.stateEngine.currentState.displayId)

        // Simulate accessibility event arriving from display 31 with ChatGPT
        val event31 = org.mockito.Mockito.mock(android.view.accessibility.AccessibilityEvent::class.java)
        org.mockito.Mockito.`when`(event31.eventType).thenReturn(android.view.accessibility.AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)
        org.mockito.Mockito.`when`(event31.packageName).thenReturn("com.openai.chatgpt")
        org.mockito.Mockito.`when`(event31.className).thenReturn("ChatGPTActivity")
        org.mockito.Mockito.`when`(event31.displayId).thenReturn(31)

        core.stateEngine.handleAccessibilityEvent(event31)

        // Verified contract: Display 31 state updated, but Display 0 currentState remains com.example.target
        assertEquals("com.openai.chatgpt", core.stateEngine.getStateForDisplay(31).foregroundPackage)
        assertEquals("com.example.target", core.stateEngine.getStateForDisplay(0).foregroundPackage)
        assertEquals("Display 0 compatibility currentState must remain com.example.target", "com.example.target", core.stateEngine.currentState.foregroundPackage)
        assertEquals("currentState displayId must remain 0", 0, core.stateEngine.currentState.displayId)
        assertEquals("latestEventState tracks the newest event from display 31", "com.openai.chatgpt", core.stateEngine.latestEventState.foregroundPackage)
    }

    @Test
    fun testHardenC_UpdateManualStateNonDefaultDisplay() {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(
            pkg = "com.example.target",
            activity = "TargetActivity",
            displayId = 0
        )
        assertEquals("com.example.target", core.stateEngine.currentState.foregroundPackage)

        // Update manual state on display 31
        core.stateEngine.updateManualState(
            pkg = "com.example.worker",
            activity = "WorkerActivity",
            displayId = 31
        )

        assertEquals("com.example.worker", core.stateEngine.getStateForDisplay(31).foregroundPackage)
        assertEquals("com.example.target", core.stateEngine.getStateForDisplay(0).foregroundPackage)
        assertEquals("Display 0 currentState must be completely untouched by display 31 manual update", "com.example.target", core.stateEngine.currentState.foregroundPackage)
        assertEquals(0, core.stateEngine.currentState.displayId)
    }

    @Test
    fun testHardenD_UserClarificationProvenance() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        val goal = Goal(goalId = "goal-prov-test", originalText = "configure", objective = "configure")
        var resumed = false

        val provider = object : ReasoningProvider {
            override val name = "ProvProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                return if (!resumed) {
                    NextDecision(
                        type = DecisionType.ASK_USER,
                        userQuestion = "Please clarify",
                        reason = "Need input"
                    )
                } else {
                    NextDecision(
                        type = DecisionType.TASK_FAILED,
                        reason = "Finished test"
                    )
                }
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            displayId = 0
        )

        val pauseResult = session.execute()
        assertEquals(GoalOutcome.NEEDS_USER, pauseResult.outcome)

        resumed = true
        session.resume("User specified parameter X")

        val step = session.recordedSteps.firstOrNull { it.capability == "user_clarification" }
        assertNotNull("Clarification step must be recorded", step)
        assertEquals("Decision source must be USER", DecisionSource.USER, step!!.decisionSource)
        assertNotEquals("Decision source must NOT be LOCAL_HEURISTIC", DecisionSource.LOCAL_HEURISTIC, step.decisionSource)
    }

    @Test
    fun testHardenE_StructuredObservationTrace() = runBlocking {
        val fakeBridge = FakeAccessibilityBridge()
        val core = createTestCore(fakeBridge)

        core.stateEngine.updateManualState(pkg = "com.test.app", activity = "MainActivity", displayId = 0)
        val goal = Goal(goalId = "goal-trace-test", originalText = "trace test", objective = "trace")

        val provider = object : ReasoningProvider {
            override val name = "TraceProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                return NextDecision(type = DecisionType.TASK_FAILED, reason = "End trace test")
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            displayId = 0
        )

        session.execute()

        val obsEvents = session.events.filter { it.type == SessionEventType.OBSERVATION_CAPTURED }
        assertTrue("Must record OBSERVATION_CAPTURED events", obsEvents.isNotEmpty())

        for (obs in obsEvents) {
            assertNotNull("Structured snapshotRevision must not be null", obs.snapshotRevision)
            assertEquals("Structured displayId must be 0", 0, obs.displayId)
            assertNotNull("Structured foregroundPackage must not be null", obs.foregroundPackage)
            assertEquals("com.example.target", obs.foregroundPackage)

            val json = obs.toJson()
            assertTrue("JSON must contain displayId", json.has("displayId"))
            assertEquals(0, json.getInt("displayId"))
            assertTrue("JSON must contain foregroundPackage", json.has("foregroundPackage"))
            assertEquals("com.example.target", json.getString("foregroundPackage"))
            assertTrue("JSON must contain snapshotRevision", json.has("snapshotRevision"))
        }
    }
}
