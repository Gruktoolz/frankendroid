package com.tunnel.turbo

import com.tunnel.turbo.chat.ChatBackend
import com.tunnel.turbo.chat.ChatMessage
import com.tunnel.turbo.chat.ConversationRuntime
import com.tunnel.turbo.chat.LocalChatEngine
import com.tunnel.turbo.chat.LocalChatSession
import com.tunnel.turbo.coordinator.IntentCoordinator
import com.tunnel.turbo.local.InteractionMode
import com.tunnel.turbo.local.LocalCognitiveAssessment
import com.tunnel.turbo.local.LocalCognitiveEngine
import com.tunnel.turbo.local.LocalCognitiveInput
import com.tunnel.turbo.local.LocalSufficiency
import com.tunnel.turbo.local.TaskDomain
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

/**
 * RED Tests for Phase 13C-0 Local Chat Routing & Isolation Contracts.
 * Enforces the strict invariant: CHAT NEVER EXECUTES ANDROID ACTIONS.
 */
class LocalChatRoutingAndContractTest {

    private lateinit var fakeChatEngine: FakeCapturingChatEngine
    private lateinit var conversationRuntime: ConversationRuntime
    private lateinit var fakeCognitiveEngine: FakeCognitiveEngine
    private lateinit var spyActionCounter: SpyAndroidActionCounter

    @Before
    fun setup() {
        fakeChatEngine = FakeCapturingChatEngine()
        conversationRuntime = ConversationRuntime(fakeChatEngine)
        fakeCognitiveEngine = FakeCognitiveEngine()
        spyActionCounter = SpyAndroidActionCounter()
    }

    @After
    fun tearDown() {
        conversationRuntime.close()
    }

    @Test
    fun chatTurnNeverInvokesAndroidExecution() = runBlocking {
        // Given: turn classified as CHAT
        fakeCognitiveEngine.nextAssessment = createAssessment(InteractionMode.CHAT)
        fakeChatEngine.loadModel("/mock/path", ChatBackend.CPU)
        fakeChatEngine.queuedResponse = "ADB es el Android Debug Bridge."

        // When: chat turn is processed through the conversation runtime / coordinator routing
        val result = conversationRuntime.submitTurn("¿Qué es ADB?")

        // Then:
        assertTrue("Chat turn must succeed", result.isSuccess)
        assertEquals("ADB es el Android Debug Bridge.", result.getOrNull())
        assertEquals("One streamed chunk is not a verified token count", 1, conversationRuntime.lastTurnMetrics?.outputChunks)
        assertEquals("Token count is unavailable without native benchmark data", null, conversationRuntime.lastTurnMetrics?.outputTokens)
        assertEquals("Token throughput is unavailable without native benchmark data", null, conversationRuntime.lastTurnMetrics?.decodeTokensPerSecond)

        // HARD INVARIANT ASSERTIONS:
        assertEquals("AgentSession execution count MUST BE ZERO for CHAT turn", 0, spyActionCounter.agentSessionExecutionCount.get())
        assertEquals("Capability execution count MUST BE ZERO for CHAT turn", 0, spyActionCounter.capabilityExecutionCount.get())
        assertEquals("Display mutation lease acquisition count MUST BE ZERO for CHAT turn", 0, spyActionCounter.mutationLeaseAcquisitionCount.get())
        assertEquals("LocalChatEngine session count should be 1", 1, fakeChatEngine.sessionStartCount.get())
    }

    @Test
    fun actionTurnDoesNotInvokeLocalChatEngine() = runBlocking {
        // Given: turn classified as ACTION
        fakeCognitiveEngine.nextAssessment = createAssessment(InteractionMode.ACTION)
        fakeChatEngine.loadModel("/mock/path", ChatBackend.CPU)

        // When: action turn is processed
        // In the routing coordinator:
        val assessment = fakeCognitiveEngine.assessTurn(LocalCognitiveInput(userMessage = "Abre ajustes"))
        if (assessment.interactionMode == InteractionMode.ACTION) {
            spyActionCounter.recordActionExecution()
        } else {
            conversationRuntime.submitTurn("Abre ajustes")
        }

        // Then:
        assertEquals("Action count should be 1", 1, spyActionCounter.agentSessionExecutionCount.get())
        assertEquals("LocalChatEngine message count MUST BE ZERO for ACTION turn", 0, fakeChatEngine.sentMessages.size)
    }

    @Test
    fun secondTurnContextIsRetained() = runBlocking {
        // Given: A loaded model and session
        fakeChatEngine.loadModel("/mock/path", ChatBackend.CPU)
        fakeChatEngine.queuedResponse = "Respuesta 1"

        // Turn 1
        val res1 = conversationRuntime.submitTurn("Explícame brevemente qué es ADB.")
        assertTrue(res1.isSuccess)

        // Turn 2
        fakeChatEngine.queuedResponse = "Respuesta 2 más corta"
        val res2 = conversationRuntime.submitTurn("Ahora dilo más corto.")
        assertTrue(res2.isSuccess)

        // Then: Bounded conversation history has 4 messages (2 user + 2 assistant)
        val history = conversationRuntime.messages.value
        assertEquals(4, history.size)
        assertEquals(ChatMessage.MessageRole.USER, history[0].role)
        assertEquals("Explícame brevemente qué es ADB.", history[0].text)
        assertEquals(ChatMessage.MessageRole.ASSISTANT, history[1].role)
        assertEquals("Respuesta 1", history[1].text)
        assertEquals(ChatMessage.MessageRole.USER, history[2].role)
        assertEquals("Ahora dilo más corto.", history[2].text)
        assertEquals(ChatMessage.MessageRole.ASSISTANT, history[3].role)
        assertEquals("Respuesta 2 más corta", history[3].text)

        // Engine received both turns in sequence
        assertEquals(2, fakeChatEngine.sentMessages.size)
        assertEquals("Explícame brevemente qué es ADB.", fakeChatEngine.sentMessages[0])
        assertEquals("Ahora dilo más corto.", fakeChatEngine.sentMessages[1])
    }

    @Test
    fun chatCancellationStopsGenerationGracefully() = runBlocking {
        fakeChatEngine.loadModel("/mock/path", ChatBackend.CPU)
        fakeChatEngine.queuedResponse = "Respuesta muy larga..."

        // Submit turn and immediately cancel
        val job = launch {
            conversationRuntime.submitTurn("Escribe un ensayo")
        }
        kotlinx.coroutines.delay(20)
        conversationRuntime.cancelGeneration()
        job.join()

        // State remains usable
        assertNotNull(conversationRuntime.sessionState.value)
    }

    @Test
    fun generalizationDifferentChatInputsNeverTriggerSideEffects() = runBlocking {
        fakeChatEngine.loadModel("/mock/path", ChatBackend.CPU)
        val chatVariations = listOf(
            "hola qué tal",
            "buenos días asistente",
            "¿cómo funciona la memoria RAM?",
            "reescribe este texto en tono formal",
            "hazlo más breve por favor",
            "cuéntame un chiste de programadores",
            "gracias por la ayuda"
        )

        for (prompt in chatVariations) {
            fakeChatEngine.queuedResponse = "Respuesta a: $prompt"
            val result = conversationRuntime.submitTurn(prompt)
            assertTrue("Prompt '$prompt' should succeed", result.isSuccess)

            // Property: For EVERY CHAT turn, side effects remain strictly 0
            assertEquals("Side effect count must remain 0 for prompt: $prompt", 0, spyActionCounter.capabilityExecutionCount.get())
            assertEquals("Mutation count must remain 0 for prompt: $prompt", 0, spyActionCounter.mutationLeaseAcquisitionCount.get())
            assertEquals("AgentSession count must remain 0 for prompt: $prompt", 0, spyActionCounter.agentSessionExecutionCount.get())
        }
    }

    // --- Test Doubles ---

    private class FakeCapturingChatEngine : LocalChatEngine {
        override var isModelLoaded: Boolean = false
        override var loadedModelPath: String? = null
        override var backend: ChatBackend = ChatBackend.CPU

        val sessionStartCount = AtomicInteger(0)
        val sentMessages = mutableListOf<String>()
        var queuedResponse: String = "Fake response"
        private var activeSession: FakeChatSession? = null

        override suspend fun loadModel(modelPath: String, backend: ChatBackend): Boolean {
            isModelLoaded = true
            loadedModelPath = modelPath
            this.backend = backend
            return true
        }

        override suspend fun startSession(profile: com.tunnel.turbo.chat.LocalChatProfile, systemPrompt: String?): LocalChatSession {
            sessionStartCount.incrementAndGet()
            val sess = FakeChatSession(this)
            activeSession = sess
            return sess
        }

        override fun close() {
            isModelLoaded = false
            loadedModelPath = null
            activeSession = null
        }
    }

    private class FakeChatSession(private val engine: FakeCapturingChatEngine) : LocalChatSession {
        override val sessionId: String = "fake-session-1"

        override fun sendMessage(text: String): Flow<String> {
            engine.sentMessages.add(text)
            return flowOf(engine.queuedResponse)
        }

        override suspend fun sendSingleMessage(text: String): String {
            engine.sentMessages.add(text)
            return engine.queuedResponse
        }

        override fun close() {}
    }

    private class FakeCognitiveEngine : LocalCognitiveEngine {
        override val modelId: String = "fake-cognitive-v1"
        override val backend: String = "JVM_FAKE"
        var nextAssessment: LocalCognitiveAssessment = createAssessment(InteractionMode.CHAT)

        override suspend fun assessTurn(input: LocalCognitiveInput): LocalCognitiveAssessment {
            return nextAssessment
        }
    }

    private class SpyAndroidActionCounter {
        val agentSessionExecutionCount = AtomicInteger(0)
        val capabilityExecutionCount = AtomicInteger(0)
        val mutationLeaseAcquisitionCount = AtomicInteger(0)

        fun recordActionExecution() {
            agentSessionExecutionCount.incrementAndGet()
            capabilityExecutionCount.incrementAndGet()
            mutationLeaseAcquisitionCount.incrementAndGet()
        }
    }

    companion object {
        fun createAssessment(mode: InteractionMode): LocalCognitiveAssessment {
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = mode,
                taskDomain = if (mode == InteractionMode.CHAT) TaskDomain.CONVERSATIONAL else TaskDomain.SYSTEM_SETTINGS,
                localSufficiency = LocalSufficiency.LOCAL_PREFERRED
            )
        }
    }
}
