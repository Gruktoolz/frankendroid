package com.tunnel.turbo

import com.tunnel.turbo.adapter.TunnelCoreAdapter
import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.model.PlanValidationError
import com.tunnel.turbo.model.PlanValidator
import com.tunnel.turbo.model.SequencePlan
import com.tunnel.turbo.provider.*
import com.tunnel.turbo.router.LocalIntentRouter
import com.tunnel.turbo.router.RouteDecision
import com.tunnel.turbo.worker.WorkerSession
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class ProviderRuntimeTest {

    @Test
    fun testLocalIntentRouterDirectMatches() {
        val router = LocalIntentRouter()

        val r1 = router.route("Abre Wi-Fi.")
        assertEquals(RouteDecision.DIRECT, r1.decision)
        assertTrue(r1.directPlan is ActionPlan)
        assertEquals("open_wifi_settings", (r1.directPlan as ActionPlan).action)

        val r1b = router.route("Wi-Fi")
        assertEquals(RouteDecision.DIRECT, r1b.decision)
        assertEquals("open_wifi_settings", (r1b.directPlan as ActionPlan).action)

        val r2 = router.route("Abre Bluetooth")
        assertEquals(RouteDecision.DIRECT, r2.decision)
        assertEquals("open_bluetooth_settings", (r2.directPlan as ActionPlan).action)

        val r2b = router.route("Bluetooth")
        assertEquals(RouteDecision.DIRECT, r2b.decision)
        assertEquals("open_bluetooth_settings", (r2b.directPlan as ActionPlan).action)

        val r3 = router.route("Abre ajustes")
        assertEquals(RouteDecision.DIRECT, r3.decision)
        assertEquals("open_settings", (r3.directPlan as ActionPlan).action)

        val r3b = router.route("Ajustes")
        assertEquals(RouteDecision.DIRECT, r3b.decision)
        assertEquals("open_settings", (r3b.directPlan as ActionPlan).action)

        val r4 = router.route("Regresa")
        assertEquals(RouteDecision.DIRECT, r4.decision)
        assertEquals("press_back", (r4.directPlan as ActionPlan).action)

        val r5 = router.route("Inicio")
        assertEquals(RouteDecision.DIRECT, r5.decision)
        assertEquals("press_home", (r5.directPlan as ActionPlan).action)
    }

    @Test
    fun testAiRequiredFailsClosedAndNeverDispatchesWifi() = runBlocking {
        val coreAdapter = TunnelCoreAdapter()
        // Provide runtime with no active provider
        val runtime = ProviderRuntime(activeProvider = null, coreAdapter = coreAdapter)

        val res = runtime.processUserIntent("Escribe un mensaje amable")
        assertEquals(RouteDecision.AI_REQUIRED, res.routeDecision)
        assertFalse(res.success)
        assertNull(res.executionResult)
        // Must NOT execute open_wifi_settings
        assertNotEquals("open_wifi_settings", (res.plan as? ActionPlan)?.action)
        assertTrue(res.error!!.contains("AI_PROVIDER_UNAVAILABLE"))
    }

    @Test
    fun testLocalIntentRouterComplexRequiresAi() {
        val router = LocalIntentRouter()

        val r1 = router.route("Abre los ajustes de Wi-Fi y después vuelve atrás.")
        assertEquals(RouteDecision.AI_REQUIRED, r1.decision)
        assertNull(r1.directPlan)

        val r2 = router.route("Busca cuál app consume más batería")
        assertEquals(RouteDecision.AI_REQUIRED, r2.decision)
    }

    @Test
    fun testLocalIntentRouterRejectsAttacks() {
        val router = LocalIntentRouter()

        val r1 = router.route("rm -rf /sdcard")
        assertEquals(RouteDecision.UNSUPPORTED, r1.decision)

        val r2 = router.route("input tap 100 200")
        assertEquals(RouteDecision.UNSUPPORTED, r2.decision)
    }

    @Test
    fun testPlanValidatorStrictAllowlist() {
        val validator = PlanValidator()

        // Valid single action
        val validJson = JSONObject("{\"type\": \"action\", \"action\": \"open_wifi_settings\", \"arguments\": {}}")
        val plan = validator.validate(validJson)
        assertTrue(plan is ActionPlan)
        assertEquals("open_wifi_settings", (plan as ActionPlan).action)

        // Disallowed action
        val badJson = JSONObject("{\"type\": \"action\", \"action\": \"execute_shell\", \"arguments\": {}}")
        try {
            validator.validate(badJson)
            fail("Expected PlanValidationError for disallowed action")
        } catch (e: Exception) {
            assertTrue(e.message!!.contains("UNAUTHORIZED_ACTION"))
        }

        // Sequence
        val seqJson = JSONObject("{\"type\": \"sequence\", \"steps\": [{\"action\": \"open_wifi_settings\"}, {\"action\": \"press_back\"}]}")
        val seqPlan = validator.validate(seqJson)
        assertTrue(seqPlan is SequencePlan)
        assertEquals(2, (seqPlan as SequencePlan).steps.size)
    }

    @Test
    fun testProviderErrorClassifierRateLimit() {
        val classifier = ProviderErrorClassifier()

        val e1 = classifier.classify("Too many requests, please slow down")
        assertEquals(ProviderErrorKind.RATE_LIMITED, e1.kind)
        assertTrue(e1.retryable)

        val e2 = classifier.classify("Rate limit exceeded")
        assertEquals(ProviderErrorKind.RATE_LIMITED, e2.kind)

        val e3 = classifier.classify("Network error occurred")
        assertEquals(ProviderErrorKind.NETWORK_ERROR, e3.kind)
    }

    @Test
    fun testRateLimitPolicyPreventsRetryStorm() {
        val policy = RateLimitPolicy(baseCooldownMs = 1000L, maxCooldownMs = 5000L, maxAutoRetries = 1)
        assertTrue(policy.canAttempt())

        policy.recordRateLimit()
        assertEquals(1, policy.consecutiveRateLimits)
        assertFalse(policy.canAttempt())

        // Immediate retry blocked
        assertFalse(policy.shouldAutoRetry(attemptCount = 1))
        assertFalse(policy.shouldAutoRetry(attemptCount = 2))

        // Reset on success
        policy.recordSuccess()
        assertEquals(0, policy.consecutiveRateLimits)
        assertTrue(policy.canAttempt())
    }

    @Test
    fun testIntentRequestQueueFifo() {
        val queue = IntentRequestQueue()
        val r1 = IntentRequest("TT_000001", "Abre Wi-Fi")
        val r2 = IntentRequest("TT_000002", "Abre Bluetooth")

        queue.enqueue(r1)
        queue.enqueue(r2)
        assertEquals(2, queue.size)

        val popped = queue.pollNext()
        assertEquals("TT_000001", popped?.requestId)
        assertEquals(1, queue.size)
    }

    @Test
    fun testWorkerSessionPersistenceAndRotation() {
        val session = WorkerSession(maxTurnsPerWorker = 30)
        val id1 = session.nextRequestId()
        val id2 = session.nextRequestId()

        assertEquals("TT_000001", id1)
        assertEquals("TT_000002", id2)
        assertEquals(2, session.turnsUsed)
        assertEquals(1, session.conversationGeneration)
        assertFalse(session.needsRotation())

        session.turnsUsed = 30
        assertTrue(session.needsRotation())
        session.rotateConversation()
        assertEquals(2, session.conversationGeneration)
        assertEquals(0, session.turnsUsed)
    }

    @Test
    fun testDirectCommandWorksWhileProviderRateLimited() = runBlocking {
        // Critical Section 34 requirement:
        // Provider RATE_LIMITED + LocalIntent DIRECT must continue functioning!
        val coreAdapter = TunnelCoreAdapter()
        val runtime = ProviderRuntime(coreAdapter = coreAdapter)

        // Force provider into RATE_LIMITED
        runtime.rateLimitPolicy.recordRateLimit()
        runtime.health.state = ProviderState.RATE_LIMITED
        runtime.health.rateLimited = true

        // 1. Direct local command ("Abre Wi-Fi.") MUST succeed immediately
        val directRes = runtime.processUserIntent("Abre Wi-Fi.")
        assertTrue(directRes.success)
        assertEquals(RouteDecision.DIRECT, directRes.routeDecision)
        assertNotNull(directRes.plan)
        assertEquals("open_wifi_settings", (directRes.plan as ActionPlan).action)

        // 2. Complex AI order while limited MUST return graceful RATE_LIMITED error without crash
        val aiRes = runtime.processUserIntent("Abre los ajustes de Wi-Fi y después vuelve atrás.")
        assertFalse(aiRes.success)
        assertEquals(RouteDecision.AI_REQUIRED, aiRes.routeDecision)
        assertTrue(aiRes.error!!.contains("RATE_LIMITED"))
        assertEquals(ProviderState.RATE_LIMITED, runtime.health.state)
    }

    @Test
    fun testOfflineBehavior() = runBlocking {
        val coreAdapter = TunnelCoreAdapter()
        val runtime = ProviderRuntime(activeProvider = null, coreAdapter = coreAdapter)
        runtime.health.state = ProviderState.OFFLINE

        // Local direct works
        val directRes = runtime.processUserIntent("Abre Bluetooth")
        assertTrue(directRes.success)
        assertEquals(RouteDecision.DIRECT, directRes.routeDecision)

        // AI returns AI_PROVIDER_UNAVAILABLE without crash
        val aiRes = runtime.processUserIntent("Abre los ajustes de Wi-Fi y después vuelve atrás.")
        assertFalse(aiRes.success)
        assertTrue(aiRes.error!!.contains("AI_PROVIDER_UNAVAILABLE"))
    }

    @Test
    fun testSharedJsonFixtures() {
        val stream = javaClass.classLoader?.getResourceAsStream("shared_plan_fixtures.json")
            ?: File("../../fixtures/shared_plan_fixtures.json").inputStream()
        val text = stream.bufferedReader().use { it.readText() }
        val root = org.json.JSONObject(text)

        val validator = PlanValidator()

        val valids = root.getJSONArray("valid_fixtures")
        for (i in 0 until valids.length()) {
            val item = valids.getJSONObject(i)
            val plan = validator.validate(item.getString("raw"))
            assertEquals(item.getString("expected_type"), plan.type)
            if (item.has("expected_action")) {
                assertEquals(item.getString("expected_action"), (plan as ActionPlan).action)
            }
            if (item.has("expected_steps_count")) {
                assertEquals(item.getInt("expected_steps_count"), (plan as SequencePlan).steps.size)
            }
        }

        val invalids = root.getJSONArray("invalid_fixtures")
        for (i in 0 until invalids.length()) {
            val item = invalids.getJSONObject(i)
            try {
                validator.validate(item.getString("raw"))
                fail("Expected PlanValidationError for: ${item.getString("id")}")
            } catch (e: PlanValidationError) {
                assertEquals(item.getString("expected_error"), e.code)
            }
        }
    }

    @Test
    fun testNativeEventJournalRingBuffer() {
        val journal = com.tunnel.turbo.core.NativeEventJournal(capacity = 5)
        for (i in 1..10) {
            journal.recordEvent("action_test", mapOf("index" to i))
        }
        assertEquals(5, journal.size())
        assertEquals(10L, journal.latestRevision())

        val events = journal.getEvents(sinceRevision = 7L)
        assertEquals(3, events.size)
        assertEquals(8L, events[0].revision)
        assertEquals(10L, events[2].revision)
    }

    @Test
    fun testDisplayTargetPolicyIsolation() {
        val policy = com.tunnel.turbo.core.DisplayTargetPolicy(primaryDisplayId = 0, workerDisplayId = null)

        // User action operations cannot touch Worker Display
        assertTrue(policy.canUserActionAccess(0))

        // Worker operations cannot touch Primary Display (0)
        assertFalse(policy.canWorkerActionAccess(0))
        assertFalse(policy.canWorkerActionAccess(8))

        // Worker resolve without registered worker display fails closed
        try {
            policy.resolveTargetDisplay(isWorkerOperation = true)
            fail("Expected IllegalStateException when worker has no registered display")
        } catch (ise: IllegalStateException) {
            assertTrue(ise.message!!.contains("UNAVAILABLE"))
        }

        // When registered, worker can access owned display
        policy.workerDisplayId = 2
        assertTrue(policy.canWorkerActionAccess(2))
        assertFalse(policy.canWorkerActionAccess(8))
        assertFalse(policy.canUserActionAccess(2))
        assertEquals(2, policy.resolveTargetDisplay(isWorkerOperation = true))

        // Resolve checks for user operation
        assertEquals(0, policy.resolveTargetDisplay(isWorkerOperation = false, requestedDisplayId = 0))

        try {
            policy.resolveTargetDisplay(isWorkerOperation = true, requestedDisplayId = 0)
            fail("Expected SecurityException when worker attempts display 0")
        } catch (se: SecurityException) {
            assertTrue(se.message!!.contains("VIOLATION"))
        }
    }

    @Test
    fun testNativeSequenceExecutorExecution() = runBlocking {
        val core = com.tunnel.turbo.core.NativeTunnelCore(context = null)
        val seqPlan = SequencePlan(
            steps = listOf(
                ActionPlan(action = "open_wifi_settings"),
                ActionPlan(action = "press_key", arguments = mapOf("key" to "BACK")),
                ActionPlan(action = "open_bluetooth_settings")
            )
        )

        val res = core.sequenceExecutor.executeSequence(seqPlan)
        assertTrue(res.success)
        assertEquals(3, res.totalSteps)
        assertEquals(3, res.executedSteps)
        assertTrue(res.totalMs > 0.0)

        val journalEvents = core.journal.getAllInOrder()
        assertTrue(journalEvents.any { it.type == "sequence_started" })
        assertTrue(journalEvents.any { it.type == "sequence_completed" })
    }

    @Test
    fun testDeterministicSequenceRouting() {
        val router = LocalIntentRouter()
        val r = router.route("Abre Wi-Fi, vuelve atrás y abre Bluetooth")
        assertEquals(RouteDecision.DIRECT, r.decision)
        assertTrue(r.directPlan is SequencePlan)
        val seq = r.directPlan as SequencePlan
        assertEquals(3, seq.steps.size)
        assertEquals("open_wifi_settings", seq.steps[0].action)
        assertEquals("press_key", seq.steps[1].action)
        assertEquals("open_bluetooth_settings", seq.steps[2].action)
    }
}
