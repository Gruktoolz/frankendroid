package com.tunnel.turbo

import com.tunnel.turbo.agent.*
import com.tunnel.turbo.capability.Capability
import com.tunnel.turbo.core.NativeTunnelCore
import com.tunnel.turbo.model.ToolStep
import com.tunnel.turbo.worker.ProviderFailureClass
import com.tunnel.turbo.worker.ProviderHealthReport
import com.tunnel.turbo.worker.ProviderHealthState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

class AgentSessionV2Test {

    private fun dummySnapshot(goalId: String = "test-goal", rev: Long = 1L) = WorldSnapshot(
        goalId = goalId,
        foregroundPackage = "com.test",
        foregroundActivity = "MainActivity",
        candidateApps = emptyList(),
        reducedObservation = ReducedObservation(
            foregroundPackage = "com.test",
            foregroundActivity = "MainActivity",
            interactiveNodes = emptyList(),
            informativeText = "Screen at rev $rev",
            metrics = ReductionMetrics(0, 0, 0, 0, 0.0)
        ),
        availableCapabilities = listOf("open_settings", "press_back"),
        relevantSkills = emptyList(),
        revision = rev
    )

    @Test
    fun testScenarioA_TwoStepRealProviderLoopInStrictMode() = runBlocking {
        GeneralAgentRuntime.strictRealProviderMode = true
        val core = NativeTunnelCore()
        val goal = Goal(
            goalId = "goal-multi-step",
            originalText = "abre ajustes y navega",
            objective = "Navegar en ajustes"
        )

        var turn = 0
        val revisionsReceived = mutableListOf<Long>()

        val multiTurnProvider = object : ReasoningProvider {
            override val name = "MultiTurnProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                turn++
                revisionsReceived.add(snapshot.revision)
                budget.providerRounds++

                return if (turn == 1) {
                    NextDecision(
                        type = DecisionType.USE_CAPABILITY,
                        capabilityId = "open_settings",
                        arguments = emptyMap(),
                        reason = "Turn 1: open settings",
                        decisionSource = DecisionSource.REAL_PROVIDER,
                        proofNonce = "nonce_1"
                    )
                } else {
                    NextDecision(
                        type = DecisionType.TASK_FAILED,
                        reason = "Turn 2: finished exploration",
                        decisionSource = DecisionSource.REAL_PROVIDER,
                        proofNonce = "nonce_2"
                    )
                }
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = multiTurnProvider
        )

        val result = session.execute()
        // Must perform at least 2 genuine provider rounds in strict mode
        assertTrue("Expected at least 2 provider rounds in strictRealProviderMode, got ${session.budget.providerRounds}", session.budget.providerRounds >= 2)
        assertTrue("Expected turn 2 to be reached", turn >= 2)
        assertEquals(2, revisionsReceived.size)
        // Fresh observation captured after action, so revision advances
        assertTrue("Revisions must increase monotonically: ${revisionsReceived[0]} < ${revisionsReceived[1]}", revisionsReceived[1] > revisionsReceived[0])
    }

    @Test
    fun testScenarioB_StaleElementRefRejection() = runBlocking {
        val core = NativeTunnelCore()
        val goal = Goal(
            goalId = "goal-stale-ref",
            originalText = "toca el boton",
            objective = "Tocar botón"
        )

        var callCount = 0
        val provider = object : ReasoningProvider {
            override val name = "StaleRefProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                callCount++
                budget.providerRounds++
                return if (callCount == 1) {
                    // Send an ElementRef pointing to a stale revision (e.g. revision 999 while snapshot is at revision 1)
                    NextDecision(
                        type = DecisionType.USE_CAPABILITY,
                        capabilityId = "click_node",
                        arguments = mapOf("elementRef" to "elem:0:999:button_submit"),
                        reason = "Click with stale ref",
                        decisionSource = DecisionSource.REAL_PROVIDER
                    )
                } else {
                    NextDecision(
                        type = DecisionType.TASK_FAILED,
                        reason = "Stopping after stale test",
                        decisionSource = DecisionSource.REAL_PROVIDER
                    )
                }
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider
        )

        session.execute()

        // Verify that STALE_ELEMENT_REF was recorded in action results and action was NOT executed successfully
        val staleAction = session.recordedActionResults.firstOrNull { it.errorClass == "STALE_ELEMENT_REF" }
        assertNotNull("Expected action result with STALE_ELEMENT_REF error", staleAction)
        assertFalse(staleAction!!.executorSuccess)
        assertEquals("STALE_ELEMENT_REF", staleAction.errorClass)
    }

    @Test
    fun testScenarioC_TaskCompleteRejectedByGoalVerifier() = runBlocking {
        val core = NativeTunnelCore()
        // Goal requires specific state that is not met
        val goal = Goal(
            goalId = "goal-music",
            originalText = "quiero escuchar musica de Queen",
            objective = "Reproducir música de Queen",
            desiredState = "Música de Queen reproduciéndose"
        )

        val provider = object : ReasoningProvider {
            override val name = "PrematureCompleteProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                // Provider falsely claims completion immediately without playing music
                return NextDecision(
                    type = DecisionType.TASK_COMPLETE,
                    reason = "I think it is complete",
                    decisionSource = DecisionSource.REAL_PROVIDER
                )
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            budget = AgentBudget(maxProviderRounds = 1)
        )

        val result = session.execute()
        // Must NOT return COMPLETED_VERIFIED because GoalVerifier rejected it
        assertNotEquals("Session must NOT return COMPLETED_VERIFIED when GoalVerifier rejects completion", GoalOutcome.COMPLETED_VERIFIED, result.outcome)
        assertFalse(result.success)
    }

    @Test
    fun testScenarioD_TaskCompleteVerified() = runBlocking {
        val core = NativeTunnelCore()
        // Goal whose desired state is trivial or matches mock environment
        val goal = Goal(
            goalId = "goal-generic",
            originalText = "abre ajustes",
            objective = "Abrir ajustes",
            desiredState = "Pantalla de ajustes visible"
        )

        val provider = object : ReasoningProvider {
            override val name = "VerifiedProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "open_settings",
                    reason = "Opening settings",
                    decisionSource = DecisionSource.REAL_PROVIDER
                )
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider,
            budget = AgentBudget(maxStateChangingActions = 2, maxProviderRounds = 2)
        )

        val result = session.execute()
        assertNotNull(result)
        assertEquals(session.sessionId, result.sessionId)
        assertEquals(goal.goalId, result.goalId)
    }

    @Test
    fun testScenarioE_ProviderInfrastructureFailoverPreservesSession() = runBlocking {
        var primaryAttempts = 0
        var fallbackAttempts = 0
        var capturedGoalId: String? = null

        val primary = object : ReasoningProvider {
            override val name = "FailingPrimary"
            override suspend fun health() = ProviderHealthReport(
                state = ProviderHealthState.UI_UNAVAILABLE,
                isReady = false,
                message = "Virtual display disconnected"
            )
            override suspend fun prepare() = false
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                primaryAttempts++
                throw IllegalStateException("Primary called despite being unhealthy")
            }
        }

        val fallback = object : ReasoningProvider {
            override val name = "HealthyFallback"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                fallbackAttempts++
                capturedGoalId = goal.goalId
                budget.providerRounds++
                return NextDecision(
                    type = DecisionType.TASK_FAILED,
                    reason = "Fallback executed cleanly",
                    decisionSource = DecisionSource.REAL_PROVIDER
                )
            }
        }

        val router = ProviderRouter(primaryProvider = primary, fallbackProvider = fallback)
        val core = NativeTunnelCore()
        val goal = Goal(goalId = "goal-failover-preserved", originalText = "test failover", objective = "Test failover")

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = router,
            budget = AgentBudget(maxProviderRounds = 1)
        )

        val result = session.execute()
        assertEquals(0, primaryAttempts)
        assertEquals(1, fallbackAttempts)
        assertEquals("goal-failover-preserved", capturedGoalId)
        assertEquals(session.sessionId, result.sessionId)
        assertEquals(goal.goalId, result.goalId)
        assertEquals(1, session.budget.providerRounds)
    }

    @Test
    fun testScenarioF_SemanticTaskFailedDoesNotFailover() = runBlocking {
        var fallbackCalled = false

        val primary = object : ReasoningProvider {
            override val name = "PrimarySemanticFailure"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                // Legitimate semantic decision from the model that goal is impossible
                return NextDecision(
                    type = DecisionType.TASK_FAILED,
                    reason = "Model evaluated that target app feature is missing",
                    decisionSource = DecisionSource.REAL_PROVIDER
                )
            }
        }

        val fallback = object : ReasoningProvider {
            override val name = "Fallback"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                fallbackCalled = true
                return NextDecision(type = DecisionType.TASK_FAILED, reason = "Fallback should not be called")
            }
        }

        val router = ProviderRouter(primaryProvider = primary, fallbackProvider = fallback)
        val decision = router.decideNext(
            goal = Goal(goalId = "g-sem", originalText = "test", objective = "test"),
            snapshot = dummySnapshot(),
            skills = emptyList(),
            capabilities = emptyList(),
            recentSteps = emptyList(),
            budget = AgentBudget(),
            reason = AiRoundReason.INITIAL_PLAN
        )

        assertEquals(DecisionType.TASK_FAILED, decision.type)
        assertEquals("Model evaluated that target app feature is missing", decision.reason)
        assertFalse("Fallback provider must NOT be invoked when primary returned a semantic decision", fallbackCalled)
    }

    @Test
    fun testScenarioG_StuckDetectionActivatesWithinBoundedCycles() {
        val detector = StuckDetector(maxNoProgressCycles = 2, maxEquivalentCycles = 3)
        val dummySnap = dummySnapshot()

        val p1 = ProgressEvaluation(ProgressState.NO_PROGRESS, "UI state remained unchanged")
        val stuck1 = detector.recordCycle(p1, "click_node", dummySnap)
        assertFalse("First no-progress cycle should not trigger stuck", stuck1)

        val p2 = ProgressEvaluation(ProgressState.NO_PROGRESS, "UI state remained unchanged")
        val stuck2 = detector.recordCycle(p2, "click_node", dummySnap)
        assertTrue("Second no-progress cycle must trigger stuck condition", stuck2)
        assertFalse("Second cycle is not yet terminal stuck", detector.isTerminalStuck())

        val p3 = ProgressEvaluation(ProgressState.NO_PROGRESS, "UI state remained unchanged")
        val stuck3 = detector.recordCycle(p3, "click_node", dummySnap)
        assertTrue(stuck3)
        assertTrue("Third cycle must trigger terminal stuck condition", detector.isTerminalStuck())
    }

    @Test
    fun testScenarioH_AskUserPauseResumableState() = runBlocking {
        val core = NativeTunnelCore()
        val goal = Goal(goalId = "goal-ask-user", originalText = "manda mensaje", objective = "Mandar mensaje")

        val provider = object : ReasoningProvider {
            override val name = "AskUserProvider"
            override suspend fun health() = ProviderHealthReport(ProviderHealthState.READY, isReady = true)
            override suspend fun prepare() = true
            override suspend fun cancel() {}
            override suspend fun resetConversationIfNeeded() {}
            override suspend fun decideNext(
                goal: Goal,
                snapshot: WorldSnapshot,
                skills: List<DynamicSkill>,
                capabilities: List<Capability>,
                recentSteps: List<AgentStep>,
                budget: AgentBudget,
                reason: AiRoundReason
            ): NextDecision {
                budget.providerRounds++
                return NextDecision(
                    type = DecisionType.ASK_USER,
                    userQuestion = "¿A quién le quieres enviar el mensaje?",
                    userOptions = listOf("Mamá", "Papá"),
                    reason = "Falta el destinatario",
                    decisionSource = DecisionSource.REAL_PROVIDER
                )
            }
        }

        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = core.agentRuntime.worldModel,
            skillMemory = core.skillMemory,
            reasoningProvider = provider
        )

        val result = session.execute()
        assertEquals(GoalOutcome.NEEDS_USER, result.outcome)
        assertEquals(SessionStatus.PAUSED_NEEDS_USER, session.status)
        assertEquals("¿A quién le quieres enviar el mensaje?", result.message)
        assertEquals(session.sessionId, result.sessionId)
        assertTrue(session.events.any { it.type == SessionEventType.ASK_USER })
    }

    @Test
    fun testScenarioI_BudgetAccountingNonOverlappingCounters() {
        val budget = AgentBudget(maxStateChangingActions = 10, maxProviderRounds = 5)

        assertEquals(0, budget.actionsExecuted)
        assertEquals(0, budget.providerRounds)
        assertEquals(0, budget.observationsCaptured)
        assertEquals(0, budget.observationsSentToProvider)

        budget.actionsExecuted++
        assertEquals(1, budget.actionsExecuted)
        assertEquals(0, budget.providerRounds)
        assertEquals(0, budget.observationsCaptured)
        assertEquals(0, budget.observationsSentToProvider)

        budget.providerRounds++
        assertEquals(1, budget.actionsExecuted)
        assertEquals(1, budget.providerRounds)
        assertEquals(0, budget.observationsCaptured)
        assertEquals(0, budget.observationsSentToProvider)

        budget.observationsCaptured++
        budget.observationsCaptured++
        assertEquals(1, budget.actionsExecuted)
        assertEquals(1, budget.providerRounds)
        assertEquals(2, budget.observationsCaptured)
        assertEquals(0, budget.observationsSentToProvider)

        budget.observationsSentToProvider++
        assertEquals(1, budget.actionsExecuted)
        assertEquals(1, budget.providerRounds)
        assertEquals(2, budget.observationsCaptured)
        assertEquals(1, budget.observationsSentToProvider)

        // Verify JSON representation includes all exact fields
        val json = budget.toJson()
        assertEquals(1, json.getInt("actionsExecuted"))
        assertEquals(1, json.getInt("providerRounds"))
        assertEquals(2, json.getInt("observationsCaptured"))
        assertEquals(1, json.getInt("observationsSentToProvider"))
    }
}
