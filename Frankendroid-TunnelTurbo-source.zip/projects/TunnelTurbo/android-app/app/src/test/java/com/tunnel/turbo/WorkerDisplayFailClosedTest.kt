package com.tunnel.turbo

import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.view.Display
import com.tunnel.turbo.worker.AiWorkerBridge
import com.tunnel.turbo.worker.DisplayBackendType
import com.tunnel.turbo.worker.PcBackendWorkerDisplayManager
import com.tunnel.turbo.worker.ProviderHealthState
import com.tunnel.turbo.worker.ShizukuWorkerDisplayManager
import com.tunnel.turbo.worker.WorkerDisplayManager
import com.tunnel.turbo.worker.WorkerLifecycle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`

class WorkerDisplayFailClosedTest {

    @Test
    fun workerDisplayUnavailableNeverResolvesSyntheticTarget_whenCreationReturnsNull() {
        val mockContext = mock(Context::class.java)
        val mockDm = mock(DisplayManager::class.java)
        `when`(mockContext.getSystemService(Context.DISPLAY_SERVICE)).thenReturn(mockDm)
        `when`(mockDm.displays).thenReturn(emptyArray())

        val manager = ShizukuWorkerDisplayManager(mockContext)
        val result = manager.createWorkerDisplay(1080, 1920, 420)

        // Must fail closed: never return fake synthetic display 8
        assertNotEquals("Must not return synthetic fallback display 8", 8, result)
        assertNull("Failed creation must return null", result)
        assertNull("getDisplayId must be null", manager.getDisplayId())
    }

    @Test
    fun workerDisplayUnavailableNeverResolvesSyntheticTarget_whenCreationThrows() {
        val mockContext = mock(Context::class.java)
        val mockDm = mock(DisplayManager::class.java)
        `when`(mockContext.getSystemService(Context.DISPLAY_SERVICE)).thenReturn(mockDm)
        `when`(mockDm.displays).thenReturn(emptyArray())
        `when`(mockDm.createVirtualDisplay(
            org.mockito.ArgumentMatchers.anyString(),
            org.mockito.ArgumentMatchers.anyInt(),
            org.mockito.ArgumentMatchers.anyInt(),
            org.mockito.ArgumentMatchers.anyInt(),
            org.mockito.ArgumentMatchers.isNull(),
            org.mockito.ArgumentMatchers.anyInt()
        )).thenThrow(SecurityException("Requires CAPTURE_VIDEO_OUTPUT permission"))

        val manager = ShizukuWorkerDisplayManager(mockContext)
        val result = manager.createWorkerDisplay(1080, 1920, 420)

        assertNotEquals("Must not return synthetic fallback display 8 when creation throws", 8, result)
        assertNull("Failed creation via exception must return null", result)
        assertNull("getDisplayId must be null", manager.getDisplayId())
    }

    @Test
    fun unrelatedExternalSecondaryDisplayIsNotCommandeerAsWorker() {
        val mockContext = mock(Context::class.java)
        val mockDm = mock(DisplayManager::class.java)
        val mainDisplay = mock(Display::class.java).apply {
            `when`(displayId).thenReturn(0)
            `when`(isValid).thenReturn(true)
        }
        val externalHdmiDisplay = mock(Display::class.java).apply {
            `when`(displayId).thenReturn(2)
            `when`(isValid).thenReturn(true)
        }
        `when`(mockContext.getSystemService(Context.DISPLAY_SERVICE)).thenReturn(mockDm)
        `when`(mockDm.displays).thenReturn(arrayOf(mainDisplay, externalHdmiDisplay))

        // Neither manager should commandeer unrelated external display 2 without ownership
        val shizukuManager = ShizukuWorkerDisplayManager(mockContext)
        assertNotEquals("Must not commandeer external display 2", 2, shizukuManager.getDisplayId())
        assertNull("Unowned display must return null", shizukuManager.getDisplayId())

        val pcManager = PcBackendWorkerDisplayManager(attachedDisplayId = null, context = mockContext)
        assertNotEquals("PcBackend must not commandeer external display 2", 2, pcManager.getDisplayId())
        assertNull("PcBackend without explicit display must return null", pcManager.getDisplayId())
    }

    @Test
    fun aiWorkerBridgeFailsClosedWhenWorkerDisplayUnavailable() {
        val failingManager = object : WorkerDisplayManager {
            override val backendType = DisplayBackendType.ANDROID_SHIZUKU_BACKEND
            override fun createWorkerDisplay(width: Int, height: Int, dpi: Int): Int? = null
            override fun destroyWorkerDisplay() {}
            override fun getDisplayId(): Int? = null
            override fun launchProviderApp(packageId: String): Boolean = false
            override fun healthCheck(): Boolean = false
        }

        val bridge = AiWorkerBridge(displayManager = failingManager)
        val startSuccess = bridge.start()

        assertFalse("Bridge start must return false when display creation fails", startSuccess)
        assertNotEquals("Bridge lifecycle must not be READY", WorkerLifecycle.READY, bridge.lifecycle)
        assertNull("Session displayId must remain null", bridge.session.displayId)

        val health = bridge.checkOperationalHealth()
        assertFalse("Health must not be ready", health.isReady)
        assertEquals(ProviderHealthState.UI_UNAVAILABLE, health.state)
    }
}
