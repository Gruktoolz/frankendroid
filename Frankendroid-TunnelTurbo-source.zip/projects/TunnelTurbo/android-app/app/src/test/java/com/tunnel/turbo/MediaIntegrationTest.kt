package com.tunnel.turbo

import com.tunnel.turbo.agent.*
import org.junit.Assert.*
import org.junit.Test

/**
 * Media Evidence Integration Test (Phase 13B-1.2a.4, Section 23)
 *
 * Verifies end-to-end integration:
 * Goal -> MediaEvidenceSource -> gatherEvidence -> GoalVerifier -> Verification Result
 *
 * NOTE: GoalEvidence is NEVER manually constructed in this test suite.
 * It is produced solely via `verifier.gatherEvidence()`.
 */
class MediaIntegrationTest {

    private class TestMediaEvidenceSource(
        var currentResult: MediaEvidenceResult
    ) : MediaEvidenceSource {
        override fun getCurrentEvidence(): MediaEvidenceResult = currentResult
    }

    @Test
    fun integrationCorrectTrackVerified() {
        val mediaSource = TestMediaEvidenceSource(
            MediaEvidenceResult(
                status = MediaEvidenceStatus.AVAILABLE,
                evidence = MediaPlaybackEvidence(
                    playbackActive = true,
                    title = "Bohemian Rhapsody",
                    artist = "Queen",
                    evidenceSource = "TEST_SOURCE",
                    observedAtMs = System.currentTimeMillis()
                )
            )
        )
        val verifier = GoalVerifier(mediaEvidenceSource = mediaSource)

        val goal = Goal(
            originalText = "reproduce Bohemian Rhapsody",
            objective = "Reproducir Bohemian Rhapsody",
            entities = listOf(GoalEntity(type = "track", value = "Bohemian Rhapsody")),
            desiredState = "Bohemian Rhapsody reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val gatheredEvidence = verifier.gatherEvidence(displayId = 0)
        val result = verifier.verify(goal, gatheredEvidence, emptyList())

        assertEquals("Matching track through gatherEvidence must be COMPLETED_VERIFIED", GoalOutcome.COMPLETED_VERIFIED, result.outcome)
        assertTrue(result.satisfied)
    }

    @Test
    fun integrationWrongTrackYieldsPartial() {
        val mediaSource = TestMediaEvidenceSource(
            MediaEvidenceResult(
                status = MediaEvidenceStatus.AVAILABLE,
                evidence = MediaPlaybackEvidence(
                    playbackActive = true,
                    title = "Radio Ga Ga",
                    artist = "Queen",
                    evidenceSource = "TEST_SOURCE",
                    observedAtMs = System.currentTimeMillis()
                )
            )
        )
        val verifier = GoalVerifier(mediaEvidenceSource = mediaSource)

        val goal = Goal(
            originalText = "reproduce Bohemian Rhapsody",
            objective = "Reproducir Bohemian Rhapsody",
            entities = listOf(GoalEntity(type = "track", value = "Bohemian Rhapsody")),
            desiredState = "Bohemian Rhapsody reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val gatheredEvidence = verifier.gatherEvidence(displayId = 0)
        val result = verifier.verify(goal, gatheredEvidence, emptyList())

        assertEquals("Mismatched track through gatherEvidence must yield PARTIAL", GoalOutcome.PARTIAL, result.outcome)
        assertFalse(result.satisfied)
    }

    @Test
    fun integrationMetadataUnavailableYieldsUnverified() {
        val mediaSource = TestMediaEvidenceSource(
            MediaEvidenceResult(
                status = MediaEvidenceStatus.METADATA_UNAVAILABLE,
                reason = "Active playback detected but no metadata exposed"
            )
        )
        val verifier = GoalVerifier(mediaEvidenceSource = mediaSource)

        val goal = Goal(
            originalText = "reproduce Bohemian Rhapsody",
            objective = "Reproducir Bohemian Rhapsody",
            entities = listOf(GoalEntity(type = "track", value = "Bohemian Rhapsody")),
            desiredState = "Bohemian Rhapsody reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val gatheredEvidence = verifier.gatherEvidence(displayId = 0)
        val result = verifier.verify(goal, gatheredEvidence, emptyList())

        assertNotEquals("Unavailable metadata must NEVER be COMPLETED_VERIFIED", GoalOutcome.COMPLETED_VERIFIED, result.outcome)
        assertFalse(result.satisfied)
    }

    @Test
    fun integrationPermissionUnavailableYieldsFailureOrUnverified() {
        val mediaSource = TestMediaEvidenceSource(
            MediaEvidenceResult(
                status = MediaEvidenceStatus.PERMISSION_UNAVAILABLE,
                reason = "Missing NotificationListenerService or MEDIA_CONTENT_CONTROL"
            )
        )
        val verifier = GoalVerifier(mediaEvidenceSource = mediaSource)

        val goal = Goal(
            originalText = "reproduce Bohemian Rhapsody",
            objective = "Reproducir Bohemian Rhapsody",
            entities = listOf(GoalEntity(type = "track", value = "Bohemian Rhapsody")),
            desiredState = "Bohemian Rhapsody reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val gatheredEvidence = verifier.gatherEvidence(displayId = 0)
        val result = verifier.verify(goal, gatheredEvidence, emptyList())

        assertNotEquals("Permission unavailable must NEVER be COMPLETED_VERIFIED", GoalOutcome.COMPLETED_VERIFIED, result.outcome)
        assertFalse(result.satisfied)
    }

    @Test
    fun integrationPlaylistUnsupportedYieldsUnverified() {
        val mediaSource = TestMediaEvidenceSource(
            MediaEvidenceResult(
                status = MediaEvidenceStatus.AVAILABLE,
                evidence = MediaPlaybackEvidence(
                    playbackActive = true,
                    title = "Track Inside Playlist",
                    artist = "Some Artist",
                    evidenceSource = "TEST_SOURCE",
                    observedAtMs = System.currentTimeMillis()
                )
            )
        )
        val verifier = GoalVerifier(mediaEvidenceSource = mediaSource)

        val goal = Goal(
            originalText = "reproduce playlist My Favorites",
            objective = "Reproducir playlist My Favorites",
            entities = listOf(GoalEntity(type = "playlist", value = "My Favorites")),
            desiredState = "playlist My Favorites reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val gatheredEvidence = verifier.gatherEvidence(displayId = 0)
        val result = verifier.verify(goal, gatheredEvidence, emptyList())

        assertEquals("Playlist goals must yield COMPLETED_UNVERIFIED", GoalOutcome.COMPLETED_UNVERIFIED, result.outcome)
        assertFalse(result.satisfied)
    }

    @Test
    fun integrationArtistAndTrackBothRequired() {
        val mediaSource = TestMediaEvidenceSource(
            MediaEvidenceResult(
                status = MediaEvidenceStatus.AVAILABLE,
                evidence = MediaPlaybackEvidence(
                    playbackActive = true,
                    title = "Bohemian Rhapsody",
                    artist = "Queen",
                    evidenceSource = "TEST_SOURCE",
                    observedAtMs = System.currentTimeMillis()
                )
            )
        )
        val verifier = GoalVerifier(mediaEvidenceSource = mediaSource)

        val goal = Goal(
            originalText = "reproduce Bohemian Rhapsody de Queen",
            objective = "Reproducir Bohemian Rhapsody de Queen",
            entities = listOf(
                GoalEntity(type = "track", value = "Bohemian Rhapsody"),
                GoalEntity(type = "artist", value = "Queen")
            ),
            desiredState = "Bohemian Rhapsody de Queen reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val gatheredEvidence = verifier.gatherEvidence(displayId = 0)
        val result = verifier.verify(goal, gatheredEvidence, emptyList())

        assertEquals("Both track and artist matching yields COMPLETED_VERIFIED", GoalOutcome.COMPLETED_VERIFIED, result.outcome)
        assertTrue(result.satisfied)
    }

    @Test
    fun integrationStaleEvidenceYieldsPartial() {
        val now = System.currentTimeMillis()
        val mediaSource = TestMediaEvidenceSource(
            MediaEvidenceResult(
                status = MediaEvidenceStatus.AVAILABLE,
                evidence = MediaPlaybackEvidence(
                    playbackActive = true,
                    title = "Bohemian Rhapsody",
                    artist = "Queen",
                    evidenceSource = "TEST_SOURCE",
                    observedAtMs = now - 120_000L // 2 minutes old
                )
            )
        )
        val verifier = GoalVerifier(mediaEvidenceSource = mediaSource)

        val goal = Goal(
            originalText = "reproduce Bohemian Rhapsody",
            objective = "Reproducir Bohemian Rhapsody",
            entities = listOf(GoalEntity(type = "track", value = "Bohemian Rhapsody")),
            desiredState = "Bohemian Rhapsody reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val gatheredEvidence = verifier.gatherEvidence(displayId = 0)
        val result = verifier.verify(goal, gatheredEvidence, emptyList())

        assertEquals("Stale evidence yields PARTIAL", GoalOutcome.PARTIAL, result.outcome)
        assertFalse(result.satisfied)
    }
}
