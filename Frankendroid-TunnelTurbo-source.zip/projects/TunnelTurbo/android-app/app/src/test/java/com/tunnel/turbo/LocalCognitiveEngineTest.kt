package com.tunnel.turbo

import com.tunnel.turbo.local.*
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.File

/**
 * Phase 13B-1.2a: Tiny Cognitive Benchmark Integrity + Dataset V2 + Shadow Hardening
 * Verifies strict fail-closed parsing, cross-field invariants, conformance fixtures,
 * generic entity extraction, bounded shadow ring buffer, and truthful shadow counters.
 */
class LocalCognitiveEngineTest {

    private lateinit var engine: RuleBasedLocalCognitiveEngine

    @Before
    fun setUp() {
        engine = RuleBasedLocalCognitiveEngine()
        LocalCognitiveEngineRegistry.resetToDefault()
        ShadowCognitiveDispatcher.clear()
    }

    @Test
    fun testScenarioA_ChatNotAndroidAction() = runBlocking {
        // "hola, cómo estás?" does NOT become Android ACTION
        val input = LocalCognitiveInput(userMessage = "hola, cómo estás?")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be CHAT mode", InteractionMode.CHAT, assessment.interactionMode)
        assertFalse("Must not require device interaction", assessment.needsDeviceInteraction)
        assertFalse("Must not require strategy", assessment.strategyRequired)
        assertEquals("Task domain should be CONVERSATIONAL", TaskDomain.CONVERSATIONAL, assessment.taskDomain)
        assertTrue("Must include GENERAL_CHAT capability", assessment.requiredCapabilityClasses.contains(CapabilityClass.GENERAL_CHAT))
        assertTrue("Candidate routes should include LOCAL_DETERMINISTIC or PROVIDER_NATIVE",
            assessment.candidateRouteClasses.contains(RouteClass.LOCAL_DETERMINISTIC) ||
            assessment.candidateRouteClasses.contains(RouteClass.PROVIDER_NATIVE))
    }

    @Test
    fun testScenarioB_ResearchCurrentInformation() = runBlocking {
        // "busca qué pasó hoy con X" classifies current-information requirement
        val input = LocalCognitiveInput(userMessage = "busca qué pasó hoy con Android 16")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be RESEARCH mode", InteractionMode.RESEARCH, assessment.interactionMode)
        assertTrue("Must require current information", assessment.needsCurrentInformation)
        assertEquals("Task domain should be RESEARCH", TaskDomain.RESEARCH, assessment.taskDomain)
        assertTrue("Must require CURRENT_WEB_INFORMATION", assessment.requiredCapabilityClasses.contains(CapabilityClass.CURRENT_WEB_INFORMATION))
        assertTrue("Must hint at CURRENT_INFO_RESEARCH provider role", assessment.providerRoleHints.contains(ProviderRoleHint.CURRENT_INFO_RESEARCH))
    }

    @Test
    fun explicitResearchRequestsSelectWebResearchRoute() = runBlocking {
        listOf("investiga en profundidad sobre diseño de interfaz Android", "busca en internet modelos locales actuales")
            .forEach { query ->
                val result = engine.assessTurn(LocalCognitiveInput(userMessage = query))
                assertEquals(query, InteractionMode.RESEARCH, result.interactionMode)
                assertTrue(result.needsCurrentInformation)
            }
    }

    @Test
    fun testScenarioC_SystemSettingsBoundedAction() = runBlocking {
        // "abre Bluetooth" classifies bounded ACTION
        val input = LocalCognitiveInput(userMessage = "abre Bluetooth")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be ACTION mode", InteractionMode.ACTION, assessment.interactionMode)
        assertEquals("Task domain should be SYSTEM_SETTINGS", TaskDomain.SYSTEM_SETTINGS, assessment.taskDomain)
        assertTrue("Must require device interaction", assessment.needsDeviceInteraction)
        assertEquals("Local sufficiency should be LOCAL_ONLY", LocalSufficiency.LOCAL_ONLY, assessment.localSufficiency)
        assertTrue("Should include SYSTEM_SETTINGS capability", assessment.requiredCapabilityClasses.contains(CapabilityClass.SYSTEM_SETTINGS))
    }

    @Test
    fun testScenarioD_SpotifyStrategyRegressionFamily() = runBlocking {
        // "pon Queen en Spotify" requires MEDIA_PLAYBACK strategy selection and does NOT force only ANDROID_UI
        // Note: Section 13 - allowed claim: "The cognitive layer recognized that this goal should undergo strategy selection and did not force ANDROID_UI as the sole conceptual route."
        val input = LocalCognitiveInput(userMessage = "pon Queen en Spotify")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be ACTION mode", InteractionMode.ACTION, assessment.interactionMode)
        assertEquals("Task domain should be MEDIA_PLAYBACK", TaskDomain.MEDIA_PLAYBACK, assessment.taskDomain)
        assertTrue("Must recognize strategyRequired == true", assessment.strategyRequired)
        assertTrue("Must require MEDIA_PLAYBACK capability", assessment.requiredCapabilityClasses.contains(CapabilityClass.MEDIA_PLAYBACK))

        // CRITICAL NORTH-STAR RULE: candidateRouteClasses MUST NOT force only ANDROID_UI
        val routes = assessment.candidateRouteClasses
        assertTrue("Candidate routes must contain non-UI options (SYSTEM_API, PROVIDER_NATIVE, or ANDROID_NATIVE)",
            routes.contains(RouteClass.SYSTEM_API) || routes.contains(RouteClass.PROVIDER_NATIVE) || routes.contains(RouteClass.ANDROID_NATIVE))
        assertNotEquals("Route classes cannot solely be a 1-element list of ANDROID_UI", listOf(RouteClass.ANDROID_UI), routes)

        // Verify generic regex entity extraction (Section 11, 12, 44: no hardcoded Queen/Spotify literals in production engine)
        assertTrue("Must extract artist entity Queen dynamically", assessment.entities.any { it.type == "artist" && it.value == "Queen" })
        assertTrue("Must extract app entity Spotify dynamically", assessment.entities.any { it.type == "app" && it.value == "Spotify" })
    }

    @Test
    fun testGenericMediaPlaybackFamily() = runBlocking {
        // Section 12: Generic media strategy family test cases without app-specific hardcoding
        val queries = listOf(
            "reproduce jazz en mi app de música",
            "play this track on my music service",
            "reproduce música en el coche"
        )
        for (q in queries) {
            val assessment = engine.assessTurn(LocalCognitiveInput(userMessage = q))
            assertEquals("Query '$q' should classify as ACTION", InteractionMode.ACTION, assessment.interactionMode)
            assertEquals("Query '$q' should have taskDomain MEDIA_PLAYBACK", TaskDomain.MEDIA_PLAYBACK, assessment.taskDomain)
            assertTrue("Query '$q' must require MEDIA_PLAYBACK capability", assessment.requiredCapabilityClasses.contains(CapabilityClass.MEDIA_PLAYBACK))
            assertTrue("Query '$q' must have strategyRequired == true", assessment.strategyRequired)
            assertTrue("Query '$q' candidate routes must include non-UI options",
                assessment.candidateRouteClasses.contains(RouteClass.SYSTEM_API) ||
                assessment.candidateRouteClasses.contains(RouteClass.PROVIDER_NATIVE) ||
                assessment.candidateRouteClasses.contains(RouteClass.ANDROID_NATIVE))
        }
    }

    @Test
    fun testScenarioE_WorkDurableWorkTask() = runBlocking {
        // "analiza estos 400 chats, identifica ventas y crea un Sheet" classifies WORK + durable work + multiple capabilities
        val input = LocalCognitiveInput(userMessage = "analiza estos 400 chats, identifica ventas y crea un Sheet")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be WORK mode", InteractionMode.WORK, assessment.interactionMode)
        assertTrue("Must require durable work", assessment.needsDurableWork)
        assertTrue("Should have parallelizable potential", assessment.parallelizablePotential)
        assertTrue("Must require strategy", assessment.strategyRequired)
        assertTrue("Must require SPREADSHEET_CREATION", assessment.requiredCapabilityClasses.contains(CapabilityClass.SPREADSHEET_CREATION))
        assertTrue("Must require DATA_EXTRACTION", assessment.requiredCapabilityClasses.contains(CapabilityClass.DATA_EXTRACTION))
        assertTrue("Must include WORK_GRAPH route", assessment.candidateRouteClasses.contains(RouteClass.WORK_GRAPH))
    }

    @Test
    fun testScenarioF_NegativeConstraintsPreserved() = runBlocking {
        // "abre Claude pero no escribas ni envíes nada" preserves negative constraints
        val input = LocalCognitiveInput(userMessage = "abre Claude pero no escribas ni envíes nada")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be ACTION mode", InteractionMode.ACTION, assessment.interactionMode)
        val negativeConstraints = assessment.constraints.filter { it.isNegative }
        assertTrue("Must preserve negative constraint 'sin escribir'", negativeConstraints.any { it.text.contains("escribir") })
        assertTrue("Must preserve negative constraint 'sin enviar'", negativeConstraints.any { it.text.contains("enviar") })
    }

    @Test
    fun testScenarioG_SpeedPreferenceConstraint() = runBlocking {
        // "hazme un video rápido" identifies media generation and SPEED preference
        val input = LocalCognitiveInput(userMessage = "hazme un video rápido")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be ACTION mode", InteractionMode.ACTION, assessment.interactionMode)
        assertTrue("Must need media generation", assessment.needsMediaGeneration)
        assertTrue("Must require VIDEO_GENERATION capability", assessment.requiredCapabilityClasses.contains(CapabilityClass.VIDEO_GENERATION))
        val speedConstraint = assessment.constraints.firstOrNull { it.category == "speed_preference" }
        assertNotNull("Must extract speed preference constraint", speedConstraint)
        assertFalse("Speed preference constraint is not negative", speedConstraint!!.isNegative)
    }

    @Test
    fun testScenarioH_QualityPreferenceConstraint() = runBlocking {
        // "hazme una imagen con máxima calidad aunque tarde" identifies media generation and QUALITY preference
        val input = LocalCognitiveInput(userMessage = "hazme una imagen con máxima calidad aunque tarde")
        val assessment = engine.assessTurn(input)

        assertEquals("Should be ACTION mode", InteractionMode.ACTION, assessment.interactionMode)
        assertTrue("Must need media generation", assessment.needsMediaGeneration)
        assertTrue("Must require IMAGE_GENERATION capability", assessment.requiredCapabilityClasses.contains(CapabilityClass.IMAGE_GENERATION))
        val qualityConstraint = assessment.constraints.firstOrNull { it.category == "quality_preference" }
        assertNotNull("Must extract quality preference constraint", qualityConstraint)
        assertFalse("Quality preference constraint is not negative", qualityConstraint!!.isNegative)
    }

    @Test
    fun testScenarioI_UnresolvedReferenceClarify() = runBlocking {
        // "haz lo mismo que antes" with insufficient context identifies unresolved reference / CLARIFY
        val input = LocalCognitiveInput(
            userMessage = "haz lo mismo que antes",
            conversationContextSummary = null,
            activeGoalSummary = null
        )
        val assessment = engine.assessTurn(input)

        assertEquals("Should be CLARIFY mode", InteractionMode.CLARIFY, assessment.interactionMode)
        assertTrue("Must require clarification", assessment.clarificationRequired)
        assertTrue("Must identify unresolved references", assessment.unresolvedReferences.isNotEmpty())
    }

    @Test
    fun testShadowDispatcherAsyncExecution() = runBlocking {
        var completed = false
        var resultAssessment: LocalCognitiveAssessment? = null

        ShadowCognitiveDispatcher.dispatchShadowAssessmentAsync(
            userMessage = "busca qué tiempo hace hoy en Madrid",
            onCompleted = {
                completed = true
                resultAssessment = it
            }
        )

        // Give coroutine a moment to complete on Dispatchers.Default
        var waitCount = 0
        while (!completed && waitCount < 20) {
            kotlinx.coroutines.delay(50)
            waitCount++
        }

        assertTrue("Shadow dispatcher should complete asynchronously", completed)
        assertNotNull("Assessment should not be null", resultAssessment)
        assertEquals(InteractionMode.RESEARCH, resultAssessment?.interactionMode)
        assertNotNull("ShadowDispatcher.lastAssessment must be set", ShadowCognitiveDispatcher.lastAssessment)

        val stats = ShadowCognitiveDispatcher.getStats()
        assertTrue("Stats must record agentSessionsObserved >= 1", stats.optInt("agentSessionsObserved") >= 1)
        assertTrue("Stats must record agentSessionsCompleted >= 1", stats.optInt("agentSessionsCompleted") >= 1)
        assertTrue("Stats must record estimatedLocalizableDecisions >= 1", stats.optInt("estimatedLocalizableDecisions") >= 1)
    }

    @Test
    fun testShadowBoundedRetentionCapacity() = runBlocking {
        // Verify bounded ring buffer does not exceed DEFAULT_RETENTION_CAPACITY (100)
        ShadowCognitiveDispatcher.clear()
        for (i in 1..150) {
            ShadowCognitiveDispatcher.assessDirect(LocalCognitiveInput(userMessage = "mensaje de prueba $i"))
        }

        val history = ShadowCognitiveDispatcher.history
        assertEquals("History size must be capped at retention capacity",
            ShadowCognitiveDispatcher.DEFAULT_RETENTION_CAPACITY, history.size)
        val last = ShadowCognitiveDispatcher.lastAssessment
        assertNotNull("lastAssessment must not be null", last)
        assertEquals("Last item in history must match lastAssessment", last!!.assessmentId, history.last().assessmentId)
        val stats = ShadowCognitiveDispatcher.getStats()
        assertEquals(ShadowCognitiveDispatcher.DEFAULT_RETENTION_CAPACITY, stats.optInt("historySize"))
        assertEquals(150, stats.optInt("devtoolsDirectCallsCount"))
        assertEquals(0, stats.optInt("agentSessionsObserved")) // Direct calls must not be mixed with product turn coverage
    }

    @Test
    fun testFailClosedParserStrictness() {
        val validJson = JSONObject().apply {
            put("assessmentId", "cog_valid_01")
            put("schemaVersion", "1.0.0")
            put("interactionMode", "CHAT")
            put("taskDomain", "CONVERSATIONAL")
            put("entities", JSONArray())
            put("constraints", JSONArray())
            put("unresolvedReferences", JSONArray())
            put("needsCurrentInformation", false)
            put("needsDeviceInteraction", false)
            put("needsBrowser", false)
            put("needsFiles", false)
            put("needsCode", false)
            put("needsMediaGeneration", false)
            put("needsDurableWork", false)
            put("localSufficiency", "LOCAL_ONLY")
            put("requiredCapabilityClasses", JSONArray(listOf("GENERAL_CHAT")))
            put("candidateRouteClasses", JSONArray(listOf("LOCAL_DETERMINISTIC")))
            put("providerRoleHints", JSONArray())
            put("strategyRequired", false)
            put("parallelizablePotential", false)
            put("clarificationRequired", false)
            put("confidence", 0.95)
            put("telemetry", JSONObject().apply {
                put("tinyEngineAvailable", true)
                put("tinyModelId", "test")
                put("tinyBackend", "JVM")
                put("tinyInferenceMs", 1)
                put("tinyColdStartMs", 0)
                put("tinyInputTokens", 1)
                put("tinyOutputTokens", 1)
                put("potentialCloudRoundsAvoided", 1)
            })
        }

        // 1. Valid payload accepted
        val parseValid = LocalCognitiveAssessment.parseStrict(validJson)
        assertTrue("Valid JSON must produce AssessmentParseResult.Valid", parseValid is AssessmentParseResult.Valid)

        // 2. Missing required field rejected
        val missingFieldJson = JSONObject(validJson.toString()).apply { remove("interactionMode") }
        val parseMissing = LocalCognitiveAssessment.parseStrict(missingFieldJson)
        assertTrue("Missing field must produce AssessmentParseResult.Invalid", parseMissing is AssessmentParseResult.Invalid)

        // 3. Unknown enum value rejected (never silently converted to CHAT)
        val unknownEnumJson = JSONObject(validJson.toString()).apply { put("interactionMode", "SUPER_INTELLIGENCE") }
        val parseUnknownEnum = LocalCognitiveAssessment.parseStrict(unknownEnumJson)
        assertTrue("Unknown enum must produce AssessmentParseResult.Invalid", parseUnknownEnum is AssessmentParseResult.Invalid)

        // 4. Unsupported schemaVersion rejected
        val unsupportedVerJson = JSONObject(validJson.toString()).apply { put("schemaVersion", "2.0.0") }
        val parseVer = LocalCognitiveAssessment.parseStrict(unsupportedVerJson)
        assertTrue("Unsupported schemaVersion must produce AssessmentParseResult.Invalid", parseVer is AssessmentParseResult.Invalid)

        // 5. Confidence out of bounds rejected
        val invalidConfJson = JSONObject(validJson.toString()).apply { put("confidence", 1.5) }
        val parseConf = LocalCognitiveAssessment.parseStrict(invalidConfJson)
        assertTrue("Confidence > 1.0 must produce AssessmentParseResult.Invalid", parseConf is AssessmentParseResult.Invalid)

        // 6. Semantic invariant violation rejected: CLARIFY requires clarificationRequired
        val invalidClarifyJson = JSONObject(validJson.toString()).apply {
            put("interactionMode", "CLARIFY")
            put("clarificationRequired", false)
        }
        val parseClarify = LocalCognitiveAssessment.parseStrict(invalidClarifyJson)
        assertTrue("CLARIFY invariant violation must produce AssessmentParseResult.Invalid", parseClarify is AssessmentParseResult.Invalid)

        // 7. Semantic invariant violation rejected: needsDurableWork requires WORK mode
        val invalidWorkJson = JSONObject(validJson.toString()).apply {
            put("interactionMode", "CHAT")
            put("needsDurableWork", true)
        }
        val parseWork = LocalCognitiveAssessment.parseStrict(invalidWorkJson)
        assertTrue("needsDurableWork with CHAT mode must produce AssessmentParseResult.Invalid", parseWork is AssessmentParseResult.Invalid)
    }

    @Test
    fun testGoldenConformanceFixturesContract() {
        val candidatePaths = listOf(
            File("schemas/local-cognitive-assessment-v1-conformance.jsonl"),
            File("../../schemas/local-cognitive-assessment-v1-conformance.jsonl"),
            File("../schemas/local-cognitive-assessment-v1-conformance.jsonl")
        )
        val fixtureFile = candidatePaths.firstOrNull { it.exists() }
        assertNotNull("Conformance fixture file must exist in schemas/", fixtureFile)

        val lines = fixtureFile!!.readLines().filter { it.isNotBlank() }
        assertTrue("Must have at least 20 conformance fixtures", lines.size >= 20)

        var disagreementCount = 0

        for (line in lines) {
            val item = JSONObject(line)
            val fixtureId = item.getString("fixtureId")
            val expectedOverallValid = item.getBoolean("expectedOverallValid")
            val payload = item.getJSONObject("payload")

            val parseResult = LocalCognitiveAssessment.parseStrict(payload)
            val actualValid = (parseResult is AssessmentParseResult.Valid)

            if (actualValid != expectedOverallValid) {
                disagreementCount++
                System.err.println("DISAGREEMENT on $fixtureId: expected valid=$expectedOverallValid, got $actualValid (result=$parseResult)")
            }
        }

        assertEquals("validatorDisagreementCount must be exactly 0 (Section 56B)", 0, disagreementCount)
    }

    @Test
    fun testAssessmentSerializationRoundTrip() {
        val original = LocalCognitiveAssessment(
            schemaVersion = "1.0.0",
            interactionMode = InteractionMode.ACTION,
            taskDomain = TaskDomain.MEDIA_PLAYBACK,
            entities = listOf(CognitiveEntity("artist", "Queen"), CognitiveEntity("app", "Spotify")),
            constraints = listOf(CognitiveConstraint("sin anuncios", isNegative = true, category = "filter")),
            unresolvedReferences = emptyList(),
            needsDeviceInteraction = true,
            requiredCapabilityClasses = listOf(CapabilityClass.MEDIA_PLAYBACK),
            candidateRouteClasses = listOf(RouteClass.SYSTEM_API, RouteClass.ANDROID_UI),
            providerRoleHints = listOf(ProviderRoleHint.GENERAL_REASONING),
            strategyRequired = true,
            confidence = 0.95,
            telemetry = CognitiveAssessmentTelemetry(
                tinyModelId = "test",
                tinyBackend = "LOCAL_JVM",
                tinyInferenceMs = 5,
                estimatedLocalizableDecisions = 2
            )
        )

        val json = original.toJson()
        val parsed = LocalCognitiveAssessment.fromJson(json)

        assertEquals(original.schemaVersion, parsed.schemaVersion)
        assertEquals(original.interactionMode, parsed.interactionMode)
        assertEquals(original.taskDomain, parsed.taskDomain)
        assertEquals(original.entities.size, parsed.entities.size)
        assertEquals("Queen", parsed.entities[0].value)
        assertEquals(original.constraints.size, parsed.constraints.size)
        assertTrue(parsed.constraints[0].isNegative)
        assertEquals(original.strategyRequired, parsed.strategyRequired)
    }

    @Test
    fun testCompleteInputSerializationPassThrough() {
        // Section 39: Construct one LocalCognitiveInput with EVERY field populated using distinct sentinel values
        val input = LocalCognitiveInput(
            userMessage = "sentinel_user_msg",
            conversationContextSummary = "sentinel_conv_summary",
            activeGoalSummary = "sentinel_goal_summary",
            activeWorkSummary = "sentinel_work_summary",
            currentForegroundPackage = "com.sentinel.package",
            availableCapabilityClasses = listOf(CapabilityClass.FILE_READ, CapabilityClass.FILE_WRITE),
            recentProgressState = "sentinel_progress_state",
            unresolvedReferences = listOf("ref_sentinel_1", "ref_sentinel_2"),
            locale = "es-MX"
        )
        val json = input.toJson()
        val roundTrip = LocalCognitiveInput.fromJson(json)

        assertEquals("userMessage must match", input.userMessage, roundTrip.userMessage)
        assertEquals("conversationContextSummary must match", input.conversationContextSummary, roundTrip.conversationContextSummary)
        assertEquals("activeGoalSummary must match", input.activeGoalSummary, roundTrip.activeGoalSummary)
        assertEquals("activeWorkSummary must match", input.activeWorkSummary, roundTrip.activeWorkSummary)
        assertEquals("currentForegroundPackage must match", input.currentForegroundPackage, roundTrip.currentForegroundPackage)
        assertEquals("availableCapabilityClasses must match", input.availableCapabilityClasses, roundTrip.availableCapabilityClasses)
        assertEquals("recentProgressState must match", input.recentProgressState, roundTrip.recentProgressState)
        assertEquals("unresolvedReferences must match", input.unresolvedReferences, roundTrip.unresolvedReferences)
        assertEquals("locale must match", input.locale, roundTrip.locale)
    }

    @Test
    fun testContextFidelityCounterfactualPairs() = runBlocking {
        // Section 40: Context counterfactual tests: same message + different context = different assessment
        // Pair 1: Same user message "haz lo mismo que antes" with null context vs activeGoalSummary
        val msg1 = "haz lo mismo que antes"
        val input1A = LocalCognitiveInput(userMessage = msg1, activeGoalSummary = null, conversationContextSummary = null)
        val assessment1A = engine.assessTurn(input1A)
        assertEquals("Without context, must be CLARIFY", InteractionMode.CLARIFY, assessment1A.interactionMode)
        assertTrue("Clarification must be required", assessment1A.clarificationRequired)
        assertTrue("Unresolved references must be present", assessment1A.unresolvedReferences.isNotEmpty())

        val input1B = LocalCognitiveInput(userMessage = msg1, activeGoalSummary = "abrir ajustes de Wi-Fi")
        val assessment1B = engine.assessTurn(input1B)
        assertEquals("With context, must be ACTION", InteractionMode.ACTION, assessment1B.interactionMode)
        assertEquals("Task domain must be SYSTEM_SETTINGS", TaskDomain.SYSTEM_SETTINGS, assessment1B.taskDomain)
        assertFalse("Clarification must not be required", assessment1B.clarificationRequired)
        assertTrue("Unresolved references must be empty", assessment1B.unresolvedReferences.isEmpty())

        // Pair 2: Same user message "no incluyas los datos de septiembre en el informe" with null work context vs active work context
        val msg2 = "no incluyas los datos de septiembre en el informe"
        val input2A = LocalCognitiveInput(userMessage = msg2, activeWorkSummary = null)
        val assessment2A = engine.assessTurn(input2A)
        assertFalse("Without active work context, needsDurableWork should be false", assessment2A.needsDurableWork)

        val input2B = LocalCognitiveInput(userMessage = msg2, activeWorkSummary = "analizando chats de soporte y ventas de Q3 para generar informe consolidado")
        val assessment2B = engine.assessTurn(input2B)
        assertEquals("With active work context, must be WORK", InteractionMode.WORK, assessment2B.interactionMode)
        assertEquals("Task domain must be PRODUCTIVITY", TaskDomain.PRODUCTIVITY, assessment2B.taskDomain)
        assertTrue("needsDurableWork must be true", assessment2B.needsDurableWork)
        assertTrue("Must require DATA_EXTRACTION", assessment2B.requiredCapabilityClasses.contains(CapabilityClass.DATA_EXTRACTION))
        assertTrue("Must contain negative constraint on septiembre", assessment2B.constraints.any { it.text == "no incluir septiembre" && it.isNegative })
    }

    @Test
    fun testShadowCallbackFailureIsolation() = runBlocking {
        // Section 42: Callback failure must not convert engine success into engine failure
        ShadowCognitiveDispatcher.clear()

        var callbackExecuted = false
        ShadowCognitiveDispatcher.dispatchShadowAssessmentAsync(
            userMessage = "hola",
            onCompleted = {
                callbackExecuted = true
                throw RuntimeException("Simulated callback exception")
            }
        )

        var wait = 0
        while (!callbackExecuted && wait < 20) {
            kotlinx.coroutines.delay(50)
            wait++
        }
        kotlinx.coroutines.delay(100) // allow callback catch block to run

        assertTrue("Callback must have been invoked", callbackExecuted)
        val stats = ShadowCognitiveDispatcher.getStats()
        assertEquals("shadowCompleted must be incremented", 1, stats.getInt("shadowCompleted"))
        assertEquals("shadowEngineFailed must NOT be incremented on callback failure", 0, stats.getInt("shadowEngineFailed"))
        assertEquals("shadowCallbackFailures must be recorded", 1, stats.getInt("shadowCallbackFailures"))
        assertEquals("Retained history must contain the completed assessment", 1, stats.getInt("retainedHistoryCount"))
    }

    @Test
    fun testShadowTimeoutSemantics() = runBlocking {
        // Section 43: Timeout on cooperative engine cancels coroutine and increments shadowTimedOut
        ShadowCognitiveDispatcher.clear()

        val slowEngine = object : LocalCognitiveEngine {
            override val modelId = "slow-fake"
            override val backend = "TEST"
            override suspend fun assessTurn(input: LocalCognitiveInput): LocalCognitiveAssessment {
                kotlinx.coroutines.delay(3000)
                return LocalCognitiveAssessment(
                    schemaVersion = "1.0.0",
                    interactionMode = InteractionMode.CHAT,
                    taskDomain = TaskDomain.CONVERSATIONAL,
                    requiredCapabilityClasses = listOf(CapabilityClass.GENERAL_CHAT),
                    candidateRouteClasses = listOf(RouteClass.LOCAL_DETERMINISTIC)
                )
            }
        }
        LocalCognitiveEngineRegistry.setEngine(slowEngine)

        ShadowCognitiveDispatcher.dispatchShadowAssessmentAsync(userMessage = "test timeout")

        var wait = 0
        while (ShadowCognitiveDispatcher.shadowTimedOut.get() == 0 && wait < 40) {
            kotlinx.coroutines.delay(100)
            wait++
        }

        val stats = ShadowCognitiveDispatcher.getStats()
        assertEquals("shadowTimedOut must be 1", 1, stats.getInt("shadowTimedOut"))
        assertEquals("shadowCompleted must remain 0", 0, stats.getInt("shadowCompleted"))
        assertEquals("shadowEngineFailed must remain 0", 0, stats.getInt("shadowEngineFailed"))
    }

    @Test
    fun testShadowBoundedWindowVsLifetimeCounters() = runBlocking {
        // Section 44: Verify retained window capacity != lifetime counters
        ShadowCognitiveDispatcher.clear()

        val targetCount = 120
        for (i in 1..targetCount) {
            ShadowCognitiveDispatcher.dispatchShadowAssessmentAsync(userMessage = "mensaje rapido $i")
        }

        var wait = 0
        while (ShadowCognitiveDispatcher.shadowCompleted.get() < targetCount && wait < 60) {
            kotlinx.coroutines.delay(50)
            wait++
        }

        val stats = ShadowCognitiveDispatcher.getStats()
        val retained = stats.getInt("retainedHistoryCount")
        val lifetimeCompleted = stats.getInt("shadowCompleted")

        assertTrue("retainedHistoryCount must not exceed capacity (100)", retained <= ShadowCognitiveDispatcher.DEFAULT_RETENTION_CAPACITY)
        assertEquals("retainedHistoryCount must be 100", 100, retained)
        assertEquals("Lifetime completed must be 120", targetCount, lifetimeCompleted)
        assertFalse("Stats must NOT contain legacy misleading totalAssessments equaling retained size", stats.has("totalAssessments"))
    }

    @Test
    fun testShadowCounterReconciliationEquation() = runBlocking {
        // Section 22: shadowAttemptsStarted == shadowCompleted + shadowEngineFailed + shadowTimedOut + shadowInFlight
        ShadowCognitiveDispatcher.clear()

        ShadowCognitiveDispatcher.dispatchShadowAssessmentAsync(userMessage = "hola")
        var wait = 0
        while (ShadowCognitiveDispatcher.shadowCompleted.get() == 0 && wait < 20) {
            kotlinx.coroutines.delay(50)
            wait++
        }

        val stats = ShadowCognitiveDispatcher.getStats()
        val attempts = stats.getInt("shadowAttemptsStarted")
        val completed = stats.getInt("shadowCompleted")
        val failed = stats.getInt("shadowEngineFailed")
        val timedOut = stats.getInt("shadowTimedOut")
        val inFlight = stats.getInt("shadowInFlight")

        assertEquals("shadowAttemptsStarted == completed + failed + timedOut + inFlight",
            attempts, completed + failed + timedOut + inFlight)
    }
}
