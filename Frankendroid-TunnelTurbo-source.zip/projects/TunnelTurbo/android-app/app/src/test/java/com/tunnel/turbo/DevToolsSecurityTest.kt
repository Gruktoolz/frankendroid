package com.tunnel.turbo

import com.tunnel.turbo.devtools.TunnelDevToolsBridge
import com.tunnel.turbo.local.CapturingLocalCognitiveEngine
import com.tunnel.turbo.local.LocalCognitiveInput
import com.tunnel.turbo.local.LocalCognitiveEngineRegistry
import com.tunnel.turbo.local.LocalCognitiveAssessment
import com.tunnel.turbo.local.RouteClass
import com.tunnel.turbo.core.NativeTunnelCore
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/**
 * TDD Security & Authority Regression Tests for TunnelDevToolsBridge (Phase 13B-1.2a.3, Section 15-21)
 *
 * Verifies:
 * 1. Typed EndpointDescriptor inventory covers all endpoints.
 * 2. ALL mutating endpoints strictly require valid x-dev-session-token header.
 * 3. Tokens in URL query strings are rejected (Section 19).
 * 4. Methods are strictly checked (e.g. GET on POST-only endpoint fails).
 * 5. Resource limits (Content-Length bounds, payload bounds) are enforced.
 * 6. Sensitive capture retention is bounded to max 50 items.
 */
class DevToolsSecurityTest {

    private fun createBridge(): Pair<TunnelDevToolsBridge, NativeTunnelCore> {
        val core = NativeTunnelCore(context = null)
        val bridge = TunnelDevToolsBridge(
            coordinator = null,
            core = core,
            accessibilityBridge = core.accessibilityBridge
        )
        return Pair(bridge, core)
    }

    @Test
    fun sessionTokenIsNeverReturnedByUnauthenticatedEndpoint() {
        val (bridge, _) = createBridge()

        // 1. Endpoint registry must NOT contain /debug_get_session_token
        assertFalse(
            "/debug_get_session_token must be completely removed from ENDPOINTS registry",
            TunnelDevToolsBridge.ENDPOINTS.containsKey("/debug_get_session_token")
        )

        // 2. HTTP GET to /debug_get_session_token must be rejected (e.g. 404 NOT_FOUND) and never return sessionToken
        val resp = bridge.handleEndpoint(
            method = "GET",
            path = "/debug_get_session_token",
            params = emptyMap(),
            body = "",
            headers = emptyMap()
        )

        assertEquals("Unregistered /debug_get_session_token must return status error", "error", resp.optString("status"))
        assertFalse(
            "Bearer token must NEVER be exposed in response body",
            resp.has("session_token")
        )
    }

    @Test
    fun releaseBuildDoesNotStartDevToolsListener() {
        val core = NativeTunnelCore(context = null)
        val releaseBridge = TunnelDevToolsBridge(
            coordinator = null,
            core = core,
            accessibilityBridge = core.accessibilityBridge,
            isDebug = false
        )
        val started = releaseBridge.start()
        assertFalse("DevTools listener must NOT start on non-debug build", started)
        assertFalse("DevToolsBridge must not be running in release build", releaseBridge.isRunning)
    }

    @Test
    fun devToolsDefaultConstructorFailsClosedWithoutDebugFlag() {
        // Production security rule: DevTools MUST NOT default to isDebug=true
        val bridge = TunnelDevToolsBridge()
        assertFalse("TunnelDevToolsBridge must fail closed by defaulting isDebug to false", bridge.isDebug)
        assertFalse("Default constructed bridge must not start", bridge.start())
    }

    @Test
    fun devToolsTokenBootstrapHappensOnlyWhenDebugEnabled() {
        val tempDir = java.io.File(System.getProperty("java.io.tmpdir"), "test_dt_token_${System.currentTimeMillis()}")
        tempDir.mkdirs()
        try {
            val releaseBridge = TunnelDevToolsBridge(isDebug = false, tokenStorageDir = tempDir)
            assertFalse("Release bridge must not start", releaseBridge.start())
            val tokenFile = java.io.File(tempDir, "dev_session_token.txt")
            assertFalse("Token file must NOT be written when isDebug is false", tokenFile.exists())

            val debugBridge = TunnelDevToolsBridge(isDebug = true, tokenStorageDir = tempDir)
            debugBridge.start()
            assertTrue("Token file must be written when isDebug is true and start() called", tokenFile.exists())
            assertEquals(debugBridge.sessionToken, tokenFile.readText())
            debugBridge.stop()
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun devToolsTokenBootstrapFailureFailsClosed() {
        // If token storage directory is non-writable / invalid, start() must fail closed
        val unwritableDir = java.io.File("/proc/non_existent_unwritable_directory_12345")
        val bridge = TunnelDevToolsBridge(isDebug = true, tokenStorageDir = unwritableDir)
        val started = bridge.start()
        assertFalse("DevTools bridge must fail closed if token bootstrap fails", started)
        assertFalse("Bridge must not be running if token bootstrap failed", bridge.isRunning)
    }

    @Test
    fun allRegisteredMutatorsRequireAuth() {
        val (bridge, _) = createBridge()
        val sessionToken = bridge.sessionToken

        // Derived directly from the single source of truth registry (Section 9)
        val mutatingEndpoints = TunnelDevToolsBridge.ENDPOINTS.values
            .filter { it.effectClass == com.tunnel.turbo.devtools.EffectClass.MUTATING }

        assertTrue("Registry must contain mutating endpoints", mutatingEndpoints.isNotEmpty())

        for (desc in mutatingEndpoints) {
            val endpoint = desc.path
            // Invariant: every mutating endpoint must require AuthPolicy.REQUIRED
            assertEquals(
                "Mutating endpoint '$endpoint' must declare AuthPolicy.REQUIRED in descriptor",
                com.tunnel.turbo.devtools.AuthPolicy.REQUIRED,
                desc.authPolicy
            )

            // Case 1: Missing Token
            val respMissing = bridge.handleEndpoint(
                method = "POST",
                path = endpoint,
                params = emptyMap(),
                body = "{}",
                headers = emptyMap()
            )
            assertEquals(
                "Missing token on '$endpoint' must fail with status error",
                "error",
                respMissing.optString("status")
            )
            assertEquals(
                "Missing token on '$endpoint' must return HTTP 401",
                401,
                respMissing.optInt("httpStatusCode")
            )
            assertTrue(
                "Missing token error message must specify UNAUTHORIZED on '$endpoint'",
                respMissing.optString("error").contains("UNAUTHORIZED", ignoreCase = true)
            )

            // Case 2: Invalid Token
            val respInvalid = bridge.handleEndpoint(
                method = "POST",
                path = endpoint,
                params = emptyMap(),
                body = "{}",
                headers = mapOf("x-dev-session-token" to "invalid_token_12345")
            )
            assertEquals(
                "Invalid token on '$endpoint' must fail with status error",
                "error",
                respInvalid.optString("status")
            )
            assertEquals(
                "Invalid token on '$endpoint' must return HTTP 401",
                401,
                respInvalid.optInt("httpStatusCode")
            )

            // Case 3: Valid Token in Header must not fail with UNAUTHORIZED
            val respValid = bridge.handleEndpoint(
                method = "POST",
                path = endpoint,
                params = emptyMap(),
                body = "{}",
                headers = mapOf("x-dev-session-token" to sessionToken)
            )
            assertFalse(
                "Valid token on '$endpoint' must not return UNAUTHORIZED error",
                respValid.optString("error").contains("UNAUTHORIZED", ignoreCase = true)
            )
        }
    }

    @Test
    fun allSensitiveEndpointsRequireAuth() {
        val (bridge, _) = createBridge()
        val sessionToken = bridge.sessionToken

        val sensitiveEndpoints = TunnelDevToolsBridge.ENDPOINTS.values
            .filter { it.sensitivity == com.tunnel.turbo.devtools.Sensitivity.SENSITIVE }

        assertTrue("Registry must contain sensitive endpoints", sensitiveEndpoints.isNotEmpty())

        for (desc in sensitiveEndpoints) {
            val endpoint = desc.path
            val method = if (desc.method.contains("POST")) "POST" else "GET"

            // Case 1: Missing Token must fail with 401 UNAUTHORIZED
            val respMissing = bridge.handleEndpoint(
                method = method,
                path = endpoint,
                params = emptyMap(),
                body = "{}",
                headers = emptyMap()
            )
            assertEquals(
                "Sensitive endpoint '$endpoint' without token must fail with status error",
                "error",
                respMissing.optString("status")
            )
            assertEquals(
                "Sensitive endpoint '$endpoint' without token must return HTTP 401",
                401,
                respMissing.optInt("httpStatusCode")
            )
            assertTrue(
                "Sensitive endpoint '$endpoint' without token must specify UNAUTHORIZED, got: ${respMissing.optString("error")}",
                respMissing.optString("error").contains("UNAUTHORIZED", ignoreCase = true)
            )

            // Case 2: Valid Token in Header must not return UNAUTHORIZED
            try {
                val respValid = bridge.handleEndpoint(
                    method = method,
                    path = endpoint,
                    params = emptyMap(),
                    body = "{}",
                    headers = mapOf("x-dev-session-token" to sessionToken)
                )
                assertFalse(
                    "Sensitive endpoint '$endpoint' with valid token must not return UNAUTHORIZED",
                    respValid.optString("error").contains("UNAUTHORIZED", ignoreCase = true)
                )
            } catch (e: IllegalStateException) {
                // Passed auth and entered endpoint execution
                assertTrue(
                    "Expected unconfigured component exception, got: ${e.message}",
                    e.message?.contains("not configured") == true
                )
            }
        }
    }

    @Test
    fun allDispatchableRoutesHaveDescriptors() {
        val (bridge, _) = createBridge()
        val sessionToken = bridge.sessionToken

        for (desc in TunnelDevToolsBridge.ENDPOINTS.values) {
            val method = if (desc.method.contains(",")) desc.method.split(",").first().trim() else desc.method
            try {
                val resp = bridge.handleEndpoint(
                    method = method,
                    path = desc.path,
                    params = emptyMap(),
                    body = "{}",
                    headers = mapOf("x-dev-session-token" to sessionToken)
                )
                assertNotEquals(
                    "Endpoint '${desc.path}' returned NOT_IMPLEMENTED (501)",
                    501,
                    resp.optInt("httpStatusCode")
                )
                assertNotEquals(
                    "Endpoint '${desc.path}' returned ENDPOINT_NOT_FOUND (404)",
                    404,
                    resp.optInt("httpStatusCode")
                )
            } catch (e: IllegalStateException) {
                // Thrown if coordinator or core is not configured, which confirms the dispatch branch was executed!
                assertTrue(
                    "Expected unconfigured component exception, got: ${e.message}",
                    e.message?.contains("not configured") == true
                )
            }
        }
    }

    @Test
    fun devtoolsRejectsTokensInQueryString() {
        val (bridge, _) = createBridge()
        val sessionToken = bridge.sessionToken

        // Passing token in query parameter instead of header must be REJECTED (Section 19)
        val resp = bridge.handleEndpoint(
            method = "POST",
            path = "/debug_execute_capability",
            params = mapOf("token" to sessionToken),
            body = "{}",
            headers = emptyMap()
        )

        assertEquals("Token in query string must not authorize mutating endpoint", "error", resp.optString("status"))
        assertTrue("Expected UNAUTHORIZED for query token", resp.optString("error").contains("UNAUTHORIZED", ignoreCase = true))
    }

    @Test
    fun devtoolsRejectsUnsupportedHttpMethod() {
        val (bridge, _) = createBridge()
        val sessionToken = bridge.sessionToken

        // GET on a POST-only mutating endpoint must be rejected
        val resp = bridge.handleEndpoint(
            method = "GET",
            path = "/debug_execute_capability",
            params = emptyMap(),
            body = "",
            headers = mapOf("x-dev-session-token" to sessionToken)
        )

        assertEquals("Unsupported method must return status error", "error", resp.optString("status"))
        assertTrue(
            "Error must indicate method not allowed",
            resp.optString("error").contains("METHOD_NOT_ALLOWED", ignoreCase = true) ||
            resp.optString("error").contains("Method", ignoreCase = true)
        )
    }

    @Test
    fun devtoolsEnforcesResourceLimitsOnPayload() {
        val (bridge, _) = createBridge()
        val sessionToken = bridge.sessionToken

        // Content-Length > 65536 bytes must be rejected
        val oversizedHeaders = mapOf(
            "x-dev-session-token" to sessionToken,
            "content-length" to "70000"
        )

        val resp = bridge.handleEndpoint(
            method = "POST",
            path = "/debug_assess_turn",
            params = emptyMap(),
            body = "{}",
            headers = oversizedHeaders
        )

        assertEquals("Oversized payload header must return status error", "error", resp.optString("status"))
        assertTrue("Error must mention payload limit", resp.optString("error").contains("PAYLOAD", ignoreCase = true))
    }

    @Test
    fun devtoolsSensitiveCaptureBoundedRetention() = kotlinx.coroutines.runBlocking {
        val engine = CapturingLocalCognitiveEngine(LocalCognitiveEngineRegistry.activeEngine)
        engine.clear()

        // Submit 60 inputs
        for (i in 1..60) {
            val input = LocalCognitiveInput(userMessage = "message_$i")
            engine.assessTurn(input)
        }

        // Bounded retention invariant: max 50 captures retained (Section 21)
        assertTrue(
            "Captured inputs must be bounded to at most 50, but was ${engine.capturedInputs.size}",
            engine.capturedInputs.size <= 50
        )
        assertEquals("message_60", engine.lastCapturedInput?.userMessage)
        assertEquals("Oldest messages before 11 should have been evicted", "message_11", engine.capturedInputs.first().userMessage)
    }
}
