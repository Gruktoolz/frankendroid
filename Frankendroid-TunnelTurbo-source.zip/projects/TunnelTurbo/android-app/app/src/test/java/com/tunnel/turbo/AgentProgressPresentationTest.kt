package com.tunnel.turbo

import com.tunnel.turbo.agent.SessionEvent
import com.tunnel.turbo.agent.SessionEventType
import com.tunnel.turbo.capability.CapabilityRegistry
import com.tunnel.turbo.ui.AgentProgressPresenter
import org.junit.Assert.*
import org.junit.Test

class AgentProgressPresentationTest {
    @Test
    fun providerProgressUsesBriefLabelAndNeverDisplaysRawReasoningSummary() {
        val privateReason = "internal planning text that must stay hidden"
        val event = SessionEvent(
            sessionId = "session-a",
            goalId = "goal-a",
            type = SessionEventType.PROVIDER_REQUESTED,
            summary = privateReason
        )

        val item = AgentProgressPresenter.present(listOf(event), CapabilityRegistry()).single()

        assertEquals("Decidiendo el siguiente paso", item.label)
        assertFalse(item.detail.contains(privateReason))
    }

    @Test
    fun actionProgressUsesCapabilityDescriptionWithoutArguments() {
        val registry = CapabilityRegistry()
        val capability = registry.getAllCapabilities().first()
        val event = SessionEvent(
            sessionId = "session-b",
            goalId = "goal-b",
            type = SessionEventType.ACTION_STARTED,
            capabilityId = capability.id,
            summary = "secret argument value"
        )

        val item = AgentProgressPresenter.present(listOf(event), registry).single()

        assertEquals(capability.description, item.detail)
        assertFalse(item.detail.contains("secret argument value"))
    }
}
