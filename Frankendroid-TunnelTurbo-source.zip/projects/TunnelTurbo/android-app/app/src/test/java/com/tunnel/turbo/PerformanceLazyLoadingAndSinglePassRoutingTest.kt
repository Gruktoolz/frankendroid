package com.tunnel.turbo

import android.content.Context
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.adapter.TunnelCoreAdapter
import com.tunnel.turbo.app.AppInfo
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.chat.ChatBackend
import com.tunnel.turbo.chat.ChatSessionState
import com.tunnel.turbo.chat.ConversationRuntime
import com.tunnel.turbo.chat.InferenceTelemetry
import com.tunnel.turbo.chat.LocalChatEngine
import com.tunnel.turbo.chat.LocalChatProfile
import com.tunnel.turbo.chat.LocalChatSession
import com.tunnel.turbo.chat.ModelLifecycleState
import com.tunnel.turbo.chat.SessionBenchmark
import com.tunnel.turbo.coordinator.IntentCoordinator
import com.tunnel.turbo.local.InteractionMode
import com.tunnel.turbo.local.LocalCognitiveAssessment
import com.tunnel.turbo.local.LocalCognitiveEngine
import com.tunnel.turbo.local.LocalCognitiveEngineRegistry
import com.tunnel.turbo.local.LocalCognitiveInput
import com.tunnel.turbo.local.LocalSufficiency
import com.tunnel.turbo.local.TaskDomain
import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.provider.ProviderRuntime
import com.tunnel.turbo.router.LocalIntentRouter
import com.tunnel.turbo.router.RouteResult
import com.tunnel.turbo.shizuku.ShizukuBridge
import com.tunnel.turbo.shizuku.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

/**
 * RED Tests for Phase 13C-0.1:
 * - Lazy Model Loading on CHAT demand only (no load on startup or ACTION)
 * - Single-Flight Concurrent Model Initialization (exactly one engine load)
 * - Single-Pass Direct Routing (router.route invoked exactly once per direct request)
 * - Output Token Cap & Fast Profile Telemetry Contracts
 */
class PerformanceLazyLoadingAndSinglePassRoutingTest {

    private lateinit var mockContext: Context
    private lateinit var spyChatEngine: SpyLocalChatEngine
    private lateinit var spyRouter: SpyLocalIntentRouter
    private lateinit var spyAppManager: SpyAppManager
    private lateinit var coreAdapter: TunnelCoreAdapter
    private lateinit var providerRuntime: ProviderRuntime
    private lateinit var shizukuBridge: ShizukuBridge
    private lateinit var accessibilityBridge: AccessibilityBridge
    private lateinit var fakeCognitiveEngine: FakeCognitiveEngine

    @Before
    fun setup() {
        mockContext = mock(Context::class.java)
        val tempDir = File(System.getProperty("java.io.tmpdir"), "tt-test-${System.currentTimeMillis()}")
        tempDir.mkdirs()
        `when`(mockContext.filesDir).thenReturn(tempDir)

        spyChatEngine = SpyLocalChatEngine()
        spyAppManager = SpyAppManager()
        spyRouter = SpyLocalIntentRouter(spyAppManager)

        coreAdapter = TunnelCoreAdapter(appContext = mockContext)
        providerRuntime = ProviderRuntime(
            activeProvider = null,
            router = spyRouter,
            coreAdapter = coreAdapter
        )

        shizukuBridge = mock(ShizukuBridge::class.java)
        `when`(shizukuBridge.checkState()).thenReturn(ShizukuState.READY)

        accessibilityBridge = mock(AccessibilityBridge::class.java)
        `when`(accessibilityBridge.isEnabled()).thenReturn(true)

        fakeCognitiveEngine = FakeCognitiveEngine()
        LocalCognitiveEngineRegistry.setEngine(fakeCognitiveEngine)
    }

    @After
    fun tearDown() {
        LocalCognitiveEngineRegistry.resetToDefault()
    }

    @Test
    fun appStartupDoesNotInitializeLocalChatEngine() = runBlocking {
        // Given: Coordinator is created with local chat engine
        val coordinator = IntentCoordinator(
            context = mockContext,
            providerRuntime = providerRuntime,
            shizukuBridge = shizukuBridge,
            accessibilityBridge = accessibilityBridge,
            localChatEngine = spyChatEngine
        )

        // Give any background init jobs a chance to settle
        kotlinx.coroutines.delay(100)

        // Then: Local model load count MUST BE 0 on application startup
        assertEquals("App start must NOT load model", 0, spyChatEngine.loadModelCount.get())
        assertEquals("Model state must remain UNLOADED", ModelLifecycleState.UNLOADED, spyChatEngine.lifecycleState)

        // When: An ACTION request arrives
        fakeCognitiveEngine.nextAssessment = createAssessment(InteractionMode.ACTION)
        val job = coordinator.submitIntent("Abre Wi-Fi")
        job?.join()

        // Then: Local model load count MUST STILL BE 0 for ACTION
        assertEquals("ACTION turn must NOT load model", 0, spyChatEngine.loadModelCount.get())
        assertEquals("Model state must still remain UNLOADED", ModelLifecycleState.UNLOADED, spyChatEngine.lifecycleState)
    }

    @Test
    fun concurrentFirstChatLoadsEngineExactlyOnce() = runBlocking {
        // Given: Coordinator with unloaded engine
        val coordinator = IntentCoordinator(
            context = mockContext,
            providerRuntime = providerRuntime,
            shizukuBridge = shizukuBridge,
            accessibilityBridge = accessibilityBridge,
            localChatEngine = spyChatEngine
        )
        coordinator.fallbackModelPath = "/mock/model.litertlm"
        fakeCognitiveEngine.nextAssessment = createAssessment(InteractionMode.CHAT)
        spyChatEngine.simulatedLoadDelayMs = 50L

        // When: Two concurrent CHAT turns arrive simultaneously while model is UNLOADED
        val job1 = async(Dispatchers.Default) { coordinator.submitIntent("Hola, asistente")?.join() }
        val job2 = async(Dispatchers.Default) { coordinator.submitIntent("¿Cómo estás?")?.join() }
        awaitAll(job1, job2)

        // Then: Exactly ONE model load operation must occur
        assertEquals("Concurrent first CHAT turns must load engine exactly once", 1, spyChatEngine.loadModelCount.get())
        assertEquals("Model state must be READY", ModelLifecycleState.READY, spyChatEngine.lifecycleState)
    }

    @Test
    fun directRequestUsesExactlyOneRouteDecision() = runBlocking {
        // Given: Coordinator receiving a DIRECT request
        val coordinator = IntentCoordinator(
            context = mockContext,
            providerRuntime = providerRuntime,
            shizukuBridge = shizukuBridge,
            accessibilityBridge = accessibilityBridge,
            localChatEngine = spyChatEngine
        )
        fakeCognitiveEngine.nextAssessment = createAssessment(InteractionMode.ACTION)

        // When: Submitting direct request "Abre Wi-Fi"
        val job = coordinator.submitIntent("Abre Wi-Fi")
        job?.join()

        // Then: router.route must be invoked EXACTLY ONCE
        assertEquals("Router must be called exactly once for direct request", 1, spyRouter.routeCount.get())
        assertEquals("Executed plan action must be open_wifi_settings", "open_wifi_settings", spyRouter.lastRoutedAction)
    }

    @Test
    fun appResolutionInvokesInventoryOnceForDirectAppRequest() = runBlocking {
        // Given: Coordinator receiving an app request
        val coordinator = IntentCoordinator(
            context = mockContext,
            providerRuntime = providerRuntime,
            shizukuBridge = shizukuBridge,
            accessibilityBridge = accessibilityBridge,
            localChatEngine = spyChatEngine
        )
        fakeCognitiveEngine.nextAssessment = createAssessment(InteractionMode.ACTION)

        // When: Submitting "Abre Chrome"
        val job = coordinator.submitIntent("Abre Chrome")
        job?.join()

        // Then: listInstalledApps must be called exactly once (no redundant pass)
        assertEquals("Router called once", 1, spyRouter.routeCount.get())
        assertEquals("listInstalledApps called once", 1, spyAppManager.listInstalledAppsCount.get())
    }

    @Test
    fun fastProfileLimitsOutputTokensAndConfiguresSampler() {
        // Contract assertion for LocalChatProfile
        val fast = LocalChatProfile.FAST
        assertEquals("FAST", fast.name)
        assertEquals(64, fast.maxOutputTokens)
        assertEquals(40, fast.topK)
        assertEquals(0.95, fast.topP ?: 0.0, 0.001)
        assertEquals(0.7, fast.temperature ?: 0.0, 0.001)
    }

    @Test
    fun failedLocalChatIsNotReportedAsReadyOrVerified() = runBlocking {
        val coordinator = IntentCoordinator(
            context = mockContext,
            providerRuntime = providerRuntime,
            shizukuBridge = shizukuBridge,
            accessibilityBridge = accessibilityBridge,
            localChatEngine = spyChatEngine,
            isDebug = false
        )
        coordinator.modelCandidatePaths = emptyList()
        fakeCognitiveEngine.nextAssessment = createAssessment(InteractionMode.CHAT)

        coordinator.submitIntent("Hola")?.join()

        assertEquals("Atención requerida", coordinator.uiState.value.statusMessage)
        assertEquals("GENERATION_FAILED", coordinator.devToolsBridge.lastTrace?.verification)
        assertEquals(false, coordinator.devToolsBridge.lastTrace?.inferenceTelemetry?.success)
    }

    // --- Test Doubles ---

    private class SpyLocalChatEngine : LocalChatEngine {
        val loadModelCount = AtomicInteger(0)
        var simulatedLoadDelayMs: Long = 0L

        override var isModelLoaded: Boolean = false
        override var loadedModelPath: String? = null
        override var backend: ChatBackend = ChatBackend.CPU
        override var lifecycleState: ModelLifecycleState = ModelLifecycleState.UNLOADED

        override suspend fun loadModel(modelPath: String, backend: ChatBackend): Boolean {
            loadModelCount.incrementAndGet()
            lifecycleState = ModelLifecycleState.LOADING
            if (simulatedLoadDelayMs > 0) {
                kotlinx.coroutines.delay(simulatedLoadDelayMs)
            }
            isModelLoaded = true
            loadedModelPath = modelPath
            this.backend = backend
            lifecycleState = ModelLifecycleState.READY
            return true
        }

        override suspend fun startSession(profile: LocalChatProfile, systemPrompt: String?): LocalChatSession {
            return SpyChatSession()
        }

        override fun close() {
            isModelLoaded = false
            loadedModelPath = null
            lifecycleState = ModelLifecycleState.UNLOADED
        }
    }

    private class SpyChatSession : LocalChatSession {
        override val sessionId: String = "spy-sess"
        override fun sendMessage(text: String): Flow<String> = flowOf("Respuesta de prueba.")
        override suspend fun sendSingleMessage(text: String): String = "Respuesta de prueba."
        override fun getBenchmarkInfo(): SessionBenchmark? = SessionBenchmark(
            initTimeInSecond = 0.05,
            timeToFirstTokenInSecond = 0.5,
            lastPrefillTokenCount = 10,
            lastDecodeTokenCount = 20,
            lastPrefillTokensPerSecond = 200.0,
            lastDecodeTokensPerSecond = 40.0
        )
        override fun close() {}
    }

    private class SpyLocalIntentRouter(appManager: AppManager) : LocalIntentRouter(appManager) {
        val routeCount = AtomicInteger(0)
        var lastRoutedAction: String? = null

        override fun route(text: String): RouteResult {
            routeCount.incrementAndGet()
            val res = super.route(text)
            if (res.directPlan is ActionPlan) {
                lastRoutedAction = (res.directPlan as ActionPlan).action
            }
            return res
        }
    }

    private class SpyAppManager : AppManager(null) {
        val listInstalledAppsCount = AtomicInteger(0)

        override fun listInstalledApps(): List<AppInfo> {
            listInstalledAppsCount.incrementAndGet()
            return listOf(
                AppInfo(packageName = "com.android.chrome", label = "Chrome")
            )
        }
    }

    private class FakeCognitiveEngine : LocalCognitiveEngine {
        override val modelId: String = "fake-cognitive-v1"
        override val backend: String = "JVM_FAKE"
        var nextAssessment: LocalCognitiveAssessment = createAssessment(InteractionMode.CHAT)

        override suspend fun assessTurn(input: LocalCognitiveInput): LocalCognitiveAssessment {
            return nextAssessment
        }
    }

    companion object {
        fun createAssessment(mode: InteractionMode): LocalCognitiveAssessment {
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = mode,
                taskDomain = if (mode == InteractionMode.CHAT) TaskDomain.CONVERSATIONAL else TaskDomain.SYSTEM_SETTINGS,
                localSufficiency = LocalSufficiency.LOCAL_PREFERRED
            )
        }
    }
}
