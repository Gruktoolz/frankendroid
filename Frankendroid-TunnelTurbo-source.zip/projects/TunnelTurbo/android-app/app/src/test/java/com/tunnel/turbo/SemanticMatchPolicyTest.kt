package com.tunnel.turbo

import com.tunnel.turbo.accessibility.SemanticMatchPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SemanticMatchPolicyTest {
    @Test
    fun firstModeStopsAfterFirstMatchAndKeepsFastPath() {
        assertTrue(SemanticMatchPolicy.shouldStopSearch("first", 1))
        assertEquals("first", SemanticMatchPolicy.selectOne("first", listOf("first")))
    }

    @Test
    fun singleModeKeepsSearchingUntilItCanProveUniqueness() {
        assertFalse(SemanticMatchPolicy.shouldStopSearch("single", 1))
        assertTrue(SemanticMatchPolicy.shouldStopSearch("single", 2))
        assertEquals("only", SemanticMatchPolicy.selectOne("single", listOf("only")))
        assertNull(SemanticMatchPolicy.selectOne("single", listOf("one", "two")))
    }

    @Test
    fun allModeCannotSilentlyBecomeASingleClick() {
        assertTrue(SemanticMatchPolicy.shouldStopSearch("all", 0))
        assertNull(SemanticMatchPolicy.selectOne("all", listOf("one", "two")))
    }

    @Test
    fun unknownModeFailsClosed() {
        assertTrue(SemanticMatchPolicy.shouldStopSearch("unknown", 0))
        assertNull(SemanticMatchPolicy.selectOne("unknown", listOf("one")))
    }
}
