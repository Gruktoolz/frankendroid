package com.tunnel.turbo

import com.tunnel.turbo.coordinator.*
import org.junit.Assert.*
import org.junit.Test

class UiStateContractAndHonestyTest {

    @Test
    fun testDefaultStateHonesty_notConfiguredWithoutFalseReadiness() {
        val defaultState = AppUiState()

        // Gate: No label says "ChatGPT READY" without real ChatGPT provider configured and checked
        assertNotEquals("Provider: ChatGPT (READY)", defaultState.debugState.providerStatusText)
        assertEquals(CloudProviderStatus.NOT_CONFIGURED, defaultState.debugState.cloudProvider.status)
        assertFalse("Simulation must be false by default", defaultState.debugState.cloudProvider.isSimulated)
        assertEquals(LocalEngineStatus.UNKNOWN, defaultState.debugState.localEngine.status)
        assertEquals(NavigationTab.CONVERSATION, defaultState.activeTab)
    }

    @Test
    fun testConversationMessageContract_retainsRouteAndProvenance() {
        val msg = ConversationMessage(
            role = MessageRole.ASSISTANT,
            text = "Acción realizada",
            route = Route.ANDROID_AGENT,
            turnStatus = TurnStatus.COMPLETED_VERIFIED,
            provenance = "Android Agent · NodeAction",
            latencyMs = 45.2,
            actionSummary = "Nodo #12",
            verificationExplanation = "Verificado con éxito",
            isSimulated = false
        )

        assertEquals(Route.ANDROID_AGENT, msg.route)
        assertEquals(TurnStatus.COMPLETED_VERIFIED, msg.turnStatus)
        assertEquals("Android Agent · NodeAction", msg.provenance)
        assertEquals(45.2, msg.latencyMs ?: 0.0, 0.001)
        assertEquals("Nodo #12", msg.actionSummary)
        assertEquals("Verificado con éxito", msg.verificationExplanation)
        assertFalse(msg.isSimulated)
    }

    @Test
    fun testNavigationTabTransitions() {
        val state = AppUiState()
        assertEquals(NavigationTab.CONVERSATION, state.activeTab)

        val deviceTab = state.copy(activeTab = NavigationTab.DEVICE)
        assertEquals(NavigationTab.DEVICE, deviceTab.activeTab)

        val labTab = state.copy(activeTab = NavigationTab.SETTINGS_LAB)
        assertEquals(NavigationTab.SETTINGS_LAB, labTab.activeTab)
    }

    @Test
    fun testSimulationIsolationModel() {
        val simState = CloudProviderState(
            status = CloudProviderStatus.RATE_LIMITED,
            providerId = "simulated_chatgpt",
            displayName = "ChatGPT (Simulado)",
            evidenceOrSource = "Simulación manual de laboratorio",
            checkedAtMs = System.currentTimeMillis(),
            isSimulated = true
        )

        assertTrue(simState.isSimulated)
        assertEquals(CloudProviderStatus.RATE_LIMITED, simState.status)
        assertTrue(simState.displayName.contains("Simulado"))
    }
}
