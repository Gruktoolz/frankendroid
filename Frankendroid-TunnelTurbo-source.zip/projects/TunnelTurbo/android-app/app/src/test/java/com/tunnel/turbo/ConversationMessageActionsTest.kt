package com.tunnel.turbo

import com.tunnel.turbo.coordinator.ConversationFeedbackReducer
import com.tunnel.turbo.coordinator.ConversationEditReducer
import com.tunnel.turbo.coordinator.ConversationMessage
import com.tunnel.turbo.coordinator.ConversationRenderPolicy
import com.tunnel.turbo.coordinator.ConversationRenderUpdate
import com.tunnel.turbo.coordinator.MessageFeedback
import com.tunnel.turbo.coordinator.MessageRole
import com.tunnel.turbo.coordinator.ProgressStatusPresenter
import org.junit.Assert.assertEquals
import org.junit.Test

class ConversationMessageActionsTest {
    @Test fun streamingTextUpdatesOnlyTheActiveBubbleAndDoesNotRebuildTranscript() {
        val user = ConversationMessage(id = "u", role = MessageRole.USER, text = "pregunta")
        val streaming = ConversationMessage(id = "a", role = MessageRole.ASSISTANT, text = "primer", turnStatus = com.tunnel.turbo.coordinator.TurnStatus.GENERATING)
        val next = streaming.copy(text = String(charArrayOf('s', 'e', 'g', 'u', 'n', 'd', 'o')))
        assertEquals(ConversationRenderUpdate.STREAMING_TEXT, ConversationRenderPolicy.decide(listOf(user, streaming), listOf(user, next)))
    }

    @Test fun completedTurnOrFeedbackChangeRebuildsActionsOnce() {
        val user = ConversationMessage(id = "u", role = MessageRole.USER, text = "pregunta")
        val streaming = ConversationMessage(id = "a", role = MessageRole.ASSISTANT, text = "respuesta", turnStatus = com.tunnel.turbo.coordinator.TurnStatus.GENERATING)
        assertEquals(ConversationRenderUpdate.REBUILD, ConversationRenderPolicy.decide(listOf(user, streaming), listOf(user, streaming.copy(turnStatus = com.tunnel.turbo.coordinator.TurnStatus.GENERATED))))
        assertEquals(ConversationRenderUpdate.REBUILD, ConversationRenderPolicy.decide(listOf(user, streaming), listOf(user, streaming.copy(feedback = MessageFeedback.POSITIVE))))
    }

    @Test fun identicalConversationDoesNotTriggerRendering() {
        val messages = listOf(ConversationMessage(id = "u", role = MessageRole.USER, text = "pregunta"))
        assertEquals(ConversationRenderUpdate.NONE, ConversationRenderPolicy.decide(messages, messages))
    }

    @Test fun feedbackTogglesOffAndOnlyChangesTargetAssistantMessage() {
        val messages = listOf(
            ConversationMessage(id = "user", role = MessageRole.USER, text = "hello"),
            ConversationMessage(id = "a1", role = MessageRole.ASSISTANT, text = "one"),
            ConversationMessage(id = "a2", role = MessageRole.ASSISTANT, text = "two")
        )
        val liked = ConversationFeedbackReducer.toggle(messages, "a1", MessageFeedback.POSITIVE)
        assertEquals(MessageFeedback.POSITIVE, liked[1].feedback)
        assertEquals(null, liked[0].feedback)
        assertEquals(null, liked[2].feedback)
        val changed = ConversationFeedbackReducer.toggle(liked, "a1", MessageFeedback.NEGATIVE)
        assertEquals(MessageFeedback.NEGATIVE, changed[1].feedback)
        assertEquals(null, ConversationFeedbackReducer.toggle(changed, "a1", MessageFeedback.NEGATIVE)[1].feedback)
    }

    @Test fun feedbackDoesNotChangeUserOrMissingMessage() {
        val messages = listOf(ConversationMessage(id = "u", role = MessageRole.USER, text = "hello"))
        assertEquals(messages, ConversationFeedbackReducer.toggle(messages, "u", MessageFeedback.POSITIVE))
        assertEquals(messages, ConversationFeedbackReducer.toggle(messages, "missing", MessageFeedback.POSITIVE))
    }

    @Test fun editingPromptRetainsOnlyEarlierConversationAndRejectsAssistantMessages() {
        val messages = listOf(
            ConversationMessage(id = "u1", role = MessageRole.USER, text = "primero"),
            ConversationMessage(id = "a1", role = MessageRole.ASSISTANT, text = "respuesta"),
            ConversationMessage(id = "u2", role = MessageRole.USER, text = "segundo"),
            ConversationMessage(id = "a2", role = MessageRole.ASSISTANT, text = "respuesta final")
        )

        assertEquals(messages.take(2), ConversationEditReducer.retainedBefore(messages, "u2"))
        assertEquals(null, ConversationEditReducer.retainedBefore(messages, "a2"))
        assertEquals(null, ConversationEditReducer.retainedBefore(messages, "missing"))
    }

    @Test fun regeneratingResponseFindsItsUserTurnAndDropsThatTurnAndLaterMessages() {
        val messages = listOf(
            ConversationMessage(id = "u1", role = MessageRole.USER, text = "primero"),
            ConversationMessage(id = "a1", role = MessageRole.ASSISTANT, text = "respuesta"),
            ConversationMessage(id = "u2", role = MessageRole.USER, text = "segundo"),
            ConversationMessage(id = "a2", role = MessageRole.ASSISTANT, text = "respuesta final")
        )

        assertEquals("u2", ConversationEditReducer.userMessageForResponse(messages, "a2")?.id)
        assertEquals(messages.take(2), ConversationEditReducer.retainedBeforeResponse(messages, "a2"))
        assertEquals(null, ConversationEditReducer.userMessageForResponse(messages, "u2"))
        assertEquals(null, ConversationEditReducer.retainedBeforeResponse(messages, "missing"))
    }

    @Test fun progressPresentationUsesOneChangingWordAndHidesWhenIdle() {
        assertEquals("Procesando", ProgressStatusPresenter.present(true, "Procesando..."))
        assertEquals("Pensando", ProgressStatusPresenter.present(true, "Planificando con modelo local…"))
        assertEquals("Verificando", ProgressStatusPresenter.present(true, "", "GoalVerifier"))
        assertEquals("", ProgressStatusPresenter.present(false, "Procesando..."))
    }
}
