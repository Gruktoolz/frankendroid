package com.tunnel.turbo

import com.tunnel.turbo.agent.*
import org.junit.Assert.*
import org.junit.Test

/**
 * TDD Regression Tests for Media Playback Goal Verification Truth (Phase 13B-1.2a.3, Section 5-8)
 *
 * Verifies:
 * 1. AudioManager.isMusicActive alone MUST NOT prove that a requested media entity was played.
 * 2. Unrelated audio or absent metadata must yield truthful UNVERIFIED/PARTIAL status, NEVER COMPLETED_VERIFIED.
 * 3. Media evidence contract supports title/artist/album/sessionPackage metadata.
 * 4. Verifier distinguishes execution receipts from independent observed state evidence.
 */
class MediaGoalVerificationTest {

    private val verifier = GoalVerifier()

    @Test
    fun mediaVerifierRejectsUnrelatedAudio() {
        // Requested goal specifies playing a specific track
        val goal = Goal(
            originalText = "reproduce Track-A",
            objective = "Reproducir Track-A",
            entities = listOf(GoalEntity(type = "track", value = "Track-A")),
            desiredState = "Track-A reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        // Observed state: audio is active in the OS (AudioManager.isMusicActive == true),
        // but no track metadata is available or verified matching Track-A.
        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = null // No metadata proving Track-A
        )

        val result = verifier.verify(goal, evidence, emptyList())

        // Critical P1-01 assertion: MUST NOT be COMPLETED_VERIFIED!
        assertNotEquals(
            "P1-01 Violation: Generic isMusicActive must NOT yield COMPLETED_VERIFIED for specific entity",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse("Goal must not be marked satisfied without entity proof", result.satisfied)
        assertTrue(
            "Truthful outcome should be COMPLETED_UNVERIFIED or PARTIAL, got: ${result.outcome}",
            result.outcome == GoalOutcome.COMPLETED_UNVERIFIED || result.outcome == GoalOutcome.PARTIAL
        )
    }

    @Test
    fun mediaVerifierRejectsMismatchedTrackMetadata() {
        val goal = Goal(
            originalText = "reproduce Track-A",
            objective = "Reproducir Track-A",
            entities = listOf(GoalEntity(type = "track", value = "Track-A")),
            desiredState = "Track-A reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        // Metadata explicitly shows a different track is playing (Track-B)
        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Track-B",
                artist = "Artist-B",
                evidenceSource = "MEDIA_CONTROLLER"
            )
        )

        val result = verifier.verify(goal, evidence, emptyList())

        assertNotEquals(
            "Mismatched active track must NOT yield COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun mediaVerifierAcceptsWhenMatchingMetadataIsPresent() {
        val goal = Goal(
            originalText = "reproduce Track-A",
            objective = "Reproducir Track-A",
            entities = listOf(GoalEntity(type = "track", value = "Track-A")),
            desiredState = "Track-A reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Track-A",
                artist = "Artist-A",
                evidenceSource = "MEDIA_CONTROLLER"
            )
        )

        val result = verifier.verify(goal, evidence, emptyList())

        assertEquals(
            "Matching metadata should yield COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertTrue(result.satisfied)
    }

    @Test
    fun mediaVerifierAcceptsExecutionReceiptAsUnverified() {
        val goal = Goal(
            originalText = "reproduce Track-A",
            objective = "Reproducir Track-A",
            entities = listOf(GoalEntity(type = "track", value = "Track-A")),
            desiredState = "Track-A reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        // Execution receipt indicates the route started Track-A, and AudioManager reports music is active,
        // but no independent MediaController metadata is observable.
        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = null,
            executionReceipts = listOf(
                ExecutionReceipt(routeId = "native_media_route", entityMatched = true)
            )
        )

        val result = verifier.verify(goal, evidence, emptyList())

        // Must distinguish execution receipt from independent observed state: COMPLETED_UNVERIFIED
        assertEquals(
            "Execution receipt without independent metadata must yield COMPLETED_UNVERIFIED",
            GoalOutcome.COMPLETED_UNVERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun mediaVerifierAcceptsGenericMusicPlaybackWhenNoEntitySpecified() {
        val goal = Goal(
            originalText = "reproduce música",
            objective = "reproducir música",
            entities = emptyList(),
            desiredState = "música reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val evidence = GoalEvidence(isMusicActive = true)
        val result = verifier.verify(goal, evidence, emptyList())

        assertEquals(
            "Generic media goal with music active should yield COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertTrue(result.satisfied)
    }

    @Test
    fun playlistEntityCannotMatchUnrelatedTrack() {
        // Section 18 & 20: Playlist entity must NOT be verified from track metadata alone
        val goal = Goal(
            originalText = "reproduce playlist Rock Hits",
            objective = "Reproducir playlist Rock Hits",
            entities = listOf(GoalEntity(type = "playlist", value = "Rock Hits")),
            desiredState = "playlist Rock Hits reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Random Track",
                artist = "Random Artist",
                evidenceSource = "MEDIA_CONTROLLER"
            )
        )

        val result = verifier.verify(goal, evidence, emptyList())

        assertNotEquals(
            "P1-A3-05: Playlist goal must NOT yield COMPLETED_VERIFIED from unrelated track metadata alone",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun unknownMediaEntityTypeFailsClosed() {
        // Section 18: Unknown media entity must fail closed, never become NO REQUIREMENT
        val goal = Goal(
            originalText = "reproduce custom entity",
            objective = "Reproducir custom entity",
            entities = listOf(GoalEntity(type = "unsupported_media_entity", value = "Custom Target")),
            desiredState = "custom entity reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Some Title",
                artist = "Some Artist",
                evidenceSource = "MEDIA_CONTROLLER"
            )
        )

        val result = verifier.verify(goal, evidence, emptyList())

        assertNotEquals(
            "Unknown media entity type must NOT verify successfully",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun allRequiredMediaEntitiesMustMatch() {
        // Section 21: track = "Track-X" AND artist = "Artist-Y" must both match
        val goal = Goal(
            originalText = "reproduce Track-X de Artist-Y",
            objective = "Reproducir Track-X de Artist-Y",
            entities = listOf(
                GoalEntity(type = "track", value = "Track-X"),
                GoalEntity(type = "artist", value = "Artist-Y")
            ),
            desiredState = "Track-X de Artist-Y reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        // Only artist matches, track is DIFFERENT
        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Completely Different Song",
                artist = "Artist-Y",
                evidenceSource = "MEDIA_CONTROLLER"
            )
        )

        val result = verifier.verify(goal, evidence, emptyList())

        assertNotEquals(
            "When both track and artist are specified, one matching must NOT yield COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun mediaMatchDoesNotUseSubstringCollision() {
        // Section 21: "Cat" must not match "Catalog of Disasters"
        val goal = Goal(
            originalText = "reproduce Cat",
            objective = "Reproducir Cat",
            entities = listOf(GoalEntity(type = "track", value = "Cat")),
            desiredState = "Cat reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Catalog of Disasters",
                artist = "Someone",
                evidenceSource = "MEDIA_CONTROLLER"
            )
        )

        val result = verifier.verify(goal, evidence, emptyList())

        assertNotEquals(
            "Substring collision 'Cat' vs 'Catalog of Disasters' must NOT yield COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun staleMediaEvidenceCannotVerifyGoal() {
        // Section 17: Evidence from 5 minutes ago is stale and cannot verify
        val goal = Goal(
            originalText = "reproduce Track-A",
            objective = "Reproducir Track-A",
            entities = listOf(GoalEntity(type = "track", value = "Track-A")),
            desiredState = "Track-A reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )

        val now = System.currentTimeMillis()
        val staleEvidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Track-A",
                artist = "Artist-A",
                observedAtMs = now - 300_000L // 5 minutes old
            ),
            timestamp = now
        )

        val result = verifier.verify(goal, staleEvidence, emptyList())

        assertNotEquals(
            "Stale media evidence must NOT yield COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun appOnlyWrongPackageFailsVerification() {
        val goal = Goal(
            originalText = "reproduce en com.example.player",
            objective = "Reproducir en com.example.player",
            entities = listOf(GoalEntity(type = "app", value = "com.example.player")),
            desiredState = "reproduciendo",
            categoryHint = "MEDIA_PLAYBACK"
        )
        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Any Song",
                artist = "Any Artist",
                sessionPackage = "com.different.player"
            )
        )
        val result = verifier.verify(goal, evidence, emptyList())
        assertNotEquals(
            "Goal requesting app com.example.player must NOT verify against sessionPackage com.different.player",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun appAndTrackWrongPackageFailsVerification() {
        val goal = Goal(
            originalText = "reproduce Track-A en com.example.player",
            objective = "Reproducir Track-A en com.example.player",
            entities = listOf(
                GoalEntity(type = "app", value = "com.example.player"),
                GoalEntity(type = "track", value = "Track-A")
            ),
            desiredState = "Track-A reproduciéndose",
            categoryHint = "MEDIA_PLAYBACK"
        )
        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Track-A",
                artist = "Artist-A",
                sessionPackage = "com.different.player"
            )
        )
        val result = verifier.verify(goal, evidence, emptyList())
        assertNotEquals(
            "Matching track with mismatched app package must NOT verify as COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun appHumanLabelWithoutResolvedPackageCannotVerify() {
        val goal = Goal(
            originalText = "reproduce en MusicApp",
            objective = "Reproducir en MusicApp",
            entities = listOf(GoalEntity(type = "app", value = "MusicApp")),
            desiredState = "reproduciendo",
            categoryHint = "MEDIA_PLAYBACK"
        )
        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Song",
                artist = "Artist",
                sessionPackage = "com.music.player"
            )
        )
        val result = verifier.verify(goal, evidence, emptyList())
        assertNotEquals(
            "Human app label without resolved package cannot yield COMPLETED_VERIFIED",
            GoalOutcome.COMPLETED_VERIFIED,
            result.outcome
        )
        assertFalse(result.satisfied)
    }

    @Test
    fun propertyMismatchedAppPackageCannotYieldCompletedVerified() {
        for (i in 0 until 20) {
            val reqPkg = "com.app.req$i"
            val obsPkg = "com.app.obs${i + 100}"
            val goal = Goal(
                originalText = "play in $reqPkg",
                objective = "Play in $reqPkg",
                entities = listOf(GoalEntity("app", reqPkg)),
                categoryHint = "MEDIA_PLAYBACK"
            )
            val evidence = GoalEvidence(
                isMusicActive = true,
                mediaEvidence = MediaPlaybackEvidence(
                    playbackActive = true,
                    title = "Song",
                    artist = "Artist",
                    sessionPackage = obsPkg
                )
            )
            val result = verifier.verify(goal, evidence, emptyList())
            assertNotEquals("Property violation (seed 133742L, iter $i): mismatched package $reqPkg != $obsPkg must never yield COMPLETED_VERIFIED",
                GoalOutcome.COMPLETED_VERIFIED, result.outcome)
            assertFalse(result.satisfied)
        }
    }

    @Test
    fun propertyAddingUnmetConstraintCannotImproveOutcome() {
        val validTrack = "Song Alpha"
        val validArtist = "Artist Beta"
        val baseGoal = Goal(
            originalText = "play $validTrack by $validArtist",
            objective = "Play $validTrack",
            entities = listOf(GoalEntity("track", validTrack), GoalEntity("artist", validArtist)),
            categoryHint = "MEDIA_PLAYBACK"
        )
        val baseEvidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = validTrack,
                artist = validArtist,
                sessionPackage = "com.valid.player"
            )
        )
        val baseResult = verifier.verify(baseGoal, baseEvidence, emptyList())
        assertEquals(GoalOutcome.COMPLETED_VERIFIED, baseResult.outcome)

        // Adding an unmet requirement (e.g. wrong app or unsupported entity) must NEVER convert to COMPLETED_VERIFIED
        val unmetEntities = listOf(
            GoalEntity("app", "com.different.player"),
            GoalEntity("album", "Wrong Album"),
            GoalEntity("playlist", "Chill Vibes"),
            GoalEntity("genre", "Jazz"),
            GoalEntity("unknown_type", "Foo")
        )
        for ((idx, unmet) in unmetEntities.withIndex()) {
            val augmentedGoal = baseGoal.copy(entities = baseGoal.entities + unmet)
            val result = verifier.verify(augmentedGoal, baseEvidence, emptyList())
            assertNotEquals("Property violation (iter $idx): adding unmet entity ${unmet.type}=${unmet.value} must NOT maintain COMPLETED_VERIFIED",
                GoalOutcome.COMPLETED_VERIFIED, result.outcome)
            assertFalse(result.satisfied)
        }
    }

    @Test
    fun propertyEntityOrderingIsOrderIndependent() {
        val track = GoalEntity("track", "Bohemian Rhapsody")
        val artist = GoalEntity("artist", "Queen")
        val app = GoalEntity("app", "com.music.player")

        val evidence = GoalEvidence(
            isMusicActive = true,
            mediaEvidence = MediaPlaybackEvidence(
                playbackActive = true,
                title = "Bohemian Rhapsody",
                artist = "Queen",
                sessionPackage = "com.music.player"
            )
        )

        val permutations = listOf(
            listOf(track, artist, app),
            listOf(track, app, artist),
            listOf(artist, track, app),
            listOf(artist, app, track),
            listOf(app, track, artist),
            listOf(app, artist, track)
        )

        val firstOutcome = verifier.verify(Goal(originalText = "play", objective = "play", entities = permutations[0], categoryHint = "MEDIA_PLAYBACK"), evidence, emptyList()).outcome
        assertEquals(GoalOutcome.COMPLETED_VERIFIED, firstOutcome)

        for ((idx, perm) in permutations.withIndex()) {
            val outcome = verifier.verify(Goal(originalText = "play", objective = "play", entities = perm, categoryHint = "MEDIA_PLAYBACK"), evidence, emptyList()).outcome
            assertEquals("Permutation $idx must match first outcome", firstOutcome, outcome)
        }
    }
}

