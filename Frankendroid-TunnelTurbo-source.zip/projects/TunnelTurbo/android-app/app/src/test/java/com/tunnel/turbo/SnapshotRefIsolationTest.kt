package com.tunnel.turbo

import android.content.Context
import android.graphics.Rect
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.core.NativeActionEngine
import com.tunnel.turbo.core.NativeStateEngine
import com.tunnel.turbo.core.NativeTunnelCore
import com.tunnel.turbo.core.NativeVerifier
import com.tunnel.turbo.model.TaskPlan
import com.tunnel.turbo.model.ToolStep
import com.tunnel.turbo.perception.ElementSource
import com.tunnel.turbo.perception.PerceptionRouter
import com.tunnel.turbo.perception.UnifiedElement
import com.tunnel.turbo.perception.WorldSnapshot
import com.tunnel.turbo.task.NativeTaskExecutor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.Mockito.mock
import org.mockito.Mockito.`when`

class SnapshotRefIsolationTest {

    private fun createTaskExecutor(): NativeTaskExecutor {
        val mockContext = mock(Context::class.java)
        val mockActionEngine = mock(NativeActionEngine::class.java)
        val mockStateEngine = mock(NativeStateEngine::class.java)
        val mockVerifier = mock(NativeVerifier::class.java)
        val mockAccessibilityBridge = mock(AccessibilityBridge::class.java)
        val mockAppManager = mock(AppManager::class.java)
        val arbiter = com.tunnel.turbo.core.DisplayMutationArbiter()

        `when`(mockStateEngine.currentState).thenReturn(com.tunnel.turbo.core.NativeDeviceState())
        `when`(mockAccessibilityBridge.getUiNodes(0)).thenReturn(emptyList())
        `when`(mockAccessibilityBridge.getUiNodes(1)).thenReturn(emptyList())

        return NativeTaskExecutor(
            context = mockContext,
            actionEngine = mockActionEngine,
            stateEngine = mockStateEngine,
            verifier = mockVerifier,
            accessibilityBridge = mockAccessibilityBridge,
            appManager = mockAppManager,
            arbiter = arbiter
        )
    }

    @Test
    fun snapshotRefsCannotCrossDisplayOrRevision_rejectsCrossDisplayMutation() = runBlocking {
        val taskExecutor = createTaskExecutor()

        // Snapshot exists for display 0 at revision 100
        val snapD0 = WorldSnapshot(
            displayId = 0,
            revision = 100L,
            capturedAtMs = System.currentTimeMillis(),
            foregroundPackage = "com.example.app",
            foregroundActivity = "MainActivity",
            unifiedElements = listOf(
                UnifiedElement(
                    ref = "a:0:100:btn1",
                    label = "Submit",
                    roleHint = "button",
                    source = ElementSource.ACCESSIBILITY,
                    confidence = 1.0f,
                    boundsInternal = Rect(100, 100, 200, 200),
                    actionableHint = "click",
                    displayId = 0,
                    revision = 100L
                )
            )
        )
        taskExecutor.currentSnapshotProvider = { snapD0 }

        // Action targets display 1 using a ref from display 0: "a:0:100:btn1"
        val stepCrossDisplay = ToolStep(
            tool = "click_node",
            arguments = mapOf(
                "displayId" to 1,
                "ref" to "a:0:100:btn1"
            )
        )
        val plan = TaskPlan(steps = listOf(stepCrossDisplay))
        val result = taskExecutor.executeTask(plan)

        assertFalse("Cross-display ref mutation must fail", result.success)
        assertTrue("Error must mention DISPLAY_MISMATCH", result.stepResults[0].error?.contains("DISPLAY_MISMATCH") == true)
    }

    @Test
    fun snapshotRefsCannotCrossDisplayOrRevision_rejectsStaleRevision() = runBlocking {
        val taskExecutor = createTaskExecutor()

        // Current snapshot is at revision 105
        val snapD0 = WorldSnapshot(
            displayId = 0,
            revision = 105L,
            capturedAtMs = System.currentTimeMillis(),
            foregroundPackage = "com.example.app",
            foregroundActivity = "MainActivity",
            unifiedElements = listOf(
                UnifiedElement(
                    ref = "a:0:105:btn1",
                    label = "Submit",
                    roleHint = "button",
                    source = ElementSource.ACCESSIBILITY,
                    confidence = 1.0f,
                    boundsInternal = Rect(100, 100, 200, 200),
                    actionableHint = "click",
                    displayId = 0,
                    revision = 105L
                )
            )
        )
        taskExecutor.currentSnapshotProvider = { snapD0 }

        // Action passes stale revision 100
        val stepStaleRevision = ToolStep(
            tool = "click_node",
            arguments = mapOf(
                "displayId" to 0,
                "ref" to "a:0:100:btn1"
            )
        )
        val plan = TaskPlan(steps = listOf(stepStaleRevision))
        val result = taskExecutor.executeTask(plan)

        assertFalse("Stale revision ref mutation must fail", result.success)
        assertTrue("Error must mention STALE_ELEMENT_REF", result.stepResults[0].error?.contains("STALE_ELEMENT_REF") == true)
    }

    @Test
    fun observingWorkerDisplayDoesNotClobberMainDisplaySnapshotInTunnelCore(): Unit = runBlocking {
        val mockPerceptionRouter = mock(PerceptionRouter::class.java)

        val snapD0 = WorldSnapshot(
            displayId = 0,
            revision = 1L,
            capturedAtMs = System.currentTimeMillis(),
            foregroundPackage = "com.example.app",
            foregroundActivity = "MainActivity",
            unifiedElements = emptyList()
        )
        val snapD1 = WorldSnapshot(
            displayId = 1,
            revision = 2L,
            capturedAtMs = System.currentTimeMillis(),
            foregroundPackage = "com.example.worker",
            foregroundActivity = "WorkerActivity",
            unifiedElements = emptyList()
        )

        `when`(mockPerceptionRouter.observeWorld(displayId = 0, goalContext = null)).thenReturn(snapD0)
        `when`(mockPerceptionRouter.observeWorld(displayId = 1, goalContext = null)).thenReturn(snapD1)

        val core = NativeTunnelCore(customPerceptionRouter = mockPerceptionRouter)

        // Observe display 0
        val r0 = core.getOrRefreshWorldSnapshot(displayId = 0, force = true)
        assertEquals(0, r0?.displayId)

        // Observe display 1
        val r1 = core.getOrRefreshWorldSnapshot(displayId = 1, force = true)
        assertEquals(1, r1?.displayId)

        // Verifying display 0 snapshot is NOT clobbered by display 1 observation
        val r0After = core.getOrRefreshWorldSnapshot(displayId = 0, force = false)
        assertNotNull("Display 0 snapshot must not be null after display 1 observation", r0After)
        assertEquals("Display 0 snapshot must retain displayId 0", 0, r0After?.displayId)
        assertEquals("Display 0 snapshot revision must remain 1", 1L, r0After?.revision)
        org.mockito.Mockito.verify(mockPerceptionRouter, org.mockito.Mockito.times(1)).observeWorld(0, null)
    }

    @Test
    fun missingDisplaySnapshotNeverReturnsOtherDisplaySnapshot() = runBlocking {
        val mockPerceptionRouter = mock(PerceptionRouter::class.java)
        val snapD0 = WorldSnapshot(
            displayId = 0,
            revision = 1L,
            capturedAtMs = System.currentTimeMillis(),
            foregroundPackage = "com.example.app",
            foregroundActivity = "MainActivity",
            unifiedElements = emptyList()
        )
        `when`(mockPerceptionRouter.observeWorld(displayId = 0, goalContext = null)).thenReturn(snapD0)

        val core = NativeTunnelCore(customPerceptionRouter = mockPerceptionRouter)
        // Refresh display 0 snapshot
        core.getOrRefreshWorldSnapshot(displayId = 0, force = true)

        // Querying snapshot for Display 1 (which has no snapshot) MUST return null, NEVER display 0 snapshot
        val snapD1 = core.taskExecutor.snapshotForDisplayProvider?.invoke(1)
        org.junit.Assert.assertNull(
            "Section 29: Missing snapshot for target display must return null, never fall back to another display's snapshot",
            snapD1
        )
    }
}
