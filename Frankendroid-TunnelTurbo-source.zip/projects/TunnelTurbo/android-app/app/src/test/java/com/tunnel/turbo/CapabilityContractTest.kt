package com.tunnel.turbo

import com.tunnel.turbo.capability.CapabilityRegistry
import com.tunnel.turbo.task.NativeTaskExecutor
import org.junit.Assert.*
import org.junit.Test

class CapabilityContractTest {

    @Test
    fun testCapabilityContractZeroMismatches() {
        val registry = CapabilityRegistry()
        val allCapabilities = registry.getAllCapabilities()

        val registeredCount = allCapabilities.size
        assertEquals("Debe haber exactamente 20 capabilities registradas", 20, registeredCount)

        val supportedTools = NativeTaskExecutor.SUPPORTED_TOOLS
        val mismatches = registry.getContractMismatches(supportedTools)

        println("=== CAPABILITY CONTRACT AUDIT ===")
        println("Registered: $registeredCount")
        println("Executable in NativeTaskExecutor: ${supportedTools.size}")
        println("Mismatches: ${mismatches.size} -> $mismatches")

        // 1. Schema Validation for every capability
        for (cap in allCapabilities) {
            assertNotNull("Capability ID must not be null", cap.id)
            assertTrue("Capability ID must not be blank", cap.id.isNotBlank())
            assertNotNull("Category must not be null for ${cap.id}", cap.category)
            assertNotNull("RiskLevel must not be null for ${cap.id}", cap.riskLevel)
            assertTrue("Description must be meaningful for ${cap.id}", cap.description.length >= 10)
            assertTrue("Capability ${cap.id} MUST be executable in NativeTaskExecutor", registry.isExecutable(cap.id))
        }

        // 2. Invariant: contractMismatchCount == 0
        assertEquals("contractMismatchCount must be exactly 0", 0, mismatches.size)

        // 3. Availability and Exposure Checks
        // Case A: Everything disabled
        val noneAvailable = registry.getAvailableCapabilities(shizukuReady = false, accessibilityReady = false)
        for (cap in noneAvailable) {
            assertFalse("Capability requiring Shizuku cannot be available without Shizuku", cap.requiresShizuku)
            assertFalse("Capability requiring Accessibility cannot be available without Accessibility", cap.requiresAccessibility)
        }

        // Case B: Everything enabled
        val allAvailable = registry.getAvailableCapabilities(shizukuReady = true, accessibilityReady = true)
        assertEquals("All 20 capabilities must be available when all dependencies are ready", 20, allAvailable.size)

        for (cap in allAvailable) {
            assertTrue("Advertised capability ${cap.id} MUST be executable", supportedTools.contains(cap.id))
        }
    }
}
