package com.tunnel.turbo.worker

data class WorkerSession(
    val provider: String = "chatgpt",
    val packageId: String = "com.openai.chatgpt",
    var displayId: Int? = null,
    var conversationGeneration: Int = 1,
    var requestCounter: Int = 0,
    var currentRequestId: String? = null,
    var turnsUsed: Int = 0,
    var maxTurnsPerWorker: Int = 30,
    var lastRequestAt: Long = System.currentTimeMillis()
) {
    fun nextRequestId(): String {
        requestCounter++
        currentRequestId = String.format("TT_%06d", requestCounter)
        turnsUsed++
        lastRequestAt = System.currentTimeMillis()
        return currentRequestId!!
    }

    fun needsRotation(): Boolean {
        return turnsUsed >= maxTurnsPerWorker
    }

    fun rotateConversation() {
        conversationGeneration++
        turnsUsed = 0
    }
}
