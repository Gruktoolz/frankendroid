package com.tunnel.turbo.core

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService
import com.tunnel.turbo.model.ActionPlan

data class ActionResult(
    val success: Boolean,
    val action: String,
    val details: String = "",
    val executionMs: Double = 0.0,
    val verified: Boolean = false,
    val verificationMs: Double = 0.0
)

enum class DisplayTargetingSupport {
    GLOBAL,
    PRIMARY_DISPLAY_ONLY,
    TARGET_DISPLAY_CAPABLE
}

class NativeActionEngine(
    private val context: Context?,
    private val stateEngine: NativeStateEngine,
    private val verifier: NativeVerifier,
    private val journal: NativeEventJournal? = null,
    val displayPolicy: DisplayTargetPolicy = DisplayTargetPolicy(),
    val arbiter: DisplayMutationArbiter = DisplayMutationArbiter()
) {
    companion object {
        val ACTION_DISPLAY_SUPPORT: Map<String, DisplayTargetingSupport> = mapOf(
            "semantic_tap" to DisplayTargetingSupport.TARGET_DISPLAY_CAPABLE,
            "open_wifi_settings" to DisplayTargetingSupport.PRIMARY_DISPLAY_ONLY,
            "open_bluetooth_settings" to DisplayTargetingSupport.PRIMARY_DISPLAY_ONLY,
            "open_settings" to DisplayTargetingSupport.PRIMARY_DISPLAY_ONLY,
            "open_app" to DisplayTargetingSupport.PRIMARY_DISPLAY_ONLY,
            "press_back" to DisplayTargetingSupport.GLOBAL,
            "press_home" to DisplayTargetingSupport.GLOBAL,
            "press_key" to DisplayTargetingSupport.GLOBAL
        )
    }

    private val packageRegex = Regex("^[a-zA-Z0-9_]+(\\.[a-zA-Z0-9_]+)+$")

    suspend fun executeAction(
        actionPlan: ActionPlan,
        isWorkerOperation: Boolean = false,
        verify: Boolean = true
    ): ActionResult {
        val requestedDisplay = (actionPlan.arguments["displayId"] as? Number)?.toInt()
        val targetDisplay = displayPolicy.resolveTargetDisplay(isWorkerOperation, requestedDisplay)

        // Section 30: If an action cannot target the requested secondary worker display, fail before side effect!
        val support = ACTION_DISPLAY_SUPPORT[actionPlan.action] ?: DisplayTargetingSupport.PRIMARY_DISPLAY_ONLY
        if (isWorkerOperation && targetDisplay != displayPolicy.primaryDisplayId && support != DisplayTargetingSupport.TARGET_DISPLAY_CAPABLE) {
            return ActionResult(
                success = false,
                action = actionPlan.action,
                details = "ACTION_FAILED: Action '${actionPlan.action}' declared display support is $support and cannot target secondary worker display $targetDisplay",
                executionMs = 0.0,
                verified = false
            )
        }

        return arbiter.withMutationLease(
            displayId = targetDisplay,
            requestId = actionPlan.action
        ) {
            executeActionInternal(actionPlan, isWorkerOperation, verify, targetDisplay)
        }
    }

    private suspend fun executeActionInternal(
        actionPlan: ActionPlan,
        isWorkerOperation: Boolean,
        verify: Boolean,
        targetDisplay: Int
    ): ActionResult {
        val t0 = System.nanoTime()
        val action = actionPlan.action
        val args = actionPlan.arguments
        val initialRev = stateEngine.currentState.revision
        val initialPkg = stateEngine.currentState.foregroundPackage
        val initialActivity = stateEngine.currentState.foregroundActivity

        journal?.recordEvent("action_started", mapOf("action" to action, "arguments" to args))

        var dispatched = false
        var message = ""

        try {
            when (action) {
                "open_wifi_settings" -> {
                    if (context != null) {
                        val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                        dispatched = true
                        message = "Intent Settings.ACTION_WIFI_SETTINGS despachado"
                    } else {
                        dispatched = true
                        message = "Headless execution: open_wifi_settings"
                    }
                }

                "open_bluetooth_settings" -> {
                    if (context != null) {
                        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                        dispatched = true
                        message = "Intent Settings.ACTION_BLUETOOTH_SETTINGS despachado"
                    } else {
                        dispatched = true
                        message = "Headless execution: open_bluetooth_settings"
                    }
                }

                "open_settings" -> {
                    if (context != null) {
                        val intent = context.packageManager.getLaunchIntentForPackage("com.android.settings")
                            ?: Intent(Settings.ACTION_SETTINGS).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                        context.startActivity(intent)
                        dispatched = true
                        message = "Intent Settings.ACTION_SETTINGS despachado"
                    } else {
                        dispatched = true
                        message = "Headless execution: open_settings"
                    }
                }

                "open_app" -> {
                    val pkg = args["package"] as? String ?: ""
                    if (!packageRegex.matches(pkg)) {
                        dispatched = false
                        message = "ACTION_FAILED: Nombre de paquete inválido o malicioso: $pkg"
                    } else if (context != null) {
                        val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                        if (launchIntent != null) {
                            launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            context.startActivity(launchIntent)
                            dispatched = true
                            message = "App $pkg iniciada vía PackageManager"
                        } else {
                            dispatched = false
                            message = "ACTION_FAILED: App $pkg no está instalada en el dispositivo"
                        }
                    } else {
                        dispatched = true
                        message = "Headless execution: open_app($pkg)"
                    }
                }

                "press_back" -> {
                    val ok = TunnelTurboAccessibilityService.instance?.performGlobalAction(
                        AccessibilityService.GLOBAL_ACTION_BACK
                    ) == true
                    dispatched = ok || context == null
                    message = if (ok) "GLOBAL_ACTION_BACK ejecutada vía Accessibility" else "press_back ejecutada"
                }

                "press_home" -> {
                    val globalOk = TunnelTurboAccessibilityService.instance?.performGlobalAction(
                        AccessibilityService.GLOBAL_ACTION_HOME
                    ) == true
                    if (!globalOk && context != null) {
                        val intent = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_HOME)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                    }
                    dispatched = true
                    message = if (globalOk) "GLOBAL_ACTION_HOME ejecutada vía Accessibility" else "Intent CATEGORY_HOME despachado"
                }

                "press_key" -> {
                    val key = args["key"] as? String ?: ""
                    when (key.uppercase()) {
                        "BACK" -> {
                            val ok = TunnelTurboAccessibilityService.instance?.performGlobalAction(
                                AccessibilityService.GLOBAL_ACTION_BACK
                            ) == true
                            dispatched = ok || context == null
                            message = "Key BACK ejecutada"
                        }
                        "HOME" -> {
                            val ok = TunnelTurboAccessibilityService.instance?.performGlobalAction(
                                AccessibilityService.GLOBAL_ACTION_HOME
                            ) == true
                            if (!ok && context != null) {
                                val intent = Intent(Intent.ACTION_MAIN).apply {
                                    addCategory(Intent.CATEGORY_HOME)
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            }
                            dispatched = true
                            message = "Key HOME ejecutada"
                        }
                        else -> {
                            dispatched = false
                            message = "ACTION_FAILED: Tecla no soportada: $key"
                        }
                    }
                }

                "semantic_tap" -> {
                    val selector = args["selector"] as? String ?: ""
                    val acc = TunnelTurboAccessibilityService.instance

                    if (acc != null) {
                        val node = acc.findNode(targetDisplay) { n ->
                            when {
                                selector.startsWith("text=") -> {
                                    val expected = selector.substring(5).trim()
                                    n.text?.toString()?.equals(expected, ignoreCase = true) == true
                                }
                                selector.startsWith("contentDescription=") -> {
                                    val expected = selector.substring(19).trim()
                                    n.contentDescription?.toString()?.equals(expected, ignoreCase = true) == true
                                }
                                selector.startsWith("resourceId=") -> {
                                    val expected = selector.substring(11).trim()
                                    n.viewIdResourceName?.equals(expected) == true
                                }
                                else -> {
                                    n.text?.toString()?.contains(selector, ignoreCase = true) == true
                                }
                            }
                        }

                        if (node != null) {
                            val clicked = acc.performClick(node)
                            dispatched = clicked
                            message = if (clicked) "Semantic tap ejecutado en display $targetDisplay ($selector)" else "Fallo al ejecutar click en nodo"
                        } else {
                            dispatched = false
                            message = "ACTION_FAILED: Nodo no encontrado para selector $selector en display $targetDisplay"
                        }
                    } else {
                        dispatched = true
                        message = "Headless validation: semantic_tap($selector) on display $targetDisplay"
                    }
                }

                else -> {
                    dispatched = false
                    message = "ACTION_FAILED: Acción desconocida o no autorizada en allowlist: $action"
                }
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            dispatched = false
            message = "Error en NativeActionEngine: ${t.message}"
        }

        val execMs = (System.nanoTime() - t0) / 1_000_000.0

        // Verification phase (performed when running with an Android context)
        var verified = false
        var verifMs = 0.0

        if (dispatched && verify && context != null) {
            val vOutcome = verifier.verifyAction(
                actionName = action,
                arguments = args,
                initialRevision = initialRev,
                initialPkg = initialPkg,
                initialActivity = initialActivity
            )
            verified = vOutcome.verified
            verifMs = vOutcome.elapsedMs
        } else {
            verified = dispatched
        }

        journal?.recordEvent(
            "action_completed",
            mapOf("action" to action, "dispatched" to dispatched, "verified" to verified, "details" to message)
        )

        return ActionResult(
            success = dispatched && (if (verify) verified else true),
            action = action,
            details = message,
            executionMs = execMs,
            verified = verified,
            verificationMs = verifMs
        )
    }
}
