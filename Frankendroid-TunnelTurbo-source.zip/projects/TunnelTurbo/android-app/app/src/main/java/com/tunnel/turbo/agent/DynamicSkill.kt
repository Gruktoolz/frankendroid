package com.tunnel.turbo.agent

import com.tunnel.turbo.model.ToolStep
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class SkillState {
    PROPOSED,
    VALIDATING,
    ACTIVE,
    DEPRECATED
}

data class SkillParameter(
    val name: String,
    val type: String,
    val description: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name)
        put("type", type)
        put("description", description)
    }

    companion object {
        fun fromJson(json: JSONObject): SkillParameter = SkillParameter(
            name = json.optString("name", ""),
            type = json.optString("type", "string"),
            description = json.optString("description", "")
        )
    }
}

data class DynamicSkill(
    val skillId: String,
    val name: String,
    val description: String,
    val goalPattern: String,
    val parameters: List<SkillParameter> = emptyList(),
    val preconditions: List<String> = emptyList(),
    val steps: List<ToolStep> = emptyList(),
    val successConditions: List<String> = emptyList(),
    val failureConditions: List<String> = emptyList(),
    var confidence: Double = 0.5,
    var successCount: Int = 0,
    var failureCount: Int = 0,
    var lastUsed: Long = 0L,
    val version: Int = 1,
    var state: SkillState = SkillState.PROPOSED,
    val examplesSeen: MutableList<String> = mutableListOf(),
    val parameterVariations: MutableList<Map<String, String>> = mutableListOf()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("skillId", skillId)
        put("name", name)
        put("description", description)
        put("goalPattern", goalPattern)
        val pArr = JSONArray()
        parameters.forEach { pArr.put(it.toJson()) }
        put("parameters", pArr)
        val preArr = JSONArray()
        preconditions.forEach { preArr.put(it) }
        put("preconditions", preArr)
        val sArr = JSONArray()
        steps.forEach { sArr.put(it.toJson()) }
        put("steps", sArr)
        val scArr = JSONArray()
        successConditions.forEach { scArr.put(it) }
        put("successConditions", scArr)
        val fcArr = JSONArray()
        failureConditions.forEach { fcArr.put(it) }
        put("failureConditions", fcArr)
        put("confidence", confidence)
        put("successCount", successCount)
        put("failureCount", failureCount)
        put("lastUsed", lastUsed)
        put("version", version)
        put("state", state.name)
        val exArr = JSONArray()
        examplesSeen.forEach { exArr.put(it) }
        put("examplesSeen", exArr)
        val pvArr = JSONArray()
        parameterVariations.forEach { pv ->
            val o = JSONObject()
            pv.forEach { (k, v) -> o.put(k, v) }
            pvArr.put(o)
        }
        put("parameterVariations", pvArr)
    }

    companion object {
        fun fromJson(json: JSONObject): DynamicSkill {
            val params = mutableListOf<SkillParameter>()
            val pArr = json.optJSONArray("parameters")
            if (pArr != null) {
                for (i in 0 until pArr.length()) {
                    val o = pArr.optJSONObject(i)
                    if (o != null) params.add(SkillParameter.fromJson(o))
                }
            }
            val pre = mutableListOf<String>()
            val preArr = json.optJSONArray("preconditions")
            if (preArr != null) {
                for (i in 0 until preArr.length()) pre.add(preArr.optString(i))
            }
            val stepsList = mutableListOf<ToolStep>()
            val sArr = json.optJSONArray("steps")
            if (sArr != null) {
                for (i in 0 until sArr.length()) {
                    val o = sArr.optJSONObject(i)
                    if (o != null) {
                        val argsMap = mutableMapOf<String, Any?>()
                        val argsObj = o.optJSONObject("arguments")
                        if (argsObj != null) {
                            val keys = argsObj.keys()
                            while (keys.hasNext()) {
                                val k = keys.next()
                                argsMap[k] = argsObj.get(k)
                            }
                        }
                        stepsList.add(ToolStep(tool = o.optString("tool", ""), arguments = argsMap))
                    }
                }
            }
            val sc = mutableListOf<String>()
            val scArr = json.optJSONArray("successConditions")
            if (scArr != null) {
                for (i in 0 until scArr.length()) sc.add(scArr.optString(i))
            }
            val fc = mutableListOf<String>()
            val fcArr = json.optJSONArray("failureConditions")
            if (fcArr != null) {
                for (i in 0 until fcArr.length()) fc.add(fcArr.optString(i))
            }
            val ex = mutableListOf<String>()
            val exArr = json.optJSONArray("examplesSeen")
            if (exArr != null) {
                for (i in 0 until exArr.length()) ex.add(exArr.optString(i))
            }
            val pv = mutableListOf<Map<String, String>>()
            val pvArr = json.optJSONArray("parameterVariations")
            if (pvArr != null) {
                for (i in 0 until pvArr.length()) {
                    val o = pvArr.optJSONObject(i)
                    if (o != null) {
                        val m = mutableMapOf<String, String>()
                        val it = o.keys()
                        while (it.hasNext()) {
                            val k = it.next()
                            m[k] = o.optString(k, "")
                        }
                        pv.add(m)
                    }
                }
            }
            return DynamicSkill(
                skillId = json.optString("skillId", ""),
                name = json.optString("name", ""),
                description = json.optString("description", ""),
                goalPattern = json.optString("goalPattern", ""),
                parameters = params,
                preconditions = pre,
                steps = stepsList,
                successConditions = sc,
                failureConditions = fc,
                confidence = json.optDouble("confidence", 0.5),
                successCount = json.optInt("successCount", 0),
                failureCount = json.optInt("failureCount", 0),
                lastUsed = json.optLong("lastUsed", 0L),
                version = json.optInt("version", 1),
                state = try { SkillState.valueOf(json.optString("state", "PROPOSED")) } catch (t: Throwable) { SkillState.PROPOSED },
                examplesSeen = ex,
                parameterVariations = pv
            )
        }
    }
}

data class SkillCandidate(
    val candidateId: String,
    val derivedFromGoal: String,
    val suggestedSkill: DynamicSkill,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("candidateId", candidateId)
        put("derivedFromGoal", derivedFromGoal)
        put("suggestedSkill", suggestedSkill.toJson())
        put("createdAt", createdAt)
    }
}

data class SkillRepairCandidate(
    val skillId: String,
    val failedStepIndex: Int,
    val failedTool: String,
    val failureReason: String,
    val observedStateSnapshot: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("skillId", skillId)
        put("failedStepIndex", failedStepIndex)
        put("failedTool", failedTool)
        put("failureReason", failureReason)
        put("observedStateSnapshot", observedStateSnapshot)
        put("timestamp", timestamp)
    }
}
