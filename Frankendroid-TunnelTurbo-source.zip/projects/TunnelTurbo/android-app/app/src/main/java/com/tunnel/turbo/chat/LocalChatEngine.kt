package com.tunnel.turbo.chat

import kotlinx.coroutines.flow.Flow
import org.json.JSONObject
import java.util.UUID

/**
 * Clean architectural abstraction for local generative language models.
 * Separated strictly from:
 * - LocalCognitiveEngine (understanding / turn classification)
 * - AgentSession (Android execution authority)
 * - GoalVerifier (Android goal completion authority)
 *
 * LocalChatEngine has NO ACCESS to Android capabilities or mutation arbiters.
 */
interface LocalChatEngine : AutoCloseable {
    val isModelLoaded: Boolean
    val loadedModelPath: String?
    val backend: ChatBackend
    val lifecycleState: ModelLifecycleState get() = if (isModelLoaded) ModelLifecycleState.READY else ModelLifecycleState.UNLOADED

    suspend fun loadModel(modelPath: String, backend: ChatBackend = ChatBackend.CPU): Boolean
    suspend fun startSession(profile: LocalChatProfile = LocalChatProfile.FAST, systemPrompt: String? = null): LocalChatSession
    suspend fun startSession(systemPrompt: String?): LocalChatSession = startSession(LocalChatProfile.FAST, systemPrompt)
    override fun close()
}

/**
 * Explicit model loading lifecycle state machine (Section 15).
 */
enum class ModelLifecycleState {
    UNLOADED,
    LOADING,
    READY,
    ERROR,
    CLOSING
}

/**
 * Named execution profile configuring token limits and sampling parameters.
 * Avoids prompt-specific hardcoded limits in production code (Sections 11 & 12).
 */
data class LocalChatProfile(
    val name: String,
    val maxOutputTokens: Int? = null,
    val topK: Int? = null,
    val topP: Double? = null,
    val temperature: Double? = null,
    val seed: Int? = null
) {
    companion object {
        val FAST = LocalChatProfile(
            name = "FAST",
            // The old 192-token ceiling cut ordinary answers mid-sentence. Keep a
            // bounded local budget while allowing a useful multi-paragraph reply.
            maxOutputTokens = 768,
            topK = 40,
            topP = 0.95,
            temperature = 0.7
        )
        val DEFAULT = LocalChatProfile(
            name = "DEFAULT",
            maxOutputTokens = 128
        )
    }
}

/**
 * Native benchmark metrics provided by the engine session.
 */
data class SessionBenchmark(
    val initTimeInSecond: Double = 0.0,
    val timeToFirstTokenInSecond: Double = 0.0,
    val lastPrefillTokenCount: Int = 0,
    val lastDecodeTokenCount: Int = 0,
    val lastPrefillTokensPerSecond: Double = 0.0,
    val lastDecodeTokensPerSecond: Double = 0.0
)

/**
 * Required performance telemetry contract (Section 6).
 */
data class InferenceTelemetry(
    val requestId: String,
    val deviceModel: String = "",
    val deviceProduct: String = "",
    val deviceFingerprint: String = "",
    val runtimeName: String = "LiteRT-LM",
    val runtimeVersion: String = "0.18.0",
    val modelId: String = "Qwen3-0.6B",
    val modelRevision: String = "litert-community",
    val modelHash: String = "UNAVAILABLE",
    val modelBytes: Long = 613722264L,
    val quantization: String = "UNAVAILABLE",
    val requestedBackend: String = "CPU",
    val effectiveBackend: String = "UNAVAILABLE",
    val engineAlreadyLoaded: Boolean = false,
    val engineLoadMs: Long = 0L,
    val conversationCreateMs: Long = 0L,
    val promptTokens: Int? = null,
    val outputTokens: Int? = null,
    val prefillMs: Double? = null,
    val ttftMs: Double? = null,
    val decodeMs: Double? = null,
    val totalMs: Double = 0.0,
    val prefillTokensPerSecond: Double? = null,
    val decodeTokensPerSecond: Double? = null,
    val peakPssKb: Long? = null,
    val nativeHeapKb: Long? = null,
    val thermalStatusBefore: Int? = null,
    val thermalStatusAfter: Int? = null,
    val cancelled: Boolean = false,
    val success: Boolean = true
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("requestId", requestId)
        obj.put("deviceModel", deviceModel)
        obj.put("deviceProduct", deviceProduct)
        obj.put("deviceFingerprint", deviceFingerprint)
        obj.put("runtimeName", runtimeName)
        obj.put("runtimeVersion", runtimeVersion)
        obj.put("modelId", modelId)
        obj.put("modelRevision", modelRevision)
        obj.put("modelHash", modelHash)
        obj.put("modelBytes", modelBytes)
        obj.put("quantization", quantization)
        obj.put("requestedBackend", requestedBackend)
        obj.put("effectiveBackend", effectiveBackend)
        obj.put("engineAlreadyLoaded", engineAlreadyLoaded)
        obj.put("engineLoadMs", engineLoadMs)
        obj.put("conversationCreateMs", conversationCreateMs)
        if (promptTokens != null) obj.put("promptTokens", promptTokens)
        if (outputTokens != null) obj.put("outputTokens", outputTokens)
        if (prefillMs != null) obj.put("prefillMs", prefillMs)
        if (ttftMs != null) obj.put("ttftMs", ttftMs)
        if (decodeMs != null) obj.put("decodeMs", decodeMs)
        obj.put("totalMs", totalMs)
        if (prefillTokensPerSecond != null) obj.put("prefillTokensPerSecond", prefillTokensPerSecond)
        if (decodeTokensPerSecond != null) obj.put("decodeTokensPerSecond", decodeTokensPerSecond)
        if (peakPssKb != null) obj.put("peakPssKb", peakPssKb)
        if (nativeHeapKb != null) obj.put("nativeHeapKb", nativeHeapKb)
        if (thermalStatusBefore != null) obj.put("thermalStatusBefore", thermalStatusBefore)
        if (thermalStatusAfter != null) obj.put("thermalStatusAfter", thermalStatusAfter)
        obj.put("cancelled", cancelled)
        obj.put("success", success)
        return obj
    }
}

/**
 * Stateful conversation session wrapping the underlying engine's chat context.
 */
interface LocalChatSession : AutoCloseable {
    val sessionId: String

    /**
     * Streams response chunks for the user prompt.
     */
    fun sendMessage(text: String): Flow<String>

    /**
     * Non-streaming convenience method returning complete response.
     */
    suspend fun sendSingleMessage(text: String): String

    /**
     * Optional benchmark details recorded by the engine session.
     */
    fun getBenchmarkInfo(): SessionBenchmark? = null

    override fun close()
}

enum class ChatBackend {
    CPU,
    GPU,
    NPU
}

enum class ChatSessionState {
    IDLE,
    LOADING_MODEL,
    READY,
    GENERATING,
    ERROR
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val text: String,
    val timestampMs: Long = System.currentTimeMillis()
) {
    enum class MessageRole {
        USER,
        ASSISTANT,
        SYSTEM
    }
}
