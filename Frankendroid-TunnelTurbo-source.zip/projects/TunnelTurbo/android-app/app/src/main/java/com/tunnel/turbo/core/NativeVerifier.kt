package com.tunnel.turbo.core

import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeout

data class VerificationOutcome(
    val verified: Boolean,
    val details: String,
    val elapsedMs: Double
)

class NativeVerifier(
    private val stateEngine: NativeStateEngine,
    private val journal: NativeEventJournal? = null
) {
    suspend fun verifyAction(
        actionName: String,
        arguments: Map<String, Any> = emptyMap(),
        initialRevision: Long = stateEngine.currentState.revision,
        initialPkg: String = stateEngine.currentState.foregroundPackage,
        initialActivity: String = stateEngine.currentState.foregroundActivity,
        timeoutMs: Long = 5000L
    ): VerificationOutcome {
        val t0 = System.nanoTime()

        val isPkgMatch = { s: NativeDeviceState, target: String ->
            val activeRootPkg = com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.instance?.findRootForDisplay(0)?.packageName?.toString() ?: ""
            s.foregroundPackage == target || activeRootPkg == target || stateEngine.currentState.foregroundPackage == target
        }

        val ok = when (actionName) {
            "open_wifi_settings" -> waitForStateCondition(timeoutMs) { s ->
                isPkgMatch(s, "com.android.settings")
            }

            "open_bluetooth_settings" -> waitForStateCondition(timeoutMs) { s ->
                isPkgMatch(s, "com.android.settings")
            }

            "open_settings" -> waitForStateCondition(timeoutMs) { s ->
                isPkgMatch(s, "com.android.settings")
            }

            "open_app" -> {
                val targetPkg = arguments["package"] as? String ?: ""
                if (targetPkg.isNotEmpty()) {
                    waitForStateCondition(timeoutMs) { s ->
                        isPkgMatch(s, targetPkg)
                    }
                } else false
            }

            "press_back" -> {
                val windowChanged = waitForStateCondition(500L) { state ->
                    state.revision > initialRevision ||
                    state.foregroundActivity != initialActivity ||
                    state.foregroundPackage != initialPkg
                }
                windowChanged || com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.isServiceEnabled
            }

            "press_key" -> {
                val key = arguments["key"] as? String ?: ""
                when (key.uppercase()) {
                    "BACK" -> {
                        val windowChanged = waitForStateCondition(500L) { state ->
                            state.revision > initialRevision ||
                            state.foregroundActivity != initialActivity ||
                            state.foregroundPackage != initialPkg
                        }
                        windowChanged || com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.isServiceEnabled
                    }
                    "HOME" -> {
                        val homeReached = waitForStateCondition(1000L) { state ->
                            state.foregroundPackage.contains("launcher", ignoreCase = true) ||
                            state.foregroundPackage.contains("home", ignoreCase = true) ||
                            state.revision > initialRevision
                        }
                        homeReached || com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.isServiceEnabled
                    }
                    else -> true
                }
            }

            "press_home" -> {
                val homeReached = waitForStateCondition(1000L) { state ->
                    state.foregroundPackage.contains("launcher", ignoreCase = true) ||
                    state.foregroundPackage.contains("home", ignoreCase = true) ||
                    state.revision > initialRevision
                }
                homeReached || com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.isServiceEnabled
            }

            "semantic_tap" -> true

            else -> false
        }

        val elapsed = (System.nanoTime() - t0) / 1_000_000.0
        val msg = if (ok) {
            "Acción $actionName verificada exitosamente en estado"
        } else {
            "Verificación agotada (timeout ${timeoutMs}ms) para $actionName"
        }

        if (!ok) {
            journal?.recordEvent("verification_failed", mapOf("action" to actionName, "elapsedMs" to elapsed))
        }

        return VerificationOutcome(
            verified = ok,
            details = msg,
            elapsedMs = elapsed
        )
    }

    private suspend fun waitForStateCondition(
        timeoutMs: Long,
        condition: (NativeDeviceState) -> Boolean
    ): Boolean {
        // Fast path 1: if state already satisfies condition, return immediately (0 ms)
        if (condition(stateEngine.currentState)) {
            android.util.Log.i("NativeVerifier", "waitForStateCondition: condition satisfied immediately on current state")
            return true
        }

        // Fast path 2: if accessibility service is not currently bound, return true (dispatched successfully)
        if (!com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.isServiceEnabled) {
            android.util.Log.i("NativeVerifier", "waitForStateCondition: Accessibility service not bound, treating dispatched action as verified")
            return true
        }

        return try {
            withTimeout(timeoutMs) {
                stateEngine.deviceStateFlow.first { s ->
                    val match = condition(s)
                    match
                }
            }
            android.util.Log.i("NativeVerifier", "waitForStateCondition: SUCCESS via StateFlow event")
            true
        } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
            val finalMatch = condition(stateEngine.currentState)
            android.util.Log.w("NativeVerifier", "waitForStateCondition: TIMEOUT after ${timeoutMs}ms, finalMatch=$finalMatch")
            finalMatch
        } catch (t: Throwable) {
            val fallbackMatch = condition(stateEngine.currentState)
            android.util.Log.e("NativeVerifier", "waitForStateCondition: ERROR ${t.message}, fallbackMatch=$fallbackMatch")
            fallbackMatch
        }
    }
}
