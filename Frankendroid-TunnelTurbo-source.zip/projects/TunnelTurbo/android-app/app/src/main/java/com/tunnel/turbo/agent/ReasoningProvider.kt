package com.tunnel.turbo.agent

import com.tunnel.turbo.capability.Capability
import com.tunnel.turbo.model.ToolStep
import com.tunnel.turbo.worker.AiWorkerBridge
import com.tunnel.turbo.worker.ProviderHealthState
import com.tunnel.turbo.worker.ProviderFailureClass
import com.tunnel.turbo.worker.ProviderHealthReport
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID

enum class DecisionType {
    USE_CAPABILITY,
    USE_SKILL,
    OBSERVE,
    TASK_COMPLETE,
    TASK_FAILED,
    ASK_USER
}

enum class AiRoundReason {
    INITIAL_PLAN,
    AMBIGUITY,
    UNEXPECTED_STATE,
    PLAN_FAILURE,
    SKILL_REPAIR,
    GOAL_VERIFICATION
}

enum class BudgetProfile {
    QUICK,
    STANDARD_INTERACTIVE,
    EXTENDED_WORK
}

data class AgentBudget(
    val maxStateChangingActions: Int = 15,
    val maxObservationToolCalls: Int = 20,
    val maxProviderRounds: Int = 3,
    val maxObservationsSentToProvider: Int = 5,
    val maxTaskDurationMs: Long = 60000L,
    val maxCapabilityCalls: Int = 35,
    val maxProviderWaitMs: Long = 15000L,
    var stateChangingActionsExecuted: Int = 0,
    var observationToolCalls: Int = 0,
    var providerRequestsAttempted: Int = 0,
    var providerPromptsInjected: Int = 0,
    var providerRounds: Int = 0,
    var observationsCaptured: Int = 0,
    var observationsSentToProvider: Int = 0,
    val profile: BudgetProfile = BudgetProfile.QUICK,
    val startTimeMs: Long = System.currentTimeMillis()
) {
    val capabilityCallsExecuted: Int
        get() = stateChangingActionsExecuted + observationToolCalls

    var actionsExecuted: Int
        get() = stateChangingActionsExecuted
        set(value) { stateChangingActionsExecuted = value }

    var stepsUsed: Int
        get() = stateChangingActionsExecuted
        set(value) { stateChangingActionsExecuted = value }

    var aiRoundsUsed: Int
        get() = providerRounds
        set(value) { providerRounds = value }

    var observationsSent: Int
        get() = observationsSentToProvider
        set(value) { observationsSentToProvider = value }

    @Deprecated("Use maxStateChangingActions", ReplaceWith("maxStateChangingActions"))
    val maxSteps: Int get() = maxStateChangingActions

    @Deprecated("Use maxProviderRounds", ReplaceWith("maxProviderRounds"))
    val maxAiRounds: Int get() = maxProviderRounds

    @Deprecated("Use maxObservationsSentToProvider", ReplaceWith("maxObservationsSentToProvider"))
    val maxObservationsSentToAi: Int get() = maxObservationsSentToProvider

    val remainingAiRounds: Int get() = maxOf(0, maxProviderRounds - providerRounds)
    val remainingActions: Int get() = maxOf(0, maxStateChangingActions - stateChangingActionsExecuted)
    val remainingObservations: Int get() = maxOf(0, maxObservationsSentToProvider - observationsSentToProvider)
    val remainingObservationCalls: Int get() = maxOf(0, maxObservationToolCalls - observationToolCalls)
    val remainingCapabilityCalls: Int get() = maxOf(0, maxCapabilityCalls - capabilityCallsExecuted)
    val remainingDurationMs: Long get() = maxOf(0L, maxTaskDurationMs - (System.currentTimeMillis() - startTimeMs))

    fun isExhausted(): Boolean {
        val elapsed = System.currentTimeMillis() - startTimeMs
        return stateChangingActionsExecuted >= maxStateChangingActions ||
                observationToolCalls >= maxObservationToolCalls ||
                capabilityCallsExecuted >= maxCapabilityCalls ||
                providerRounds >= maxProviderRounds ||
                observationsSentToProvider >= maxObservationsSentToProvider ||
                elapsed >= maxTaskDurationMs
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("profile", profile.name)
        put("maxSteps", maxSteps)
        put("maxStateChangingActions", maxStateChangingActions)
        put("maxObservationToolCalls", maxObservationToolCalls)
        put("maxCapabilityCalls", maxCapabilityCalls)
        put("stepsUsed", actionsExecuted)
        put("actionsExecuted", actionsExecuted)
        put("stateChangingActionsExecuted", stateChangingActionsExecuted)
        put("observationToolCalls", observationToolCalls)
        put("capabilityCallsExecuted", capabilityCallsExecuted)
        put("maxAiRounds", maxAiRounds)
        put("maxProviderRounds", maxProviderRounds)
        put("aiRoundsUsed", providerRounds)
        put("providerRounds", providerRounds)
        put("providerRequestsAttempted", providerRequestsAttempted)
        put("providerPromptsInjected", providerPromptsInjected)
        put("maxObservationsSentToAi", maxObservationsSentToAi)
        put("maxObservationsSentToProvider", maxObservationsSentToProvider)
        put("observationsSent", observationsSentToProvider)
        put("observationsCaptured", observationsCaptured)
        put("observationsSentToProvider", observationsSentToProvider)
        put("maxTaskDurationMs", maxTaskDurationMs)
        put("elapsedMs", System.currentTimeMillis() - startTimeMs)
        put("remainingAiRounds", remainingAiRounds)
        put("remainingActions", remainingActions)
        put("remainingObservationCalls", remainingObservationCalls)
        put("remainingCapabilityCalls", remainingCapabilityCalls)
        put("remainingObservations", remainingObservations)
        put("remainingDurationMs", remainingDurationMs)
        put("isExhausted", isExhausted())
    }

    companion object {
        fun forProfile(profile: BudgetProfile): AgentBudget = when (profile) {
            BudgetProfile.QUICK -> AgentBudget(
                maxStateChangingActions = 8,
                maxObservationToolCalls = 12,
                maxCapabilityCalls = 20,
                maxProviderRounds = 3,
                maxObservationsSentToProvider = 5,
                maxTaskDurationMs = 60_000L,
                profile = BudgetProfile.QUICK
            )
            BudgetProfile.STANDARD_INTERACTIVE -> AgentBudget(
                maxStateChangingActions = 15,
                maxObservationToolCalls = 20,
                maxCapabilityCalls = 35,
                maxProviderRounds = 6,
                maxObservationsSentToProvider = 10,
                maxTaskDurationMs = 120_000L,
                profile = BudgetProfile.STANDARD_INTERACTIVE
            )
            BudgetProfile.EXTENDED_WORK -> AgentBudget(
                maxStateChangingActions = 30,
                maxObservationToolCalls = 40,
                maxCapabilityCalls = 70,
                maxProviderRounds = 12,
                maxObservationsSentToProvider = 20,
                maxTaskDurationMs = 300_000L,
                profile = BudgetProfile.EXTENDED_WORK
            )
        }

        fun quick(): AgentBudget = forProfile(BudgetProfile.QUICK)
        fun standardInteractive(): AgentBudget = forProfile(BudgetProfile.STANDARD_INTERACTIVE)
        fun extendedWork(): AgentBudget = forProfile(BudgetProfile.EXTENDED_WORK)
    }
}

data class NextDecision(
    val type: DecisionType,
    val capabilityId: String? = null,
    val arguments: Map<String, Any?> = emptyMap(),
    val skillId: String? = null,
    val skillParameters: Map<String, Any?> = emptyMap(),
    val userQuestion: String? = null,
    val userOptions: List<String> = emptyList(),
    val reason: String = "",
    val suggestedFollowUpSteps: List<ToolStep> = emptyList(),
    val decisionSource: DecisionSource = DecisionSource.LOCAL_HEURISTIC,
    val providerCallId: String? = null,
    val proofNonce: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", type.name)
        if (capabilityId != null) put("capabilityId", capabilityId)
        val argsObj = JSONObject()
        arguments.forEach { (k, v) -> argsObj.put(k, v) }
        put("arguments", argsObj)
        if (skillId != null) put("skillId", skillId)
        val spObj = JSONObject()
        skillParameters.forEach { (k, v) -> spObj.put(k, v) }
        put("skillParameters", spObj)
        if (userQuestion != null) put("userQuestion", userQuestion)
        val optArr = JSONArray()
        userOptions.forEach { optArr.put(it) }
        put("userOptions", optArr)
        put("reason", reason)
        val fuArr = JSONArray()
        suggestedFollowUpSteps.forEach { fuArr.put(it.toJson()) }
        put("suggestedFollowUpSteps", fuArr)
        put("decisionSource", decisionSource.name)
        if (providerCallId != null) put("providerCallId", providerCallId)
        if (proofNonce != null) put("proofNonce", proofNonce)
    }

    companion object {
        fun fromJson(
            json: JSONObject,
            source: DecisionSource = DecisionSource.REAL_PROVIDER,
            providerCallId: String? = null,
            proofNonce: String? = null
        ): NextDecision {
            val typeStr = json.optString("type", "TASK_FAILED")
            val type = try { DecisionType.valueOf(typeStr) } catch (t: Throwable) { DecisionType.TASK_FAILED }
            val argsMap = mutableMapOf<String, Any?>()
            val aObj = json.optJSONObject("arguments")
            if (aObj != null) {
                val it = aObj.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    argsMap[k] = aObj.get(k)
                }
            }
            val spMap = mutableMapOf<String, Any?>()
            val spObj = json.optJSONObject("skillParameters")
            if (spObj != null) {
                val it = spObj.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    spMap[k] = spObj.get(k)
                }
            }
            val optList = mutableListOf<String>()
            val optArr = json.optJSONArray("userOptions")
            if (optArr != null) {
                for (i in 0 until optArr.length()) optList.add(optArr.optString(i))
            }
            val fuList = mutableListOf<ToolStep>()
            val fuArr = json.optJSONArray("suggestedFollowUpSteps")
            if (fuArr != null) {
                for (i in 0 until fuArr.length()) {
                    val o = fuArr.optJSONObject(i)
                    if (o != null) {
                        val m = mutableMapOf<String, Any?>()
                        val mo = o.optJSONObject("arguments")
                        if (mo != null) {
                            val it = mo.keys()
                            while (it.hasNext()) {
                                val k = it.next()
                                m[k] = mo.get(k)
                            }
                        }
                        fuList.add(ToolStep(tool = o.optString("tool", ""), arguments = m))
                    }
                }
            }

            return NextDecision(
                type = type,
                capabilityId = if (json.has("capabilityId")) json.optString("capabilityId") else null,
                arguments = argsMap,
                skillId = if (json.has("skillId")) json.optString("skillId") else null,
                skillParameters = spMap,
                userQuestion = if (json.has("userQuestion")) json.optString("userQuestion") else null,
                userOptions = optList,
                reason = json.optString("reason", ""),
                suggestedFollowUpSteps = fuList,
                decisionSource = source,
                providerCallId = providerCallId,
                proofNonce = proofNonce
            )
        }
    }
}

data class StrategyProposal(
    val goalId: String,
    val requestId: String,
    val proofNonce: String,
    val options: List<String> = emptyList(),
    val recommended: Map<String, Any?> = emptyMap(),
    val reason: String = "",
    val nextDecision: NextDecision,
    val decisionSource: DecisionSource = DecisionSource.REAL_PROVIDER,
    val providerCallId: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("goalId", goalId)
        put("requestId", requestId)
        put("proofNonce", proofNonce)
        val optArr = JSONArray()
        options.forEach { optArr.put(it) }
        put("options", optArr)
        val recObj = JSONObject()
        recommended.forEach { (k, v) -> recObj.put(k, v) }
        put("recommended", recObj)
        put("reason", reason)
        put("nextDecision", nextDecision.toJson())
        put("decisionSource", decisionSource.name)
        if (providerCallId != null) put("providerCallId", providerCallId)
    }
}

interface ReasoningProvider {
    val name: String
    suspend fun health(): ProviderHealthReport
    suspend fun prepare(): Boolean
    suspend fun decideNext(
        goal: Goal,
        snapshot: WorldSnapshot,
        skills: List<DynamicSkill>,
        capabilities: List<Capability>,
        recentSteps: List<AgentStep>,
        budget: AgentBudget,
        reason: AiRoundReason
    ): NextDecision
    suspend fun cancel()
    suspend fun resetConversationIfNeeded()
}

class AndroidAiAppReasoningProvider(
    override val name: String = "chatgpt_reasoning_provider",
    val workerBridge: AiWorkerBridge = AiWorkerBridge()
) : ReasoningProvider {

    override suspend fun health(): ProviderHealthReport = workerBridge.checkOperationalHealth()
    override suspend fun prepare(): Boolean = workerBridge.preflight().isReady
    override suspend fun cancel() { workerBridge.stop() }
    override suspend fun resetConversationIfNeeded() { workerBridge.promptBuffer.clear() }

    companion object {
        private var callCounter = 0

        const val AGENT_REASONING_PROMPT = """You are the reasoning engine of Tunnel Turbo Android Agent.
Analyze the user's Goal, current World Snapshot, Candidate Apps, and decide the NEXT logical action.

GOAL:
"%s"
OBJECTIVE: %s
ENTITIES: %s

WORLD SNAPSHOT:
Foreground: %s (%s)
Candidate Apps: %s
Informative Text Visible:
%s

AVAILABLE CAPABILITIES:
%s

KNOWN SKILLS:
%s

RECENT STEPS EXECUTED:
%s

DECIDE THE NEXT ACTION. Return ONLY raw JSON matching one of:
1. USE_CAPABILITY:
{"request_id":"%s","proof_nonce":"%s","type":"USE_CAPABILITY","capabilityId":"<cap>","arguments":{...},"reason":"<explanation>","suggestedFollowUpSteps":[{"tool":"...","arguments":{...}}]}

2. USE_SKILL:
{"request_id":"%s","proof_nonce":"%s","type":"USE_SKILL","skillId":"<id>","skillParameters":{...},"reason":"<explanation>"}

3. OBSERVE:
{"request_id":"%s","proof_nonce":"%s","type":"OBSERVE","reason":"<why observation is needed>"}

4. ASK_USER:
{"request_id":"%s","proof_nonce":"%s","type":"ASK_USER","userQuestion":"<question>","userOptions":["opt1","opt2"],"reason":"<ambiguity reason>"}

5. TASK_COMPLETE:
{"request_id":"%s","proof_nonce":"%s","type":"TASK_COMPLETE","reason":"<evidence that goal is satisfied>"}

6. TASK_FAILED:
{"request_id":"%s","proof_nonce":"%s","type":"TASK_FAILED","reason":"<unrecoverable failure reason>"}

CRITICAL RULES:
- Return ONLY RAW JSON. No conversational text.
- You MUST include "request_id": "%s" and "proof_nonce": "%s" in your JSON.
- NO shell, bash, adb, eval or code. Only registered capabilities or skills."""
    }

    private fun sha256(text: String): String {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val bytes = md.digest(text.toByteArray(Charsets.UTF_8))
            bytes.take(8).joinToString("") { "%02x".format(it) }
        } catch (t: Throwable) {
            "h_${text.hashCode()}"
        }
    }

    override suspend fun decideNext(
        goal: Goal,
        snapshot: WorldSnapshot,
        skills: List<DynamicSkill>,
        capabilities: List<Capability>,
        recentSteps: List<AgentStep>,
        budget: AgentBudget,
        reason: AiRoundReason
    ): NextDecision {
        if (budget.isExhausted()) {
            return NextDecision(
                type = DecisionType.TASK_FAILED,
                reason = "Agent budget exhausted (steps=${budget.stepsUsed}, aiRounds=${budget.aiRoundsUsed})",
                decisionSource = DecisionSource.DETERMINISTIC
            )
        }

        val callId = String.format("TT_AI_%06d", ++callCounter)
        val reqId = "AR_${System.currentTimeMillis() % 100000}"
        val proofNonce = "TT_PROOF_" + UUID.randomUUID().toString().replace("-", "").take(6).uppercase()
        val startedAt = System.currentTimeMillis()
        val dispId = workerBridge.session.displayId ?: 28

        // Build structured prompt for AI Worker
        val entitiesStr = goal.entities.joinToString { "${it.type}=${it.value}" }
        val candAppsStr = snapshot.candidateApps.take(4).joinToString { "${it.label} (${it.packageName}, rel=${it.relevance})" }
        val capsStr = capabilities.joinToString { it.id }
        val skillsStr = skills.map { "${it.skillId}: ${it.name} (${it.state})" }.joinToString()
        val stepsStr = recentSteps.takeLast(4).joinToString { "step${it.stepIndex}: ${it.capability}(${it.arguments}) -> ${it.verification}" }

        val prompt = String.format(
            AGENT_REASONING_PROMPT,
            goal.originalText,
            goal.objective,
            entitiesStr,
            snapshot.foregroundPackage,
            snapshot.foregroundActivity,
            candAppsStr,
            snapshot.reducedObservation.informativeText.take(400),
            capsStr,
            skillsStr,
            stepsStr,
            reqId, proofNonce,
            reqId, proofNonce,
            reqId, proofNonce,
            reqId, proofNonce,
            reqId, proofNonce,
            reqId, proofNonce,
            reqId, proofNonce
        )
        val promptHash = sha256(prompt)

        var promptInjected = false
        var turnBefore = 0
        var turnAfter = 0
        var responseDetected = false
        var responseHash = ""
        var responseLength = 0
        var decisionProduced = "NONE"
        var providerError: String? = null
        var failureClass: String = ProviderFailureClass.NONE.name
        var injectionTimestamp: Long? = null
        var responseTimestamp: Long? = null

        // Preflight check before consuming round
        val tPreflight0 = System.nanoTime()
        val preflightReport = workerBridge.preflight(timeoutMs = 3000L)
        val preflightMs = (System.nanoTime() - tPreflight0) / 1_000_000.0
        val isReady = preflightReport.isReady

        if (isReady) {
            turnBefore = workerBridge.countConversationTurns(dispId)
            val tInject0 = System.currentTimeMillis()
            promptInjected = workerBridge.sendRequest(prompt, reqId, proofNonce)

            if (promptInjected) {
                injectionTimestamp = tInject0
                budget.providerPromptsInjected++
                budget.observationsSentToProvider++
                val resp = workerBridge.readResponse(reqId, proofNonce, turnBefore, timeoutMs = 25000L)
                turnAfter = resp.turnAfter
                responseTimestamp = resp.responseTimestamp ?: System.currentTimeMillis()

                if (resp.success && !resp.rawText.isNullOrBlank()) {
                    var cleaned = resp.rawText.trim()
                    if (cleaned.startsWith("```")) {
                        cleaned = cleaned.replace(Regex("^```(?:json)?\\s*"), "").replace(Regex("\\s*```$"), "")
                    }
                    try {
                        val parsed = JSONObject(cleaned)
                        val respNonce = parsed.optString("proof_nonce")
                        val respReqId = parsed.optString("request_id")

                        // Section 4 & 5: Strict validation of proof_nonce and request_id
                        if (respNonce == proofNonce && respReqId == reqId) {
                            responseDetected = true
                            responseHash = sha256(cleaned)
                            responseLength = cleaned.length

                            val decision = NextDecision.fromJson(
                                json = parsed,
                                source = DecisionSource.REAL_PROVIDER,
                                providerCallId = callId,
                                proofNonce = proofNonce
                            )
                            decisionProduced = decision.type.name

                            // Rule A: Increment AI Round ONLY when all truth criteria are met
                            budget.providerRounds++

                            val elapsed = (System.currentTimeMillis() - startedAt).toDouble()
                            val trace = ProviderCallTrace(
                                providerCallId = callId,
                                goalId = goal.goalId,
                                requestId = reqId,
                                provider = "chatgpt",
                                providerPackage = "com.openai.chatgpt",
                                workerDisplayId = dispId,
                                reason = reason.name,
                                startedAt = startedAt,
                                promptPrepared = true,
                                promptInjected = true,
                                promptHash = promptHash,
                                conversationTurnBefore = turnBefore,
                                conversationTurnAfter = turnAfter,
                                responseDetected = true,
                                responseHash = responseHash,
                                responseLength = responseLength,
                                decisionProduced = decisionProduced,
                                completedAt = System.currentTimeMillis(),
                                latencyMs = elapsed,
                                error = null,
                                proofNonce = proofNonce,
                                providerPreflightMs = preflightMs,
                                providerReadyAtDispatch = true,
                                injectionTimestamp = injectionTimestamp,
                                responseTimestamp = responseTimestamp,
                                failureClass = ProviderFailureClass.NONE.name,
                                proofMatched = true
                            )
                            ProviderCallRepository.recordCall(trace)
                            ProviderCallRepository.recordDecision(DecisionSource.REAL_PROVIDER)

                            return decision
                        } else {
                            failureClass = ProviderFailureClass.PROVIDER_PROOF_MISMATCH.name
                            providerError = "PROOF_NONCE_MISMATCH: expected $proofNonce/$reqId, got $respNonce/$respReqId"
                        }
                    } catch (t: Throwable) {
                        failureClass = ProviderFailureClass.PROVIDER_RESPONSE_PARSE_FAILURE.name
                        providerError = "JSON_PARSE_ERROR: ${t.message}"
                        android.util.Log.w("ReasoningProvider", "Failed to parse AI worker JSON response: ${t.message}")
                    }
                } else {
                    failureClass = if (resp.failureClass != "NONE") resp.failureClass else ProviderFailureClass.PROVIDER_RESPONSE_TIMEOUT.name
                    providerError = resp.error ?: "RESPONSE_EMPTY_OR_TIMEOUT"
                }
            } else {
                failureClass = ProviderFailureClass.PROMPT_INJECTION_FAILURE.name
                providerError = "PROMPT_INJECTION_FAILURE: Failed to inject prompt via Accessibility"
            }
        } else {
            failureClass = when (preflightReport.state) {
                ProviderHealthState.AUTH_REQUIRED -> ProviderFailureClass.PROVIDER_AUTH_REQUIRED.name
                ProviderHealthState.RATE_LIMITED -> ProviderFailureClass.PROVIDER_RATE_LIMITED.name
                ProviderHealthState.STARTING -> ProviderFailureClass.PROVIDER_START_FAILURE.name
                ProviderHealthState.UI_UNAVAILABLE -> ProviderFailureClass.PROVIDER_UI_NOT_READY.name
                ProviderHealthState.WARMING_UP -> ProviderFailureClass.PROVIDER_UI_NOT_READY.name
                ProviderHealthState.TIMED_OUT -> ProviderFailureClass.PROVIDER_RESPONSE_TIMEOUT.name
                ProviderHealthState.FAILED -> ProviderFailureClass.PROVIDER_UNKNOWN_FAILURE.name
                else -> ProviderFailureClass.PROVIDER_UNKNOWN_FAILURE.name
            }
            providerError = "${failureClass}: ${preflightReport.message}"
        }

        // Record failed ProviderCallTrace
        val elapsed = (System.currentTimeMillis() - startedAt).toDouble()
        val trace = ProviderCallTrace(
            providerCallId = callId,
            goalId = goal.goalId,
            requestId = reqId,
            provider = "chatgpt",
            providerPackage = "com.openai.chatgpt",
            workerDisplayId = dispId,
            reason = reason.name,
            startedAt = startedAt,
            promptPrepared = true,
            promptInjected = promptInjected,
            promptHash = promptHash,
            conversationTurnBefore = turnBefore,
            conversationTurnAfter = turnAfter,
            responseDetected = responseDetected,
            responseHash = responseHash,
            responseLength = responseLength,
            decisionProduced = "FAILED",
            completedAt = System.currentTimeMillis(),
            latencyMs = elapsed,
            error = providerError,
            proofNonce = proofNonce,
            providerPreflightMs = preflightMs,
            providerReadyAtDispatch = isReady,
            injectionTimestamp = injectionTimestamp,
            responseTimestamp = responseTimestamp,
            failureClass = failureClass,
            proofMatched = false
        )
        ProviderCallRepository.recordCall(trace)

        // Section 6: STRICT_REAL_PROVIDER_MODE check
        if (GeneralAgentRuntime.strictRealProviderMode) {
            ProviderCallRepository.recordDecision(DecisionSource.REAL_PROVIDER)
            // DO NOT fall back in strict mode
            return NextDecision(
                type = DecisionType.TASK_FAILED,
                reason = "Real reasoning provider call failed in STRICT mode: $providerError",
                decisionSource = DecisionSource.REAL_PROVIDER,
                providerCallId = callId,
                proofNonce = proofNonce
            )
        }

        // Deterministic General Reasoning Engine Fallback (Normal Mode Only)
        // Rule A: NO AI ROUND INCREMENT for deterministic / local heuristic fallback
        val localDecision = generateDeterministicReasoningDecision(goal, snapshot, skills, recentSteps)
        ProviderCallRepository.recordDecision(localDecision.decisionSource)
        return localDecision
    }

    fun fallbackLocalHeuristic(
        goal: Goal,
        snapshot: WorldSnapshot,
        capabilities: List<Capability>,
        skills: List<DynamicSkill>,
        reason: AiRoundReason
    ): NextDecision {
        return generateDeterministicReasoningDecision(goal, snapshot, skills, emptyList())
    }

    private fun generateDeterministicReasoningDecision(
        goal: Goal,
        snapshot: WorldSnapshot,
        skills: List<DynamicSkill>,
        recentSteps: List<AgentStep>
    ): NextDecision {
        val lowerGoal = goal.originalText.lowercase()

        // 1. Check if a known DynamicSkill matches the goal
        for (skill in skills) {
            if (skill.state == SkillState.ACTIVE || skill.state == SkillState.VALIDATING || skill.state == SkillState.PROPOSED) {
                if (skill.name.contains("artist", ignoreCase = true) || skill.name.contains("music", ignoreCase = true)) {
                    val artistEntity = goal.entities.firstOrNull { it.type == "artist" }
                    if (artistEntity != null && (lowerGoal.contains("escuchar") || lowerGoal.contains("reproduce") || lowerGoal.contains("pon "))) {
                        return NextDecision(
                            type = DecisionType.USE_SKILL,
                            skillId = skill.skillId,
                            skillParameters = mapOf("artist" to artistEntity.value),
                            reason = "Skill compatible encontrada: ${skill.name} para artista ${artistEntity.value}",
                            decisionSource = DecisionSource.SKILL
                        )
                    }
                }
            }
        }

        // 1.5. Semantic Node Action Goal
        if (goal.categoryHint == "SEMANTIC_NODE_ACTION") {
            val clickStep = recentSteps.firstOrNull { it.capability == "click_node" }
            if (clickStep != null) {
                return NextDecision(
                    type = DecisionType.TASK_COMPLETE,
                    reason = "Acción click_node ejecutada sobre el nodo objetivo; solicitando verificación a GoalVerifier",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC
                )
            } else {
                val targetText = goal.entities.firstOrNull { it.type == "text" }?.value?.takeIf { it.isNotBlank() }
                val targetRes = goal.entities.firstOrNull { it.type == "resource_id" }?.value?.takeIf { it.isNotBlank() }
                val targetBounds = goal.entities.firstOrNull { it.type == "bounds" }?.value?.takeIf { it.isNotBlank() }
                val targetNodeId = goal.entities.firstOrNull { it.type == "node_id" }?.value?.takeIf { it.isNotBlank() }

                val selectorMap = mutableMapOf<String, Any>()
                if (targetText != null) selectorMap["text"] = targetText
                if (targetRes != null) selectorMap["resourceId"] = targetRes
                if (targetBounds != null) selectorMap["bounds"] = targetBounds
                if (targetNodeId != null) selectorMap["nodeId"] = targetNodeId

                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "click_node",
                    arguments = mapOf("selector" to selectorMap, "displayId" to snapshot.displayId),
                    reason = "Ejecutando click_node sobre el nodo seleccionado en display ${snapshot.displayId}",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC
                )
            }
        }

        // 2. Music / Media Goal
        val artistEntity = goal.entities.firstOrNull { it.type == "artist" }
        if (artistEntity != null || goal.categoryHint == "MEDIA_PLAYBACK") {
            val artistName = artistEntity?.value ?: "música"
            val bestCandidate = snapshot.candidateApps.firstOrNull()
            if (bestCandidate != null) {
                val targetPkg = bestCandidate.packageName
                if (snapshot.foregroundPackage != targetPkg) {
                    return NextDecision(
                        type = DecisionType.USE_CAPABILITY,
                        capabilityId = "open_app",
                        arguments = mapOf("package" to targetPkg),
                        reason = "Seleccionada app candidata '${bestCandidate.label}' para reproducir a $artistName (${bestCandidate.reason})",
                        decisionSource = DecisionSource.LOCAL_HEURISTIC,
                        suggestedFollowUpSteps = listOf(
                            ToolStep(tool = "wait_for", arguments = mapOf("condition" to "foreground_package", "value" to targetPkg, "timeoutMs" to 5000L)),
                            ToolStep(tool = "click_node", arguments = mapOf("selector" to mapOf("text" to "Buscar"))),
                            ToolStep(tool = "wait_for", arguments = mapOf("condition" to "text_exists", "value" to "Buscar", "timeoutMs" to 5000L)),
                            ToolStep(tool = "click_node", arguments = mapOf("selector" to mapOf("editable" to true))),
                            ToolStep(tool = "set_text", arguments = mapOf("selector" to mapOf("editable" to true), "text" to artistName)),
                            ToolStep(tool = "wait_for", arguments = mapOf("condition" to "text_exists", "value" to artistName, "timeoutMs" to 4000L)),
                            ToolStep(tool = "click_node", arguments = mapOf("selector" to mapOf("text" to artistName)))
                        )
                    )
                } else {
                    return NextDecision(
                        type = DecisionType.TASK_COMPLETE,
                        reason = "Reproducción iniciada exitosamente en $targetPkg para $artistName",
                        decisionSource = DecisionSource.LOCAL_HEURISTIC
                    )
                }
            } else {
                return NextDecision(
                    type = DecisionType.TASK_FAILED,
                    reason = "No se encontraron reproductores de música instalados para satisfacer el objetivo",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC
                )
            }
        }

        // 3. Settings / Font Size Goal
        if (lowerGoal.contains("letra") || lowerGoal.contains("fuente") || lowerGoal.contains("tamaño") || goal.categoryHint == "SYSTEM_SETTINGS") {
            val targetPkg = "com.android.settings"
            if (snapshot.foregroundPackage != targetPkg) {
                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "open_settings",
                    arguments = emptyMap(),
                    reason = "Abriendo Configuración del sistema para localizar ajuste de tamaño de letra",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC,
                    suggestedFollowUpSteps = listOf(
                        ToolStep(tool = "wait_for", arguments = mapOf("condition" to "foreground_package", "value" to targetPkg, "timeoutMs" to 5000L)),
                        ToolStep(tool = "click_node", arguments = mapOf("selector" to mapOf("text" to "Pantalla"))),
                        ToolStep(tool = "wait_for", arguments = mapOf("condition" to "text_exists", "value" to "Pantalla", "timeoutMs" to 5000L))
                    )
                )
            } else {
                return NextDecision(
                    type = DecisionType.TASK_COMPLETE,
                    reason = "Navegación completada hacia configuración de pantalla y texto",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC
                )
            }
        }

        // 4. Notes / Productivity Goal
        if (lowerGoal.contains("nota") || lowerGoal.contains("notes") || goal.categoryHint == "PRODUCTIVITY") {
            val noteApps = snapshot.candidateApps.filter { it.relevance >= 0.8 }
            if (noteApps.size > 1) {
                return NextDecision(
                    type = DecisionType.ASK_USER,
                    userQuestion = "Encontré varias aplicaciones de notas: ${noteApps.joinToString { it.label }}. ¿Cuál prefieres usar?",
                    userOptions = noteApps.map { it.label },
                    reason = "Múltiples opciones equivalentes disponibles sin preferencia previa registrada",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC
                )
            } else if (noteApps.size == 1) {
                val app = noteApps.first()
                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "open_app",
                    arguments = mapOf("package" to app.packageName),
                    reason = "Abriendo ${app.label} para tomar notas",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC,
                    suggestedFollowUpSteps = listOf(
                        ToolStep(tool = "wait_for", arguments = mapOf("condition" to "foreground_package", "value" to app.packageName, "timeoutMs" to 5000L))
                    )
                )
            } else {
                return NextDecision(
                    type = DecisionType.TASK_FAILED,
                    reason = "No se encontraron aplicaciones de notas instaladas",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC
                )
            }
        }

        // 5. Photos Goal (Section 15)
        if (goal.categoryHint == "PHOTOS_GALLERY" || lowerGoal.contains("fotos") || lowerGoal.contains("galería")) {
            val photoApp = snapshot.candidateApps.firstOrNull {
                it.packageName.contains("gallery") || it.packageName.contains("photos")
            } ?: snapshot.candidateApps.firstOrNull()
            if (photoApp != null) {
                return NextDecision(
                    type = DecisionType.USE_CAPABILITY,
                    capabilityId = "open_app",
                    arguments = mapOf("package" to photoApp.packageName),
                    reason = "Abriendo ${photoApp.label} para visualizar fotos",
                    decisionSource = DecisionSource.LOCAL_HEURISTIC,
                    suggestedFollowUpSteps = listOf(
                        ToolStep(tool = "wait_for", arguments = mapOf("condition" to "foreground_package", "value" to photoApp.packageName, "timeoutMs" to 5000L))
                    )
                )
            }
        }

        // Bluetooth Goal (Section 14)
        if (goal.categoryHint == "CONNECTIVITY_BLUETOOTH" || lowerGoal.contains("bluetooth") || lowerGoal.contains("blueytyohn")) {
            return NextDecision(
                type = DecisionType.USE_CAPABILITY,
                capabilityId = "open_bluetooth_settings",
                arguments = emptyMap(),
                reason = "Abriendo Ajustes de Bluetooth del sistema para verificar y configurar estado",
                decisionSource = DecisionSource.LOCAL_HEURISTIC,
                suggestedFollowUpSteps = listOf(
                    ToolStep(tool = "wait_for", arguments = mapOf("condition" to "foreground_package", "value" to "com.android.settings", "timeoutMs" to 5000L))
                )
            )
        }

        // 6. Section 22: Eliminación total de falso éxito por exploración general
        // Si no se encuentra una acción específica para alcanzar el desiredState, retornar TASK_FAILED
        return NextDecision(
            type = DecisionType.TASK_FAILED,
            reason = "No se encontró un camino local verificable para alcanzar el objetivo",
            decisionSource = DecisionSource.LOCAL_HEURISTIC
        )
    }
}

typealias ChatGPTMobileProvider = AndroidAiAppReasoningProvider

class ProviderRouter(
    val primaryProvider: ReasoningProvider,
    val fallbackProvider: ReasoningProvider? = null
) : ReasoningProvider {
    override val name: String = "provider_router"

    override suspend fun health(): ProviderHealthReport {
        val pHealth = primaryProvider.health()
        if (pHealth.isReady) return pHealth
        return fallbackProvider?.health() ?: pHealth
    }

    override suspend fun prepare(): Boolean {
        if (primaryProvider.prepare()) return true
        return fallbackProvider?.prepare() ?: false
    }

    override suspend fun cancel() {
        primaryProvider.cancel()
        fallbackProvider?.cancel()
    }

    override suspend fun resetConversationIfNeeded() {
        primaryProvider.resetConversationIfNeeded()
        fallbackProvider?.resetConversationIfNeeded()
    }

    override suspend fun decideNext(
        goal: Goal,
        snapshot: WorldSnapshot,
        skills: List<DynamicSkill>,
        capabilities: List<Capability>,
        recentSteps: List<AgentStep>,
        budget: AgentBudget,
        reason: AiRoundReason
    ): NextDecision {
        val pHealth = primaryProvider.health()
        var infraFailed = !pHealth.isReady
        var primaryDecision: NextDecision? = null
        var infraFailureReason = if (infraFailed) pHealth.message else ""
        var infraFailureClass = if (infraFailed) pHealth.state.name else ProviderFailureClass.NONE.name

        if (!infraFailed) {
            try {
                val traceBefore = ProviderCallRepository.getLastTrace()
                primaryDecision = primaryProvider.decideNext(
                    goal, snapshot, skills, capabilities, recentSteps, budget, reason
                )
                val lastTrace = ProviderCallRepository.getLastTrace()
                if (lastTrace != null && lastTrace !== traceBefore && lastTrace.goalId == goal.goalId && lastTrace.failureClass != ProviderFailureClass.NONE.name) {
                    infraFailed = true
                    infraFailureReason = lastTrace.error ?: "Provider infrastructure failure"
                    infraFailureClass = lastTrace.failureClass
                }
            } catch (t: Throwable) {
                infraFailed = true
                infraFailureReason = t.message ?: "Exception calling primary provider"
                infraFailureClass = ProviderFailureClass.PROVIDER_UNKNOWN_FAILURE.name
            }
        }

        // If primary succeeded without infrastructure failure, return its decision directly
        // (Even if semantic TASK_FAILED, ASK_USER, TASK_COMPLETE, etc.)
        if (!infraFailed && primaryDecision != null) {
            return primaryDecision
        }

        // Only genuine infrastructure failures trigger failover to fallback
        if (fallbackProvider != null) {
            try {
                android.util.Log.w("ProviderRouter", "Failing over to fallback provider '${fallbackProvider.name}' due to primary failure ($infraFailureClass: $infraFailureReason)")
            } catch (ignored: Throwable) {}
            return fallbackProvider.decideNext(
                goal, snapshot, skills, capabilities, recentSteps, budget, reason
            )
        }

        return primaryDecision ?: NextDecision(
            type = DecisionType.TASK_FAILED,
            reason = "Primary provider failed ($infraFailureClass: $infraFailureReason) and no fallback available."
        )
    }
}

