package com.tunnel.turbo.core

class DisplayTargetPolicy(
    val primaryDisplayId: Int = 0,
    var workerDisplayId: Int? = null
) {
    fun canUserActionAccess(displayId: Int): Boolean {
        // User action operations cannot touch Worker Display
        val wId = workerDisplayId
        if (wId != null && displayId == wId) {
            return false
        }
        return displayId == primaryDisplayId
    }

    fun canWorkerActionAccess(displayId: Int): Boolean {
        // Worker operations cannot touch primary user Display 0
        if (displayId == primaryDisplayId) {
            return false
        }
        val wId = workerDisplayId
        // Worker operation requires an owned, registered worker display
        return wId != null && displayId == wId
    }

    fun resolveTargetDisplay(isWorkerOperation: Boolean, requestedDisplayId: Int? = null): Int {
        return if (isWorkerOperation) {
            val target = requestedDisplayId ?: workerDisplayId
                ?: throw IllegalStateException("UNAVAILABLE: Worker operation requires an active registered worker display, none available")
            if (target == primaryDisplayId) {
                throw SecurityException("VIOLATION: Worker operation attempted on protected Primary Display $primaryDisplayId")
            }
            if (!canWorkerActionAccess(target)) {
                throw SecurityException("VIOLATION: Worker operation attempted on unowned or unregistered display $target (worker display: $workerDisplayId)")
            }
            target
        } else {
            val target = requestedDisplayId ?: primaryDisplayId
            if (!canUserActionAccess(target)) {
                throw SecurityException("VIOLATION: User operation attempted on protected Worker Display $workerDisplayId")
            }
            target
        }
    }
}
