package com.tunnel.turbo.local

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Tunnel Turbo — Local Cognitive Contract
 * Schema Version: 1.0.0
 *
 * Defines the strongly typed contract for the Tiny Local Cognitive Engine.
 * Operates ABOVE the raw tool layer to understand user turns cheaply,
 * routing across CHAT, RESEARCH, ACTION, WORK, and CLARIFY.
 */

enum class InteractionMode {
    CHAT,
    RESEARCH,
    ACTION,
    WORK,
    CLARIFY
}

enum class TaskDomain {
    CONVERSATIONAL,
    RESEARCH,
    MEDIA_PLAYBACK,
    SYSTEM_SETTINGS,
    DEVICE_CONTROL,
    COMMUNICATION,
    PRODUCTIVITY,
    FILE_MANAGEMENT,
    CREATIVE_MEDIA,
    CODE_DEVELOPMENT,
    NAVIGATION,
    GENERAL_KNOWLEDGE,
    UNKNOWN
}

enum class LocalSufficiency {
    LOCAL_ONLY,
    LOCAL_PREFERRED,
    CLOUD_PREFERRED,
    CLOUD_REQUIRED,
    UNKNOWN
}

enum class CapabilityClass {
    GENERAL_CHAT,
    CURRENT_WEB_INFORMATION,
    MEDIA_PLAYBACK,
    SYSTEM_SETTINGS,
    SYSTEM_CONTROL,
    ANDROID_NAVIGATION,
    APP_INTERACTION,
    FILE_READ,
    FILE_WRITE,
    DATA_EXTRACTION,
    SPREADSHEET_CREATION,
    DOCUMENT_CREATION,
    CODE_EDITING,
    CODE_EXECUTION,
    IMAGE_GENERATION,
    VIDEO_GENERATION,
    EMAIL,
    CALENDAR,
    MAPS,
    PRODUCTIVITY_SUITE
}

enum class RouteClass {
    LOCAL_DETERMINISTIC,
    SYSTEM_API,
    ANDROID_NATIVE,
    ANDROID_UI,
    PROVIDER_NATIVE,
    WEB,
    BROWSER,
    FILES,
    CODE_RUNTIME,
    MEDIA_GENERATION,
    WORK_GRAPH
}

enum class ProviderRoleHint {
    GENERAL_REASONING,
    CURRENT_INFO_RESEARCH,
    LONG_DOCUMENT_ANALYSIS,
    CODE,
    MULTIMODAL_ANALYSIS,
    IMAGE_GENERATION,
    VIDEO_GENERATION,
    PRODUCTIVITY,
    COMPUTER_USE
}

sealed class AssessmentParseResult {
    data class Valid(val assessment: LocalCognitiveAssessment) : AssessmentParseResult()
    data class Invalid(val reason: String, val violations: List<String>) : AssessmentParseResult()
}

data class CognitiveEntity(
    val type: String,
    val value: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", type)
        put("value", value)
    }

    companion object {
        fun fromJson(json: JSONObject): CognitiveEntity = CognitiveEntity(
            type = json.optString("type", "unknown"),
            value = json.optString("value", "")
        )
    }
}

data class CognitiveConstraint(
    val text: String,
    val isNegative: Boolean,
    val category: String = "execution"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("text", text)
        put("isNegative", isNegative)
        put("category", category)
    }

    companion object {
        fun fromJson(json: JSONObject): CognitiveConstraint = CognitiveConstraint(
            text = json.optString("text", ""),
            isNegative = json.optBoolean("isNegative", false),
            category = json.optString("category", "execution")
        )
    }
}

data class LocalCognitiveInput(
    val userMessage: String,
    val conversationContextSummary: String? = null,
    val activeGoalSummary: String? = null,
    val activeWorkSummary: String? = null,
    val currentForegroundPackage: String? = null,
    val availableCapabilityClasses: List<CapabilityClass> = emptyList(),
    val recentProgressState: String? = null,
    val unresolvedReferences: List<String> = emptyList(),
    val locale: String = "es-ES"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("userMessage", userMessage)
        if (conversationContextSummary != null) put("conversationContextSummary", conversationContextSummary)
        if (activeGoalSummary != null) put("activeGoalSummary", activeGoalSummary)
        if (activeWorkSummary != null) put("activeWorkSummary", activeWorkSummary)
        if (currentForegroundPackage != null) put("currentForegroundPackage", currentForegroundPackage)
        put("availableCapabilityClasses", JSONArray(availableCapabilityClasses.map { it.name }))
        if (recentProgressState != null) put("recentProgressState", recentProgressState)
        put("unresolvedReferences", JSONArray(unresolvedReferences))
        put("locale", locale)
    }

    companion object {
        fun fromJson(json: JSONObject): LocalCognitiveInput {
            fun optNullableString(key: String): String? {
                if (!json.has(key) || json.isNull(key)) return null
                val str = json.optString(key, "").trim()
                return if (str.isEmpty() || str == "null") null else str
            }
            val capsArr = json.optJSONArray("availableCapabilityClasses") ?: JSONArray()
            val caps = mutableListOf<CapabilityClass>()
            for (i in 0 until capsArr.length()) {
                val name = capsArr.optString(i)
                try { caps.add(CapabilityClass.valueOf(name)) } catch (ignored: Throwable) {}
            }
            val refsArr = json.optJSONArray("unresolvedReferences") ?: JSONArray()
            val refs = mutableListOf<String>()
            for (i in 0 until refsArr.length()) {
                val r = refsArr.optString(i).trim()
                if (r.isNotEmpty() && r != "null") {
                    refs.add(r)
                }
            }
            return LocalCognitiveInput(
                userMessage = json.optString("userMessage", ""),
                conversationContextSummary = optNullableString("conversationContextSummary"),
                activeGoalSummary = optNullableString("activeGoalSummary"),
                activeWorkSummary = optNullableString("activeWorkSummary"),
                currentForegroundPackage = optNullableString("currentForegroundPackage"),
                availableCapabilityClasses = caps,
                recentProgressState = optNullableString("recentProgressState"),
                unresolvedReferences = refs,
                locale = json.optString("locale", "es-ES")
            )
        }
    }
}

data class CognitiveAssessmentTelemetry(
    val tinyEngineAvailable: Boolean = true,
    val tinyModelId: String = "rule-based-baseline-v1",
    val tinyBackend: String = "LOCAL_JVM",
    val tinyInferenceMs: Long = 0L,
    val tinyColdStartMs: Long = 0L,
    val tinyInputTokens: Int = 0,
    val tinyOutputTokens: Int = 0,
    val potentialCloudRoundsAvoided: Int = 0,
    val estimatedLocalizableDecisions: Int = 0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("tinyEngineAvailable", tinyEngineAvailable)
        put("tinyModelId", tinyModelId)
        put("tinyBackend", tinyBackend)
        put("tinyInferenceMs", tinyInferenceMs)
        put("tinyColdStartMs", tinyColdStartMs)
        put("tinyInputTokens", tinyInputTokens)
        put("tinyOutputTokens", tinyOutputTokens)
        put("potentialCloudRoundsAvoided", potentialCloudRoundsAvoided)
        put("estimatedLocalizableDecisions", estimatedLocalizableDecisions)
    }

    companion object {
        fun fromJson(json: JSONObject): CognitiveAssessmentTelemetry = CognitiveAssessmentTelemetry(
            tinyEngineAvailable = json.optBoolean("tinyEngineAvailable", true),
            tinyModelId = json.optString("tinyModelId", "unknown"),
            tinyBackend = json.optString("tinyBackend", "UNKNOWN"),
            tinyInferenceMs = json.optLong("tinyInferenceMs", 0L),
            tinyColdStartMs = json.optLong("tinyColdStartMs", 0L),
            tinyInputTokens = json.optInt("tinyInputTokens", 0),
            tinyOutputTokens = json.optInt("tinyOutputTokens", 0),
            potentialCloudRoundsAvoided = json.optInt("potentialCloudRoundsAvoided", 0),
            estimatedLocalizableDecisions = if (json.has("estimatedLocalizableDecisions")) {
                json.optInt("estimatedLocalizableDecisions", 0)
            } else {
                json.optInt("potentialCloudRoundsAvoided", 0)
            }
        )
    }
}

object LocalCognitiveAssessmentValidator {
    /**
     * Deterministic validation rules enforcing cross-field semantic contract invariants.
     * Section 5:
     * - confidence must be between 0.0 and 1.0
     * - schemaVersion must be "1.0.0"
     * - interactionMode == CLARIFY -> clarificationRequired == true
     * - clarificationRequired == true -> unresolvedReferences or explicit riskHint must exist
     * - needsCurrentInformation == true -> assessment must indicate appropriate research capability, route, or role hint
     * - needsDurableWork == true -> interactionMode == WORK
     * - strategyRequired == true -> at least one RequiredCapabilityClass must exist
     * - ACTION / WORK -> side-effect or capability requirements must not be completely empty
     */
    fun validateInvariants(assessment: LocalCognitiveAssessment): List<String> {
        val violations = mutableListOf<String>()

        if (assessment.confidence < 0.0 || assessment.confidence > 1.0) {
            violations.add("confidence must be between 0.0 and 1.0, got ${assessment.confidence}")
        }

        if (assessment.schemaVersion != "1.0.0") {
            violations.add("unsupported schemaVersion: '${assessment.schemaVersion}', expected '1.0.0'")
        }

        if (assessment.interactionMode == InteractionMode.CLARIFY && !assessment.clarificationRequired) {
            violations.add("interactionMode == CLARIFY requires clarificationRequired == true")
        }

        if (assessment.clarificationRequired && assessment.unresolvedReferences.isEmpty() && assessment.riskHint.isNullOrBlank()) {
            violations.add("clarificationRequired == true requires unresolvedReferences or explicit riskHint")
        }

        if (assessment.needsCurrentInformation) {
            val hasResearchCap = assessment.requiredCapabilityClasses.contains(CapabilityClass.CURRENT_WEB_INFORMATION) ||
                    assessment.candidateRouteClasses.any { it == RouteClass.WEB || it == RouteClass.BROWSER || it == RouteClass.PROVIDER_NATIVE } ||
                    assessment.providerRoleHints.contains(ProviderRoleHint.CURRENT_INFO_RESEARCH)
            if (!hasResearchCap) {
                violations.add("needsCurrentInformation == true requires appropriate research/web capability, route, or role hint")
            }
        }

        if (assessment.needsDurableWork && assessment.interactionMode != InteractionMode.WORK) {
            violations.add("needsDurableWork == true requires interactionMode == WORK")
        }

        if (assessment.strategyRequired && assessment.requiredCapabilityClasses.isEmpty()) {
            violations.add("strategyRequired == true requires at least one RequiredCapabilityClass")
        }

        if ((assessment.interactionMode == InteractionMode.ACTION || assessment.interactionMode == InteractionMode.WORK) &&
            !assessment.needsDeviceInteraction &&
            !assessment.needsBrowser &&
            !assessment.needsFiles &&
            !assessment.needsCode &&
            !assessment.needsMediaGeneration &&
            !assessment.needsDurableWork &&
            assessment.requiredCapabilityClasses.isEmpty() &&
            assessment.candidateRouteClasses.isEmpty()
        ) {
            violations.add("ACTION or WORK mode must not have empty capability, route, and requirement flags")
        }

        return violations
    }
}

data class LocalCognitiveAssessment(
    val assessmentId: String = "cog_${UUID.randomUUID().toString().take(8)}",
    val schemaVersion: String = "1.0.0",
    val interactionMode: InteractionMode = InteractionMode.CHAT,
    val taskDomain: TaskDomain = TaskDomain.CONVERSATIONAL,
    val entities: List<CognitiveEntity> = emptyList(),
    val constraints: List<CognitiveConstraint> = emptyList(),
    val unresolvedReferences: List<String> = emptyList(),
    val needsCurrentInformation: Boolean = false,
    val needsDeviceInteraction: Boolean = false,
    val needsBrowser: Boolean = false,
    val needsFiles: Boolean = false,
    val needsCode: Boolean = false,
    val needsMediaGeneration: Boolean = false,
    val needsDurableWork: Boolean = false,
    val localSufficiency: LocalSufficiency = LocalSufficiency.LOCAL_ONLY,
    val requiredCapabilityClasses: List<CapabilityClass> = emptyList(),
    val candidateRouteClasses: List<RouteClass> = emptyList(),
    val providerRoleHints: List<ProviderRoleHint> = emptyList(),
    val strategyRequired: Boolean = false,
    val parallelizablePotential: Boolean = false,
    val clarificationRequired: Boolean = false,
    val riskHint: String? = null,
    val confidence: Double = 1.0,
    val telemetry: CognitiveAssessmentTelemetry = CognitiveAssessmentTelemetry()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("assessmentId", assessmentId)
        put("schemaVersion", schemaVersion)
        put("interactionMode", interactionMode.name)
        put("taskDomain", taskDomain.name)
        put("entities", JSONArray(entities.map { it.toJson() }))
        put("constraints", JSONArray(constraints.map { it.toJson() }))
        put("unresolvedReferences", JSONArray(unresolvedReferences))
        put("needsCurrentInformation", needsCurrentInformation)
        put("needsDeviceInteraction", needsDeviceInteraction)
        put("needsBrowser", needsBrowser)
        put("needsFiles", needsFiles)
        put("needsCode", needsCode)
        put("needsMediaGeneration", needsMediaGeneration)
        put("needsDurableWork", needsDurableWork)
        put("localSufficiency", localSufficiency.name)
        put("requiredCapabilityClasses", JSONArray(requiredCapabilityClasses.map { it.name }))
        put("candidateRouteClasses", JSONArray(candidateRouteClasses.map { it.name }))
        put("providerRoleHints", JSONArray(providerRoleHints.map { it.name }))
        put("strategyRequired", strategyRequired)
        put("parallelizablePotential", parallelizablePotential)
        put("clarificationRequired", clarificationRequired)
        if (riskHint != null) put("riskHint", riskHint)
        put("confidence", confidence)
        put("telemetry", telemetry.toJson())
    }

    companion object {
        /**
         * Fail-closed structural and semantic assessment parser.
         * Enforces strict schema fields, enum validity, numeric bounds, and semantic invariants.
         * Never silently converts unknown enums to default values like CHAT.
         */
        fun parseStrict(json: JSONObject): AssessmentParseResult {
            val violations = mutableListOf<String>()

            // 1. Required fields presence check
            val requiredFields = listOf(
                "assessmentId", "schemaVersion", "interactionMode", "taskDomain",
                "entities", "constraints", "unresolvedReferences", "needsCurrentInformation",
                "needsDeviceInteraction", "needsBrowser", "needsFiles", "needsCode",
                "needsMediaGeneration", "needsDurableWork", "localSufficiency",
                "requiredCapabilityClasses", "candidateRouteClasses", "providerRoleHints",
                "strategyRequired", "parallelizablePotential", "clarificationRequired",
                "confidence", "telemetry"
            )
            for (field in requiredFields) {
                if (!json.has(field)) {
                    violations.add("Missing required field: '$field'")
                }
            }

            // Enforce schema additionalProperties: false
            val allowedFields = setOf(
                "assessmentId", "schemaVersion", "interactionMode", "taskDomain",
                "entities", "constraints", "unresolvedReferences", "needsCurrentInformation",
                "needsDeviceInteraction", "needsBrowser", "needsFiles", "needsCode",
                "needsMediaGeneration", "needsDurableWork", "localSufficiency",
                "requiredCapabilityClasses", "candidateRouteClasses", "providerRoleHints",
                "strategyRequired", "parallelizablePotential", "clarificationRequired",
                "riskHint", "confidence", "telemetry"
            )
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                if (key !in allowedFields) {
                    violations.add("Extraneous property not allowed by schema: '$key'")
                }
            }

            val schemaVer = json.optString("schemaVersion", "")
            if (schemaVer != "1.0.0") {
                violations.add("Unsupported or missing schemaVersion: '$schemaVer', expected '1.0.0'")
            }

            // 2. Strict Enum Resolution
            val modeStr = json.optString("interactionMode", "")
            val mode = try {
                if (modeStr.isEmpty()) null else InteractionMode.valueOf(modeStr)
            } catch (t: Throwable) {
                null
            }
            if (mode == null) {
                violations.add("Invalid or unknown interactionMode: '$modeStr'")
            }

            val domainStr = json.optString("taskDomain", "")
            val domain = try {
                if (domainStr.isEmpty()) null else TaskDomain.valueOf(domainStr)
            } catch (t: Throwable) {
                null
            }
            if (domain == null) {
                violations.add("Invalid or unknown taskDomain: '$domainStr'")
            }

            val suffStr = json.optString("localSufficiency", "")
            val suff = try {
                if (suffStr.isEmpty()) null else LocalSufficiency.valueOf(suffStr)
            } catch (t: Throwable) {
                null
            }
            if (suff == null) {
                violations.add("Invalid or unknown localSufficiency: '$suffStr'")
            }

            // 3. Confidence range check
            val confRaw = json.optDouble("confidence", Double.NaN)
            if (confRaw.isNaN() || confRaw < 0.0 || confRaw > 1.0) {
                violations.add("Invalid confidence value: $confRaw (must be between 0.0 and 1.0)")
            }

            // 4. Entities
            val entities = mutableListOf<CognitiveEntity>()
            val entArr = json.optJSONArray("entities")
            if (entArr == null && json.has("entities")) {
                violations.add("Field 'entities' must be an array")
            } else if (entArr != null) {
                for (i in 0 until entArr.length()) {
                    val o = entArr.optJSONObject(i)
                    if (o == null) {
                        violations.add("entities[$i] must be a valid JSON object")
                    } else {
                        val t = o.optString("type", "")
                        val v = o.optString("value", "")
                        if (t.isEmpty() || v.isEmpty()) {
                            violations.add("entities[$i] requires non-empty 'type' and 'value'")
                        } else {
                            entities.add(CognitiveEntity(type = t, value = v))
                        }
                    }
                }
            }

            // 5. Constraints
            val constraints = mutableListOf<CognitiveConstraint>()
            val conArr = json.optJSONArray("constraints")
            if (conArr == null && json.has("constraints")) {
                violations.add("Field 'constraints' must be an array")
            } else if (conArr != null) {
                for (i in 0 until conArr.length()) {
                    val o = conArr.optJSONObject(i)
                    if (o == null) {
                        violations.add("constraints[$i] must be a valid JSON object")
                    } else {
                        val txt = o.optString("text", "")
                        if (txt.isEmpty()) {
                            violations.add("constraints[$i] requires non-empty 'text'")
                        }
                        if (!o.has("isNegative")) {
                            violations.add("constraints[$i] requires boolean 'isNegative'")
                        }
                        constraints.add(CognitiveConstraint(
                            text = txt,
                            isNegative = o.optBoolean("isNegative", false),
                            category = o.optString("category", "execution")
                        ))
                    }
                }
            }

            // 6. Unresolved References
            val refs = mutableListOf<String>()
            val refArr = json.optJSONArray("unresolvedReferences")
            if (refArr == null && json.has("unresolvedReferences")) {
                violations.add("Field 'unresolvedReferences' must be an array")
            } else if (refArr != null) {
                for (i in 0 until refArr.length()) {
                    refs.add(refArr.optString(i))
                }
            }

            // 7. Capability Classes
            val caps = mutableListOf<CapabilityClass>()
            val capArr = json.optJSONArray("requiredCapabilityClasses")
            if (capArr == null && json.has("requiredCapabilityClasses")) {
                violations.add("Field 'requiredCapabilityClasses' must be an array")
            } else if (capArr != null) {
                for (i in 0 until capArr.length()) {
                    val cStr = capArr.optString(i)
                    try {
                        caps.add(CapabilityClass.valueOf(cStr))
                    } catch (t: Throwable) {
                        violations.add("Invalid capability class in requiredCapabilityClasses[$i]: '$cStr'")
                    }
                }
            }

            // 8. Route Classes
            val routes = mutableListOf<RouteClass>()
            val routeArr = json.optJSONArray("candidateRouteClasses")
            if (routeArr == null && json.has("candidateRouteClasses")) {
                violations.add("Field 'candidateRouteClasses' must be an array")
            } else if (routeArr != null) {
                for (i in 0 until routeArr.length()) {
                    val rStr = routeArr.optString(i)
                    try {
                        routes.add(RouteClass.valueOf(rStr))
                    } catch (t: Throwable) {
                        violations.add("Invalid route class in candidateRouteClasses[$i]: '$rStr'")
                    }
                }
            }

            // 9. Provider Role Hints
            val roles = mutableListOf<ProviderRoleHint>()
            val roleArr = json.optJSONArray("providerRoleHints")
            if (roleArr == null && json.has("providerRoleHints")) {
                violations.add("Field 'providerRoleHints' must be an array")
            } else if (roleArr != null) {
                for (i in 0 until roleArr.length()) {
                    val roStr = roleArr.optString(i)
                    try {
                        roles.add(ProviderRoleHint.valueOf(roStr))
                    } catch (t: Throwable) {
                        violations.add("Invalid provider role hint in providerRoleHints[$i]: '$roStr'")
                    }
                }
            }

            // 10. Telemetry
            val teleObj = json.optJSONObject("telemetry")
            if (teleObj == null) {
                violations.add("Field 'telemetry' must be a valid JSON object")
            }

            // If structural validation failed, fail closed immediately
            if (violations.isNotEmpty() || mode == null || domain == null || suff == null) {
                return AssessmentParseResult.Invalid(
                    reason = "Structural validation failed with ${violations.size} violations",
                    violations = violations
                )
            }

            val assessment = LocalCognitiveAssessment(
                assessmentId = json.optString("assessmentId", "cog_${UUID.randomUUID().toString().take(8)}"),
                schemaVersion = schemaVer,
                interactionMode = mode,
                taskDomain = domain,
                entities = entities,
                constraints = constraints,
                unresolvedReferences = refs,
                needsCurrentInformation = json.optBoolean("needsCurrentInformation", false),
                needsDeviceInteraction = json.optBoolean("needsDeviceInteraction", false),
                needsBrowser = json.optBoolean("needsBrowser", false),
                needsFiles = json.optBoolean("needsFiles", false),
                needsCode = json.optBoolean("needsCode", false),
                needsMediaGeneration = json.optBoolean("needsMediaGeneration", false),
                needsDurableWork = json.optBoolean("needsDurableWork", false),
                localSufficiency = suff,
                requiredCapabilityClasses = caps,
                candidateRouteClasses = routes,
                providerRoleHints = roles,
                strategyRequired = json.optBoolean("strategyRequired", false),
                parallelizablePotential = json.optBoolean("parallelizablePotential", false),
                clarificationRequired = json.optBoolean("clarificationRequired", false),
                riskHint = json.optString("riskHint", null.toString()).takeIf { it != "null" },
                confidence = confRaw,
                telemetry = teleObj?.let { CognitiveAssessmentTelemetry.fromJson(it) } ?: CognitiveAssessmentTelemetry()
            )

            // 11. Cross-field Semantic Invariants
            val invariantViolations = LocalCognitiveAssessmentValidator.validateInvariants(assessment)
            if (invariantViolations.isNotEmpty()) {
                return AssessmentParseResult.Invalid(
                    reason = "Semantic invariant validation failed with ${invariantViolations.size} violations",
                    violations = invariantViolations
                )
            }

            return AssessmentParseResult.Valid(assessment)
        }

        /**
         * Strongly typed conversion from JSON.
         * Throws IllegalArgumentException on invalid structural or semantic payload.
         * Never silently falls back to defaults.
         */
        @Throws(IllegalArgumentException::class)
        fun fromJson(json: JSONObject): LocalCognitiveAssessment {
            return when (val res = parseStrict(json)) {
                is AssessmentParseResult.Valid -> res.assessment
                is AssessmentParseResult.Invalid -> throw IllegalArgumentException(
                    "Malformed LocalCognitiveAssessment: ${res.reason}. Violations: ${res.violations.joinToString("; ")}"
                )
            }
        }
    }
}
