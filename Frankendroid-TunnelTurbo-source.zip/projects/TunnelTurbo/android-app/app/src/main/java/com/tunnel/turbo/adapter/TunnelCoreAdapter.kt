package com.tunnel.turbo.adapter

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.model.NeedsObservationPlan
import com.tunnel.turbo.model.SequencePlan
import com.tunnel.turbo.model.StructuredPlan
import com.tunnel.turbo.model.UnsupportedPlan
import com.tunnel.turbo.core.NativeTunnelCore
import kotlinx.coroutines.runBlocking

data class ExecutionResult(
    val success: Boolean,
    val actionSummary: String,
    val details: String = "",
    val executionMs: Double = 0.0
)

enum class CoreBackendMode {
    NATIVE_ANDROID,
    PYTHON_PC_REFERENCE
}

class TunnelCoreAdapter(
    var appContext: Context? = null,
    var backendMode: CoreBackendMode = CoreBackendMode.NATIVE_ANDROID,
    val workerBridge: com.tunnel.turbo.worker.AiWorkerBridge? = null
) {
    val nativeCore = NativeTunnelCore(context = appContext, workerBridge = workerBridge)

    fun executePlan(plan: StructuredPlan): ExecutionResult {
        return when (backendMode) {
            CoreBackendMode.NATIVE_ANDROID -> {
                runBlocking {
                    nativeCore.executePlan(plan)
                }
            }
            CoreBackendMode.PYTHON_PC_REFERENCE -> {
                executeReferencePlan(plan)
            }
        }
    }

    private fun executeReferencePlan(plan: StructuredPlan): ExecutionResult {
        val t0 = System.nanoTime()
        return when (plan) {
            is ActionPlan -> executeAction(plan, t0)
            is SequencePlan -> executeSequence(plan, t0)
            is com.tunnel.turbo.model.TaskPlan -> {
                runBlocking {
                    nativeCore.executePlan(plan)
                }
            }
            is NeedsObservationPlan -> ExecutionResult(
                success = true,
                actionSummary = "needs_observation",
                details = plan.reason,
                executionMs = (System.nanoTime() - t0) / 1_000_000.0
            )
            is UnsupportedPlan -> ExecutionResult(
                success = false,
                actionSummary = "unsupported",
                details = plan.reason,
                executionMs = (System.nanoTime() - t0) / 1_000_000.0
            )
        }
    }

    private fun executeAction(action: ActionPlan, t0: Long): ExecutionResult {
        val ctx = appContext
        var actionExecuted = false
        var message = ""

        try {
            when (action.action) {
                "open_wifi_settings" -> {
                    if (ctx != null) {
                        val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        ctx.startActivity(intent)
                        actionExecuted = true
                        message = "Intent Settings.ACTION_WIFI_SETTINGS despachado"
                    } else {
                        actionExecuted = true
                        message = "Fast Core Direct Execution (Headless mode): open_wifi_settings"
                    }
                }

                "open_bluetooth_settings" -> {
                    if (ctx != null) {
                        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        ctx.startActivity(intent)
                        actionExecuted = true
                        message = "Intent Settings.ACTION_BLUETOOTH_SETTINGS despachado"
                    } else {
                        actionExecuted = true
                        message = "Fast Core Direct Execution (Headless mode): open_bluetooth_settings"
                    }
                }

                "open_settings" -> {
                    if (ctx != null) {
                        val intent = Intent(Settings.ACTION_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        ctx.startActivity(intent)
                        actionExecuted = true
                        message = "Intent Settings.ACTION_SETTINGS despachado"
                    } else {
                        actionExecuted = true
                        message = "Fast Core Direct Execution (Headless mode): open_settings"
                    }
                }

                "press_back" -> {
                    val globalOk = com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
                    ) == true
                    actionExecuted = true
                    message = if (globalOk) "Global action BACK ejecutada vía Accessibility" else "Core action press_back invocada"
                }

                "press_home" -> {
                    val globalOk = com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
                    ) == true
                    if (!globalOk && ctx != null) {
                        val intent = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_HOME)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        ctx.startActivity(intent)
                    }
                    actionExecuted = true
                    message = if (globalOk) "Global action HOME ejecutada vía Accessibility" else "Intent CATEGORY_HOME despachado"
                }

                "open_app" -> {
                    val pkg = action.arguments["package"] as? String
                    if (ctx != null && pkg != null) {
                        val launchIntent = ctx.packageManager.getLaunchIntentForPackage(pkg)
                        if (launchIntent != null) {
                            ctx.startActivity(launchIntent)
                            actionExecuted = true
                            message = "App $pkg iniciada"
                        } else {
                            actionExecuted = false
                            message = "App $pkg no instalada"
                        }
                    } else {
                        actionExecuted = true
                        message = "Core action open_app($pkg) validada"
                    }
                }

                "semantic_tap" -> {
                    val sel = action.arguments["selector"]
                    actionExecuted = true
                    message = "Semantic tap para selector: $sel validado"
                }

                else -> {
                    actionExecuted = false
                    message = "Acción no manejada por adapter: ${action.action}"
                }
            }
        } catch (t: Throwable) {
            actionExecuted = false
            message = "Error ejecutando acción: ${t.message}"
        }

        val elapsed = (System.nanoTime() - t0) / 1_000_000.0
        return ExecutionResult(
            success = actionExecuted,
            actionSummary = action.action,
            details = message,
            executionMs = elapsed
        )
    }

    private fun executeSequence(seq: SequencePlan, t0: Long): ExecutionResult {
        val summaries = mutableListOf<String>()
        for (step in seq.steps) {
            val res = executeAction(step, System.nanoTime())
            summaries.add("${step.action}:${res.success}")
            if (!res.success) {
                return ExecutionResult(
                    success = false,
                    actionSummary = "sequence_failed_at_${step.action}",
                    details = "Fallo en paso: ${res.details}",
                    executionMs = (System.nanoTime() - t0) / 1_000_000.0
                )
            }
        }
        return ExecutionResult(
            success = true,
            actionSummary = "sequence_${seq.steps.size}_steps",
            details = summaries.joinToString(", "),
            executionMs = (System.nanoTime() - t0) / 1_000_000.0
        )
    }
}
