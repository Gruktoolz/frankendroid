package com.tunnel.turbo.perception

import android.graphics.Rect
import java.text.Normalizer
import java.util.Locale

class PerceptionFusionEngine {

    companion object {
        fun computeIoU(r1: Rect?, r2: Rect?): Float {
            if (r1 == null || r2 == null) return 0f
            val interLeft = maxOf(r1.left, r2.left)
            val interTop = maxOf(r1.top, r2.top)
            val interRight = minOf(r1.right, r2.right)
            val interBottom = minOf(r1.bottom, r2.bottom)

            val interWidth = maxOf(0, interRight - interLeft)
            val interHeight = maxOf(0, interBottom - interTop)
            val interArea = interWidth.toLong() * interHeight.toLong()

            val area1 = r1.width().toLong() * r1.height().toLong()
            val area2 = r2.width().toLong() * r2.height().toLong()
            val unionArea = area1 + area2 - interArea

            return if (unionArea > 0) interArea.toFloat() / unionArea.toFloat() else 0f
        }

        fun computeContainment(inner: Rect?, outer: Rect?): Float {
            if (inner == null || outer == null) return 0f
            val interLeft = maxOf(inner.left, outer.left)
            val interTop = maxOf(inner.top, outer.top)
            val interRight = minOf(inner.right, outer.right)
            val interBottom = minOf(inner.bottom, outer.bottom)

            val interWidth = maxOf(0, interRight - interLeft)
            val interHeight = maxOf(0, interBottom - interTop)
            val interArea = interWidth.toLong() * interHeight.toLong()
            val innerArea = inner.width().toLong() * inner.height().toLong()

            return if (innerArea > 0) interArea.toFloat() / innerArea.toFloat() else 0f
        }

        fun normalizeText(input: String?): String {
            if (input.isNullOrBlank()) return ""
            return Normalizer.normalize(input, Normalizer.Form.NFD)
                .replace("\\p{M}".toRegex(), "")
                .lowercase(Locale.ROOT)
                .replace("[^a-z0-9\\s]".toRegex(), " ")
                .replace("\\s+".toRegex(), " ")
                .trim()
        }

        fun textSimilarity(s1: String?, s2: String?): Float {
            val n1 = normalizeText(s1)
            val n2 = normalizeText(s2)
            if (n1.isEmpty() && n2.isEmpty()) return 1.0f
            if (n1.isEmpty() || n2.isEmpty()) return 0.0f
            if (n1 == n2) return 1.0f
            if (n1.contains(n2) || n2.contains(n1)) return 0.85f

            val words1 = n1.split(" ").filter { it.isNotBlank() }.toSet()
            val words2 = n2.split(" ").filter { it.isNotBlank() }.toSet()
            val union = words1 union words2
            val inter = words1 intersect words2
            return if (union.isNotEmpty()) inter.size.toFloat() / union.size.toFloat() else 0.0f
        }
    }

    fun fuse(
        displayId: Int,
        revision: Long,
        a11yElements: List<SemanticElement>,
        ocrElements: List<OcrElement>
    ): List<UnifiedElement> {
        val unified = mutableListOf<UnifiedElement>()
        val matchedA11yIds = mutableSetOf<String>()
        val matchedOcrIds = mutableSetOf<String>()

        var elementCounter = 0

        // 1. Cross-matching A11y and OCR
        for (ocr in ocrElements) {
            var bestMatch: SemanticElement? = null
            var bestScore = 0.0f

            for (a11y in a11yElements) {
                val iou = computeIoU(ocr.boundingBox, a11y.bounds)
                val containment = computeContainment(ocr.boundingBox, a11y.bounds)
                val sim = textSimilarity(ocr.text, a11y.effectiveLabel())

                if (iou > 0.20f || containment > 0.60f) {
                    if (a11y.effectiveLabel().isEmpty() || sim > 0.40f) {
                        val score = maxOf(iou, containment) * 0.5f + maxOf(sim, 0.5f) * 0.5f
                        if (score > bestScore) {
                            bestScore = score
                            bestMatch = a11y
                        }
                    }
                }
            }

            if (bestMatch != null && bestScore > 0.45f) {
                matchedA11yIds.add(bestMatch.id)
                matchedOcrIds.add(ocr.id)
                elementCounter++

                // Prefer non-empty text, OCR if a11y was blank, or cleaner string
                val label = when {
                    bestMatch.text.isNotBlank() -> bestMatch.text
                    ocr.text.isNotBlank() -> ocr.text
                    else -> bestMatch.contentDescription
                }

                // FUSION_CONFIDENCE calculation (Section 16)
                val fusionConfidence = (0.85f + bestScore * 0.14f).coerceIn(0.85f, 0.99f)
                val refToken = "f:$displayId:$revision:$elementCounter"

                unified.add(
                    UnifiedElement(
                        ref = refToken,
                        label = label,
                        roleHint = bestMatch.role,
                        source = ElementSource.FUSED,
                        confidence = fusionConfidence,
                        boundsInternal = bestMatch.bounds,
                        actionableHint = if (bestMatch.clickable) "clickable" else if (bestMatch.editable) "editable" else "none",
                        displayId = displayId,
                        revision = revision
                    )
                )
            }
        }

        // 2. Unmatched A11y Elements -> ACCESSIBILITY_ONLY
        for (a11y in a11yElements) {
            if (!matchedA11yIds.contains(a11y.id)) {
                elementCounter++
                val refToken = "a:$displayId:$revision:$elementCounter"
                unified.add(
                    UnifiedElement(
                        ref = refToken,
                        label = a11y.effectiveLabel(),
                        roleHint = a11y.role,
                        source = ElementSource.ACCESSIBILITY,
                        confidence = 1.0f,
                        boundsInternal = a11y.bounds,
                        actionableHint = if (a11y.clickable) "clickable" else if (a11y.editable) "editable" else "none",
                        displayId = displayId,
                        revision = revision
                    )
                )
            }
        }

        // 3. Unmatched OCR Elements -> OCR_ONLY
        for (ocr in ocrElements) {
            if (!matchedOcrIds.contains(ocr.id)) {
                elementCounter++
                val refToken = "o:$displayId:$revision:$elementCounter"
                val roleGuess = if (ocr.text.contains("?") || ocr.text.contains("Buscar", ignoreCase = true)) "search_bar" else "text_region"
                unified.add(
                    UnifiedElement(
                        ref = refToken,
                        label = ocr.text,
                        roleHint = roleGuess,
                        source = ElementSource.OCR,
                        confidence = 0.82f,
                        boundsInternal = ocr.boundingBox,
                        actionableHint = "candidate_interactive",
                        displayId = displayId,
                        revision = revision
                    )
                )
            }
        }

        return unified
    }
}
