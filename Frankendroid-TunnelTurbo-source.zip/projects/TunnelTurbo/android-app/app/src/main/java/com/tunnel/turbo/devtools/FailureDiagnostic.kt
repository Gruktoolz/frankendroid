package com.tunnel.turbo.devtools

import com.tunnel.turbo.accessibility.UiNodeInfo
import org.json.JSONArray
import org.json.JSONObject

data class FailureDiagnostic(
    val failureType: String,
    val failedStepIndex: Int,
    val failedTool: String,
    val expectedCondition: String,
    val actualCondition: String,
    val foregroundPackage: String,
    val foregroundActivity: String,
    val displayId: Int = 0,
    val providerState: String = "NOT_APPLICABLE",
    val relevantNodes: List<UiNodeInfo> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("failureType", failureType)
        obj.put("failedStepIndex", failedStepIndex)
        obj.put("failedTool", failedTool)
        obj.put("expectedCondition", expectedCondition)
        obj.put("actualCondition", actualCondition)
        obj.put("foregroundPackage", foregroundPackage)
        obj.put("foregroundActivity", foregroundActivity)
        obj.put("displayId", displayId)
        obj.put("providerState", providerState)
        val arr = JSONArray()
        for (n in relevantNodes) {
            arr.put(n.toJson())
        }
        obj.put("relevantNodes", arr)
        obj.put("timestamp", timestamp)
        return obj
    }
}
