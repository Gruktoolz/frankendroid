package com.tunnel.turbo.coordinator

enum class UiMode {
    APP_MODE,
    DEBUG_MODE
}

enum class NavigationTab {
    CONVERSATION,
    ACTIVITY,
    SETTINGS,
    MODEL_CENTER,
    CONNECTIONS,
    DEVICE,
    SETTINGS_LAB
}

enum class MessageRole {
    USER,
    ASSISTANT,
    SYSTEM_STATUS
}

enum class MessageFeedback { POSITIVE, NEGATIVE }

object ConversationFeedbackReducer {
    fun toggle(messages: List<ConversationMessage>, messageId: String, feedback: MessageFeedback): List<ConversationMessage> {
        val index = messages.indexOfFirst { it.id == messageId && it.role == MessageRole.ASSISTANT }
        if (index < 0) return messages
        return messages.toMutableList().also { copy ->
            val current = copy[index].feedback
            copy[index] = copy[index].copy(feedback = if (current == feedback) null else feedback)
        }
    }
}

object ConversationEditReducer {
    /** Retains only the transcript before the selected user message so it can be submitted again. */
    fun retainedBefore(messages: List<ConversationMessage>, messageId: String): List<ConversationMessage>? {
        val index = messages.indexOfFirst { it.id == messageId }
        if (index < 0 || messages[index].role != MessageRole.USER) return null
        return messages.take(index)
    }

    /** Finds the user turn answered by an assistant message and removes that turn onward. */
    fun userMessageForResponse(messages: List<ConversationMessage>, responseId: String): ConversationMessage? {
        val responseIndex = messages.indexOfFirst { it.id == responseId && it.role == MessageRole.ASSISTANT }
        if (responseIndex < 0) return null
        return messages.subList(0, responseIndex).lastOrNull { it.role == MessageRole.USER }
    }

    fun retainedBeforeResponse(messages: List<ConversationMessage>, responseId: String): List<ConversationMessage>? {
        val userMessage = userMessageForResponse(messages, responseId) ?: return null
        return retainedBefore(messages, userMessage.id)
    }
}

enum class ConversationRenderUpdate { NONE, STREAMING_TEXT, REBUILD }

/** Avoid rebuilding the whole transcript for each streamed text fragment. */
object ConversationRenderPolicy {
    fun decide(previous: List<ConversationMessage>?, current: List<ConversationMessage>): ConversationRenderUpdate {
        if (previous == null || previous.size != current.size) return ConversationRenderUpdate.REBUILD
        if (previous.indices.any { index ->
                val before = previous[index]
                val after = current[index]
                before.id != after.id || before.role != after.role || before.route != after.route ||
                    before.turnStatus != after.turnStatus || before.feedback != after.feedback ||
                    before.timestamp != after.timestamp || before.provenance != after.provenance ||
                    before.latencyMs != after.latencyMs || before.actionSummary != after.actionSummary ||
                    before.verificationExplanation != after.verificationExplanation
            }) return ConversationRenderUpdate.REBUILD

        val changedTextIndexes = previous.indices.filter { previous[it].text !== current[it].text }
        if (changedTextIndexes.isEmpty()) return ConversationRenderUpdate.NONE
        val onlyIndex = changedTextIndexes.singleOrNull()
        val onlyMessage = onlyIndex?.let(current::getOrNull)
        return if (onlyIndex == current.lastIndex && onlyMessage?.role == MessageRole.ASSISTANT &&
            onlyMessage.turnStatus == TurnStatus.GENERATING
        ) ConversationRenderUpdate.STREAMING_TEXT else ConversationRenderUpdate.REBUILD
    }
}

/** One concise visible state for the chat progress affordance. */
object ProgressStatusPresenter {
    fun present(isBusy: Boolean, statusMessage: String, latestActivity: String? = null): String {
        if (!isBusy) return ""
        val normalized = "$latestActivity $statusMessage".lowercase()
        return when {
            "verif" in normalized -> "Verificando"
            "busc" in normalized || "research" in normalized -> "Buscando"
            "observ" in normalized -> "Observando"
            "acción" in normalized || "ejecut" in normalized || "activ" in normalized -> "Actuando"
            "pens" in normalized || "plan" in normalized || "razon" in normalized || "entend" in normalized || "siguiente paso" in normalized -> "Pensando"
            "investig" in normalized || "decidi" in normalized -> "Pensando"
            "carg" in normalized || "prepar" in normalized -> "Preparando"
            else -> "Procesando"
        }
    }
}

enum class Route {
    LOCAL_CHAT,
    CLOUD_API,
    ANDROID_DIRECT,
    ANDROID_AGENT,
    RESEARCH,
    WORK,
    CLARIFY,
    UNSUPPORTED
}

enum class TurnStatus {
    IDLE,
    CLASSIFYING,
    ROUTING,
    WAITING_MODEL,
    GENERATING,
    ACTION_RUNNING,
    VERIFYING,
    GENERATED,
    COMPLETED_VERIFIED,
    COMPLETED_UNVERIFIED,
    FAILED,
    NEEDS_CLARIFICATION,
    UNSUPPORTED
}

data class ConversationMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: MessageRole,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val route: Route? = null,
    val turnStatus: TurnStatus? = null,
    val provenance: String? = null,
    val latencyMs: Double? = null,
    val actionSummary: String? = null,
    val verificationExplanation: String? = null,
    val isSimulated: Boolean = false,
    val feedback: MessageFeedback? = null
)

enum class LocalEngineStatus {
    NOT_INSTALLED,
    INSTALLED_NOT_LOADED,
    LOADING,
    READY,
    GENERATING,
    ERROR,
    UNKNOWN
}

data class LocalEngineState(
    val status: LocalEngineStatus = LocalEngineStatus.UNKNOWN,
    val modelId: String? = null,
    val displayName: String? = null,
    val requestedBackend: String? = null,
    val effectiveBackend: String? = null,
    val fileSizeBytes: Long? = null,
    val filePath: String? = null,
    val lastUsedMs: Long? = null,
    val lastTtftMs: Double? = null,
    val lastDecodeTokensPerSec: Double? = null,
    val errorMessage: String? = null
)

enum class CloudProviderStatus {
    NOT_CONFIGURED,
    AUTH_REQUIRED,
    CHECKING,
    READY_CHECKED,
    RATE_LIMITED,
    OFFLINE,
    ERROR,
    UNKNOWN
}

data class CloudProviderState(
    val status: CloudProviderStatus = CloudProviderStatus.NOT_CONFIGURED,
    val providerId: String = "none",
    val displayName: String = "Cloud Provider",
    val endpointOrModel: String? = null,
    val checkedAtMs: Long? = null,
    val evidenceOrSource: String? = "No cloud API configured; local-first architecture",
    val errorMessage: String? = null,
    val isSimulated: Boolean = false
)

enum class CapabilityHealth {
    DISABLED,
    PERMISSION_REQUIRED,
    ENABLED_NOT_BOUND,
    CONNECTED,
    ERROR,
    UNKNOWN
}

data class AndroidCapabilitiesState(
    val accessibility: CapabilityHealth = CapabilityHealth.UNKNOWN,
    val shizuku: CapabilityHealth = CapabilityHealth.UNKNOWN,
    val directApi: CapabilityHealth = CapabilityHealth.UNKNOWN,
    val lastCheckMs: Long = System.currentTimeMillis()
)

data class DebugUiState(
    val shizukuStatusText: String = "Shizuku: CHECKING...",
    val accessibilityStatusText: String = "Accessibility: CHECKING...",
    val providerStatusText: String = "Provider: NOT_CONFIGURED",
    val cloudProvider: CloudProviderState = CloudProviderState(),
    val localEngine: LocalEngineState = LocalEngineState(),
    val capabilities: AndroidCapabilitiesState = AndroidCapabilitiesState(),
    val workerDisplayId: Int? = null,
    val coreBackend: String = "NATIVE_ANDROID",
    val stateEngineRevision: Long = 0L,
    val journalEventCount: Int = 0,
    val lastRequestId: String = "NONE",
    val lastRoute: String = "NONE",
    val lastPlan: String = "NONE",
    val lastActionSummary: String = "NONE",
    val lastVerification: String = "NONE",
    val lastLatencyMs: Double = 0.0,
    val logOutput: String = "Tunnel Turbo Coordinator iniciado."
)

data class AppUiState(
    val uiMode: UiMode = UiMode.APP_MODE,
    val activeTab: NavigationTab = NavigationTab.CONVERSATION,
    val statusMessage: String = "Sin actividad",
    val isBusy: Boolean = false,
    val conversation: List<ConversationMessage> = listOf(
        ConversationMessage(
            role = MessageRole.ASSISTANT,
            text = "Hola. Soy Tunnel Turbo. ¿En qué te ayudo?"
        )
    ),
    val debugState: DebugUiState = DebugUiState()
)
