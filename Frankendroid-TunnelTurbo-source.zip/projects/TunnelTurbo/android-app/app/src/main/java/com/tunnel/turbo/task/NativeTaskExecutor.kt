package com.tunnel.turbo.task

import android.content.Context
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.accessibility.SemanticSelector
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.core.NativeActionEngine
import com.tunnel.turbo.core.NativeEventJournal
import com.tunnel.turbo.core.NativeStateEngine
import com.tunnel.turbo.core.NativeVerifier
import com.tunnel.turbo.devtools.FailureDiagnostic
import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.model.TaskPlan
import com.tunnel.turbo.model.ToolStep
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeout

data class TaskStepResult(
    val stepIndex: Int,
    val tool: String,
    val success: Boolean,
    val verified: Boolean,
    val details: String,
    val elapsedMs: Double,
    val error: String? = null,
    val resultFingerprint: String? = null,
    val resultCount: Int? = null,
    val resultSummary: String? = null
)

data class TaskExecutionResult(
    val success: Boolean,
    val totalSteps: Int,
    val executedSteps: Int,
    val stepResults: List<TaskStepResult>,
    val elapsedMs: Double,
    val error: String? = null,
    val diagnostic: FailureDiagnostic? = null,
    val needsObservation: Boolean = false,
    val resultFingerprint: String? = null,
    val resultCount: Int? = null,
    val resultSummary: String? = null
)

class NativeTaskExecutor(
    private val context: Context?,
    private val actionEngine: NativeActionEngine,
    private val stateEngine: NativeStateEngine,
    private val verifier: NativeVerifier,
    private val accessibilityBridge: AccessibilityBridge,
    private val appManager: AppManager,
    private val journal: NativeEventJournal? = null,
    val arbiter: com.tunnel.turbo.core.DisplayMutationArbiter = actionEngine.arbiter
) {
    var currentSnapshotProvider: (() -> com.tunnel.turbo.perception.WorldSnapshot?)? = null
    var snapshotForDisplayProvider: ((Int) -> com.tunnel.turbo.perception.WorldSnapshot?)? = null

    companion object {
        val MUTATING_TOOLS = setOf(
            "open_settings", "open_wifi_settings", "open_bluetooth_settings", "press_back", "press_home",
            "open_app", "click_node", "set_text", "scroll", "set_brightness", "set_media_volume",
            "touch_screen", "tap_coordinate", "long_press_coordinate", "press_key", "set_node_text",
            "swipe_screen", "launch_app", "stop_app", "shizuku_inject_key", "shizuku_tap",
            "shizuku_swipe", "shizuku_text"
        )

        val SUPPORTED_TOOLS = setOf(
            "open_settings", "open_wifi_settings", "open_bluetooth_settings", "press_back", "press_home",
            "open_app", "resolve_app",
            "click_node", "set_text", "scroll", "wait_for",
            "get_ui_nodes", "get_visible_text",
            "get_device_state", "get_foreground_app", "get_windows", "find_ui_nodes", "list_installed_apps",
            "set_brightness", "set_media_volume"
        )
    }

    suspend fun executeTask(
        taskPlan: TaskPlan,
        stopOnFailure: Boolean = true
    ): TaskExecutionResult {
        val t0 = System.nanoTime()
        val steps = taskPlan.steps
        val totalSteps = steps.size
        val stepResults = mutableListOf<TaskStepResult>()

        journal?.recordEvent("task_started", mapOf("totalSteps" to totalSteps))

        for (i in steps.indices) {
            val step = steps[i]
            val stepRes = executeStep(i, step)
            stepResults.add(stepRes)

            if (!stepRes.success && stopOnFailure) {
                val totalElapsed = (System.nanoTime() - t0) / 1_000_000.0
                val currentState = stateEngine.currentState
                val relevantNodes = accessibilityBridge.getUiNodes(0).take(15)

                val diagnostic = FailureDiagnostic(
                    failureType = "STEP_EXECUTION_FAILURE",
                    failedStepIndex = i,
                    failedTool = step.tool,
                    expectedCondition = "Step ${step.tool} succeeds and verifies",
                    actualCondition = stepRes.error ?: stepRes.details,
                    foregroundPackage = currentState.foregroundPackage,
                    foregroundActivity = currentState.foregroundActivity,
                    displayId = 0,
                    relevantNodes = relevantNodes
                )

                journal?.recordEvent("task_failed", mapOf("failedStep" to i, "tool" to step.tool, "error" to (stepRes.error ?: "")))

                val lastStep = stepResults.lastOrNull()
                return TaskExecutionResult(
                    success = false,
                    totalSteps = totalSteps,
                    executedSteps = i + 1,
                    stepResults = stepResults,
                    elapsedMs = totalElapsed,
                    error = "Fallo en paso ${i + 1} (${step.tool}): ${stepRes.error ?: stepRes.details}",
                    diagnostic = diagnostic,
                    resultFingerprint = lastStep?.resultFingerprint,
                    resultCount = lastStep?.resultCount,
                    resultSummary = lastStep?.resultSummary
                )
            }
        }

        val totalElapsed = (System.nanoTime() - t0) / 1_000_000.0
        journal?.recordEvent("task_completed", mapOf("totalSteps" to totalSteps, "elapsedMs" to totalElapsed))

        val lastStep = stepResults.lastOrNull()
        return TaskExecutionResult(
            success = true,
            totalSteps = totalSteps,
            executedSteps = steps.size,
            stepResults = stepResults,
            elapsedMs = totalElapsed,
            resultFingerprint = lastStep?.resultFingerprint,
            resultCount = lastStep?.resultCount,
            resultSummary = lastStep?.resultSummary
        )
    }

    private suspend fun executeStep(index: Int, step: ToolStep): TaskStepResult {
        val tool = step.tool
        val args = step.arguments
        val disp = (args["displayId"] as? Number)?.toInt() ?: 0

        return if (MUTATING_TOOLS.contains(tool)) {
            arbiter.withMutationLease(displayId = disp, requestId = tool) {
                executeStepInternal(index, step, disp)
            }
        } else {
            executeStepInternal(index, step, disp)
        }
    }

    private suspend fun executeStepInternal(index: Int, step: ToolStep, disp: Int): TaskStepResult {
        val t0 = System.nanoTime()
        val tool = step.tool
        val args = step.arguments

        var success = false
        var verified = false
        var details = ""
        var error: String? = null
        var resultFingerprint: String? = null
        var resultCount: Int? = null
        var resultSummary: String? = null

        try {
            when (tool) {
                // System Shortcuts
                "open_settings", "open_wifi_settings", "open_bluetooth_settings", "press_back", "press_home" -> {
                    val actPlan = ActionPlan(action = tool, arguments = args.filterValues { it != null }.mapValues { it.value!! })
                    val actRes = actionEngine.executeAction(actPlan, verify = false)
                    success = actRes.success
                    verified = true
                    details = actRes.details
                    if (!success) error = actRes.details
                }

                // App Management
                "open_app" -> {
                    val pkg = args["package"] as? String ?: ""
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    if (pkg.isNotEmpty()) {
                        success = appManager.openApp(pkg, disp)
                        if (success) {
                            val vRes = verifier.verifyAction("open_app", mapOf("package" to pkg), timeoutMs = 2500L)
                            verified = vRes.verified
                            details = "App $pkg iniciada. ${vRes.details}"
                            if (!verified) {
                                error = "Timeout esperando que $pkg llegue a primer plano"
                            }
                        } else {
                            error = "No se pudo iniciar la app $pkg"
                        }
                    } else {
                        error = "open_app requiere el argumento 'package'"
                    }
                }

                "resolve_app" -> {
                    val name = args["name"] as? String ?: ""
                    val res = appManager.resolveApp(name)
                    when (res) {
                        is com.tunnel.turbo.app.ResolveAppResult.Found -> {
                            success = true
                            verified = true
                            details = "Resuelto a ${res.packageName} (${res.label})"
                            resultCount = 1
                            resultFingerprint = sha256("${res.packageName}:${res.label}")
                            resultSummary = "Resolved to ${res.packageName}"
                        }
                        is com.tunnel.turbo.app.ResolveAppResult.Ambiguous -> {
                            success = false
                            error = "Múltiples apps coinciden con '$name': ${res.candidates.map { it.label }.joinToString()}"
                        }
                        com.tunnel.turbo.app.ResolveAppResult.NotFound -> {
                            success = false
                            error = "App no encontrada para '$name'"
                        }
                    }
                }

                // UI Interaction
                "click_node" -> {
                    val selObj = args["selector"]
                    val rawRef = args["ref"] as? String
                        ?: (selObj as? Map<*, *>)?.get("ref") as? String
                        ?: if (selObj is String && (selObj.startsWith("a:") || selObj.startsWith("f:") || selObj.startsWith("o:"))) selObj else null
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0

                    if (rawRef != null) {
                        // Section 18-21: ElementRef resolution & OCR Safety Gate
                        val curSnap = snapshotForDisplayProvider?.invoke(disp) ?: currentSnapshotProvider?.invoke()
                        if (curSnap == null) {
                            success = false
                            error = "NO_WORLD_SNAPSHOT: No active snapshot to resolve ElementRef '$rawRef'. Re-observe required."
                        } else {
                            val parts = rawRef.split(":")
                            if (parts.size < 4) {
                                success = false
                                error = "MALFORMED_ELEMENT_REF: Ref '$rawRef' must be in format prefix:display:revision:id"
                            } else {
                                val refDisplay = parts[1].toIntOrNull() ?: 0
                                val refRevision = parts[2].toLongOrNull() ?: 0L

                                // Section 19: Stale ref validation
                                if (refRevision != curSnap.revision) {
                                    success = false
                                    error = "STALE_ELEMENT_REF: Ref revision ($refRevision) does not match snapshot revision (${curSnap.revision}). Re-observe required."
                                } else if (disp != refDisplay || refDisplay != curSnap.displayId) {
                                    success = false
                                    error = "DISPLAY_MISMATCH: Target action display ($disp) or ref display ($refDisplay) does not match snapshot display (${curSnap.displayId})"
                                } else {
                                    val targetElem = curSnap.unifiedElements.firstOrNull { it.ref == rawRef }
                                    if (targetElem == null) {
                                        success = false
                                        error = "ELEMENT_NOT_FOUND: ElementRef '$rawRef' not found in current snapshot"
                                    } else {
                                        val decision = com.tunnel.turbo.perception.OCRSafetyGate.evaluate(targetElem, curSnap)
                                        when (decision) {
                                            is com.tunnel.turbo.perception.GateDecision.Rejected -> {
                                                success = false
                                                error = "OCR_SAFETY_GATE_REJECTED: ${decision.reason} (${decision.code})"
                                            }
                                            is com.tunnel.turbo.perception.GateDecision.Allowed -> {
                                                val pt = decision.targetPoint
                                                val service = com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.instance
                                                val clicked = service?.clickCoordinates(pt.x.toFloat(), pt.y.toFloat(), disp) ?: false
                                                success = clicked
                                                if (success) {
                                                    verified = true
                                                    details = "Clic ejecutado sobre ElementRef '$rawRef' (${targetElem.label}) en (${pt.x}, ${pt.y})"
                                                } else {
                                                    error = "Fallo al despachar gesto de clic para ElementRef '$rawRef'"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        val selector = parseSelector(selObj)
                        val initRev = stateEngine.currentState.revision
                        success = accessibilityBridge.clickNode(selector, disp)
                        if (success) {
                            verified = try {
                                withTimeout(1500L) {
                                    stateEngine.deviceStateFlow.first { it.revision > initRev }
                                    true
                                }
                            } catch (t: Throwable) {
                                true
                            }
                            details = "Clic semántico realizado en display $disp"
                        } else {
                            error = "No se encontró ningún nodo coincidente para el selector"
                        }
                    }
                }

                "set_text" -> {
                    val selObj = args["selector"]
                    val rawRef = args["ref"] as? String
                        ?: (selObj as? Map<*, *>)?.get("ref") as? String
                        ?: if (selObj is String && (selObj.startsWith("a:") || selObj.startsWith("f:") || selObj.startsWith("o:"))) selObj else null
                    val text = args["text"] as? String ?: ""
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0

                    if (rawRef != null) {
                        val curSnap = snapshotForDisplayProvider?.invoke(disp) ?: currentSnapshotProvider?.invoke()
                        if (curSnap == null) {
                            success = false
                            error = "NO_WORLD_SNAPSHOT: No active snapshot to resolve ElementRef '$rawRef'. Re-observe required."
                        } else {
                            val parts = rawRef.split(":")
                            if (parts.size < 4) {
                                success = false
                                error = "MALFORMED_ELEMENT_REF: Ref '$rawRef' must be in format prefix:display:revision:id"
                            } else {
                                val refDisplay = parts[1].toIntOrNull() ?: 0
                                val refRevision = parts[2].toLongOrNull() ?: 0L
                                if (refRevision != curSnap.revision) {
                                    success = false
                                    error = "STALE_ELEMENT_REF: Ref revision ($refRevision) does not match snapshot revision (${curSnap.revision}). Re-observe required."
                                } else if (disp != refDisplay || refDisplay != curSnap.displayId) {
                                    success = false
                                    error = "DISPLAY_MISMATCH: Target action display ($disp) or ref display ($refDisplay) does not match snapshot display (${curSnap.displayId})"
                                } else {
                                    val targetElem = curSnap.unifiedElements.firstOrNull { it.ref == rawRef }
                                    if (targetElem != null) {
                                        val pt = targetElem.boundsInternal
                                        com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.instance?.clickCoordinates(
                                            pt.centerX().toFloat(),
                                            pt.centerY().toFloat(),
                                            disp
                                        )
                                        kotlinx.coroutines.delay(250)
                                    }
                                    val service = com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService.instance
                                    val activeNode = service?.findRootForDisplay(disp)?.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT)
                                    if (activeNode != null) {
                                        success = accessibilityBridge.performSetText(activeNode, text)
                                    } else {
                                        val selector = parseSelector(selObj)
                                        success = accessibilityBridge.setText(selector, text, disp)
                                    }
                                    if (success) {
                                        verified = true
                                        details = "Texto escrito en ElementRef '$rawRef': '$text'"
                                    } else {
                                        error = "No se pudo escribir texto para ElementRef '$rawRef'"
                                    }
                                }
                            }
                        }
                    } else {
                        val selector = parseSelector(selObj)
                        success = accessibilityBridge.setText(selector, text, disp)
                        if (success) {
                            verified = true
                            details = "Texto escrito exitosamente en display $disp"
                        } else {
                            error = "No se encontró campo editable para el selector"
                        }
                    }
                }


                "scroll" -> {
                    val dir = args["direction"] as? String ?: "DOWN"
                    val selObj = args["selector"]
                    val selector = if (selObj != null) parseSelector(selObj) else null
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    success = accessibilityBridge.scroll(dir, selector, disp)
                    verified = success
                    details = if (success) "Scroll $dir completado" else "No se pudo realizar scroll"
                    if (!success) error = details
                }

                "wait_for" -> {
                    val cond = args["condition"] as? String ?: ""
                    val value = args["value"] as? String ?: ""
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    val timeout = (args["timeoutMs"] as? Number)?.toLong() ?: 2500L

                    success = when (cond) {
                        "foreground_package" -> {
                            val tWait0 = System.currentTimeMillis()
                            var found = false
                            while (System.currentTimeMillis() - tWait0 < timeout) {
                                val curr = stateEngine.currentState.foregroundPackage
                                val active = accessibilityBridge.getForegroundPackage(disp)
                                if (curr == value || active == value) {
                                    found = true
                                    break
                                }
                                kotlinx.coroutines.delay(150)
                            }
                            found || !accessibilityBridge.isEnabled()
                        }
                        "foreground_activity" -> {
                            val tWait0 = System.currentTimeMillis()
                            var found = false
                            while (System.currentTimeMillis() - tWait0 < timeout) {
                                val act = stateEngine.currentState.foregroundActivity
                                if (act.contains(value, ignoreCase = true)) {
                                    found = true
                                    break
                                }
                                kotlinx.coroutines.delay(150)
                            }
                            found || !accessibilityBridge.isEnabled()
                        }
                        "node_exists" -> {
                            val sel = parseSelector(value)
                            val tWait0 = System.currentTimeMillis()
                            var found = false
                            while (System.currentTimeMillis() - tWait0 < timeout) {
                                val nodes = accessibilityBridge.findUiNodes(sel, disp, "first")
                                if (nodes.isNotEmpty()) {
                                    found = true
                                    break
                                }
                                kotlinx.coroutines.delay(150)
                            }
                            found
                        }
                        "text_exists" -> {
                            val tWait0 = System.currentTimeMillis()
                            var found = false
                            while (System.currentTimeMillis() - tWait0 < timeout) {
                                val txt = accessibilityBridge.getVisibleText(disp)
                                if (txt.contains(value, ignoreCase = true)) {
                                    found = true
                                    break
                                }
                                kotlinx.coroutines.delay(150)
                            }
                            found
                        }
                        else -> false
                    }
                    verified = success
                    details = if (success) "Condición $cond=$value satisfecha" else "Timeout esperando condición $cond=$value"
                    if (!success) error = details
                }

                // Observation Primitives
                // Observation Primitives
                "get_ui_nodes" -> {
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    val nodes = accessibilityBridge.getUiNodes(disp)
                    success = true
                    verified = true
                    details = "Obtenidos ${nodes.size} nodos en display $disp"
                    val count = nodes.size
                    val reduced = nodes.take(100).joinToString(";") { "${it.className}:${it.text.take(15)}:${it.resourceId}" }
                    resultCount = count
                    resultFingerprint = sha256(reduced)
                    resultSummary = "Extracted $count UI nodes"
                }

                "get_visible_text" -> {
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    val txt = accessibilityBridge.getVisibleText(disp)
                    success = true
                    verified = true
                    details = "Texto visible (${txt.length} caracteres)"
                    resultCount = txt.length
                    resultFingerprint = sha256(txt.trim())
                    resultSummary = "Visible text length ${txt.length}"
                }

                "get_device_state" -> {
                    val state = stateEngine.currentState
                    success = true
                    verified = true
                    details = "DeviceState(pkg=${state.foregroundPackage}, act=${state.foregroundActivity}, orient=${state.orientation}, rev=${state.revision})"
                    resultCount = 1
                    resultFingerprint = sha256("${state.foregroundPackage}:${state.foregroundActivity}:${state.orientation}:${state.revision}")
                    resultSummary = "DeviceState pkg=${state.foregroundPackage}"
                }

                "get_foreground_app" -> {
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    val activePkg = accessibilityBridge.getForegroundPackage(disp)
                    val state = stateEngine.currentState
                    val pkg = if (activePkg.isNotEmpty()) activePkg else state.foregroundPackage
                    val act = state.foregroundActivity
                    success = true
                    verified = true
                    details = "Foreground: $pkg / $act (display $disp)"
                    resultCount = 1
                    resultFingerprint = sha256("$pkg:$act:$disp")
                    resultSummary = "Foreground: $pkg / $act (display $disp)"
                }

                "get_windows" -> {
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    val windows = accessibilityBridge.getWindowsForDisplay(disp)
                    success = true
                    verified = true
                    details = "Obtenidas ${windows.size} ventanas en display $disp"
                    val winSummary = windows.joinToString(",") { "${it.id}:${it.type}:${it.displayId}" }
                    resultCount = windows.size
                    resultFingerprint = sha256(winSummary)
                    resultSummary = "Obtained ${windows.size} windows"
                }

                "find_ui_nodes" -> {
                    val selObj = args["selector"]
                    val selector = parseSelector(selObj)
                    val disp = (args["displayId"] as? Number)?.toInt() ?: 0
                    val match = args["match"] as? String ?: "all"
                    val nodes = accessibilityBridge.findUiNodes(selector, disp, match)
                    success = true
                    verified = true
                    details = "Encontrados ${nodes.size} nodos coincidentes en display $disp"
                    val count = nodes.size
                    val refs = nodes.joinToString(",") { "${it.nodeId}:${it.text.take(20)}:${it.resourceId}" }
                    resultCount = count
                    resultFingerprint = sha256(refs)
                    resultSummary = "Found $count matching nodes"
                }

                "list_installed_apps" -> {
                    val apps = appManager.listInstalledApps()
                    success = true
                    verified = true
                    details = "Listadas ${apps.size} aplicaciones instaladas"
                    resultCount = apps.size
                    resultFingerprint = sha256(apps.map { it.packageName }.sorted().joinToString(","))
                    resultSummary = "Listed ${apps.size} installed apps"
                }

                "set_brightness" -> {
                    val bVal = (args["value"] as? Number)?.toInt() ?: 128
                    val ok = try {
                        val p = Runtime.getRuntime().exec(arrayOf("settings", "put", "system", "screen_brightness", bVal.toString()))
                        p.waitFor() == 0
                    } catch (t: Throwable) {
                        false
                    }
                    success = ok
                    verified = ok
                    details = if (ok) "Brillo ajustado a $bVal" else "Fallo al ajustar brillo"
                    if (!ok) error = details
                }

                "set_media_volume" -> {
                    val vVal = (args["value"] as? Number)?.toInt() ?: 5
                    val ok = if (context != null) {
                        val am = context.getSystemService(android.media.AudioManager::class.java)
                        if (am != null) {
                            am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, vVal, 0)
                            true
                        } else false
                    } else false
                    success = ok
                    verified = ok
                    details = if (ok) "Volumen multimedia ajustado a $vVal" else "Fallo al ajustar volumen"
                    if (!ok) error = details
                }

                else -> {
                    error = "Herramienta '$tool' no reconocida o no soportada"
                }
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            success = false
            error = "Excepción ejecutando $tool: ${t.message}"
        }

        val elapsed = (System.nanoTime() - t0) / 1_000_000.0
        return TaskStepResult(
            stepIndex = index,
            tool = tool,
            success = success,
            verified = verified,
            details = details,
            elapsedMs = elapsed,
            error = error,
            resultFingerprint = resultFingerprint,
            resultCount = resultCount,
            resultSummary = resultSummary
        )
    }

    private fun sha256(input: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun parseSelector(obj: Any?): SemanticSelector {
        return when (obj) {
            is Map<*, *> -> {
                @Suppress("UNCHECKED_CAST")
                SemanticSelector.fromMap(obj as Map<String, Any?>)
            }
            is String -> SemanticSelector.fromString(obj)
            else -> SemanticSelector()
        }
    }
}
