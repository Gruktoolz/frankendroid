package com.tunnel.turbo.agent

import com.tunnel.turbo.core.NativeTunnelCore

/**
 * AdaptivePlanner compatibility facade.
 * Single canonical execution authority is owned by [AgentSession].
 * This class is preserved for backwards compatibility with existing callers and tests.
 */
class AdaptivePlanner(
    val core: NativeTunnelCore,
    val worldModel: WorldModel,
    val skillMemory: SkillMemory,
    val reasoningProvider: ReasoningProvider
) {

    suspend fun executeGoal(goal: Goal, displayId: Int = 0): AgentTaskResult {
        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = worldModel,
            skillMemory = skillMemory,
            reasoningProvider = reasoningProvider,
            displayId = displayId
        )
        return session.execute()
    }
}
