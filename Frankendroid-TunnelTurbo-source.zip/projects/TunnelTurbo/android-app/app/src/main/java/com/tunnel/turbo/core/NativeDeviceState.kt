package com.tunnel.turbo.core

import android.content.res.Configuration

data class NativeDeviceState(
    val deviceReady: Boolean = true,
    val foregroundPackage: String = "",
    val foregroundActivity: String = "",
    val displayId: Int = 0,
    val screenInteractive: Boolean = true,
    val orientation: Int = Configuration.ORIENTATION_PORTRAIT,
    val revision: Long = 0L,
    val timestamp: Long = System.currentTimeMillis()
)
