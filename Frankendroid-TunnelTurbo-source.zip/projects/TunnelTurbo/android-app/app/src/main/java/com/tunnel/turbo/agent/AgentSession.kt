package com.tunnel.turbo.agent

import com.tunnel.turbo.capability.Capability
import com.tunnel.turbo.capability.CapabilityCategory
import com.tunnel.turbo.capability.RiskLevel
import com.tunnel.turbo.core.NativeTunnelCore
import com.tunnel.turbo.model.TaskPlan
import com.tunnel.turbo.model.ToolStep
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class SessionEventType {
    SESSION_STARTED,
    OBSERVATION_CAPTURED,
    PROVIDER_REQUESTED,
    PROVIDER_DECISION,
    ACTION_STARTED,
    ACTION_COMPLETED,
    VERIFICATION,
    PROGRESS_DETECTED,
    OPERATIONAL_PROGRESS,
    INFORMATION_PROGRESS,
    PROGRESS_UNKNOWN,
    NO_PROGRESS,
    STUCK_DETECTED,
    PROVIDER_FAILOVER,
    ASK_USER,
    INVESTIGATE,
    SESSION_COMPLETED,
    SESSION_FAILED,
    SESSION_CANCELLED
}

data class SessionEvent(
    val eventId: String = "evt_${UUID.randomUUID().toString().take(8)}",
    val sessionId: String,
    val goalId: String,
    val type: SessionEventType,
    val timestamp: Long = System.currentTimeMillis(),
    val snapshotRevision: Long? = null,
    val providerCallId: String? = null,
    val actionId: String? = null,
    val capabilityId: String? = null,
    val displayId: Int? = null,
    val foregroundPackage: String? = null,
    val foregroundActivity: String? = null,
    val summary: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("eventId", eventId)
        put("sessionId", sessionId)
        put("goalId", goalId)
        put("type", type.name)
        put("timestamp", timestamp)
        if (snapshotRevision != null) put("snapshotRevision", snapshotRevision)
        if (providerCallId != null) put("providerCallId", providerCallId)
        if (actionId != null) put("actionId", actionId)
        if (capabilityId != null) put("capabilityId", capabilityId)
        if (displayId != null) put("displayId", displayId)
        if (foregroundPackage != null) put("foregroundPackage", foregroundPackage)
        if (foregroundActivity != null) put("foregroundActivity", foregroundActivity)
        put("summary", summary)
    }
}

data class ActionResult(
    val actionId: String = "act_${UUID.randomUUID().toString().take(8)}",
    val goalId: String,
    val sessionId: String,
    val capabilityId: String,
    val arguments: Map<String, Any?> = emptyMap(),
    val sourceDecisionId: String? = null,
    val providerCallId: String? = null,
    val snapshotRevisionBefore: Long = 0L,
    val startedAt: Long = System.currentTimeMillis(),
    val completedAt: Long = System.currentTimeMillis(),
    val executorSuccess: Boolean = false,
    val stateChanged: Boolean = false,
    val finalStateChanged: Boolean = stateChanged,
    val stateChangeObservedImmediately: Boolean = false,
    val stateChangeObservedDuringSettle: Boolean = false,
    val settleWaitMs: Long = 0L,
    val isObservational: Boolean = false,
    val resultFingerprint: String? = null,
    val resultCount: Int? = null,
    val resultSummary: String? = null,
    val errorClass: String? = null,
    val errorMessage: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("actionId", actionId)
        put("goalId", goalId)
        put("sessionId", sessionId)
        put("capabilityId", capabilityId)
        val aObj = JSONObject()
        arguments.forEach { (k, v) -> aObj.put(k, v) }
        put("arguments", aObj)
        if (sourceDecisionId != null) put("sourceDecisionId", sourceDecisionId)
        if (providerCallId != null) put("providerCallId", providerCallId)
        put("snapshotRevisionBefore", snapshotRevisionBefore)
        put("startedAt", startedAt)
        put("completedAt", completedAt)
        put("executorSuccess", executorSuccess)
        put("stateChanged", finalStateChanged)
        put("finalStateChanged", finalStateChanged)
        put("stateChangeObservedImmediately", stateChangeObservedImmediately)
        put("stateChangeObservedDuringSettle", stateChangeObservedDuringSettle)
        put("settleWaitMs", settleWaitMs)
        put("isObservational", isObservational)
        if (resultFingerprint != null) put("resultFingerprint", resultFingerprint)
        if (resultCount != null) put("resultCount", resultCount)
        if (resultSummary != null) put("resultSummary", resultSummary)
        if (errorClass != null) put("errorClass", errorClass)
        if (errorMessage != null) put("errorMessage", errorMessage)
    }
}

enum class ProgressState {
    OPERATIONAL_PROGRESS,
    INFORMATION_PROGRESS,
    NO_PROGRESS,
    UNKNOWN;

    companion object {
        val PROGRESS = OPERATIONAL_PROGRESS
    }
}

data class ProgressEvaluation(
    val state: ProgressState,
    val reason: String,
    val evidenceDelta: String = "",
    val resultFingerprint: String? = null
)

class ProgressDetector {
    private val observationHistory = mutableMapOf<String, String>()

    fun reset() {
        observationHistory.clear()
    }

    fun evaluate(
        before: WorldSnapshot?,
        after: WorldSnapshot,
        actionResult: ActionResult?,
        goal: Goal
    ): ProgressEvaluation {
        if (before == null) return ProgressEvaluation(ProgressState.UNKNOWN, "Initial observation")
        if (actionResult != null && !actionResult.executorSuccess) {
            return ProgressEvaluation(
                ProgressState.NO_PROGRESS,
                "Action execution failed: ${actionResult.errorMessage ?: actionResult.errorClass ?: "unknown"}"
            )
        }

        // Observational capability progress evaluation
        if (actionResult?.isObservational == true) {
            val reqKey = "${actionResult.capabilityId}:${actionResult.arguments}"
            val currentFp = actionResult.resultFingerprint

            if (currentFp == null) {
                return ProgressEvaluation(
                    ProgressState.NO_PROGRESS,
                    "Observation capability '${actionResult.capabilityId}' produced no data"
                )
            }

            // For find_ui_nodes: must find matching nodes
            if (actionResult.capabilityId == "find_ui_nodes" && (actionResult.resultCount ?: 0) == 0) {
                return ProgressEvaluation(
                    ProgressState.NO_PROGRESS,
                    "find_ui_nodes returned 0 matching nodes"
                )
            }

            val lastFp = observationHistory[reqKey]
            return if (lastFp == null) {
                observationHistory[reqKey] = currentFp
                ProgressEvaluation(
                    ProgressState.INFORMATION_PROGRESS,
                    "Observation '${actionResult.capabilityId}' yielded initial information (${actionResult.resultSummary ?: currentFp})",
                    evidenceDelta = currentFp,
                    resultFingerprint = currentFp
                )
            } else if (lastFp != currentFp) {
                observationHistory[reqKey] = currentFp
                ProgressEvaluation(
                    ProgressState.INFORMATION_PROGRESS,
                    "Observation '${actionResult.capabilityId}' yielded new information (fingerprint delta: $lastFp -> $currentFp)",
                    evidenceDelta = currentFp,
                    resultFingerprint = currentFp
                )
            } else {
                ProgressEvaluation(
                    ProgressState.NO_PROGRESS,
                    "Repeated observation '${actionResult.capabilityId}' with identical arguments produced unchanged result fingerprint ($currentFp)",
                    resultFingerprint = currentFp
                )
            }
        }

        // State-changing action progress evaluation
        // 1. Foreground Package or Activity changed
        if (before.foregroundPackage != after.foregroundPackage && after.foregroundPackage.isNotBlank()) {
            return ProgressEvaluation(
                ProgressState.OPERATIONAL_PROGRESS,
                "Foreground package changed from '${before.foregroundPackage}' to '${after.foregroundPackage}'"
            )
        }
        if (before.foregroundActivity != after.foregroundActivity && after.foregroundActivity.isNotBlank()) {
            return ProgressEvaluation(
                ProgressState.OPERATIONAL_PROGRESS,
                "Foreground activity changed to '${after.foregroundActivity}'"
            )
        }

        // 2. Visible UI Text changed
        val textBefore = before.reducedObservation.informativeText.trim()
        val textAfter = after.reducedObservation.informativeText.trim()
        if (textBefore != textAfter && textAfter.isNotBlank()) {
            return ProgressEvaluation(
                ProgressState.OPERATIONAL_PROGRESS,
                "Visible UI content updated"
            )
        }

        // 3. Goal entity presence delta
        val targetApp = goal.entities.firstOrNull { it.type == "app" }?.value
        if (targetApp != null) {
            val wasInTarget = before.foregroundPackage.contains(targetApp, ignoreCase = true)
            val nowInTarget = after.foregroundPackage.contains(targetApp, ignoreCase = true)
            if (!wasInTarget && nowInTarget) {
                return ProgressEvaluation(
                    ProgressState.OPERATIONAL_PROGRESS,
                    "Target application '$targetApp' reached in foreground"
                )
            }
        }

        // 4. State changed flag from action executor (immediate or during settle)
        if (actionResult?.finalStateChanged == true) {
            val settleNote = if (actionResult.stateChangeObservedDuringSettle) " (observed during settle ${actionResult.settleWaitMs}ms)" else ""
            return ProgressEvaluation(
                ProgressState.OPERATIONAL_PROGRESS,
                "Action caused verified state change in system$settleNote"
            )
        }

        return ProgressEvaluation(ProgressState.NO_PROGRESS, "UI and system state remained unchanged")
    }
}

class StuckDetector(
    val maxNoProgressCycles: Int = 2,
    val maxEquivalentCycles: Int = 3
) {
    var consecutiveNoProgressCount = 0
        private set
    private val actionHistory = mutableListOf<String>()
    private val snapshotTextHistory = mutableListOf<String>()

    fun recordCycle(
        progress: ProgressEvaluation,
        capabilityId: String?,
        snapshot: WorldSnapshot
    ): Boolean {
        when (progress.state) {
            ProgressState.NO_PROGRESS -> {
                consecutiveNoProgressCount++
            }
            ProgressState.OPERATIONAL_PROGRESS,
            ProgressState.INFORMATION_PROGRESS -> {
                consecutiveNoProgressCount = 0
            }
            ProgressState.UNKNOWN -> {
                // Do not increment stuck counter
            }
        }

        if (capabilityId != null) actionHistory.add(capabilityId)
        snapshotTextHistory.add(snapshot.reducedObservation.informativeText.take(120))

        // UI oscillation detection (A <-> B <-> A <-> B)
        val size = snapshotTextHistory.size
        val isCycling = size >= 4 &&
                snapshotTextHistory[size - 1] == snapshotTextHistory[size - 3] &&
                snapshotTextHistory[size - 2] == snapshotTextHistory[size - 4]

        return consecutiveNoProgressCount >= maxNoProgressCycles || isCycling
    }

    fun isTerminalStuck(): Boolean = consecutiveNoProgressCount >= maxEquivalentCycles

    fun getStuckReason(): String = when {
        consecutiveNoProgressCount >= maxEquivalentCycles ->
            "Terminal stuck condition: $consecutiveNoProgressCount consecutive cycles without operational progress"
        consecutiveNoProgressCount >= maxNoProgressCycles ->
            "Stuck condition detected: $consecutiveNoProgressCount cycles without progress; adaptive replanning required"
        else -> "UI state oscillation detected between alternate screens"
    }

    fun reset() {
        consecutiveNoProgressCount = 0
        actionHistory.clear()
        snapshotTextHistory.clear()
    }
}

enum class SessionStatus {
    STARTING,
    RUNNING,
    PAUSED_NEEDS_USER,
    COMPLETED,
    FAILED,
    CANCELLED
}

class AgentSession(
    val goal: Goal,
    val core: NativeTunnelCore,
    val worldModel: WorldModel,
    val skillMemory: SkillMemory,
    val reasoningProvider: ReasoningProvider,
    val displayId: Int = 0,
    val budget: AgentBudget = AgentBudget(),
    val sessionId: String = "session_${UUID.randomUUID().toString().take(8)}"
) {
    val verifier = GoalVerifier(context = core.context, accessibilityBridge = core.accessibilityBridge)
    val progressDetector = ProgressDetector()
    val stuckDetector = StuckDetector()

    val events = java.util.concurrent.CopyOnWriteArrayList<SessionEvent>()
    fun snapshotEvents(): List<SessionEvent> = events.toList()

    val recordedSteps = mutableListOf<AgentStep>()
    val recordedActionResults = mutableListOf<ActionResult>()
    val aiReasons = mutableListOf<String>()
    val userClarifications = mutableListOf<String>()

    var effectiveGoal: Goal = goal
        private set

    var currentSnapshot: WorldSnapshot? = null
        private set
    var snapshotRevision: Long = 0L
        private set
    var previousSnapshot: WorldSnapshot? = null
        private set

    var status: SessionStatus = SessionStatus.STARTING
        private set

    var replansCount: Int = 0
        private set
    var skillUsedName: String? = null
        private set
    var selectedCandidateApp: CandidateApp? = null
        private set
    var currentSkillCandidate: SkillCandidate? = null
        private set

    var t0: Long = System.nanoTime()
        internal set

    fun recordEvent(
        type: SessionEventType,
        summary: String,
        actionId: String? = null,
        capabilityId: String? = null,
        providerCallId: String? = null,
        displayId: Int? = null,
        foregroundPackage: String? = null,
        foregroundActivity: String? = null
    ) {
        val evt = SessionEvent(
            sessionId = sessionId,
            goalId = effectiveGoal.goalId,
            type = type,
            timestamp = System.currentTimeMillis(),
            snapshotRevision = snapshotRevision,
            providerCallId = providerCallId,
            actionId = actionId,
            capabilityId = capabilityId,
            displayId = displayId,
            foregroundPackage = foregroundPackage,
            foregroundActivity = foregroundActivity,
            summary = summary
        )
        events.add(evt)
    }

    suspend fun observeFreshState(): WorldSnapshot {
        previousSnapshot = currentSnapshot
        val fresh = worldModel.createSnapshot(effectiveGoal, displayId)
        currentSnapshot = fresh
        snapshotRevision = fresh.revision
        budget.observationsCaptured++
        recordEvent(
            type = SessionEventType.OBSERVATION_CAPTURED,
            summary = "Observed fresh WorldSnapshot rev $snapshotRevision for package ${fresh.foregroundPackage}",
            displayId = fresh.displayId,
            foregroundPackage = fresh.foregroundPackage,
            foregroundActivity = fresh.foregroundActivity
        )
        return fresh
    }

    fun verifyGoal(snapshot: WorldSnapshot): GoalVerificationResult {
        val ev = verifier.gatherEvidence(displayId)
        val ver = verifier.verify(effectiveGoal, ev, recordedSteps)
        recordEvent(SessionEventType.VERIFICATION, "GoalVerifier evaluated: satisfied=${ver.satisfied}, outcome=${ver.outcome.name} (${ver.explanation})")
        return ver
    }

    suspend fun execute(): AgentTaskResult {
        t0 = System.nanoTime()
        status = SessionStatus.RUNNING
        recordEvent(SessionEventType.SESSION_STARTED, "AgentSession $sessionId started for goal '${effectiveGoal.originalText}'")

        try {
            return executeInternal()
        } catch (ce: kotlinx.coroutines.CancellationException) {
            status = SessionStatus.CANCELLED
            recordEvent(SessionEventType.SESSION_CANCELLED, "AgentSession $sessionId cancelled")
            throw ce
        }
    }

    private suspend fun executeInternal(): AgentTaskResult {
        // Phase 13B-1.2: Asynchronous Tiny Local Cognitive Engine Shadow Dispatch
        com.tunnel.turbo.local.ShadowCognitiveDispatcher.dispatchShadowAssessmentAsync(
            userMessage = effectiveGoal.originalText,
            activeGoalSummary = effectiveGoal.objective,
            currentForegroundPackage = null
        )

        // 1. Non-operational conversational requests
        if (effectiveGoal.categoryHint == "CONVERSATIONAL_NON_OPERATIONAL") {
            val ev = verifier.gatherEvidence(displayId)
            recordEvent(SessionEventType.SESSION_FAILED, "Goal is non-operational conversational text")
            status = SessionStatus.FAILED
            ProviderCallRepository.recordDecision(DecisionSource.DETERMINISTIC)
            return AgentTaskResult(
                goalId = effectiveGoal.goalId,
                sessionId = sessionId,
                goal = effectiveGoal,
                success = false,
                successType = SuccessType.FAILED,
                failureReason = FailureReason.AMBIGUOUS,
                outcome = GoalOutcome.NOT_UNDERSTOOD,
                message = "No entendí qué acción quieres que haga.",
                steps = emptyList(),
                aiRounds = 0,
                aiRoundReasons = emptyList(),
                replansCount = 0,
                totalElapsedMs = (System.nanoTime() - t0) / 1_000_000.0,
                decisionSource = DecisionSource.DETERMINISTIC,
                goalEvidence = ev
            )
        }

        // 2. Incomplete messaging requests
        if (effectiveGoal.categoryHint == "INCOMPLETE_REQUEST") {
            val ev = verifier.gatherEvidence(displayId)
            recordEvent(SessionEventType.ASK_USER, "Goal is incomplete request requiring recipient or content")
            status = SessionStatus.PAUSED_NEEDS_USER
            ProviderCallRepository.recordDecision(DecisionSource.DETERMINISTIC)
            return AgentTaskResult(
                goalId = effectiveGoal.goalId,
                sessionId = sessionId,
                goal = effectiveGoal,
                success = false,
                successType = SuccessType.FAILED,
                failureReason = FailureReason.USER_INPUT_REQUIRED,
                outcome = GoalOutcome.NEEDS_USER,
                message = "¿A quién y qué quieres enviar?",
                steps = emptyList(),
                aiRounds = 0,
                aiRoundReasons = emptyList(),
                replansCount = 0,
                totalElapsedMs = (System.nanoTime() - t0) / 1_000_000.0,
                decisionSource = DecisionSource.DETERMINISTIC,
                goalEvidence = ev
            )
        }

        return runLoop()
    }

    suspend fun resume(userResponse: String): AgentTaskResult {
        if (status != SessionStatus.PAUSED_NEEDS_USER) {
            throw IllegalStateException("Cannot resume session $sessionId with status $status; must be PAUSED_NEEDS_USER")
        }
        userClarifications.add(userResponse)
        effectiveGoal = effectiveGoal.copy(
            originalText = "${effectiveGoal.originalText} [Aclaración del usuario: $userResponse]"
        )
        recordedSteps.add(
            AgentStep(
                stepId = "clarification_${System.currentTimeMillis()}",
                goalId = goal.goalId,
                stepIndex = recordedSteps.size + 1,
                decisionSource = DecisionSource.USER,
                capability = "user_clarification",
                arguments = mapOf("response" to userResponse),
                executionResult = mapOf("status" to "SUCCESS"),
                observationBefore = "",
                observationAfter = "",
                verification = "User clarification recorded",
                durationMs = 0.0
            )
        )
        recordEvent(SessionEventType.SESSION_STARTED, "AgentSession $sessionId resumed with user clarification: $userResponse")
        status = SessionStatus.RUNNING
        return runLoop()
    }

    private suspend fun runLoop(): AgentTaskResult {
        var goalSatisfied = false
        var failureReason = FailureReason.NONE
        var finalMessage = ""
        var lastDecisionSource = DecisionSource.REAL_PROVIDER
        var lastProviderCallId: String? = null
        var lastProofNonce: String? = null

        // Canonical Closed Loop: OBSERVE -> VERIFY -> MEASURE PROGRESS -> DECIDE -> ACT -> OBSERVE
        while (!budget.isExhausted() && !goalSatisfied && failureReason == FailureReason.NONE) {

            // Step A: OBSERVE fresh state
            val snapshot = observeFreshState()
            if (selectedCandidateApp == null) {
                selectedCandidateApp = snapshot.candidateApps.firstOrNull()
            }

            // Step B: VERIFY goal against fresh observation
            val currentVerification = verifyGoal(snapshot)
            if (currentVerification.satisfied && currentVerification.outcome == GoalOutcome.COMPLETED_VERIFIED) {
                goalSatisfied = true
                finalMessage = currentVerification.explanation
                recordEvent(SessionEventType.SESSION_COMPLETED, "Goal proved complete by GoalVerifier: $finalMessage")
                break
            }

            // Step C: MEASURE PROGRESS & STUCK
            val lastAction = recordedActionResults.lastOrNull()
            val progress = progressDetector.evaluate(previousSnapshot, snapshot, lastAction, effectiveGoal)
            val progressEvt = when (progress.state) {
                ProgressState.OPERATIONAL_PROGRESS -> SessionEventType.OPERATIONAL_PROGRESS
                ProgressState.INFORMATION_PROGRESS -> SessionEventType.INFORMATION_PROGRESS
                ProgressState.UNKNOWN -> SessionEventType.PROGRESS_UNKNOWN
                ProgressState.NO_PROGRESS -> SessionEventType.NO_PROGRESS
            }
            recordEvent(progressEvt, progress.reason)

            // UNKNOWN progress must not increment StuckDetector counters
            if (progress.state != ProgressState.UNKNOWN) {
                val isStuck = stuckDetector.recordCycle(progress, lastAction?.capabilityId, snapshot)
                if (isStuck) {
                    recordEvent(SessionEventType.STUCK_DETECTED, stuckDetector.getStuckReason())
                    if (stuckDetector.isTerminalStuck()) {
                        failureReason = FailureReason.STEP_FAILED
                        finalMessage = stuckDetector.getStuckReason()
                        recordEvent(SessionEventType.SESSION_FAILED, finalMessage)
                        break
                    }
                }
            }

            // Step D: DECIDE next logical action
            // Check Skill Memory if allowed (disabled in strictRealProviderMode)
            val matchedSkill = if (!GeneralAgentRuntime.strictRealProviderMode && recordedSteps.isEmpty()) {
                skillMemory.findMatchingSkill(effectiveGoal)
            } else null

            val decision: NextDecision = if (matchedSkill != null) {
                val (skill, paramMap) = matchedSkill
                skillUsedName = skill.name
                ProviderCallRepository.recordDecision(DecisionSource.SKILL)
                lastDecisionSource = DecisionSource.SKILL
                NextDecision(
                    type = DecisionType.USE_SKILL,
                    skillId = skill.skillId,
                    skillParameters = paramMap,
                    reason = "Reutilizando skill aprendida: ${skill.name} con parámetros $paramMap",
                    decisionSource = DecisionSource.SKILL
                )
            } else {
                val reason = when {
                    stuckDetector.consecutiveNoProgressCount >= stuckDetector.maxNoProgressCycles -> AiRoundReason.PLAN_FAILURE
                    recordedSteps.isEmpty() -> AiRoundReason.INITIAL_PLAN
                    else -> AiRoundReason.UNEXPECTED_STATE
                }
                aiReasons.add(reason.name)
                recordEvent(SessionEventType.PROVIDER_REQUESTED, "Dispatching reasoning request (reason=${reason.name}) at revision $snapshotRevision")
                budget.providerRequestsAttempted++

                val d = reasoningProvider.decideNext(
                    goal = effectiveGoal,
                    snapshot = snapshot,
                    skills = skillMemory.getAllSkills(),
                    capabilities = getAdvertisedCapabilities(),
                    recentSteps = recordedSteps,
                    budget = budget,
                    reason = reason
                )
                lastDecisionSource = d.decisionSource
                lastProviderCallId = d.providerCallId
                lastProofNonce = d.proofNonce
                d
            }

            recordEvent(SessionEventType.PROVIDER_DECISION, "Provider returned ${decision.type.name}: ${decision.reason}", providerCallId = decision.providerCallId)

            // Step E: HANDLE DECISION
            when (decision.type) {
                DecisionType.TASK_COMPLETE -> {
                    // SECTION 15: Explicit evidence provenance - observe fresh state after provider claim
                    val postCompleteSnapshot = observeFreshState()
                    val postCompleteVerification = verifyGoal(postCompleteSnapshot)
                    if (postCompleteVerification.satisfied && postCompleteVerification.outcome == GoalOutcome.COMPLETED_VERIFIED) {
                        goalSatisfied = true
                        finalMessage = postCompleteVerification.explanation
                        recordEvent(SessionEventType.SESSION_COMPLETED, "Goal complete verified by verifier: $finalMessage")
                        break
                    } else {
                        // Verifier rejected completion claim
                        recordEvent(SessionEventType.NO_PROGRESS, "Provider claimed TASK_COMPLETE, but GoalVerifier rejected: ${postCompleteVerification.explanation}")
                        if (budget.isExhausted()) {
                            failureReason = FailureReason.GOAL_NOT_VERIFIABLE
                            finalMessage = postCompleteVerification.explanation
                            break
                        }
                        // Continue closed loop for adaptive replanning
                        replansCount++
                    }
                }

                DecisionType.TASK_FAILED -> {
                    // SECTION 16: Evaluate failure reason
                    failureReason = FailureReason.STEP_FAILED
                    finalMessage = decision.reason.ifBlank { "El agente determinó que no es posible continuar" }
                    recordEvent(SessionEventType.SESSION_FAILED, finalMessage)
                    break
                }

                DecisionType.ASK_USER -> {
                    // SECTION 17: Return NEEDS_USER, preserve session
                    status = SessionStatus.PAUSED_NEEDS_USER
                    failureReason = FailureReason.USER_INPUT_REQUIRED
                    finalMessage = decision.userQuestion ?: "Se requiere aclaración del usuario"
                    recordEvent(SessionEventType.ASK_USER, finalMessage)
                    break
                }

                DecisionType.OBSERVE -> {
                    // Re-observe fresh state next cycle
                    continue
                }

                DecisionType.USE_SKILL -> {
                    val skillId = decision.skillId ?: ""
                    val skill = skillMemory.getSkill(skillId)
                    if (skill != null) {
                        skillUsedName = skill.name
                        val params = decision.skillParameters
                        val instantiatedSteps = skill.steps.map { s ->
                            val substArgs = mutableMapOf<String, Any?>()
                            for ((k, v) in s.arguments) {
                                if (v is String && v.contains("{") && v.contains("}")) {
                                    var replaced: String = v
                                    for ((pk, pv) in params) {
                                        if (pv != null) replaced = replaced.replace("{$pk}", pv.toString())
                                    }
                                    substArgs[k] = replaced
                                } else {
                                    substArgs[k] = v
                                }
                            }
                            ToolStep(tool = s.tool, arguments = substArgs)
                        }

                        // Execute skill steps boundedly
                        var skillOk = true
                        for (step in instantiatedSteps) {
                            if (budget.isExhausted()) { skillOk = false; break }
                            val res = executeSingleCapability(step.tool, step.arguments, DecisionSource.SKILL, decision.providerCallId)
                            if (!res.executorSuccess) { skillOk = false; break }
                        }

                        if (!skillOk) {
                            replansCount++
                        }
                    } else {
                        failureReason = FailureReason.APP_NOT_FOUND
                        finalMessage = "Skill no encontrada en memoria: $skillId"
                        break
                    }
                }

                DecisionType.USE_CAPABILITY -> {
                    // SECTION 4: ONE logical capability per reasoning cycle!
                    val capId = decision.capabilityId ?: ""
                    val capArgs = decision.arguments

                    // SECTION 5: Check ElementRef freshness
                    val rawRef = capArgs["elementRef"] as? String ?: capArgs["targetRef"] as? String
                    if (rawRef != null && isStaleElementRef(rawRef, snapshotRevision)) {
                        recordEvent(SessionEventType.ACTION_COMPLETED, "Rejected STALE_ELEMENT_REF '$rawRef' at revision $snapshotRevision")
                        val actRes = ActionResult(
                            goalId = goal.goalId,
                            sessionId = sessionId,
                            capabilityId = capId,
                            arguments = capArgs,
                            sourceDecisionId = decision.providerCallId,
                            providerCallId = decision.providerCallId,
                            snapshotRevisionBefore = snapshotRevision,
                            startedAt = System.currentTimeMillis(),
                            completedAt = System.currentTimeMillis(),
                            executorSuccess = false,
                            stateChanged = false,
                            errorClass = "STALE_ELEMENT_REF",
                            errorMessage = "ElementRef '$rawRef' does not match snapshot revision $snapshotRevision"
                        )
                        recordedActionResults.add(actRes)
                        replansCount++
                        continue
                    }

                    // Execute single action
                    val actionResult = executeSingleCapability(capId, capArgs, decision.decisionSource, decision.providerCallId)
                    if (!actionResult.executorSuccess) {
                        replansCount++
                    }

                    // If suggestedFollowUpSteps exist, log as hints only (SECTION 4)
                    if (decision.suggestedFollowUpSteps.isNotEmpty()) {
                        recordEvent(SessionEventType.ACTION_COMPLETED, "Noted ${decision.suggestedFollowUpSteps.size} suggested follow-up step hints; deferring to next fresh observation")
                    }
                }
            }
        }

        if (budget.isExhausted() && !goalSatisfied) {
            failureReason = FailureReason.BUDGET_EXCEEDED
            finalMessage = "Límite de presupuesto del agente alcanzado (actions=${budget.actionsExecuted}, providerRounds=${budget.providerRounds})"
            recordEvent(SessionEventType.SESSION_FAILED, finalMessage)
        }

        // Final verification pass
        val finalEvidence = verifier.gatherEvidence(displayId)
        val finalVer = verifier.verify(effectiveGoal, finalEvidence, recordedSteps)

        val finalOutcome: GoalOutcome = when {
            goalSatisfied && finalVer.outcome == GoalOutcome.COMPLETED_VERIFIED -> GoalOutcome.COMPLETED_VERIFIED
            finalVer.outcome == GoalOutcome.PARTIAL -> GoalOutcome.PARTIAL
            failureReason == FailureReason.USER_INPUT_REQUIRED -> GoalOutcome.NEEDS_USER
            failureReason == FailureReason.AMBIGUOUS -> GoalOutcome.NOT_UNDERSTOOD
            else -> finalVer.outcome
        }

        val successType = when (finalOutcome) {
            GoalOutcome.COMPLETED_VERIFIED -> SuccessType.SUCCESS_VERIFIED
            GoalOutcome.COMPLETED_UNVERIFIED -> SuccessType.SUCCESS_UNVERIFIED
            GoalOutcome.PARTIAL -> SuccessType.PARTIAL_SUCCESS
            else -> SuccessType.FAILED
        }

        status = if (goalSatisfied) SessionStatus.COMPLETED else if (finalOutcome == GoalOutcome.NEEDS_USER) SessionStatus.PAUSED_NEEDS_USER else SessionStatus.FAILED

        // Dynamic skill candidate synthesis upon verified goal success with 2+ steps
        if (goalSatisfied && recordedSteps.size >= 2) {
            val candidate = synthesizeSkillCandidate(effectiveGoal, recordedSteps.map { ToolStep(it.capability, it.arguments) }, selectedCandidateApp)
            if (candidate != null) {
                currentSkillCandidate = candidate
                skillMemory.recordSkillCandidate(candidate)
                val stringParams = effectiveGoal.entities.associate { it.type to it.value }
                skillMemory.recordSkillSuccess(candidate.suggestedSkill.skillId, stringParams, effectiveGoal.originalText)
            }
            if (selectedCandidateApp != null) {
                worldModel.recordAppSuccess(effectiveGoal.categoryHint ?: "general", selectedCandidateApp!!.packageName)
            }
        }

        val diagnostic = if (!goalSatisfied && finalOutcome != GoalOutcome.COMPLETED_VERIFIED) {
            val dispState = core.stateEngine.getStateForDisplay(displayId)
            val relevantNodes = core.accessibilityBridge.getUiNodes(displayId).take(15)
            val pHealth = reasoningProvider.health()
            com.tunnel.turbo.devtools.FailureDiagnostic(
                failureType = failureReason.name,
                failedStepIndex = recordedSteps.size,
                failedTool = recordedSteps.lastOrNull()?.capability ?: "none",
                expectedCondition = effectiveGoal.desiredState,
                actualCondition = finalMessage.ifBlank { finalVer.explanation },
                foregroundPackage = dispState.foregroundPackage,
                foregroundActivity = dispState.foregroundActivity,
                displayId = displayId,
                providerState = pHealth.state.name,
                relevantNodes = relevantNodes
            )
        } else null

        val totalElapsed = (System.nanoTime() - t0) / 1_000_000.0

        return AgentTaskResult(
            goalId = effectiveGoal.goalId,
            sessionId = sessionId,
            goal = effectiveGoal,
            success = goalSatisfied,
            successType = successType,
            failureReason = failureReason,
            outcome = finalOutcome,
            message = finalMessage.ifBlank { finalVer.explanation },
            steps = recordedSteps,
            aiRounds = budget.providerRounds,
            aiRoundReasons = aiReasons,
            replansCount = replansCount,
            skillUsed = skillUsedName,
            candidateAppSelected = selectedCandidateApp,
            skillCandidateCreated = currentSkillCandidate,
            totalElapsedMs = totalElapsed,
            hardcodedShortcutsUsed = 0,
            diagnostic = diagnostic,
            budget = budget,
            decisionSource = lastDecisionSource,
            providerCallId = lastProviderCallId,
            proofNonce = lastProofNonce,
            goalEvidence = finalEvidence
        )
    }

    private suspend fun executeSingleCapability(
        capabilityId: String,
        arguments: Map<String, Any?>,
        source: DecisionSource,
        providerCallId: String?
    ): ActionResult {
        val t0 = System.currentTimeMillis()
        val textBefore = core.accessibilityBridge.getVisibleText(displayId).take(150)
        val fgBefore = core.accessibilityBridge.getForegroundPackage(displayId)
        val actBefore = core.accessibilityBridge.getForegroundActivity(displayId)
        recordEvent(SessionEventType.ACTION_STARTED, "Starting execution of capability '$capabilityId'", capabilityId = capabilityId, providerCallId = providerCallId)

        val nonNullArgs = mutableMapOf<String, Any>()
        arguments.forEach { (k, v) -> if (v != null) nonNullArgs[k] = v }
        val step = ToolStep(tool = capabilityId, arguments = nonNullArgs)
        val plan = TaskPlan(steps = listOf(step))

        val execRes = core.taskExecutor.executeTask(plan)
        val elapsed = System.currentTimeMillis() - t0
        val textAfter = core.accessibilityBridge.getVisibleText(displayId).take(150)
        val fgAfter = core.accessibilityBridge.getForegroundPackage(displayId)
        val actAfter = core.accessibilityBridge.getForegroundActivity(displayId)

        val capMeta = core.capabilityRegistry.getCapability(capabilityId)
        val isObservational = capMeta?.category == CapabilityCategory.OBSERVATION ||
                capMeta?.riskLevel == RiskLevel.READ_ONLY ||
                capabilityId.startsWith("get_") || capabilityId.startsWith("find_") ||
                capabilityId == "resolve_app" || capabilityId == "list_installed_apps"

        if (isObservational) {
            budget.observationToolCalls++
        } else {
            budget.stateChangingActionsExecuted++
        }

        val textImmediate = core.accessibilityBridge.getVisibleText(displayId).take(150)
        val fgImmediate = core.accessibilityBridge.getForegroundPackage(displayId)
        val actImmediate = core.accessibilityBridge.getForegroundActivity(displayId)

        val immediateChanged = (textBefore != textImmediate) ||
                (fgBefore.isNotEmpty() && fgImmediate.isNotEmpty() && fgBefore != fgImmediate) ||
                (actBefore.isNotEmpty() && actImmediate.isNotEmpty() && actBefore != actImmediate)

        var settleWaitMs = 0L
        var stateChangeDuringSettle = false

        if (!isObservational && execRes.success && !immediateChanged) {
            val settleStart = System.currentTimeMillis()
            val maxSettleMs = 1200L
            val pollIntervalMs = 150L

            while ((System.currentTimeMillis() - settleStart) < maxSettleMs) {
                kotlinx.coroutines.delay(pollIntervalMs)
                val textCur = core.accessibilityBridge.getVisibleText(displayId).take(150)
                val fgCur = core.accessibilityBridge.getForegroundPackage(displayId)
                val actCur = core.accessibilityBridge.getForegroundActivity(displayId)

                val changed = (textBefore != textCur) ||
                        (fgBefore.isNotEmpty() && fgCur.isNotEmpty() && fgBefore != fgCur) ||
                        (actBefore.isNotEmpty() && actCur.isNotEmpty() && actBefore != actCur)

                if (changed) {
                    stateChangeDuringSettle = true
                    break
                }
            }
            settleWaitMs = System.currentTimeMillis() - settleStart
        }

        val finalStateChanged = if (isObservational) false else (immediateChanged || stateChangeDuringSettle)

        val actionRes = ActionResult(
            goalId = effectiveGoal.goalId,
            sessionId = sessionId,
            capabilityId = capabilityId,
            arguments = arguments,
            providerCallId = providerCallId,
            snapshotRevisionBefore = snapshotRevision,
            startedAt = t0,
            completedAt = System.currentTimeMillis(),
            executorSuccess = execRes.success,
            stateChanged = finalStateChanged,
            finalStateChanged = finalStateChanged,
            stateChangeObservedImmediately = if (isObservational) false else immediateChanged,
            stateChangeObservedDuringSettle = stateChangeDuringSettle,
            settleWaitMs = settleWaitMs,
            isObservational = isObservational,
            resultFingerprint = execRes.resultFingerprint,
            resultCount = execRes.resultCount,
            resultSummary = execRes.resultSummary,
            errorClass = if (!execRes.success) "ACTION_EXECUTION_FAILURE" else null,
            errorMessage = execRes.error
        )
        recordedActionResults.add(actionRes)

        val stepRecord = AgentStep(
            stepId = "step_${UUID.randomUUID().toString().substring(0, 6)}",
            goalId = effectiveGoal.goalId,
            stepIndex = recordedSteps.size + 1,
            decisionSource = source,
            capability = capabilityId,
            arguments = arguments,
            executionResult = mapOf(
                "success" to execRes.success,
                "executedSteps" to execRes.executedSteps,
                "error" to (execRes.error ?: ""),
                "isObservational" to isObservational,
                "resultFingerprint" to (execRes.resultFingerprint ?: ""),
                "resultCount" to (execRes.resultCount ?: 0),
                "resultSummary" to (execRes.resultSummary ?: ""),
                "settleWaitMs" to settleWaitMs,
                "stateChangeObservedDuringSettle" to stateChangeDuringSettle
            ),
            observationBefore = textBefore,
            observationAfter = if (stateChangeDuringSettle) core.accessibilityBridge.getVisibleText(displayId).take(150) else textImmediate,
            verification = if (execRes.success) "SUCCESS" else (execRes.error ?: "FAILED"),
            durationMs = elapsed.toDouble(),
            providerCallId = providerCallId
        )
        recordedSteps.add(stepRecord)

        val settleInfo = if (stateChangeDuringSettle) " settleWaitMs=${settleWaitMs}ms (async state change detected)" else ""
        recordEvent(
            SessionEventType.ACTION_COMPLETED,
            "Completed capability '$capabilityId' success=${execRes.success} stateChanged=$finalStateChanged (immediate=$immediateChanged, settle=$stateChangeDuringSettle)$settleInfo in ${elapsed}ms",
            actionId = actionRes.actionId,
            capabilityId = capabilityId,
            providerCallId = providerCallId
        )

        return actionRes
    }

    private fun isStaleElementRef(ref: String, currentRevision: Long): Boolean {
        val parts = ref.split(":")
        if (parts.size >= 4) {
            val refRevision = parts[2].toLongOrNull()
            if (refRevision != null && refRevision != currentRevision) {
                return true
            }
        }
        return false
    }

    private fun synthesizeSkillCandidate(
        goal: Goal,
        steps: List<ToolStep>,
        app: CandidateApp?
    ): SkillCandidate? {
        val artistEntity = goal.entities.firstOrNull { it.type == "artist" }
        if (artistEntity != null) {
            val generalizedSteps = steps.map { s ->
                val gArgs = mutableMapOf<String, Any?>()
                s.arguments.forEach { (k, v) ->
                    if (v is String && v.equals(artistEntity.value, ignoreCase = true)) {
                        gArgs[k] = "{artist}"
                    } else {
                        gArgs[k] = v
                    }
                }
                ToolStep(tool = s.tool, arguments = gArgs)
            }

            val skill = DynamicSkill(
                skillId = "skill_play_artist",
                name = "play_artist",
                description = "Reproduce música de un artista específico en ${app?.label ?: "reproductor"}",
                goalPattern = "reproducir música de {artist}",
                parameters = listOf(SkillParameter(name = "artist", type = "string", description = "Nombre del artista")),
                preconditions = listOf("app_installed"),
                steps = generalizedSteps,
                successConditions = listOf("music_playing"),
                failureConditions = listOf("artist_not_found"),
                confidence = 0.6,
                state = SkillState.PROPOSED,
                examplesSeen = mutableListOf(goal.originalText),
                parameterVariations = mutableListOf(mapOf("artist" to artistEntity.value))
            )

            return SkillCandidate(
                candidateId = "cand_play_artist_${System.currentTimeMillis() % 10000}",
                derivedFromGoal = goal.originalText,
                suggestedSkill = skill
            )
        }
        return null
    }

    private fun getAdvertisedCapabilities(): List<Capability> {
        val szReady = core.shizukuBridge?.checkState() == com.tunnel.turbo.shizuku.ShizukuState.READY
        val a11yReady = core.accessibilityBridge.isEnabled()
        return core.capabilityRegistry.getAvailableCapabilities(szReady, a11yReady)
    }
}
