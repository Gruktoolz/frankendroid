package com.tunnel.turbo.shizuku

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

enum class ShizukuState {
    NOT_INSTALLED,
    NOT_RUNNING,
    PERMISSION_REQUIRED,
    READY,
    ERROR
}

class ShizukuBridge(private val context: Context) {

    var onStateChanged: ((ShizukuState) -> Unit)? = null

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        onStateChanged?.invoke(checkState())
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        onStateChanged?.invoke(checkState())
    }

    private val requestPermissionResultListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        onStateChanged?.invoke(checkState())
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
        } catch (t: Throwable) {
            // Shizuku not available
        }
    }

    fun isInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (e: Exception) {
            android.util.Log.w("ShizukuBridge", "isInstalled failed: ${e.message}")
            false
        }
    }

    fun isRunning(): Boolean {
        return try {
            val ping = Shizuku.pingBinder()
            android.util.Log.d("ShizukuBridge", "pingBinder returned: $ping")
            ping
        } catch (t: Throwable) {
            android.util.Log.w("ShizukuBridge", "pingBinder threw: ${t.message}")
            false
        }
    }

    fun hasPermission(): Boolean {
        return try {
            if (!isRunning()) return false
            if (Shizuku.isPreV11()) false
            else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (t: Throwable) {
            android.util.Log.w("ShizukuBridge", "hasPermission threw: ${t.message}")
            false
        }
    }

    fun requestPermission(requestCode: Int = 1001) {
        try {
            if (isRunning() && !hasPermission()) {
                Shizuku.requestPermission(requestCode)
            }
        } catch (t: Throwable) {
            android.util.Log.w("ShizukuBridge", "requestPermission threw: ${t.message}")
        }
    }

    fun checkState(): ShizukuState {
        val installed = isInstalled()
        val running = isRunning()
        val permitted = hasPermission()
        android.util.Log.i("ShizukuBridge", "checkState: installed=$installed, running=$running, permitted=$permitted")
        if (!installed) return ShizukuState.NOT_INSTALLED
        if (!running) return ShizukuState.NOT_RUNNING
        if (!permitted) return ShizukuState.PERMISSION_REQUIRED
        return ShizukuState.READY
    }

    fun isReady(): Boolean = checkState() == ShizukuState.READY

    fun takeScreenshotBitmap(displayId: Int = 0): android.graphics.Bitmap? {
        if (!isReady()) return null
        return try {
            val cmd = if (displayId != 0) "screencap -d $displayId -p" else "screencap -p"
            val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            m.isAccessible = true
            val proc = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as java.lang.Process
            val bytes = proc.inputStream.readBytes()
            proc.waitFor()
            if (bytes.isNotEmpty()) {
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } else null
        } catch (t: Throwable) {
            android.util.Log.e("ShizukuBridge", "takeScreenshotBitmap failed: ${t.message}")
            null
        }
    }


    fun destroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
        } catch (ignored: Throwable) {}
    }
}

