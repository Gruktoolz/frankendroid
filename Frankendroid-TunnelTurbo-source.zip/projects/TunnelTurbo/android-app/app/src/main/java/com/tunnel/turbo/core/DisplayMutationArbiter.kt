package com.tunnel.turbo.core

import kotlinx.coroutines.Job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.coroutineContext

/**
 * MutationLeaseElement: Tracks active mutation leases held by the current coroutine context
 * to allow safe, non-deadlocking reentrancy when composed subsystems (e.g. AgentSession -> NativeTaskExecutor -> NativeActionEngine)
 * execute under the same authoritative lease.
 */
class MutationLeaseElement(
    val activeLeases: Map<Int, MutationLease>
) : CoroutineContext.Element {
    companion object Key : CoroutineContext.Key<MutationLeaseElement>
    override val key: CoroutineContext.Key<*> get() = Key
}

/**
 * MutationLease represents the authoritative right to execute mutating operations
 * on a specific Android display (Phase 13B-1.2a.3, Section 9-10).
 */
data class MutationLease(
    val displayId: Int,
    val ownerSessionId: String? = null,
    val ownerGoalId: String? = null,
    val requestId: String? = null,
    val generation: Long,
    val acquiredAtMs: Long = System.currentTimeMillis()
) {
    internal val leaseMutex = Mutex()
    @Volatile internal var activeJob: Job? = null

    fun toJson(): JSONObject = JSONObject().apply {
        put("displayId", displayId)
        if (ownerSessionId != null) put("ownerSessionId", ownerSessionId)
        if (ownerGoalId != null) put("ownerGoalId", ownerGoalId)
        if (requestId != null) put("requestId", requestId)
        put("generation", generation)
        put("acquiredAtMs", acquiredAtMs)
    }
}

/**
 * DisplayMutationArbiter: Centrally serializes mutating operations PER DISPLAY.
 *
 * Invariants:
 * - Display 0 has at most ONE active mutating owner across direct and agentic request paths.
 * - Leases are strictly display-scoped; independent displays (e.g. D0 and D1) can execute concurrently.
 * - Non-mutating (read-only) observations do not require a mutation lease and proceed concurrently.
 * - Leases are released on completion, exceptions, and coroutine cancellation via structured concurrency.
 * - Safe coroutine-context reentrancy prevents deadlocks when a lease-holding coroutine invokes nested mutating operations.
 * - Parallel child coroutines inheriting the lease context cannot execute mutating operations concurrently (Section 28).
 */
class DisplayMutationArbiter {
    private val displayMutexes = ConcurrentHashMap<Int, Mutex>()
    private val activeLeases = ConcurrentHashMap<Int, MutationLease>()
    private val generationCounter = AtomicLong(0)

    fun getActiveLease(displayId: Int): MutationLease? = activeLeases[displayId]

    fun isDisplayLocked(displayId: Int): Boolean = activeLeases.containsKey(displayId)

    suspend fun <T> withMutationLease(
        displayId: Int,
        ownerSessionId: String? = null,
        ownerGoalId: String? = null,
        requestId: String? = null,
        block: suspend (MutationLease) -> T
    ): T {
        val currentJob = coroutineContext[Job]
        val currentElement = coroutineContext[MutationLeaseElement]
        val existingLease = currentElement?.activeLeases?.get(displayId)
        if (existingLease != null) {
            // Sequential reentrancy on the exact same coroutine/Job that currently holds authority
            if (existingLease.activeJob != null && existingLease.activeJob === currentJob) {
                return block(existingLease)
            }
            // Child or concurrent coroutine inheriting the lease context:
            // Must serialize through the lease's internal mutex to prevent parallel execution
            return existingLease.leaseMutex.withLock {
                val prevJob = existingLease.activeJob
                existingLease.activeJob = currentJob
                try {
                    block(existingLease)
                } finally {
                    existingLease.activeJob = prevJob
                }
            }
        }

        val mutex = displayMutexes.computeIfAbsent(displayId) { Mutex() }
        mutex.lock()
        val lease = MutationLease(
            displayId = displayId,
            ownerSessionId = ownerSessionId,
            ownerGoalId = ownerGoalId,
            requestId = requestId,
            generation = generationCounter.incrementAndGet()
        )
        activeLeases[displayId] = lease
        try {
            val updatedMap = (currentElement?.activeLeases ?: emptyMap()) + (displayId to lease)
            return withContext(MutationLeaseElement(updatedMap)) {
                val prevJob = lease.activeJob
                lease.activeJob = coroutineContext[Job]
                try {
                    block(lease)
                } finally {
                    lease.activeJob = prevJob
                }
            }
        } finally {
            activeLeases.remove(displayId, lease)
            mutex.unlock()
        }
    }
}
