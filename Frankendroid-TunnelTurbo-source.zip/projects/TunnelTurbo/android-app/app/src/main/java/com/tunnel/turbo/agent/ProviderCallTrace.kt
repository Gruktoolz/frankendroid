package com.tunnel.turbo.agent

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

data class ProviderCallTrace(
    val providerCallId: String,
    val goalId: String,
    val requestId: String,
    val provider: String,
    val providerPackage: String,
    val workerDisplayId: Int,
    val reason: String,
    val startedAt: Long,
    val promptPrepared: Boolean,
    val promptInjected: Boolean,
    val promptHash: String,
    val conversationTurnBefore: Int,
    val conversationTurnAfter: Int,
    val responseDetected: Boolean,
    val responseHash: String,
    val responseLength: Int,
    val decisionProduced: String,
    val completedAt: Long,
    val latencyMs: Double,
    val error: String? = null,
    val proofNonce: String = "",
    val providerPreflightMs: Double = 0.0,
    val providerReadyAtDispatch: Boolean = false,
    val injectionTimestamp: Long? = null,
    val responseTimestamp: Long? = null,
    val failureClass: String = "NONE",
    val proofMatched: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("providerCallId", providerCallId)
        put("goalId", goalId)
        put("requestId", requestId)
        put("provider", provider)
        put("providerPackage", providerPackage)
        put("workerDisplayId", workerDisplayId)
        put("reason", reason)
        put("startedAt", startedAt)
        put("promptPrepared", promptPrepared)
        put("promptInjected", promptInjected)
        put("promptHash", promptHash)
        put("conversationTurnBefore", conversationTurnBefore)
        put("conversationTurnAfter", conversationTurnAfter)
        put("responseDetected", responseDetected)
        put("responseHash", responseHash)
        put("responseLength", responseLength)
        put("decisionProduced", decisionProduced)
        put("completedAt", completedAt)
        put("latencyMs", latencyMs)
        if (error != null) put("error", error)
        put("proofNonce", proofNonce)
        put("providerPreflightMs", providerPreflightMs)
        put("providerReadyAtDispatch", providerReadyAtDispatch)
        if (injectionTimestamp != null) put("injectionTimestamp", injectionTimestamp)
        if (responseTimestamp != null) put("responseTimestamp", responseTimestamp)
        put("failureClass", failureClass)
        put("proofMatched", proofMatched)
    }
}

object ProviderCallRepository {
    private val traces = CopyOnWriteArrayList<ProviderCallTrace>()
    private val decisionCounts = ConcurrentHashMap<DecisionSource, Int>()

    init {
        DecisionSource.values().forEach { decisionCounts[it] = 0 }
    }

    fun recordCall(trace: ProviderCallTrace) {
        traces.add(trace)
    }

    fun recordDecision(source: DecisionSource) {
        decisionCounts.compute(source) { _, current -> (current ?: 0) + 1 }
    }

    fun getAllTraces(): List<ProviderCallTrace> = traces.toList()

    fun getLastTrace(): ProviderCallTrace? = traces.lastOrNull()

    fun getTrace(providerCallId: String): ProviderCallTrace? =
        traces.firstOrNull { it.providerCallId == providerCallId }

    fun getDecisionProvenance(): Map<String, Int> =
        decisionCounts.mapKeys { it.key.name }

    fun clear() {
        traces.clear()
        DecisionSource.values().forEach { decisionCounts[it] = 0 }
    }
}
