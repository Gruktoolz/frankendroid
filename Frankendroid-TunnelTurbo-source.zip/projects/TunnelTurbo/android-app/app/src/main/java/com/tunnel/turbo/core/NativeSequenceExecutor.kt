package com.tunnel.turbo.core

import com.tunnel.turbo.model.SequencePlan

data class SequenceExecutionResult(
    val success: Boolean,
    val totalSteps: Int,
    val executedSteps: Int,
    val stepResults: List<ActionResult>,
    val totalMs: Double,
    val failedStepIndex: Int? = null,
    val error: String? = null
)

class NativeSequenceExecutor(
    private val actionEngine: NativeActionEngine,
    private val journal: NativeEventJournal? = null
) {
    suspend fun executeSequence(
        sequence: SequencePlan,
        stopOnFailure: Boolean = true
    ): SequenceExecutionResult {
        val t0 = System.nanoTime()
        val steps = sequence.steps
        journal?.recordEvent("sequence_started", mapOf("stepCount" to steps.size))

        val stepResults = mutableListOf<ActionResult>()
        var failedIndex: Int? = null
        var failureError: String? = null

        for (i in steps.indices) {
            val step = steps[i]
            if (i > 0) {
                kotlinx.coroutines.delay(50)
            }
            val result = actionEngine.executeAction(step, verify = true)
            stepResults.add(result)

            journal?.recordEvent(
                "step_completed",
                mapOf("stepIndex" to i, "action" to step.action, "success" to result.success)
            )

            if (!result.success) {
                failedIndex = i
                failureError = "Fallo en paso $i (${step.action}): ${result.details}"
                if (stopOnFailure) {
                    break
                }
            }
        }

        val totalElapsed = (System.nanoTime() - t0) / 1_000_000.0
        val overallSuccess = failedIndex == null

        journal?.recordEvent(
            "sequence_completed",
            mapOf("success" to overallSuccess, "executedSteps" to stepResults.size, "totalMs" to totalElapsed)
        )

        return SequenceExecutionResult(
            success = overallSuccess,
            totalSteps = steps.size,
            executedSteps = stepResults.size,
            stepResults = stepResults,
            totalMs = totalElapsed,
            failedStepIndex = failedIndex,
            error = failureError
        )
    }
}
