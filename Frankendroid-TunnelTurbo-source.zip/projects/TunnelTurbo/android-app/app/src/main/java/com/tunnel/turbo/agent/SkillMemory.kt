package com.tunnel.turbo.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class SkillMemory(private val context: Context? = null) {

    private val skills = ConcurrentHashMap<String, DynamicSkill>()
    private val candidates = ConcurrentHashMap<String, SkillCandidate>()
    private val repairCandidates = ConcurrentHashMap<String, SkillRepairCandidate>()

    private val storageFile: File?
        get() = context?.filesDir?.let { File(it, "skills_memory.json") }

    init {
        loadFromDisk()
    }

    @Synchronized
    fun getAllSkills(): List<DynamicSkill> = skills.values.toList()

    @Synchronized
    fun getSkill(skillId: String): DynamicSkill? = skills[skillId]

    @Synchronized
    fun getAllCandidates(): List<SkillCandidate> = candidates.values.toList()

    @Synchronized
    fun getAllRepairCandidates(): List<SkillRepairCandidate> = repairCandidates.values.toList()

    @Synchronized
    fun saveSkill(skill: DynamicSkill) {
        skills[skill.skillId] = skill
        persistToDisk()
    }

    @Synchronized
    fun removeSkill(skillId: String): Boolean {
        val removed = skills.remove(skillId) != null
        if (removed) persistToDisk()
        return removed
    }

    @Synchronized
    fun recordSkillCandidate(candidate: SkillCandidate) {
        candidates[candidate.candidateId] = candidate
        // Also register as proposed skill in memory
        skills[candidate.suggestedSkill.skillId] = candidate.suggestedSkill
        persistToDisk()
    }

    @Synchronized
    fun recordSkillRepair(repair: SkillRepairCandidate) {
        repairCandidates["${repair.skillId}_${repair.timestamp}"] = repair
        val skill = skills[repair.skillId]
        if (skill != null) {
            skill.failureCount++
            skill.confidence = maxOf(0.1, skill.confidence - 0.2)
            if (skill.failureCount >= 3 && skill.state == SkillState.ACTIVE) {
                skill.state = SkillState.VALIDATING
            }
        }
        persistToDisk()
    }

    @Synchronized
    fun recordSkillSuccess(skillId: String, parameterValues: Map<String, String>, exampleText: String) {
        val skill = skills[skillId] ?: return
        skill.successCount++
        skill.lastUsed = System.currentTimeMillis()
        skill.confidence = minOf(1.0, skill.confidence + 0.15)
        if (!skill.examplesSeen.contains(exampleText)) {
            skill.examplesSeen.add(exampleText)
        }
        if (parameterValues.isNotEmpty() && !skill.parameterVariations.contains(parameterValues)) {
            skill.parameterVariations.add(parameterValues)
        }

        // State promotion rules (Section 23)
        // 1st success -> PROPOSED (already)
        // 2nd distinct variation -> VALIDATING
        // 3+ successes with 2+ parameter variations -> ACTIVE
        if (skill.state == SkillState.PROPOSED && skill.parameterVariations.size >= 2) {
            skill.state = SkillState.VALIDATING
        } else if (skill.state == SkillState.VALIDATING && skill.successCount >= 3) {
            skill.state = SkillState.ACTIVE
        }
        persistToDisk()
    }

    @Synchronized
    fun findMatchingSkill(goal: Goal): Pair<DynamicSkill, Map<String, String>>? {
        val lowerGoal = goal.originalText.lowercase()
        for (skill in skills.values) {
            if (skill.state == SkillState.DEPRECATED) continue

            // Check if goalPattern matches or if entities align
            if (skill.goalPattern.isNotBlank()) {
                val patternLower = skill.goalPattern.lowercase()
                // Regex or template matching like "reproducir música de {artist}"
                if (patternLower.contains("{") && patternLower.contains("}")) {
                    val regexPattern = patternLower
                        .replace("{artist}", "(.+)")
                        .replace("{query}", "(.+)")
                    val regex = Regex(regexPattern, RegexOption.IGNORE_CASE)
                    val match = regex.find(lowerGoal)
                    if (match != null && match.groupValues.size > 1) {
                        val paramValue = match.groupValues[1].trim()
                        val paramKey = if (patternLower.contains("{artist}")) "artist" else "query"
                        return Pair(skill, mapOf(paramKey to paramValue))
                    }
                }
            }

            // Entity based matching: if skill is media/music and goal has artist entity
            if (skill.name.contains("artist", ignoreCase = true) || skill.name.contains("music", ignoreCase = true)) {
                val artistEntity = goal.entities.firstOrNull { it.type == "artist" }
                if (artistEntity != null && (lowerGoal.contains("escuchar") || lowerGoal.contains("reproduce") || lowerGoal.contains("pon "))) {
                    return Pair(skill, mapOf("artist" to artistEntity.value))
                }
            }
        }
        return null
    }

    private fun persistToDisk() {
        val file = storageFile ?: return
        try {
            val root = JSONObject()
            val sArr = JSONArray()
            skills.values.forEach { sArr.put(it.toJson()) }
            root.put("skills", sArr)

            val cArr = JSONArray()
            candidates.values.forEach { cArr.put(it.toJson()) }
            root.put("candidates", cArr)

            file.writeText(root.toString(2))
        } catch (t: Throwable) {
            android.util.Log.e("SkillMemory", "Failed to persist skills to disk: ${t.message}")
        }
    }

    private fun loadFromDisk() {
        val file = storageFile ?: return
        if (!file.exists()) return
        try {
            val content = file.readText()
            if (content.isBlank()) return
            val root = JSONObject(content)
            val sArr = root.optJSONArray("skills")
            if (sArr != null) {
                for (i in 0 until sArr.length()) {
                    val o = sArr.optJSONObject(i)
                    if (o != null) {
                        val s = DynamicSkill.fromJson(o)
                        skills[s.skillId] = s
                    }
                }
            }
            val cArr = root.optJSONArray("candidates")
            if (cArr != null) {
                for (i in 0 until cArr.length()) {
                    val o = cArr.optJSONObject(i)
                    if (o != null) {
                        val c = SkillCandidate(
                            candidateId = o.optString("candidateId", ""),
                            derivedFromGoal = o.optString("derivedFromGoal", ""),
                            suggestedSkill = DynamicSkill.fromJson(o.getJSONObject("suggestedSkill")),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis())
                        )
                        candidates[c.candidateId] = c
                    }
                }
            }
        } catch (t: Throwable) {
            android.util.Log.e("SkillMemory", "Failed to load skills from disk: ${t.message}")
        }
    }
}
