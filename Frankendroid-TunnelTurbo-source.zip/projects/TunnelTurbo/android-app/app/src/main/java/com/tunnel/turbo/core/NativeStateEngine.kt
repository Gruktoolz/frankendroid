package com.tunnel.turbo.core

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService

class NativeStateEngine(
    private val context: Context? = null,
    private val journal: NativeEventJournal? = null
) {
    // Static cached properties (query once, safe for Android and JVM unit tests)
    val model: String = try { android.os.Build.MODEL ?: "Generic" } catch (t: Throwable) { "Generic" }
    val apiLevel: Int = try { android.os.Build.VERSION.SDK_INT } catch (t: Throwable) { 35 }
    val manufacturer: String = try { android.os.Build.MANUFACTURER ?: "Generic" } catch (t: Throwable) { "Generic" }

    @Volatile
    var currentState: NativeDeviceState = NativeDeviceState(
        deviceReady = true,
        displayId = 0,
        orientation = context?.resources?.configuration?.orientation ?: Configuration.ORIENTATION_PORTRAIT,
        screenInteractive = isScreenInteractive()
    )
        private set

    @Volatile
    var latestEventState: NativeDeviceState = currentState
        private set

    private val _deviceStateFlow = kotlinx.coroutines.flow.MutableStateFlow(currentState)
    val deviceStateFlow: kotlinx.coroutines.flow.StateFlow<NativeDeviceState> = _deviceStateFlow

    val statesByDisplayId = java.util.concurrent.ConcurrentHashMap<Int, NativeDeviceState>()

    private val accessibilityListener: (AccessibilityEvent) -> Unit = { event ->
        handleAccessibilityEvent(event)
    }

    init {
        statesByDisplayId[0] = currentState
        TunnelTurboAccessibilityService.addEventListener(accessibilityListener)
    }

    fun destroy() {
        TunnelTurboAccessibilityService.removeEventListener(accessibilityListener)
    }

    fun getStateForDisplay(displayId: Int): NativeDeviceState {
        return statesByDisplayId[displayId] ?: NativeDeviceState(
            deviceReady = true,
            displayId = displayId,
            orientation = context?.resources?.configuration?.orientation ?: Configuration.ORIENTATION_PORTRAIT,
            screenInteractive = isScreenInteractive()
        )
    }

    private fun isScreenInteractive(): Boolean {
        return try {
            val pm = context?.getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.isInteractive ?: true
        } catch (t: Throwable) {
            true
        }
    }

    fun handleAccessibilityEvent(event: AccessibilityEvent) {
        val eventType = event.eventType
        val rawPkg = event.packageName?.toString() ?: ""
        val isIme = rawPkg.contains("inputmethod", ignoreCase = true)
        val isSystemUi = rawPkg.contains("systemui", ignoreCase = true)

        if (isSystemUi && (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED)) {
            return
        }

        val disp = if (event.displayId >= 0) event.displayId else 0
        val currentDisplayState = getStateForDisplay(disp)

        val isWindowTransition = eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            (!isSystemUi && eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) ||
            (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && rawPkg.isNotEmpty() && !isIme && !isSystemUi && rawPkg != currentDisplayState.foregroundPackage)

        if (isWindowTransition && !isIme && rawPkg.isNotEmpty()) {
            val pkg = rawPkg
            val act = event.className?.toString() ?: ""
            val oldDisplayState = currentDisplayState

            val displayChanged = pkg != oldDisplayState.foregroundPackage ||
                    (act.isNotEmpty() && act != oldDisplayState.foregroundActivity)

            if (displayChanged) {
                val newRev = oldDisplayState.revision + 1
                val newDisplayState = oldDisplayState.copy(
                    foregroundPackage = pkg,
                    foregroundActivity = if (act.isNotEmpty()) act else oldDisplayState.foregroundActivity,
                    displayId = disp,
                    screenInteractive = isScreenInteractive(),
                    orientation = context?.resources?.configuration?.orientation ?: oldDisplayState.orientation,
                    revision = newRev,
                    timestamp = System.currentTimeMillis()
                )
                statesByDisplayId[disp] = newDisplayState
                latestEventState = newDisplayState

                if (pkg != oldDisplayState.foregroundPackage) {
                    journal?.recordEvent("package_changed", mapOf("package" to pkg, "displayId" to disp, "revision" to newRev))
                }
                if (act.isNotEmpty() && act != oldDisplayState.foregroundActivity) {
                    journal?.recordEvent("activity_changed", mapOf("activity" to act, "displayId" to disp, "revision" to newRev))
                }

                // Explicit contract: currentState and _deviceStateFlow track Display 0 ONLY
                if (disp == 0) {
                    val oldGlobal = currentState
                    val newGlobalRev = oldGlobal.revision + 1
                    val newGlobal = oldGlobal.copy(
                        foregroundPackage = pkg,
                        foregroundActivity = if (act.isNotEmpty()) act else oldGlobal.foregroundActivity,
                        displayId = 0,
                        screenInteractive = isScreenInteractive(),
                        orientation = context?.resources?.configuration?.orientation ?: oldGlobal.orientation,
                        revision = newGlobalRev,
                        timestamp = System.currentTimeMillis()
                    )
                    currentState = newGlobal
                    _deviceStateFlow.value = newGlobal
                }
            }
        }
    }

    fun updateManualState(
        pkg: String? = null,
        activity: String? = null,
        displayId: Int? = null,
        interactive: Boolean? = null
    ) {
        val targetDisplay = displayId ?: 0
        val oldDisplayState = getStateForDisplay(targetDisplay)
        val newDisplayRev = oldDisplayState.revision + 1
        val newDisplayState = oldDisplayState.copy(
            foregroundPackage = pkg ?: oldDisplayState.foregroundPackage,
            foregroundActivity = activity ?: oldDisplayState.foregroundActivity,
            displayId = targetDisplay,
            screenInteractive = interactive ?: oldDisplayState.screenInteractive,
            revision = newDisplayRev,
            timestamp = System.currentTimeMillis()
        )
        statesByDisplayId[targetDisplay] = newDisplayState
        latestEventState = newDisplayState

        // Explicit contract: currentState and _deviceStateFlow track Display 0 ONLY
        if (targetDisplay == 0) {
            val oldState = currentState
            val newRev = oldState.revision + 1
            val newState = oldState.copy(
                foregroundPackage = pkg ?: oldState.foregroundPackage,
                foregroundActivity = activity ?: oldState.foregroundActivity,
                displayId = 0,
                screenInteractive = interactive ?: oldState.screenInteractive,
                revision = newRev,
                timestamp = System.currentTimeMillis()
            )
            currentState = newState
            _deviceStateFlow.value = newState
        }
    }
}
