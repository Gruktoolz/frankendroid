package com.tunnel.turbo.accessibility

import android.view.accessibility.AccessibilityNodeInfo

data class SemanticSelector(
    val text: String? = null,
    val contentDescription: String? = null,
    val resourceId: String? = null,
    val className: String? = null,
    val clickable: Boolean? = null,
    val editable: Boolean? = null,
    val match: String = "first" // "single", "first", "all"
) {
    companion object {
        fun fromMap(map: Map<String, Any?>): SemanticSelector {
            val txt = map["text"] as? String
            val desc = map["contentDescription"] as? String ?: map["desc"] as? String
            val res = map["resourceId"] as? String ?: map["res"] as? String
            val cls = map["className"] as? String ?: map["class"] as? String
            val click = map["clickable"] as? Boolean
            val edit = map["editable"] as? Boolean
            val m = (map["match"] as? String) ?: "first"
            return SemanticSelector(
                text = txt?.takeIf { it.isNotBlank() },
                contentDescription = desc?.takeIf { it.isNotBlank() },
                resourceId = res?.takeIf { it.isNotBlank() },
                className = cls?.takeIf { it.isNotBlank() },
                clickable = click,
                editable = edit,
                match = if (m == "single") "single" else if (m == "all") "all" else "first"
            )
        }

        fun fromString(str: String): SemanticSelector {
            val parts = str.split(",")
            val map = mutableMapOf<String, Any>()
            for (part in parts) {
                val kv = part.split("=", limit = 2)
                if (kv.size == 2) {
                    val k = kv[0].trim()
                    val v = kv[1].trim()
                    when (k) {
                        "text", "txt" -> map["text"] = v
                        "desc", "contentDescription" -> map["contentDescription"] = v
                        "res", "resourceId" -> map["resourceId"] = v
                        "class", "className" -> map["className"] = v
                        "clickable" -> map["clickable"] = v.toBoolean()
                        "editable" -> map["editable"] = v.toBoolean()
                        "match" -> map["match"] = v
                    }
                } else if (part.isNotBlank() && !map.containsKey("text")) {
                    map["text"] = part.trim()
                }
            }
            return fromMap(map)
        }
    }

    fun matchesNode(node: AccessibilityNodeInfo): Boolean {
        if (text != null) {
            val nText = node.text?.toString() ?: ""
            val nDesc = node.contentDescription?.toString() ?: ""
            if (!nText.contains(text, ignoreCase = true) && !nDesc.contains(text, ignoreCase = true)) return false
        }
        if (contentDescription != null) {
            val nDesc = node.contentDescription?.toString() ?: ""
            if (!nDesc.contains(contentDescription, ignoreCase = true)) return false
        }
        if (resourceId != null) {
            val nRes = node.viewIdResourceName ?: ""
            if (!nRes.equals(resourceId, ignoreCase = true) && !nRes.endsWith(resourceId, ignoreCase = true)) {
                return false
            }
        }
        if (className != null) {
            val nCls = node.className?.toString() ?: ""
            if (!nCls.equals(className, ignoreCase = true) && !nCls.endsWith(className, ignoreCase = true)) {
                return false
            }
        }
        if (clickable != null) {
            if (node.isClickable != clickable) return false
        }
        if (editable != null) {
            if (node.isEditable != editable) return false
        }
        return true
    }

    fun matchesUiNode(node: UiNodeInfo): Boolean {
        if (text != null) {
            val hasText = node.text.contains(text, ignoreCase = true)
            val hasDesc = node.contentDescription.contains(text, ignoreCase = true)
            if (!hasText && !hasDesc) return false
        }
        if (contentDescription != null) {
            if (!node.contentDescription.contains(contentDescription, ignoreCase = true)) return false
        }
        if (resourceId != null) {
            if (!node.resourceId.equals(resourceId, ignoreCase = true) && !node.resourceId.endsWith(resourceId, ignoreCase = true)) {
                return false
            }
        }
        if (className != null) {
            if (!node.className.equals(className, ignoreCase = true) && !node.className.endsWith(className, ignoreCase = true)) {
                return false
            }
        }
        if (clickable != null) {
            if (node.clickable != clickable) return false
        }
        if (editable != null) {
            if (node.editable != editable) return false
        }
        return true
    }
}
