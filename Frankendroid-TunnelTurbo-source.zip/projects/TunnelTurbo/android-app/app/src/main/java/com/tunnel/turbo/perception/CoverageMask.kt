package com.tunnel.turbo.perception

import android.graphics.Rect

class CoverageMask(private val screenWidth: Int = 1220, private val screenHeight: Int = 2712) {

    private val gridStep = 20
    private val gridCols = (screenWidth / gridStep) + 1
    private val gridRows = (screenHeight / gridStep) + 1
    private val grid = Array(gridRows) { BooleanArray(gridCols) }

    fun markCovered(rect: Rect) {
        val startCol = (rect.left.coerceIn(0, screenWidth) / gridStep)
        val endCol = (rect.right.coerceIn(0, screenWidth) / gridStep).coerceAtMost(gridCols - 1)
        val startRow = (rect.top.coerceIn(0, screenHeight) / gridStep)
        val endRow = (rect.bottom.coerceIn(0, screenHeight) / gridStep).coerceAtMost(gridRows - 1)

        for (r in startRow..endRow) {
            for (c in startCol..endCol) {
                grid[r][c] = true
            }
        }
    }

    fun calculateCoverageRatio(): Float {
        var covered = 0
        var total = 0
        for (r in 0 until gridRows) {
            for (c in 0 until gridCols) {
                total++
                if (grid[r][c]) covered++
            }
        }
        return if (total > 0) covered.toFloat() / total.toFloat() else 0f
    }

    fun getUncoveredGaps(minHeightPx: Int = 300): List<Rect> {
        val gaps = mutableListOf<Rect>()
        var inGap = false
        var gapStartRow = 0

        for (r in 0 until gridRows) {
            var rowHasCoverage = false
            for (c in 0 until gridCols) {
                if (grid[r][c]) {
                    rowHasCoverage = true
                    break
                }
            }
            if (!rowHasCoverage) {
                if (!inGap) {
                    inGap = true
                    gapStartRow = r
                }
            } else {
                if (inGap) {
                    val gapHeight = (r - gapStartRow) * gridStep
                    if (gapHeight >= minHeightPx) {
                        gaps.add(Rect(0, gapStartRow * gridStep, screenWidth, r * gridStep))
                    }
                    inGap = false
                }
            }
        }
        if (inGap) {
            val gapHeight = (gridRows - gapStartRow) * gridStep
            if (gapHeight >= minHeightPx) {
                gaps.add(Rect(0, gapStartRow * gridStep, screenWidth, screenHeight))
            }
        }
        return gaps
    }
}
