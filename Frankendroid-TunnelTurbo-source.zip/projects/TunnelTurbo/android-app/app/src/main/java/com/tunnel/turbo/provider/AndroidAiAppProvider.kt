package com.tunnel.turbo.provider

import com.tunnel.turbo.model.PlanValidationError
import com.tunnel.turbo.model.PlanValidator
import com.tunnel.turbo.model.StructuredPlan
import com.tunnel.turbo.worker.AiWorkerBridge
import org.json.JSONObject
import java.util.regex.Pattern

class AndroidAiAppProvider(
    override val name: String = "chatgpt_app",
    val workerBridge: AiWorkerBridge = AiWorkerBridge(),
    val validator: PlanValidator = PlanValidator()
) : IntentProvider {

    companion object {
        const val PROMPT_TEMPLATE = """Process ONLY the current Tunnel Turbo request.
Do not continue, modify or execute any previous Tunnel Turbo request.

USER:
"%s"

AVAILABLE TOOLS:
- open_settings ()
- open_wifi_settings ()
- open_bluetooth_settings ()
- open_app (package: string)
- press_key (key: "BACK" | "HOME" | "ENTER")
- press_back ()
- press_home ()
- semantic_tap (selector: "text=...", match: "single" | "first")

RETURN ONLY VALID JSON MATCHING:
1. Single action:
{"type": "action", "action": "<name>", "arguments": { ... }}

2. Sequence of actions:
{"type": "sequence", "steps": [{"action": "<name>", "arguments": { ... }}, ...]}

3. If unknown on-screen information is required:
{"type": "needs_observation", "reason": "<explanation>"}

4. If dangerous, shell/adb/bash, or impossible:
{"type": "unsupported", "reason": "<explanation>"}

RETURN ONLY RAW JSON. NO CODE FENCES. NO CONVERSATIONAL FILLER."""
    }

    override suspend fun healthCheck(): Boolean {
        return workerBridge.healthCheck()
    }

    override suspend fun plan(userText: String, requestId: String): IntentResult {
        val t0 = System.nanoTime()
        if (!workerBridge.isReady()) {
            workerBridge.start()
        }

        val prompt = String.format(PROMPT_TEMPLATE, userText)
        val sendOk = workerBridge.sendRequest(prompt, requestId)
        if (!sendOk) {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return IntentResult(
                success = false,
                error = "Failed to inject prompt into AI worker bridge",
                providerMs = elapsed
            )
        }

        val bridgeResp = workerBridge.readResponse(requestId)
        if (!bridgeResp.success) {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return IntentResult(
                success = false,
                rawResponse = bridgeResp.rawText,
                error = bridgeResp.error ?: "Failed to read response from AI worker",
                providerMs = elapsed
            )
        }

        // Clean JSON fences
        var cleaned = bridgeResp.rawText.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replace(Regex("^```(?:json)?\\s*"), "").replace(Regex("\\s*```$"), "")
        }

        val parsedJson = try {
            JSONObject(cleaned)
        } catch (e: Exception) {
            val matcher = Pattern.compile("(\\{.*\\})", Pattern.DOTALL).matcher(cleaned)
            if (matcher.find()) {
                try {
                    JSONObject(matcher.group(1)!!)
                } catch (e2: Exception) {
                    val elapsed = (System.nanoTime() - t0) / 1_000_000.0
                    return IntentResult(
                        success = false,
                        rawResponse = cleaned,
                        error = "Failed to parse JSON response: ${e.message}",
                        providerMs = elapsed
                    )
                }
            } else {
                val elapsed = (System.nanoTime() - t0) / 1_000_000.0
                return IntentResult(
                    success = false,
                    rawResponse = cleaned,
                    error = "Failed to parse JSON response: ${e.message}",
                    providerMs = elapsed
                )
            }
        }

        // Validate strictly with deterministic PlanValidator
        val validatedPlan = try {
            validator.validate(parsedJson)
        } catch (pve: PlanValidationError) {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return IntentResult(
                success = false,
                rawResponse = cleaned,
                error = "Plan validation error: [${pve.code}] ${pve.message}",
                providerMs = elapsed
            )
        }

        val elapsed = (System.nanoTime() - t0) / 1_000_000.0
        return IntentResult(
            success = true,
            plan = validatedPlan,
            rawResponse = cleaned,
            providerMs = elapsed
        )
    }
}
