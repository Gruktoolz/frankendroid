package com.tunnel.turbo.coordinator

import android.content.Context
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.model.SequencePlan
import com.tunnel.turbo.provider.ProviderRuntime
import com.tunnel.turbo.provider.ProviderState
import com.tunnel.turbo.router.RouteDecision
import com.tunnel.turbo.shizuku.ShizukuBridge
import com.tunnel.turbo.shizuku.ShizukuState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withLock

class IntentCoordinator(
    private val context: Context,
    val providerRuntime: ProviderRuntime,
    val shizukuBridge: ShizukuBridge,
    val accessibilityBridge: AccessibilityBridge,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
    val isDebug: Boolean = com.tunnel.turbo.BuildConfig.DEBUG,
    val localChatEngine: com.tunnel.turbo.chat.LocalChatEngine = com.tunnel.turbo.chat.LiteRtLmLocalChatEngine()
) {
    private val geminiKeyVault by lazy { com.tunnel.turbo.chat.ApiKeyVault(context) }
    private val geminiApiClient by lazy { com.tunnel.turbo.chat.GeminiFreeApiClient() }
    private val conversationMemoryStore by lazy { com.tunnel.turbo.chat.ConversationMemoryStore(context.applicationContext) }
    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    private var requestCounter = 0

    val conversationRuntime = com.tunnel.turbo.chat.ConversationRuntime(localChatEngine, scope = scope)

    /** Restores lightweight conversation UI state after a configuration recreation. */
    fun restoreConversation(messages: List<ConversationMessage>) {
        if (messages.isEmpty()) return
        _uiState.update { it.copy(conversation = messages.takeLast(40)) }
    }

    fun clearConversationHistory() {
        conversationRuntime.clearConversation()
        conversationMemoryStore.clear()
        _uiState.update { it.copy(conversation = listOf(ConversationMessage(role = MessageRole.ASSISTANT, text = "Hola. Soy Tunnel Turbo. ¿En qué te ayudo?"))) }
    }

    fun conversationMemory(): com.tunnel.turbo.chat.ConversationMemory = conversationMemoryStore.read()

    suspend fun saveConversationMemory(memory: com.tunnel.turbo.chat.ConversationMemory): Boolean {
        if (_uiState.value.isBusy) return false
        conversationMemoryStore.save(memory)
        conversationRuntime.resetActiveSessionPreservingHistory()
        return true
    }

    fun beginCloudChatTurn(userText: String, searched: Boolean, userAlreadyInConversation: Boolean = false): String {
        val responseId = java.util.UUID.randomUUID().toString()
        val user = ConversationMessage(role = MessageRole.USER, text = userText)
        val placeholder = ConversationMessage(
            id = responseId,
            role = MessageRole.ASSISTANT,
            text = "",
            route = if (searched) Route.RESEARCH else Route.CLOUD_API,
            turnStatus = TurnStatus.GENERATING,
            provenance = if (searched) "Gemini API · Google Search" else "Gemini API"
        )
        _uiState.update { state -> state.copy(
            isBusy = true,
            statusMessage = if (searched) "Buscando" else "Generando respuesta",
            conversation = (state.conversation + (if (userAlreadyInConversation) emptyList() else listOf(user)) + placeholder).takeLast(40)
        ) }
        return responseId
    }

    fun updateStreamingAssistant(responseId: String, text: String) {
        _uiState.update { state ->
            if (state.conversation.none { it.id == responseId }) state
            else state.copy(conversation = state.conversation.map { message ->
                if (message.id == responseId && message.turnStatus == TurnStatus.GENERATING) message.copy(text = text) else message
            })
        }
    }

    fun appendCloudChatTurn(userText: String, response: String, elapsedMs: Long, searched: Boolean, sources: List<Pair<String, String>>, responseId: String? = null, truncated: Boolean = false) {
        val user = ConversationMessage(role = MessageRole.USER, text = userText)
        val sourceText = sources.take(6).joinToString("\n") { "- ${it.first}: ${it.second}" }
        val limitNote = buildString {
            if (truncated) append("\n\nLa respuesta alcanzó el límite de esta generación. Puedes pedirme que continúe.")
            if (searched && sources.isEmpty()) append("\n\nNo recibí enlaces verificables de la búsqueda. Esta respuesta podría no estar fundamentada en resultados web.")
        }
        val assistant = ConversationMessage(
            id = responseId ?: java.util.UUID.randomUUID().toString(),
            role = MessageRole.ASSISTANT,
            text = response + limitNote + if (sourceText.isNotBlank()) "\n\nFuentes consultadas:\n$sourceText" else "",
            route = if (searched) Route.RESEARCH else Route.CLOUD_API,
            turnStatus = TurnStatus.GENERATED,
            provenance = if (searched) "Gemini API · Google Search" else "Gemini API",
            latencyMs = elapsedMs.toDouble(),
            verificationExplanation = if (searched && sources.isEmpty()) "La búsqueda se solicitó, pero la respuesta no incluyó URLs citables." else null
        )
        _uiState.update { state ->
            val hasStreamingResponse = responseId != null && state.conversation.any { it.id == responseId }
            val conversation = if (hasStreamingResponse) state.conversation.map { if (it.id == responseId) assistant else it }
            else state.conversation + user + assistant
            state.copy(isBusy = false, conversation = conversation.takeLast(40), statusMessage = "Respuesta Gemini ${if (searched) "con búsqueda web" else "sin búsqueda web"}")
        }
    }

    fun appendCloudChatFailure(userText: String, message: String, responseId: String? = null, searched: Boolean = false) {
        val user = ConversationMessage(role = MessageRole.USER, text = userText)
        val assistant = ConversationMessage(
            id = responseId ?: java.util.UUID.randomUUID().toString(),
            role = MessageRole.ASSISTANT,
            text = message,
            route = if (searched) Route.RESEARCH else Route.CLOUD_API,
            turnStatus = TurnStatus.FAILED,
            provenance = if (searched) "Gemini API · Google Search · solicitud fallida" else "Gemini API · solicitud fallida",
            verificationExplanation = "La llamada no produjo una respuesta; revisa la conexión de Gemini."
        )
        _uiState.update { state ->
            val hasStreamingResponse = responseId != null && state.conversation.any { it.id == responseId }
            val conversation = if (hasStreamingResponse) state.conversation.map { if (it.id == responseId) assistant else it }
            else state.conversation + user + assistant
            state.copy(isBusy = false, statusMessage = "Gemini no disponible", conversation = conversation.takeLast(40))
        }
    }

    fun setMessageFeedback(messageId: String, feedback: MessageFeedback) {
        _uiState.update { state -> state.copy(conversation = ConversationFeedbackReducer.toggle(state.conversation, messageId, feedback)) }
    }

    /** Replays an edited user prompt, dropping the old answer and every later turn. */
    @Synchronized
    fun submitEditedPrompt(messageId: String, updatedText: String): Job? {
        if (updatedText.isBlank() || !prepareEditedPrompt(messageId)) return null
        return submitIntent(updatedText, source = "EDITED_USER_INPUT")
    }

    /** Drops the previous answer and following turns so the caller can replay on the same provider. */
    @Synchronized
    fun prepareEditedPrompt(messageId: String): Boolean {
        val current = _uiState.value
        if (current.isBusy) return false
        val retained = ConversationEditReducer.retainedBefore(current.conversation, messageId) ?: return false
        _uiState.update { state -> if (state.isBusy) state else state.copy(conversation = retained) }
        return !_uiState.value.isBusy
    }

    val devToolsBridge = com.tunnel.turbo.devtools.TunnelDevToolsBridge(
        coordinator = this,
        core = providerRuntime.coreAdapter.nativeCore,
        providerRuntime = providerRuntime,
        accessibilityBridge = accessibilityBridge,
        isDebug = isDebug,
        tokenStorageDir = context.filesDir,
        maxRequestDurationMs = 60_000L
    )

    private val modelLoadMutex = kotlinx.coroutines.sync.Mutex()
    var preferredBackend: com.tunnel.turbo.chat.ChatBackend = com.tunnel.turbo.chat.ChatBackend.CPU
    var fallbackModelPath: String? = null
    private val modelPreferences by lazy {
        runCatching { context.getSharedPreferences("local_model_selection", Context.MODE_PRIVATE) }.getOrNull()
    }
    @Volatile
    var selectedLocalModelId: String = runCatching {
        modelPreferences?.getString("model_id", null)
    }.getOrNull() ?: com.tunnel.turbo.chat.LocalModelCatalog.DEFAULT_MODEL_ID
        private set
    var modelCandidatePaths: List<String> = listOf(
        "/data/local/tmp/Qwen3-0.6B.litertlm",
        "/sdcard/Download/Qwen3-0.6B.litertlm",
        java.io.File(context.filesDir, "models/Qwen3-0.6B.litertlm").absolutePath
    )

    init {
        refreshBridgesStatus()
        if (isDebug) {
            devToolsBridge.start()
        }
    }

    suspend fun ensureModelLoaded(): Boolean {
        val target = resolveSelectedModelPath()
        if (target == null) {
            _uiState.update { it.copy(statusMessage = "Modelo local no instalado") }
            return false
        }
        if ((localChatEngine.lifecycleState == com.tunnel.turbo.chat.ModelLifecycleState.READY || localChatEngine.isModelLoaded) &&
            localChatEngine.backend == preferredBackend && localChatEngine.loadedModelPath == target) {
            return true
        }
        return modelLoadMutex.withLock {
            val lockedTarget = resolveSelectedModelPath() ?: return@withLock false
            if ((localChatEngine.lifecycleState == com.tunnel.turbo.chat.ModelLifecycleState.READY || localChatEngine.isModelLoaded) &&
                localChatEngine.backend == preferredBackend && localChatEngine.loadedModelPath == lockedTarget) {
                return@withLock true
            }
            if (localChatEngine.isModelLoaded &&
                (localChatEngine.backend != preferredBackend || localChatEngine.loadedModelPath != lockedTarget)) {
                conversationRuntime.clearConversation()
                localChatEngine.close()
            }
            _uiState.update { it.copy(statusMessage = "Cargando ${selectedModelDisplayName()}…") }
            val ok = localChatEngine.loadModel(lockedTarget, preferredBackend)
            if (ok) {
                android.util.Log.i("IntentCoordinator", "Loaded ${selectedLocalModelId} from: $lockedTarget (backend=$preferredBackend)")
                _uiState.update { it.copy(statusMessage = "Modelo listo: ${selectedModelDisplayName()}") }
            } else {
                _uiState.update { it.copy(statusMessage = "No se pudo cargar ${selectedModelDisplayName()}") }
            }
            ok
        }
    }

    private fun resolveSelectedModelPath(): String? {
        if (selectedLocalModelId == com.tunnel.turbo.chat.LocalModelCatalog.DEFAULT_MODEL_ID) {
            val catalogModel = com.tunnel.turbo.chat.LocalModelCatalog.get(context, selectedLocalModelId)
            val candidates = if (catalogModel != null) {
                com.tunnel.turbo.chat.LocalModelCatalog.candidateFiles(context, catalogModel).map { it.absolutePath } + modelCandidatePaths
            } else modelCandidatePaths
            val candidate = candidates.distinct().firstOrNull { path ->
                val file = java.io.File(path)
                file.exists() && file.canRead()
            }
            if (candidate != null) return candidate
            val fallback = fallbackModelPath
            if (fallback != null) return fallback
            return null
        }
        val spec = com.tunnel.turbo.chat.LocalModelCatalog.get(context, selectedLocalModelId) ?: return null
        return com.tunnel.turbo.chat.LocalModelCatalog.candidateFiles(context, spec)
            .firstOrNull { it.exists() && it.canRead() }?.absolutePath
    }

    fun localModelOptions(): List<String> = com.tunnel.turbo.chat.LocalModelCatalog.modelsFor(context).map { model ->
        val installed = com.tunnel.turbo.chat.LocalModelCatalog.candidateFiles(context, model)
            .any { it.parentFile == java.io.File(context.filesDir, "models") && it.exists() && it.canRead() }
        val label = if (installed) "EN APP · LISTO PARA CARGAR" else "IMPORTAR DESDE DESCARGAS"
        "${model.displayName} · $label"
    }

    fun selectedModelDisplayName(): String = com.tunnel.turbo.chat.LocalModelCatalog.get(context, selectedLocalModelId)?.displayName
        ?: selectedLocalModelId

    suspend fun selectLocalModel(modelId: String, backend: com.tunnel.turbo.chat.ChatBackend): Boolean {
        val spec = com.tunnel.turbo.chat.LocalModelCatalog.get(context, modelId) ?: return false
        val targetExists = if (modelId == com.tunnel.turbo.chat.LocalModelCatalog.DEFAULT_MODEL_ID) {
            val catalogPaths = com.tunnel.turbo.chat.LocalModelCatalog.candidateFiles(context, spec)
            catalogPaths.any { it.exists() && it.canRead() } || modelCandidatePaths.any { java.io.File(it).exists() && java.io.File(it).canRead() } || fallbackModelPath?.let { java.io.File(it).canRead() } == true
        } else {
            com.tunnel.turbo.chat.LocalModelCatalog.candidateFiles(context, spec).any { it.exists() && it.canRead() }
        }
        if (!targetExists) {
            _uiState.update { it.copy(statusMessage = if (spec.gated) "Modelo requiere acceso autorizado" else "Falta ${spec.fileName}") }
            return false
        }
        val previousModelId = selectedLocalModelId
        val previousBackend = preferredBackend
        selectedLocalModelId = modelId
        preferredBackend = backend
        runCatching { modelPreferences?.edit()?.putString("model_id", modelId)?.apply() }
        if (ensureModelLoaded()) return true

        // A model is not considered selectable when the runtime rejects it. Restore
        // the prior selection and try to recover its loaded engine before returning.
        selectedLocalModelId = previousModelId
        preferredBackend = previousBackend
        runCatching { modelPreferences?.edit()?.putString("model_id", previousModelId)?.apply() }
        if (previousModelId != modelId) ensureModelLoaded()
        refreshBridgesStatus()
        return false
    }

    fun setUiMode(mode: UiMode) {
        if (_uiState.value.uiMode == UiMode.DEBUG_MODE && mode == UiMode.APP_MODE) {
            // Requirement 12: Clear simulation state upon exiting Debug Mode
            clearSimulatedProviderState()
        }
        _uiState.update { it.copy(uiMode = mode) }
    }

    fun toggleUiMode() {
        val next = if (_uiState.value.uiMode == UiMode.APP_MODE) UiMode.DEBUG_MODE else UiMode.APP_MODE
        setUiMode(next)
    }

    fun refreshBridgesStatus() {
        val szState = shizukuBridge.checkState()
        val szText = when (szState) {
            ShizukuState.READY -> "Shizuku: CONNECTED (UID 2000)"
            ShizukuState.PERMISSION_REQUIRED -> "Shizuku: PERMISSION_REQUIRED"
            ShizukuState.NOT_RUNNING -> "Shizuku: NOT_RUNNING"
            ShizukuState.NOT_INSTALLED -> "Shizuku: NOT_INSTALLED"
            ShizukuState.ERROR -> "Shizuku: ERROR"
        }

        val a11yState = try { accessibilityBridge.getServiceState() } catch (_: Throwable) { null }
        val a11yStatus = a11yState?.status ?: if (try { accessibilityBridge.isEnabled() } catch (_: Throwable) { false }) "ENABLED" else "DISABLED"
        val a11yText = when (a11yStatus) {
            "CONNECTED" -> "Accessibility: CONNECTED"
            "CRASHED_OR_BLOCKED" -> "Accessibility: CRASHED/BLOCKED"
            "ENABLED_NOT_BOUND" -> "Accessibility: ENABLED_NOT_BOUND"
            "ENABLED" -> "Accessibility: ENABLED"
            else -> "Accessibility: DISABLED"
        }

        val pState = providerRuntime.health.state
        val isSim = _uiState.value.debugState.cloudProvider.isSimulated
        val pText = if (isSim) {
            "[SIMULACIÓN] Estado de API cloud ($pState)"
        } else {
            val pName = providerRuntime.activeProvider?.javaClass?.simpleName?.removeSuffix("Provider")
            if (providerRuntime.health.lastSuccessAt > 0L) {
                "Agente Android: ${pName ?: "no configurado"} · última ejecución correcta registrada"
            } else {
                "Agente Android: ${pName ?: "no configurado"} · sin prueba de ejecución"
            }
        }

        val loadedModel = localChatEngine.loadedModelPath
        val selectedModel = com.tunnel.turbo.chat.LocalModelCatalog.get(context, selectedLocalModelId)
        val modelInstalled = selectedModel?.let { spec ->
            com.tunnel.turbo.chat.LocalModelCatalog.candidateFiles(context, spec)
                .any { it.exists() && it.canRead() }
        } ?: false
        val localStatus = when {
            localChatEngine.lifecycleState == com.tunnel.turbo.chat.ModelLifecycleState.LOADING -> LocalEngineStatus.LOADING
            localChatEngine.lifecycleState == com.tunnel.turbo.chat.ModelLifecycleState.ERROR -> LocalEngineStatus.ERROR
            localChatEngine.isModelLoaded -> LocalEngineStatus.READY
            modelInstalled -> LocalEngineStatus.INSTALLED_NOT_LOADED
            else -> LocalEngineStatus.NOT_INSTALLED
        }
        val localEngineState = LocalEngineState(
            status = localStatus,
            modelId = selectedLocalModelId,
            displayName = com.tunnel.turbo.chat.LocalModelCatalog.get(context, selectedLocalModelId)?.displayName,
            requestedBackend = preferredBackend.name,
            effectiveBackend = localChatEngine.backend.name,
            filePath = loadedModel
        )

        val szHealth = when (szState) {
            ShizukuState.READY -> CapabilityHealth.CONNECTED
            ShizukuState.PERMISSION_REQUIRED -> CapabilityHealth.PERMISSION_REQUIRED
            ShizukuState.NOT_RUNNING, ShizukuState.NOT_INSTALLED -> CapabilityHealth.DISABLED
            ShizukuState.ERROR -> CapabilityHealth.ERROR
        }
        val a11yHealth = when (a11yStatus) {
            "CONNECTED" -> CapabilityHealth.CONNECTED
            "CRASHED_OR_BLOCKED" -> CapabilityHealth.ERROR
            "ENABLED_NOT_BOUND" -> CapabilityHealth.ENABLED_NOT_BOUND
            "ENABLED" -> CapabilityHealth.PERMISSION_REQUIRED
            else -> CapabilityHealth.DISABLED
        }
        val capabilitiesState = AndroidCapabilitiesState(
            accessibility = a11yHealth,
            shizuku = szHealth,
            directApi = CapabilityHealth.UNKNOWN,
            lastCheckMs = System.currentTimeMillis()
        )

        val currentCloud = _uiState.value.debugState.cloudProvider
        val cloudState = if (isSim) {
            _uiState.value.debugState.cloudProvider
        } else if (geminiKeyVault.hasKey()) {
            if (currentCloud.providerId == "google_gemini" && currentCloud.status == CloudProviderStatus.READY_CHECKED) currentCloud
            else CloudProviderState(
                status = CloudProviderStatus.AUTH_REQUIRED,
                providerId = "google_gemini",
                displayName = "Gemini API",
                endpointOrModel = com.tunnel.turbo.chat.GeminiFreeApiClient.DEFAULT_FREE_TEST_MODEL,
                evidenceOrSource = "Clave cifrada guardada; conexión aún no comprobada",
                isSimulated = false
            )
        } else {
            CloudProviderState(
                status = CloudProviderStatus.NOT_CONFIGURED,
                providerId = "none",
                displayName = "Cloud API",
                evidenceOrSource = "No cloud API configured; local-first device architecture",
                isSimulated = false
            )
        }

        val core = providerRuntime.coreAdapter.nativeCore
        val rev = core.stateEngine.currentState.revision
        val jCount = core.journal.size()

        _uiState.update { curr ->
            curr.copy(
                debugState = curr.debugState.copy(
                    shizukuStatusText = szText,
                    accessibilityStatusText = a11yText,
                    providerStatusText = pText,
                    cloudProvider = cloudState,
                    localEngine = localEngineState,
                    capabilities = capabilitiesState,
                    stateEngineRevision = rev,
                    journalEventCount = jCount
                )
            )
        }
    }

    fun selectNavigationTab(tab: NavigationTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun recordGeminiApiCheck(success: Boolean, message: String, model: String = com.tunnel.turbo.chat.GeminiFreeApiClient.DEFAULT_FREE_TEST_MODEL) {
        val status = if (success) CloudProviderStatus.READY_CHECKED else CloudProviderStatus.ERROR
        val cloud = if (success) {
            CloudProviderState(
                status = status,
                providerId = "google_gemini",
                displayName = "Gemini API",
                endpointOrModel = model,
                checkedAtMs = System.currentTimeMillis(),
                evidenceOrSource = "generateContent respondió correctamente; plan/cuota no se consultan desde la app",
                errorMessage = null,
                isSimulated = false
            )
        } else {
            CloudProviderState(
                status = status,
                providerId = "google_gemini",
                displayName = "Gemini API",
                endpointOrModel = model,
                checkedAtMs = System.currentTimeMillis(),
                evidenceOrSource = "Prueba real de conexión desde Tunnel Turbo",
                errorMessage = message,
                isSimulated = false
            )
        }
        _uiState.update { state ->
            state.copy(debugState = state.debugState.copy(cloudProvider = cloud, providerStatusText = "Gemini API · $status"))
        }
    }

    fun submitIntent(userText: String, source: String = "USER_INPUT"): Job? {
        val cleaned = userText.trim()
        if (cleaned.isEmpty()) return null

        requestCounter++
        val reqTag = String.format("TT_UI_%04d", requestCounter)

        // Add user message to conversation history
        val userMsg = ConversationMessage(role = MessageRole.USER, text = cleaned)
        _uiState.update { curr ->
            curr.copy(
                isBusy = true,
                statusMessage = "Procesando...",
                conversation = curr.conversation + userMsg
            )
        }

        val initialRev = providerRuntime.coreAdapter.nativeCore.stateEngine.currentState.revision

        return scope.launch {
            com.tunnel.turbo.chat.MemoryCommandParser.parse(cleaned)?.let { command ->
                val confirmation = when (command.type) {
                    com.tunnel.turbo.chat.MemoryCommandType.REMEMBER -> {
                        if (conversationMemoryStore.remember(command.value)) "Lo recordaré en este chat, solo en este dispositivo. Puedes revisar o borrar estos datos en Ajustes · Memoria del chat."
                        else "Ese dato ya estaba guardado en la memoria local de este chat."
                    }
                    com.tunnel.turbo.chat.MemoryCommandType.FORGET -> {
                        if (conversationMemoryStore.forget(command.value)) "Olvidé ese dato de la memoria local de este chat."
                        else "No encontré ese dato en la memoria de este chat. Puedes editarla en Ajustes · Memoria del chat."
                    }
                    com.tunnel.turbo.chat.MemoryCommandType.CLEAR -> {
                        conversationMemoryStore.clear()
                        "Borré los recuerdos y la instrucción maestra guardados para este chat."
                    }
                }
                conversationRuntime.resetActiveSessionPreservingHistory()
                _uiState.update { state -> state.copy(
                    isBusy = false,
                    statusMessage = "Memoria actualizada",
                    conversation = (state.conversation + ConversationMessage(role = MessageRole.ASSISTANT, text = confirmation)).takeLast(40)
                ) }
                return@launch
            }

            if (com.tunnel.turbo.chat.ResearchIntentPolicy.requiresWeb(cleaned)) {
                handleGeminiResearchTurn(cleaned)
                return@launch
            }

            // Assess turn using LocalCognitiveEngine before executing actions
            val cognitiveEngine = com.tunnel.turbo.local.LocalCognitiveEngineRegistry.activeEngine
            val contextSummary = _uiState.value.conversation.takeLast(4).joinToString("\n") { "${it.role}: ${it.text}" }
            val assessment = cognitiveEngine.assessTurn(
                com.tunnel.turbo.local.LocalCognitiveInput(
                    userMessage = cleaned,
                    conversationContextSummary = contextSummary
                )
            )

            if (assessment.interactionMode == com.tunnel.turbo.local.InteractionMode.CHAT) {
                handleChatTurn(cleaned, reqTag, source)
                return@launch
            }

            if (assessment.interactionMode == com.tunnel.turbo.local.InteractionMode.CLARIFY) {
                handleClarifyTurn(cleaned, assessment, reqTag, source)
                return@launch
            }

            if (assessment.interactionMode == com.tunnel.turbo.local.InteractionMode.RESEARCH) {
                handleGeminiResearchTurn(cleaned)
                return@launch
            }

            if (assessment.interactionMode == com.tunnel.turbo.local.InteractionMode.WORK) {
                handleUnsupportedModeTurn(cleaned, assessment, reqTag, source)
                return@launch
            }

            val routeCheck = if (com.tunnel.turbo.agent.GeneralAgentRuntime.strictRealProviderMode) {
                // Section 6: in STRICT_REAL_PROVIDER_MODE, disable local router shortcuts for agent reasoning
                com.tunnel.turbo.router.RouteResult(
                    decision = RouteDecision.AI_REQUIRED,
                    reason = "STRICT_REAL_PROVIDER_MODE_ACTIVE"
                )
            } else {
                providerRuntime.router.route(cleaned)
            }

            if (routeCheck.decision == RouteDecision.DIRECT) {
                val res = providerRuntime.processUserIntent(cleaned, precomputedRoute = routeCheck)

                val assistantText = if (res.success) {
                    when (val p = res.plan) {
                        is ActionPlan -> when (p.action) {
                            "open_wifi_settings" -> "Listo. Abriendo ajustes de Wi-Fi."
                            "open_bluetooth_settings" -> "Listo. Abriendo ajustes de Bluetooth."
                            "open_settings" -> "Listo. Abriendo ajustes del sistema."
                            "press_back" -> "Listo. Retrocediendo."
                            "press_home" -> "Listo. Volviendo a la pantalla principal."
                            "open_app" -> "Listo. Iniciando la aplicación solicitada."
                            else -> "Listo. Acción completada."
                        }
                        is SequencePlan -> "Listo. Secuencia de ${p.steps.size} pasos completada exitosamente."
                        is com.tunnel.turbo.model.TaskPlan -> "Listo. Tarea de ${p.steps.size} pasos completada exitosamente."
                        else -> "Listo. Acción completada."
                    }
                } else {
                    when {
                        res.providerState == ProviderState.RATE_LIMITED ->
                            "El proveedor está temporalmente ocupado. Por favor, intenta de nuevo en unos instantes."
                        res.providerState == ProviderState.OFFLINE ->
                            "El servicio de asistencia remota no está disponible actualmente."
                        res.routeDecision == RouteDecision.UNSUPPORTED ->
                            "No pude reconocer esa instrucción: ${res.error ?: "no soportada"}."
                        else ->
                            "No pude conectar con el modelo en este momento. Estoy intentando recuperar la conexión."
                    }
                }

                val resolvedAction = when (val p = res.plan) {
                    is ActionPlan -> p.action
                    is SequencePlan -> "sequence(${p.steps.size})"
                    is com.tunnel.turbo.model.TaskPlan -> "task(${p.steps.size})"
                    else -> "none"
                }
                val coreAction = res.executionResult?.actionSummary ?: "none"
                val verification = if (res.success) "SUCCESS" else (res.error ?: "FAILED")

                val assistantMsg = ConversationMessage(
                    role = MessageRole.ASSISTANT,
                    text = assistantText,
                    route = Route.ANDROID_DIRECT,
                    turnStatus = if (res.success) TurnStatus.COMPLETED_VERIFIED else TurnStatus.FAILED,
                    provenance = "Android Direct · $resolvedAction",
                    latencyMs = res.totalMs,
                    actionSummary = coreAction,
                    verificationExplanation = if (res.success) "Ejecutado y verificado directamente" else res.error
                )

                val core = providerRuntime.coreAdapter.nativeCore
                val finalRev = core.stateEngine.currentState.revision
                val jCount = core.journal.size()

                val debugBlock = """
[$reqTag]
input = "$cleaned" (src: $source)
route = ${res.routeDecision} | action = $resolvedAction | plan = ${res.plan?.type ?: "none"}
core_action = $coreAction | verification = $verification | total = ${String.format("%.1f", res.totalMs)}ms
                """.trimIndent()

                val trace = com.tunnel.turbo.devtools.RequestTrace(
                    requestId = res.requestId,
                    input = cleaned,
                    route = res.routeDecision.name,
                    provider = "LOCAL_ROUTER",
                    planType = res.plan?.type ?: "none",
                    capabilitiesUsed = when (val p = res.plan) {
                        is ActionPlan -> listOf(p.action)
                        is SequencePlan -> p.steps.map { it.action }
                        is com.tunnel.turbo.model.TaskPlan -> p.steps.map { it.tool }
                        else -> emptyList()
                    },
                    stepResults = listOf(mapOf("summary" to coreAction, "success" to res.success)),
                    initialRevision = initialRev,
                    finalRevision = finalRev,
                    verification = verification,
                    totalMs = res.totalMs,
                    error = res.error
                )
                devToolsBridge.recordTrace(trace)

                _uiState.update { curr ->
                    curr.copy(
                        isBusy = false,
                        statusMessage = if (res.success) "Listo" else "Atención requerida",
                        conversation = curr.conversation + assistantMsg,
                        debugState = curr.debugState.copy(
                            lastRequestId = res.requestId,
                            lastRoute = res.routeDecision.name,
                            lastPlan = res.plan?.type ?: "none",
                            lastActionSummary = coreAction,
                            lastVerification = verification,
                            lastLatencyMs = res.totalMs,
                            stateEngineRevision = finalRev,
                            journalEventCount = jCount,
                            logOutput = "$debugBlock\n\n${curr.debugState.logOutput}"
                        )
                    )
                }
            } else {
                // Route unprogrammed goals to GeneralAgentRuntime (Parity with DevTools)
                val core = providerRuntime.coreAdapter.nativeCore
                val agentRuntime = core.agentRuntime
                val localPlannerReady = !com.tunnel.turbo.agent.GeneralAgentRuntime.strictRealProviderMode && ensureModelLoaded()
                if (localPlannerReady) {
                    agentRuntime.setReasoningProvider(com.tunnel.turbo.agent.LocalModelReasoningProvider(localChatEngine))
                    _uiState.update { it.copy(statusMessage = "Planificando con modelo local…") }
                } else {
                    agentRuntime.useDefaultReasoningProvider()
                }
                val agentResult = core.agentRuntime.executeUserGoal(cleaned)

                // Section 23: Human Response Composer based on GoalOutcome
                val assistantText = when (agentResult.outcome) {
                    com.tunnel.turbo.agent.GoalOutcome.COMPLETED_VERIFIED -> {
                        if (agentResult.message.isNotBlank() && !agentResult.message.contains("Objetivo alcanzado", ignoreCase = true)) {
                            "Listo. ${agentResult.message}"
                        } else {
                            "Listo."
                        }
                    }
                    com.tunnel.turbo.agent.GoalOutcome.PARTIAL -> {
                        "Avancé con la búsqueda para '${cleaned}', pero todavía no pude confirmar la reproducción activa."
                    }
                    com.tunnel.turbo.agent.GoalOutcome.NEEDS_USER -> {
                        agentResult.message.ifBlank { "¿A quién y qué quieres enviar?" }
                    }
                    com.tunnel.turbo.agent.GoalOutcome.NOT_UNDERSTOOD -> {
                        "No entendí qué acción quieres que haga."
                    }
                    com.tunnel.turbo.agent.GoalOutcome.NOT_POSSIBLE -> {
                        "No encontré una forma disponible de hacerlo."
                    }
                    com.tunnel.turbo.agent.GoalOutcome.FAILED -> {
                        if (agentResult.failureReason == com.tunnel.turbo.agent.FailureReason.TIMEOUT ||
                            agentResult.message.contains("provider", ignoreCase = true) ||
                            agentResult.message.contains("STRICT", ignoreCase = true)) {
                            "No pude consultar al modelo en este momento."
                        } else {
                            "No pude completar la solicitud: ${agentResult.message}"
                        }
                    }
                    else -> "No se pudo completar la operación."
                }

                val agentStatus = when (agentResult.outcome) {
                    com.tunnel.turbo.agent.GoalOutcome.COMPLETED_VERIFIED -> TurnStatus.COMPLETED_VERIFIED
                    com.tunnel.turbo.agent.GoalOutcome.COMPLETED_UNVERIFIED -> TurnStatus.COMPLETED_UNVERIFIED
                    else -> TurnStatus.FAILED
                }
                val assistantMsg = ConversationMessage(
                    role = MessageRole.ASSISTANT,
                    text = assistantText,
                    route = Route.ANDROID_AGENT,
                    turnStatus = agentStatus,
                    provenance = "Agente ${agentRuntime.reasoningProvider.name} · ${agentResult.steps.lastOrNull()?.capability ?: "Evaluación"}",
                    latencyMs = agentResult.totalElapsedMs,
                    actionSummary = agentResult.message,
                    verificationExplanation = "Resultado: ${agentResult.outcome.name} (${String.format("%.0f", agentResult.totalElapsedMs)}ms)"
                )
                val finalRev = core.stateEngine.currentState.revision
                val jCount = core.journal.size()

                val debugBlock = """
[$reqTag]
input = "$cleaned" (src: $source)
route = AI_REQUIRED | goal = ${agentResult.goalId} | plan = AGENT_ADAPTIVE
aiRounds = ${agentResult.aiRounds} | steps = ${agentResult.steps.size} | outcome = ${agentResult.outcome.name} | total = ${String.format("%.1f", agentResult.totalElapsedMs)}ms
                """.trimIndent()

                val trace = com.tunnel.turbo.devtools.RequestTrace(
                    requestId = agentResult.goalId,
                    input = cleaned,
                    route = "AI_REQUIRED",
                    provider = "CHATGPT_WORKER",
                    planType = "AGENT_ADAPTIVE",
                    capabilitiesUsed = agentResult.steps.map { it.capability },
                    stepResults = agentResult.steps.map {
                        mapOf("summary" to "${it.capability}(${it.arguments})", "success" to ((it.executionResult["success"] as? Boolean) ?: true))
                    },
                    initialRevision = initialRev,
                    finalRevision = finalRev,
                    verification = agentResult.successType.name,
                    totalMs = agentResult.totalElapsedMs,
                    error = if (agentResult.success) null else agentResult.message
                )
                devToolsBridge.recordTrace(trace)

                _uiState.update { curr ->
                    curr.copy(
                        isBusy = false,
                        statusMessage = if (agentResult.success) "Listo" else "Atención requerida",
                        conversation = curr.conversation + assistantMsg,
                        debugState = curr.debugState.copy(
                            lastRequestId = agentResult.goalId,
                            lastRoute = "AI_REQUIRED",
                            lastPlan = "AGENT_ADAPTIVE",
                            lastActionSummary = agentResult.steps.lastOrNull()?.capability ?: "none",
                            lastVerification = agentResult.successType.name,
                            lastLatencyMs = agentResult.totalElapsedMs,
                            stateEngineRevision = finalRev,
                            journalEventCount = jCount,
                            logOutput = "$debugBlock\n\n${curr.debugState.logOutput}"
                        )
                    )
                }
            }
        }
    }

    private suspend fun handleGeminiResearchTurn(cleaned: String) {
        val apiKey = geminiKeyVault.read()
        if (apiKey.isNullOrBlank()) {
            val response = ConversationMessage(
                role = MessageRole.ASSISTANT,
                text = "Para buscar información actual necesito Gemini API. Configura una clave en Ajustes · Conexiones; después usaré búsqueda web automáticamente solo en consultas de investigación.",
                route = Route.RESEARCH,
                turnStatus = TurnStatus.UNSUPPORTED,
                provenance = "Búsqueda web no configurada"
            )
            _uiState.update { it.copy(isBusy = false, statusMessage = "Falta conectar búsqueda web", conversation = (it.conversation + response).takeLast(40)) }
            return
        }

        // Only the current request is sent to Google; the local transcript is not attached.
        val responseId = beginCloudChatTurn(cleaned, searched = true, userAlreadyInConversation = true)
        val streamed = StringBuilder()
        var lastPublishedAt = 0L
        try {
            val answer = geminiApiClient.generateChatTurnStream(apiKey, cleaned, emptyList(), useGoogleSearch = true) { chunk ->
                streamed.append(chunk)
                val now = android.os.SystemClock.elapsedRealtime()
                if (now - lastPublishedAt >= STREAMING_UI_INTERVAL_MS) {
                    lastPublishedAt = now
                    updateStreamingAssistant(responseId, streamed.toString())
                }
            }
            recordGeminiApiCheck(true, "Búsqueda grounded y respuesta recibidas", answer.model)
            appendCloudChatTurn(cleaned, answer.text, answer.elapsedMs, searched = true, sources = answer.sources, responseId = responseId, truncated = answer.truncated)
        } catch (error: Throwable) {
            if (error is kotlinx.coroutines.CancellationException) throw error
            val apiError = error as? com.tunnel.turbo.chat.GeminiApiException
            val friendly = apiError?.let {
                com.tunnel.turbo.chat.GeminiApiFailurePresenter.describe(it.httpStatus, it.apiStatus, it.message.orEmpty())
            } ?: "No se pudo completar la búsqueda web. Revisa la conexión Gemini en Ajustes · Conexiones."
            recordGeminiApiCheck(false, friendly)
            appendCloudChatFailure(cleaned, friendly, responseId = responseId, searched = true)
        }
    }

    // --- Debug Mode Simulator Actions ---

    fun simulateRateLimit() {
        val simState = CloudProviderState(
            status = CloudProviderStatus.RATE_LIMITED,
            providerId = "simulated_cloud_api",
            displayName = "API cloud (simulada)",
            evidenceOrSource = "Simulación manual de laboratorio",
            checkedAtMs = System.currentTimeMillis(),
            isSimulated = true
        )
        _uiState.update { curr ->
            curr.copy(
                debugState = curr.debugState.copy(
                    providerStatusText = "[SIMULACIÓN] API cloud (RATE_LIMITED)",
                    cloudProvider = simState,
                    logOutput = "[DEBUG SIMULATION] Estado de API cloud mostrado como RATE_LIMITED; salud real del runtime intacta\n${curr.debugState.logOutput}"
                )
            )
        }
    }

    fun simulateOffline() {
        val simState = CloudProviderState(
            status = CloudProviderStatus.OFFLINE,
            providerId = "simulated_cloud_api",
            displayName = "API cloud (simulada)",
            evidenceOrSource = "Simulación manual de laboratorio",
            checkedAtMs = System.currentTimeMillis(),
            isSimulated = true
        )
        _uiState.update { curr ->
            curr.copy(
                debugState = curr.debugState.copy(
                    providerStatusText = "[SIMULACIÓN] API cloud (OFFLINE)",
                    cloudProvider = simState,
                    logOutput = "[DEBUG SIMULATION] Estado de API cloud mostrado como OFFLINE; salud real del runtime intacta\n${curr.debugState.logOutput}"
                )
            )
        }
    }

    fun clearSimulatedProviderState() {
        val cloudState = CloudProviderState(
            status = CloudProviderStatus.NOT_CONFIGURED,
            providerId = "none",
            displayName = "Cloud API",
            evidenceOrSource = "No cloud API configured; local-first device architecture",
            isSimulated = false
        )
        _uiState.update { curr ->
            curr.copy(
                debugState = curr.debugState.copy(
                    providerStatusText = "Agente Android: ${providerRuntime.activeProvider?.javaClass?.simpleName?.removeSuffix("Provider") ?: "no configurado"} · sin prueba de ejecución",
                    cloudProvider = cloudState,
                    logOutput = "[DEBUG] Estado simulado de proveedor restaurado a real\n${curr.debugState.logOutput}"
                )
            )
        }
        refreshBridgesStatus()
    }

    private suspend fun handleChatTurn(cleaned: String, reqTag: String, source: String) {
        val t0 = System.currentTimeMillis()
        val responseId = java.util.UUID.randomUUID().toString()
        val streamedText = StringBuilder()
        var lastPublishedAt = 0L
        val pManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
        val thermalBefore = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            pManager?.currentThermalStatus
        } else null

        val memInfo = android.os.Debug.MemoryInfo()
        android.os.Debug.getMemoryInfo(memInfo)
        val nativeHeapKb = android.os.Debug.getNativeHeapAllocatedSize() / 1024L
        val peakPssKb = memInfo.totalPss.toLong()

        val placeholder = ConversationMessage(
            id = responseId,
            role = MessageRole.ASSISTANT,
            text = "",
            route = Route.LOCAL_CHAT,
            turnStatus = TurnStatus.GENERATING,
            provenance = "Local · ${selectedModelDisplayName()}"
        )
        val previousTurns = _uiState.value.conversation.dropLast(1).takeLast(MAX_CONTEXT_TURNS)
        val previousTurnPairs = previousTurns.mapNotNull { turn ->
            val role = when (turn.role) {
                MessageRole.USER -> "user"
                MessageRole.ASSISTANT -> "model"
                MessageRole.SYSTEM_STATUS -> null
            }
            role?.let { it to turn.text }
        }
        val previousContextPrompt = com.tunnel.turbo.chat.LocalChatContextBuilder.build(
            memory = conversationMemoryStore.read(),
            previousTurns = previousTurnPairs,
            currentRequest = cleaned
        )
        _uiState.update { state -> state.copy(statusMessage = "Preparando el modelo local…", conversation = state.conversation + placeholder) }
        ensureModelLoaded()
        _uiState.update { it.copy(statusMessage = "Generando respuesta local…") }
        val chatResult = conversationRuntime.submitTurn(cleaned, onChunk = { chunk ->
            streamedText.append(chunk)
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastPublishedAt >= STREAMING_UI_INTERVAL_MS) {
                lastPublishedAt = now
                updateStreamingAssistant(responseId, streamedText.toString())
            }
        }, systemPrompt = previousContextPrompt)
        val assistantText = if (chatResult.isSuccess) {
            chatResult.getOrNull() ?: "Listo."
        } else {
            if (!localChatEngine.isModelLoaded) {
                "El modelo de chat local no está cargado. Coloca el modelo en /sdcard/Download/Qwen3-0.6B.litertlm."
            } else {
                "No pude generar respuesta local: ${chatResult.exceptionOrNull()?.message ?: "error desconocido"}"
            }
        }

        val elapsed = (System.currentTimeMillis() - t0).toDouble()
        val assistantMsg = ConversationMessage(
            id = responseId,
            role = MessageRole.ASSISTANT,
            text = assistantText,
            route = Route.LOCAL_CHAT,
            turnStatus = if (chatResult.isSuccess) TurnStatus.GENERATED else TurnStatus.FAILED,
            provenance = "Local · ${localChatEngine.loadedModelPath?.substringAfterLast('/') ?: selectedLocalModelId} (${localChatEngine.backend})",
            latencyMs = elapsed
        )

        val thermalAfter = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            pManager?.currentThermalStatus
        } else null

        android.util.Log.i("IntentCoordinator", "Chat response for '$cleaned': $assistantText")

        val core = providerRuntime.coreAdapter.nativeCore
        val finalRev = core.stateEngine.currentState.revision
        val jCount = core.journal.size()

        val benchmark = conversationRuntime.lastBenchmarkInfo
        val metrics = conversationRuntime.lastTurnMetrics
        val modelSpec = com.tunnel.turbo.chat.LocalModelCatalog.get(context, selectedLocalModelId)
        val loadedFile = localChatEngine.loadedModelPath?.let { java.io.File(it) }
        val telemetry = com.tunnel.turbo.chat.InferenceTelemetry(
            requestId = reqTag,
            deviceModel = android.os.Build.MODEL ?: "UNAVAILABLE",
            deviceProduct = android.os.Build.PRODUCT ?: "UNAVAILABLE",
            deviceFingerprint = android.os.Build.FINGERPRINT ?: "UNAVAILABLE",
            runtimeName = "LiteRT-LM",
            runtimeVersion = "0.18.0",
            modelId = modelSpec?.id ?: selectedLocalModelId,
            modelRevision = modelSpec?.repository ?: "UNAVAILABLE",
            modelHash = modelSpec?.sha256 ?: "UNAVAILABLE",
            modelBytes = loadedFile?.takeIf { it.exists() }?.length() ?: modelSpec?.bytes ?: 0L,
            requestedBackend = preferredBackend.name,
            effectiveBackend = localChatEngine.backend.name,
            engineAlreadyLoaded = true,
            promptTokens = benchmark?.lastPrefillTokenCount,
            outputTokens = benchmark?.lastDecodeTokenCount ?: metrics?.outputTokens,
            ttftMs = benchmark?.let { it.timeToFirstTokenInSecond * 1000.0 } ?: metrics?.ttftMs,
            decodeMs = benchmark?.let { elapsed - (it.timeToFirstTokenInSecond * 1000.0) } ?: metrics?.decodeMs,
            totalMs = elapsed,
            prefillTokensPerSecond = benchmark?.lastPrefillTokensPerSecond,
            decodeTokensPerSecond = benchmark?.lastDecodeTokensPerSecond ?: metrics?.decodeTokensPerSecond,
            peakPssKb = peakPssKb,
            nativeHeapKb = nativeHeapKb,
            thermalStatusBefore = thermalBefore,
            thermalStatusAfter = thermalAfter,
            cancelled = false,
            success = chatResult.isSuccess
        )

        val chatOutcome = if (chatResult.isSuccess) "GENERATED" else "GENERATION_FAILED"
        val debugBlock = """
[$reqTag]
input = "$cleaned" (src: $source)
route = LOCAL_CHAT | model = ${localChatEngine.loadedModelPath ?: "none"}
backend = ${localChatEngine.backend} | outcome = $chatOutcome | total = ${String.format("%.1f", elapsed)}ms
ttft = ${String.format("%.1f", telemetry.ttftMs ?: 0.0)}ms | decodeRate = ${String.format("%.1f", telemetry.decodeTokensPerSecond ?: 0.0)}tok/s
        """.trimIndent()

        val trace = com.tunnel.turbo.devtools.RequestTrace(
            requestId = reqTag,
            input = cleaned,
            route = "LOCAL_CHAT",
            provider = "LITERT_LM_LOCAL",
            planType = "CHAT",
            capabilitiesUsed = emptyList(),
            stepResults = listOf(mapOf("assistantResponse" to assistantText)),
            initialRevision = finalRev,
            finalRevision = finalRev,
            verification = chatOutcome,
            totalMs = elapsed,
            error = if (chatResult.isSuccess) null else chatResult.exceptionOrNull()?.message,
            diagnostic = null,
            interactionMode = "CHAT",
            localChatEngineUsed = true,
            agentSessionUsed = false,
            capabilityCalls = 0,
            mutationLeaseAcquisitions = 0,
            inferenceTelemetry = telemetry
        )
        devToolsBridge.recordTrace(trace)

        _uiState.update { curr ->
            curr.copy(
                isBusy = false,
                statusMessage = if (chatResult.isSuccess) "Respuesta generada" else "Atención requerida",
                conversation = curr.conversation.map { if (it.id == responseId) assistantMsg else it },
                debugState = curr.debugState.copy(
                    lastVerification = chatOutcome,
                    lastLatencyMs = elapsed,
                    stateEngineRevision = finalRev,
                    journalEventCount = jCount,
                    logOutput = "$debugBlock\n\n${curr.debugState.logOutput}"
                )
            )
        }
    }

    companion object {
        private const val STREAMING_UI_INTERVAL_MS = 300L
        private const val MAX_CONTEXT_TURNS = 8
    }

    private fun handleClarifyTurn(cleaned: String, assessment: com.tunnel.turbo.local.LocalCognitiveAssessment, reqTag: String, source: String) {
        val clarifyText = assessment.unresolvedReferences.firstOrNull()?.let { "¿Puedes aclarar a qué te refieres con: $it?" }
            ?: "¿Puedes darme más detalles sobre lo que deseas hacer?"
        val assistantMsg = ConversationMessage(
            role = MessageRole.ASSISTANT,
            text = clarifyText,
            route = Route.CLARIFY,
            turnStatus = TurnStatus.NEEDS_CLARIFICATION,
            provenance = "Tunnel Turbo (Local Cognitive)"
        )

        val core = providerRuntime.coreAdapter.nativeCore
        val rev = core.stateEngine.currentState.revision
        val jCount = core.journal.size()

        val trace = com.tunnel.turbo.devtools.RequestTrace(
            requestId = reqTag,
            input = cleaned,
            route = "CLARIFY",
            provider = "LOCAL_COGNITIVE",
            planType = "CLARIFICATION",
            initialRevision = rev,
            finalRevision = rev,
            verification = "COMPLETED_VERIFIED",
            interactionMode = "CLARIFY",
            localChatEngineUsed = false,
            agentSessionUsed = false,
            capabilityCalls = 0,
            mutationLeaseAcquisitions = 0
        )
        devToolsBridge.recordTrace(trace)

        _uiState.update { curr ->
            curr.copy(
                isBusy = false,
                statusMessage = "Esperando aclaración",
                conversation = curr.conversation + assistantMsg,
                debugState = curr.debugState.copy(
                    stateEngineRevision = rev,
                    journalEventCount = jCount,
                    logOutput = "[$reqTag] (src: $source) CLARIFY: $clarifyText\n\n${curr.debugState.logOutput}"
                )
            )
        }
    }

    private fun handleUnsupportedModeTurn(cleaned: String, assessment: com.tunnel.turbo.local.LocalCognitiveAssessment, reqTag: String, source: String) {
        val mode = assessment.interactionMode
        val msgText = "La función de ${mode.name.lowercase()} no está implementada localmente en esta versión."
        val r = if (mode == com.tunnel.turbo.local.InteractionMode.RESEARCH) Route.RESEARCH else Route.WORK
        val assistantMsg = ConversationMessage(
            role = MessageRole.ASSISTANT,
            text = msgText,
            route = r,
            turnStatus = TurnStatus.UNSUPPORTED,
            provenance = "Tunnel Turbo (Sin ruta configurada)"
        )

        val core = providerRuntime.coreAdapter.nativeCore
        val rev = core.stateEngine.currentState.revision
        val jCount = core.journal.size()

        val trace = com.tunnel.turbo.devtools.RequestTrace(
            requestId = reqTag,
            input = cleaned,
            route = "UNSUPPORTED_MODE",
            provider = "LOCAL_COGNITIVE",
            planType = mode.name,
            initialRevision = rev,
            finalRevision = rev,
            verification = "UNSUPPORTED",
            interactionMode = mode.name,
            localChatEngineUsed = false,
            agentSessionUsed = false,
            capabilityCalls = 0,
            mutationLeaseAcquisitions = 0
        )
        devToolsBridge.recordTrace(trace)

        _uiState.update { curr ->
            curr.copy(
                isBusy = false,
                statusMessage = "Modo no soportado",
                conversation = curr.conversation + assistantMsg,
                debugState = curr.debugState.copy(
                    stateEngineRevision = rev,
                    journalEventCount = jCount,
                    logOutput = "[$reqTag] (src: $source) UNSUPPORTED: $mode\n\n${curr.debugState.logOutput}"
                )
            )
        }
    }

    var currentSemanticSnapshot: com.tunnel.turbo.accessibility.AccessibilitySnapshot? = null
        private set

    fun captureSemanticSnapshot(displayId: Int = 0): com.tunnel.turbo.accessibility.AccessibilitySnapshot {
        val snap = accessibilityBridge.getUiSnapshot(displayId, includeVisibleText = true)
        currentSemanticSnapshot = snap
        return snap
    }

    suspend fun actOnSelectedNode(
        node: com.tunnel.turbo.accessibility.UiNodeInfo,
        snapshot: com.tunnel.turbo.accessibility.AccessibilitySnapshot
    ): com.tunnel.turbo.agent.AgentTaskResult {
        val ageMs = snapshot.getSnapshotAgeMs()
        if (ageMs > 15_000L) {
            val failedGoal = com.tunnel.turbo.agent.Goal(
                goalId = "demo_stale_${System.currentTimeMillis()}",
                originalText = "Tocar nodo #${node.nodeId}",
                objective = "Actuar sobre nodo seleccionado",
                desiredState = "NODE_ACTION_COMPLETED",
                categoryHint = "SEMANTIC_NODE_ACTION"
            )
            return com.tunnel.turbo.agent.AgentTaskResult(
                goalId = failedGoal.goalId,
                sessionId = "stale_session",
                goal = failedGoal,
                success = false,
                successType = com.tunnel.turbo.agent.SuccessType.FAILED,
                failureReason = com.tunnel.turbo.agent.FailureReason.STALE_STATE,
                outcome = com.tunnel.turbo.agent.GoalOutcome.FAILED,
                message = "RECHAZADO POR NODO OBSOLETO: El snapshot tiene ${ageMs}ms de antigüedad (> 15s). Se requiere actualizar la observación antes de actuar.",
                steps = emptyList(),
                aiRounds = 0,
                aiRoundReasons = emptyList(),
                replansCount = 0,
                totalElapsedMs = 0.0,
                decisionSource = com.tunnel.turbo.agent.DecisionSource.DETERMINISTIC
            )
        }

        val nodeLabel = node.text.ifBlank { node.contentDescription.ifBlank { node.resourceId.ifBlank { "nodo_${node.nodeId}" } } }
        val goal = com.tunnel.turbo.agent.Goal(
            goalId = "demo_act_${System.currentTimeMillis()}",
            originalText = "Tocar $nodeLabel",
            objective = "Ejecutar acción semántica autorizada sobre nodo seleccionado en display ${snapshot.displayId}",
            desiredState = "NODE_ACTION_COMPLETED",
            categoryHint = "SEMANTIC_NODE_ACTION",
                entities = listOf(
                com.tunnel.turbo.agent.GoalEntity(type = "node_id", value = node.nodeId),
                com.tunnel.turbo.agent.GoalEntity(type = "bounds", value = node.bounds.take(4).joinToString(",")),
                com.tunnel.turbo.agent.GoalEntity(type = "text", value = node.text),
                com.tunnel.turbo.agent.GoalEntity(type = "resource_id", value = node.resourceId)
            )
        )

        val agentRuntime = providerRuntime.coreAdapter.nativeCore.agentRuntime
        val result = agentRuntime.executeGoal(goal, displayId = snapshot.displayId)

        // Capture fresh snapshot post-action to maintain synchronization
        runCatching { captureSemanticSnapshot(snapshot.displayId) }

        val outcomeTurnStatus = when (result.outcome) {
            com.tunnel.turbo.agent.GoalOutcome.COMPLETED_VERIFIED -> TurnStatus.COMPLETED_VERIFIED
            com.tunnel.turbo.agent.GoalOutcome.COMPLETED_UNVERIFIED -> TurnStatus.COMPLETED_UNVERIFIED
            else -> TurnStatus.FAILED
        }
        val assistantMsg = ConversationMessage(
            role = MessageRole.ASSISTANT,
            text = "Acción sobre el nodo #${node.nodeId}: ${result.message}",
            route = Route.ANDROID_AGENT,
            turnStatus = outcomeTurnStatus,
            provenance = "Android Agent · NodeAction",
            latencyMs = result.totalElapsedMs,
            actionSummary = "Nodo #${node.nodeId} ($nodeLabel)",
            verificationExplanation = result.message
        )
        _uiState.update { curr ->
            curr.copy(
                conversation = curr.conversation + assistantMsg
            )
        }

        return result
    }
}
