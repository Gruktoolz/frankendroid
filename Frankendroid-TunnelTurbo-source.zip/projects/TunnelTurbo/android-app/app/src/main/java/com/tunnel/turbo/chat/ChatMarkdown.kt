package com.tunnel.turbo.chat

import android.text.Spanned
import android.text.Html

/** Small safe renderer for the Markdown subset commonly emitted in chat. */
object ChatMarkdown {
    fun render(source: String): Spanned {
        return Html.fromHtml(toHtml(source), Html.FROM_HTML_MODE_COMPACT)
    }

    fun toHtml(source: String): String {
        val out = StringBuilder()
        var inCode = false
        var listTag: String? = null
        source.lines().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.startsWith("```")) {
                listTag?.let { out.append("</$it>") }
                listTag = null
                out.append(if (inCode) "</code></pre>" else "<pre><code>")
                inCode = !inCode
                return@forEach
            }
            if (inCode) {
                out.append(escape(line)).append("<br>")
                return@forEach
            }
            val bullet = trimmed.startsWith("- ") || trimmed.startsWith("* ")
            val orderedPrefix = Regex("^\\d+[.)]").find(trimmed)?.value?.takeIf {
                trimmed.drop(it.length).firstOrNull()?.isWhitespace() == true
            }
            val ordered = orderedPrefix != null
            val nextListTag = if (bullet) "ul" else null
            if (nextListTag != listTag) {
                listTag?.let { out.append("</$it>") }
                nextListTag?.let { out.append("<$it>") }
                listTag = nextListTag
            }
            val content = when {
                bullet -> trimmed.drop(2)
                ordered -> trimmed.drop(orderedPrefix!!.length).trimStart()
                else -> trimmed
            }
            val heading = content.takeWhile { it == '#' }.length.coerceAtMost(6)
            val body = inline(if (heading > 0) content.drop(heading).trimStart() else content)
            when {
                trimmed.isEmpty() -> out.append("<br>")
                bullet -> out.append("<li>").append(body).append("</li>")
                ordered -> out.append(escape(orderedPrefix!!)).append(" ").append(body).append("<br>")
                heading > 0 -> out.append("<h$heading>").append(body).append("</h$heading>")
                else -> out.append(body).append("<br>")
            }
        }
        listTag?.let { out.append("</$it>") }
        if (inCode) out.append("</code></pre>")
        return out.toString()
    }

    private fun inline(value: String): String {
        var formatted = escape(value)
            .replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>$1</b>")
            .replace(Regex("(?<!`)`([^`]+)`(?!`)"), "<tt>$1</tt>")
            .replace(Regex("~~(.+?)~~"), "<s>$1</s>")
        // A model can stop at its output limit while an emphasis marker is open.
        // Do not leak the unmatched Markdown delimiter into the visible transcript.
        if (Regex("\\*\\*").findAll(formatted).count() % 2 != 0) {
            val unmatched = formatted.lastIndexOf("**")
            if (unmatched >= 0) formatted = formatted.removeRange(unmatched, unmatched + 2)
        }
        return formatted
    }

    private fun escape(value: String) = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}
