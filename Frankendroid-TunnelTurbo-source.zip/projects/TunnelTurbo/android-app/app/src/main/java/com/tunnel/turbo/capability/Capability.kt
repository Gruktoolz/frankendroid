package com.tunnel.turbo.capability

import org.json.JSONObject

enum class CapabilityCategory {
    SYSTEM,
    APP,
    UI,
    OBSERVATION,
    NAVIGATION
}

enum class RiskLevel {
    READ_ONLY,
    NAVIGATION,
    TEXT_INPUT,
    SYSTEM_CHANGE
}

data class Capability(
    val id: String,
    val category: CapabilityCategory,
    val description: String,
    val argumentSchema: Map<String, String> = emptyMap(),
    val riskLevel: RiskLevel,
    val requiresShizuku: Boolean = false,
    val requiresAccessibility: Boolean = false,
    val requiresForeground: Boolean = false,
    val supportsVerification: Boolean = true,
    val available: Boolean = true
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("category", category.name)
        obj.put("description", description)
        val argsObj = JSONObject()
        for ((k, v) in argumentSchema) {
            argsObj.put(k, v)
        }
        obj.put("argumentSchema", argsObj)
        obj.put("riskLevel", riskLevel.name)
        obj.put("requiresShizuku", requiresShizuku)
        obj.put("requiresAccessibility", requiresAccessibility)
        obj.put("requiresForeground", requiresForeground)
        obj.put("supportsVerification", supportsVerification)
        obj.put("available", available)
        return obj
    }
}
