package com.tunnel.turbo.provider

class ProviderRegistry {
    private val providers = mutableMapOf<String, IntentProvider>()

    fun register(provider: IntentProvider) {
        providers[provider.name] = provider
    }

    fun get(name: String): IntentProvider? {
        return providers[name]
    }

    fun listAvailable(): List<String> {
        return providers.keys.toList()
    }
}
