package com.tunnel.turbo.agent

import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.accessibility.UiNodeInfo
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.capability.Capability
import com.tunnel.turbo.capability.CapabilityRegistry
import com.tunnel.turbo.core.NativeStateEngine
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

data class CandidateApp(
    val packageName: String,
    val label: String,
    val relevance: Double, // 0.0 to 1.0
    val knownSuccess: Int = 0,
    val currentAvailability: Boolean = true,
    val reason: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("packageName", packageName)
        put("label", label)
        put("relevance", relevance)
        put("knownSuccess", knownSuccess)
        put("currentAvailability", currentAvailability)
        put("reason", reason)
    }

    companion object {
        fun fromJson(json: JSONObject): CandidateApp = CandidateApp(
            packageName = json.optString("packageName", ""),
            label = json.optString("label", ""),
            relevance = json.optDouble("relevance", 0.0),
            knownSuccess = json.optInt("knownSuccess", 0),
            currentAvailability = json.optBoolean("currentAvailability", true),
            reason = json.optString("reason", "")
        )
    }
}

data class WorldSnapshot(
    val goalId: String,
    val foregroundPackage: String,
    val foregroundActivity: String,
    val candidateApps: List<CandidateApp>,
    val reducedObservation: ReducedObservation,
    val availableCapabilities: List<String>,
    val relevantSkills: List<String>,
    val timestamp: Long = System.currentTimeMillis(),
    val revision: Long = 1L,
    val displayId: Int = 0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("goalId", goalId)
        put("foregroundPackage", foregroundPackage)
        put("foregroundActivity", foregroundActivity)
        val cArr = JSONArray()
        candidateApps.forEach { cArr.put(it.toJson()) }
        put("candidateApps", cArr)
        put("reducedObservation", reducedObservation.toJson())
        val capArr = JSONArray()
        availableCapabilities.forEach { capArr.put(it) }
        put("availableCapabilities", capArr)
        val skArr = JSONArray()
        relevantSkills.forEach { skArr.put(it) }
        put("relevantSkills", skArr)
        put("timestamp", timestamp)
        put("revision", revision)
        put("displayId", displayId)
    }
}

class WorldModel(
    private val appManager: AppManager,
    private val capabilityRegistry: CapabilityRegistry,
    private val accessibilityBridge: AccessibilityBridge,
    private val stateEngine: NativeStateEngine,
    val skillMemory: SkillMemory
) {
    private val revisionCounter = java.util.concurrent.atomic.AtomicLong(1L)
    private val observationReducer = ObservationReducer()
    private val successfulAppChoices = ConcurrentHashMap<String, Int>() // domain/category -> packageName
    private val failurePatterns = ConcurrentHashMap<String, Int>()

    fun recordAppSuccess(category: String, packageName: String) {
        val key = "${category.lowercase()}_$packageName"
        successfulAppChoices[key] = (successfulAppChoices[key] ?: 0) + 1
    }

    fun recordFailurePattern(pattern: String) {
        failurePatterns[pattern] = (failurePatterns[pattern] ?: 0) + 1
    }

    // Dynamic environment discovery and relevance scoring
    fun discoverCandidateApps(goal: Goal): List<CandidateApp> {
        val installed = appManager.listInstalledApps()
        val candidates = mutableListOf<CandidateApp>()
        val lowerGoal = (goal.originalText + " " + goal.objective).lowercase()

        for (app in installed) {
            val pkg = app.packageName.lowercase()
            val lbl = app.label.lowercase()
            var relevance = 0.0
            var reason = ""

            // Music / Media discovery
            if (lowerGoal.contains("música") || lowerGoal.contains("musica") || lowerGoal.contains("escuchar") ||
                lowerGoal.contains("reproduce") || lowerGoal.contains("pon ") || goal.categoryHint == "MEDIA_PLAYBACK") {
                if (pkg.contains("spotify") || lbl.contains("spotify")) {
                    relevance = 0.95
                    reason = "Reproductor de streaming de música principal"
                } else if (pkg.contains("youtube") && !pkg.contains("music") || lbl.contains("youtube")) {
                    relevance = 0.75
                    reason = "Plataforma de video y audio"
                } else if (pkg.contains("music") || lbl.contains("música") || lbl.contains("musica")) {
                    relevance = 0.85
                    reason = "Aplicación de música detectada en el dispositivo"
                }
            }

            // Notes / Productivity discovery
            if (lowerGoal.contains("nota") || lowerGoal.contains("notes") || lowerGoal.contains("escribir") ||
                lowerGoal.contains("apunte") || goal.categoryHint == "PRODUCTIVITY") {
                if (pkg.contains("keep") || lbl.contains("keep")) {
                    relevance = 0.90
                    reason = "Aplicación de notas de Google"
                } else if (pkg.contains("note") || lbl.contains("nota") || lbl.contains("notes")) {
                    relevance = 0.85
                    reason = "Aplicación de notas del sistema/usuario"
                }
            }

            // Settings / System configuration discovery
            if (lowerGoal.contains("letra") || lowerGoal.contains("fuente") || lowerGoal.contains("tamaño") ||
                lowerGoal.contains("ajustes") || lowerGoal.contains("configura") || goal.categoryHint == "SYSTEM_SETTINGS") {
                if (pkg == "com.android.settings") {
                    relevance = 0.95
                    reason = "Configuración del sistema Android"
                }
            }

            // Photos / Gallery discovery (Section 15)
            if (lowerGoal.contains("foto") || lowerGoal.contains("fotos") || lowerGoal.contains("galería") ||
                lowerGoal.contains("galeria") || goal.categoryHint == "PHOTOS_GALLERY") {
                if (pkg.contains("gallery") || lbl.contains("galería") || lbl.contains("galeria") || lbl.contains("gallery")) {
                    relevance = 0.95
                    reason = "Galería de fotos del dispositivo"
                } else if (pkg.contains("photos") || lbl.contains("fotos") || lbl.contains("photos")) {
                    relevance = 0.90
                    reason = "Aplicación de fotos"
                }
            }

            // General keyword matching if not categorized
            if (relevance == 0.0) {
                for (entity in goal.entities) {
                    if (lbl.contains(entity.value.lowercase()) || pkg.contains(entity.value.lowercase())) {
                        relevance = 0.70
                        reason = "Coincidencia directa con entidad del objetivo: ${entity.value}"
                        break
                    }
                }
            }

            if (relevance > 0.0) {
                val historicalSuccessKey = "${goal.categoryHint?.lowercase() ?: "general"}_${app.packageName}"
                val pastSuccess = successfulAppChoices[historicalSuccessKey] ?: 0
                candidates.add(
                    CandidateApp(
                        packageName = app.packageName,
                        label = app.label,
                        relevance = minOf(1.0, relevance + (pastSuccess * 0.05)),
                        knownSuccess = pastSuccess,
                        currentAvailability = true,
                        reason = reason
                    )
                )
            }
        }

        return candidates.sortedByDescending { it.relevance }
    }

    fun createSnapshot(goal: Goal, displayId: Int = 0, explicitRevision: Long? = null): WorldSnapshot {
        // One root/tree query supplies package, activity, nodes and text for this revision.
        val accessibilitySnapshot = accessibilityBridge.getUiSnapshot(displayId)
        val accessibilityFgPkg = accessibilitySnapshot.foregroundPackage
        val displayState = stateEngine.getStateForDisplay(displayId)
        val fgPkg = if (accessibilityFgPkg.isNotBlank()) {
            accessibilityFgPkg
        } else if (displayState.foregroundPackage.isNotBlank() && displayState.displayId == displayId) {
            displayState.foregroundPackage
        } else {
            "UNKNOWN"
        }

        val accessibilityFgAct = accessibilitySnapshot.foregroundActivity
        val fgAct = if (accessibilityFgAct.isNotBlank()) {
            accessibilityFgAct
        } else if (displayState.displayId == displayId && displayState.foregroundPackage == fgPkg && displayState.foregroundActivity.isNotBlank()) {
            displayState.foregroundActivity
        } else {
            "UNKNOWN"
        }

        val rawNodes = accessibilitySnapshot.nodes
        val rawVisibleText = accessibilitySnapshot.visibleText

        val reducedObs = observationReducer.reduce(
            foregroundPackage = fgPkg,
            foregroundActivity = fgAct,
            allNodes = rawNodes,
            fullVisibleText = rawVisibleText
        )

        val candidateApps = discoverCandidateApps(goal)
        val availableCaps = capabilityRegistry.getAllCapabilities().map { it.id }
        val relevantSkills = skillMemory.getAllSkills()
            .filter { it.state == SkillState.ACTIVE || it.state == SkillState.VALIDATING || it.state == SkillState.PROPOSED }
            .map { it.name }

        val rev = explicitRevision ?: revisionCounter.getAndIncrement()

        return WorldSnapshot(
            goalId = goal.goalId,
            foregroundPackage = fgPkg,
            foregroundActivity = fgAct,
            candidateApps = candidateApps,
            reducedObservation = reducedObs,
            availableCapabilities = availableCaps,
            relevantSkills = relevantSkills,
            timestamp = System.currentTimeMillis(),
            revision = rev,
            displayId = displayId
        )
    }

    fun getStaticModelJson(): JSONObject = JSONObject().apply {
        val appArr = JSONArray()
        appManager.listInstalledApps().forEach {
            appArr.put(JSONObject().apply {
                put("packageName", it.packageName)
                put("label", it.label)
            })
        }
        put("installedAppsCount", appArr.length())
        put("installedApps", appArr)
        put("totalCapabilities", capabilityRegistry.getAllCapabilities().size)
        put("availableCapabilities", capabilityRegistry.getAllCapabilities().size)
    }

    fun getDynamicModelJson(displayId: Int = 0): JSONObject = JSONObject().apply {
        val s = stateEngine.getStateForDisplay(displayId)
        put("foregroundPackage", s.foregroundPackage)
        put("foregroundActivity", s.foregroundActivity)
        put("displayId", s.displayId)
        put("screenInteractive", s.screenInteractive)
        put("stateRevision", s.revision)
    }

    fun getLearnedModelJson(): JSONObject = JSONObject().apply {
        put("knownSkillsCount", skillMemory.getAllSkills().size)
        put("skillCandidatesCount", skillMemory.getAllCandidates().size)
        val scObj = JSONObject()
        successfulAppChoices.forEach { (k, v) -> scObj.put(k, v) }
        put("successfulAppChoices", scObj)
        val fpObj = JSONObject()
        failurePatterns.forEach { (k, v) -> fpObj.put(k, v) }
        put("failurePatterns", fpObj)
    }
}
