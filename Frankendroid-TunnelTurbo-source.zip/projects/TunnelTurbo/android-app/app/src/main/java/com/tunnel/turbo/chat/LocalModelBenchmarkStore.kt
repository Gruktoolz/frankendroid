package com.tunnel.turbo.chat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class LocalBenchmarkSample(
    val modelId: String,
    val backend: String,
    val totalMs: Long,
    val loadMs: Long,
    val ttftMs: Long?,
    val decodeTokensPerSecond: Double?,
    val pssKb: Long,
    val nativeHeapKb: Long,
    val thermalStatus: Int?,
    val batteryPercent: Int?,
    val batteryTemperatureC: Double?,
    val success: Boolean,
    val error: String? = null
) {
    fun toJson() = JSONObject().apply {
        put("modelId", modelId); put("backend", backend); put("totalMs", totalMs); put("loadMs", loadMs)
        put("ttftMs", ttftMs ?: JSONObject.NULL); put("decodeTokensPerSecond", decodeTokensPerSecond ?: JSONObject.NULL)
        put("pssKb", pssKb); put("nativeHeapKb", nativeHeapKb); put("thermalStatus", thermalStatus ?: JSONObject.NULL)
        put("batteryPercent", batteryPercent ?: JSONObject.NULL); put("batteryTemperatureC", batteryTemperatureC ?: JSONObject.NULL)
        put("success", success); put("error", error ?: JSONObject.NULL)
    }
}

data class LocalBenchmarkRun(val id: String, val startedAtMs: Long, val samples: List<LocalBenchmarkSample>) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("startedAtMs", startedAtMs)
        put("deviceModel", android.os.Build.MODEL ?: "UNAVAILABLE")
        put("deviceProduct", android.os.Build.PRODUCT ?: "UNAVAILABLE")
        put("runtime", "LiteRT-LM 0.18.0")
        put("gpuUtilization", "UNAVAILABLE: Android standard app API does not expose generic process GPU utilization")
        put("samples", JSONArray().apply { samples.forEach { put(it.toJson()) } })
    }
}

data class BackendBenchmarkSummary(val backend: String, val successfulRuns: Int, val totalRuns: Int, val medianTotalMs: Long?, val medianDecodeTokensPerSecond: Double?)

object LocalBenchmarkStatistics {
    fun summarize(samples: List<LocalBenchmarkSample>): List<BackendBenchmarkSummary> = samples.groupBy { it.backend }.map { (backend, rows) ->
        val valid = rows.filter { it.success }
        BackendBenchmarkSummary(backend, valid.size, rows.size, median(valid.map { it.totalMs }), median(valid.mapNotNull { it.decodeTokensPerSecond }))
    }

    fun <T : Comparable<T>> median(values: List<T>): T? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        return sorted[(sorted.size - 1) / 2]
    }
}

/** App-private append-only JSONL history for reproducible local comparisons. */
class LocalModelBenchmarkStore(context: Context) {
    private val file = File(context.filesDir, "benchmark-runs/local-model-runs.jsonl")
    @Synchronized fun save(run: LocalBenchmarkRun): File {
        check(file.parentFile?.mkdirs() == true || file.parentFile?.isDirectory == true)
        file.appendText(run.toJson().toString() + "\n")
        return file
    }

    fun history(): List<JSONObject> = if (!file.isFile) emptyList() else file.useLines { lines ->
        lines.filter { it.isNotBlank() }.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }.toList()
    }
}
