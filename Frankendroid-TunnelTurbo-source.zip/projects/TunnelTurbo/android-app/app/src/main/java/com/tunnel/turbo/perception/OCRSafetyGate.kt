package com.tunnel.turbo.perception

import android.graphics.Point
import android.graphics.Rect

sealed class GateDecision {
    data class Allowed(val targetPoint: Point, val reason: String) : GateDecision()
    data class Rejected(val reason: String, val code: String) : GateDecision()
}

object OCRSafetyGate {

    private const val MIN_OCR_CONFIDENCE = 0.25f
    private const val MAX_BOUNDS_AREA_RATIO = 0.85f // Avoid tapping full screen backgrounds

    fun evaluate(
        element: UnifiedElement,
        currentSnapshot: WorldSnapshot,
        displayWidth: Int = 1200,
        displayHeight: Int = 1920
    ): GateDecision {
        // 1. Stale revision check
        if (element.revision != currentSnapshot.revision) {
            return GateDecision.Rejected(
                reason = "Element revision (${element.revision}) does not match current snapshot revision (${currentSnapshot.revision})",
                code = "STALE_ELEMENT_REF"
            )
        }

        // 2. Display check
        if (element.displayId != currentSnapshot.displayId) {
            return GateDecision.Rejected(
                reason = "Element display (${element.displayId}) does not match snapshot display (${currentSnapshot.displayId})",
                code = "DISPLAY_MISMATCH"
            )
        }

        val bounds = element.boundsInternal
        // 3. Bounds validity check
        if (bounds.width() <= 0 || bounds.height() <= 0) {
            return GateDecision.Rejected(
                reason = "Invalid element bounds: $bounds",
                code = "INVALID_BOUNDS"
            )
        }

        // 4. Source-specific safety
        when (element.source) {
            ElementSource.ACCESSIBILITY, ElementSource.FUSED -> {
                // High confidence - accessibility semantics or fusion verified
                val pt = Point(bounds.centerX(), bounds.centerY())
                return GateDecision.Allowed(
                    targetPoint = pt,
                    reason = "Safe accessibility/fused element '${element.label}'"
                )
            }

            ElementSource.OCR -> {
                // OCR-only element: must verify plausible interaction target
                if (element.confidence > 0f && element.confidence < MIN_OCR_CONFIDENCE) {
                    return GateDecision.Rejected(
                        reason = "OCR confidence (${element.confidence}) below threshold ($MIN_OCR_CONFIDENCE)",
                        code = "LOW_CONFIDENCE"
                    )
                }

                val area = bounds.width().toLong() * bounds.height().toLong()
                val screenArea = displayWidth.toLong() * displayHeight.toLong()
                if (screenArea > 0 && (area.toFloat() / screenArea.toFloat()) > MAX_BOUNDS_AREA_RATIO) {
                    return GateDecision.Rejected(
                        reason = "OCR element occupies ${((area.toFloat() / screenArea.toFloat()) * 100).toInt()}% of screen, likely background",
                        code = "BOUNDS_TOO_LARGE"
                    )
                }

                if (element.label.isBlank()) {
                    return GateDecision.Rejected(
                        reason = "OCR element has empty text label",
                        code = "EMPTY_LABEL"
                    )
                }

                val pt = Point(bounds.centerX(), bounds.centerY())
                return GateDecision.Allowed(
                    targetPoint = pt,
                    reason = "OCR text target passed safety gate: '${element.label}' at $bounds"
                )
            }

            ElementSource.SYSTEM -> {
                val pt = Point(bounds.centerX(), bounds.centerY())
                return GateDecision.Allowed(
                    targetPoint = pt,
                    reason = "System element"
                )
            }

            ElementSource.VISUAL_REGION -> {
                return GateDecision.Rejected(
                    reason = "Direct visual region tap without semantic/text grounding is unverified",
                    code = "VISUAL_UNRESOLVED"
                )
            }
        }
    }
}
