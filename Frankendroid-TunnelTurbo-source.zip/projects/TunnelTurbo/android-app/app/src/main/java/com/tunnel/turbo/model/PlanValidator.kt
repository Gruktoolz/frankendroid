package com.tunnel.turbo.model

import org.json.JSONObject

class PlanValidationError(val code: String, message: String) : Exception("[$code] $message")

class PlanValidator {

    companion object {
        val ALLOWED_ACTIONS = setOf(
            "open_settings",
            "open_wifi_settings",
            "open_bluetooth_settings",
            "open_app",
            "press_key",
            "press_back",
            "press_home",
            "semantic_tap"
        )
        val ALLOWED_KEYS = setOf("BACK", "HOME", "ENTER")
        val ALLOWED_MATCH = setOf("single", "first")
    }

    fun validate(rawJson: String): StructuredPlan {
        val parsed = try {
            JSONObject(rawJson)
        } catch (e: Exception) {
            throw PlanValidationError("MALFORMED_JSON", "Invalid JSON format: ${e.message}")
        }
        return validate(parsed)
    }

    fun validate(json: JSONObject): StructuredPlan {
        val type = json.optString("type")
        if (type.isEmpty()) {
            throw PlanValidationError("MISSING_TYPE", "Plan is missing 'type' field")
        }

        return when (type) {
            "action" -> validateAction(json)
            "sequence" -> validateSequence(json)
            "task" -> validateTask(json)
            "needs_observation" -> validateNeedsObservation(json)
            "unsupported" -> validateUnsupported(json)
            else -> throw PlanValidationError("INVALID_PLAN_TYPE", "Unknown plan type: $type")
        }
    }

    private fun validateTask(json: JSONObject): TaskPlan {
        val stepsArr = json.optJSONArray("steps")
            ?: throw PlanValidationError("MISSING_STEPS", "Task plan missing 'steps' array")

        if (stepsArr.length() == 0) {
            throw PlanValidationError("EMPTY_TASK", "Task cannot be empty")
        }
        if (stepsArr.length() > 12) {
            throw PlanValidationError("TASK_TOO_LONG", "Task exceeds maximum 12 steps")
        }

        val stepList = mutableListOf<ToolStep>()
        for (i in 0 until stepsArr.length()) {
            val stepObj = stepsArr.optJSONObject(i)
                ?: throw PlanValidationError("INVALID_STEP", "Step $i is not a JSON object")

            val tool = stepObj.optString("tool").ifEmpty { stepObj.optString("action") }
            if (tool.isEmpty()) {
                throw PlanValidationError("MISSING_TOOL", "Step $i missing 'tool' field")
            }

            val argsObj = stepObj.optJSONObject("arguments") ?: JSONObject()
            val argsMap = mutableMapOf<String, Any?>()
            val it = argsObj.keys()
            while (it.hasNext()) {
                val k = it.next()
                argsMap[k] = argsObj.get(k)
            }

            // Safety validations per tool
            when (tool) {
                "click_node", "set_text" -> {
                    val ref = argsMap["ref"] as? String
                    val sel = argsMap["selector"]
                    val selStr = when {
                        !ref.isNullOrBlank() -> ref
                        sel is String -> sel
                        sel is Map<*, *> -> sel.values.joinToString(" ")
                        sel is JSONObject -> sel.toString()
                        else -> null
                    }
                    if (selStr.isNullOrBlank()) {
                        throw PlanValidationError("EMPTY_SELECTOR", "Tool '$tool' requires non-empty selector or ref")
                    }
                    if (ref.isNullOrBlank()) {
                        validateSelectorString(selStr)
                    }

                    if (tool == "set_text" && (argsMap["text"] as? String).isNullOrEmpty()) {
                        throw PlanValidationError("MISSING_ARGUMENT", "set_text requires 'text'")
                    }
                }

                "open_app" -> {
                    val pkg = argsMap["package"] as? String
                    if (pkg.isNullOrBlank()) {
                        throw PlanValidationError("MISSING_ARGUMENT", "open_app requires 'package'")
                    }
                }
                "resolve_app" -> {
                    val name = argsMap["name"] as? String
                    if (name.isNullOrBlank()) {
                        throw PlanValidationError("MISSING_ARGUMENT", "resolve_app requires 'name'")
                    }
                }
                "scroll" -> {
                    val dir = argsMap["direction"] as? String ?: "DOWN"
                    if (dir.uppercase() !in setOf("UP", "DOWN", "LEFT", "RIGHT")) {
                        throw PlanValidationError("INVALID_ARGUMENT", "scroll direction must be UP, DOWN, LEFT, or RIGHT")
                    }
                }
                "wait_for" -> {
                    val cond = argsMap["condition"] as? String
                    val v = argsMap["value"] as? String
                    if (cond.isNullOrBlank() || v == null) {
                        throw PlanValidationError("MISSING_ARGUMENT", "wait_for requires 'condition' and 'value'")
                    }
                }
            }

            stepList.add(ToolStep(tool = tool, arguments = argsMap))
        }

        return TaskPlan(steps = stepList)
    }

    private fun validateSelectorString(sel: String) {
        if (sel.contains(Regex("""\b(x|y)\s*[:=]\s*\d+""", RegexOption.IGNORE_CASE)) || sel.matches(Regex("""^\d+\s+\d+$"""))) {
            throw PlanValidationError("COORDINATES_FORBIDDEN", "Raw screen coordinates are strictly forbidden.")
        }
        val forbiddenPatterns = listOf(
            Regex("""\brm\b"""), Regex("""\bsh\b"""), Regex("""\bbash\b"""),
            Regex(";"), Regex("""\|"""), Regex("&&"), Regex(">"), Regex("<"), Regex("`")
        )
        for (p in forbiddenPatterns) {
            if (sel.contains(p)) {
                throw PlanValidationError("SHELL_INJECTION_DETECTED", "Dangerous character/pattern in selector")
            }
        }
    }

    private fun validateAction(json: JSONObject): ActionPlan {
        val action = json.optString("action")
        if (action.isEmpty()) {
            throw PlanValidationError("MISSING_ACTION", "Action plan missing 'action' field")
        }
        if (action !in ALLOWED_ACTIONS) {
            throw PlanValidationError("UNAUTHORIZED_ACTION", "Action '$action' is not in allowlist")
        }

        val argsObj = json.optJSONObject("arguments") ?: JSONObject()
        val argsMap = mutableMapOf<String, Any>()
        val it = argsObj.keys()
        while (it.hasNext()) {
            val k = it.next()
            argsMap[k] = argsObj.get(k)
        }

        val allowedArgsForAction = when (action) {
            "open_settings", "open_wifi_settings", "open_bluetooth_settings", "press_back", "press_home" -> emptySet()
            "open_app" -> setOf("package")
            "press_key" -> setOf("key")
            "semantic_tap" -> setOf("selector", "match")
            else -> emptySet()
        }

        for (k in argsMap.keys) {
            if (k !in allowedArgsForAction) {
                throw PlanValidationError("EXTRA_ARGUMENT", "Unexpected argument '$k' for action '$action'")
            }
        }

        when (action) {
            "open_app" -> {
                val pkg = argsMap["package"] as? String
                if (pkg.isNullOrBlank()) {
                    throw PlanValidationError("INVALID_ARGUMENT", "open_app requires non-empty 'package'")
                }
            }
            "press_key" -> {
                val key = argsMap["key"] as? String
                if (key !in ALLOWED_KEYS) {
                    throw PlanValidationError("INVALID_ARGUMENT", "press_key requires 'key' in $ALLOWED_KEYS")
                }
            }
            "semantic_tap" -> {
                val sel = argsMap["selector"] as? String
                if (sel.isNullOrBlank()) {
                    throw PlanValidationError("EMPTY_SELECTOR", "Semantic selector cannot be empty.")
                }
                if (sel.contains(Regex("""\b(x|y)\s*[:=]\s*\d+""", RegexOption.IGNORE_CASE)) || sel.matches(Regex("""^\d+\s+\d+$"""))) {
                    throw PlanValidationError("COORDINATES_FORBIDDEN", "Raw screen coordinates are strictly forbidden.")
                }
                val forbiddenPatterns = listOf(
                    Regex("""\brm\b"""), Regex("""\bsh\b"""), Regex("""\bbash\b"""),
                    Regex(";"), Regex("""\|"""), Regex("&&"), Regex(">"), Regex("<"), Regex("`")
                )
                for (p in forbiddenPatterns) {
                    if (sel.contains(p)) {
                        throw PlanValidationError("SHELL_INJECTION_DETECTED", "Dangerous character/pattern in selector")
                    }
                }
                if (!sel.startsWith("text=")) {
                    throw PlanValidationError("INVALID_ARGUMENT", "semantic_tap requires 'selector' starting with 'text='")
                }
                val match = argsMap["match"] as? String ?: "single"
                if (match !in ALLOWED_MATCH) {
                    throw PlanValidationError("INVALID_ARGUMENT", "semantic_tap 'match' must be 'single' or 'first'")
                }
            }
            "open_settings", "open_wifi_settings", "open_bluetooth_settings", "press_back", "press_home" -> {
                // Must not have unexpected arguments
            }
        }

        return ActionPlan(action = action, arguments = argsMap)
    }

    private fun validateSequence(json: JSONObject): SequencePlan {
        val stepsArr = json.optJSONArray("steps")
            ?: throw PlanValidationError("MISSING_STEPS", "Sequence plan missing 'steps' array")

        if (stepsArr.length() == 0) {
            throw PlanValidationError("EMPTY_SEQUENCE", "Sequence cannot be empty")
        }
        if (stepsArr.length() > 10) {
            throw PlanValidationError("SEQUENCE_TOO_LONG", "Sequence exceeds maximum 10 steps")
        }

        val stepList = mutableListOf<ActionPlan>()
        for (i in 0 until stepsArr.length()) {
            val stepObj = stepsArr.optJSONObject(i)
                ?: throw PlanValidationError("INVALID_STEP", "Step $i is not a JSON object")
            
            // Check if stepObj has type=action or implied action
            val actName = stepObj.optString("action")
            if (actName.isEmpty()) {
                throw PlanValidationError("MISSING_ACTION", "Step $i missing 'action'")
            }
            val stepWrapper = JSONObject()
            stepWrapper.put("type", "action")
            stepWrapper.put("action", actName)
            stepWrapper.put("arguments", stepObj.optJSONObject("arguments") ?: JSONObject())
            stepList.add(validateAction(stepWrapper))
        }

        return SequencePlan(steps = stepList)
    }

    private fun validateNeedsObservation(json: JSONObject): NeedsObservationPlan {
        val reason = json.optString("reason", "Needs on-screen observation")
        return NeedsObservationPlan(reason = reason)
    }

    private fun validateUnsupported(json: JSONObject): UnsupportedPlan {
        val reason = json.optString("reason", "Command is unsupported or outside safe allowlist")
        return UnsupportedPlan(reason = reason)
    }
}
