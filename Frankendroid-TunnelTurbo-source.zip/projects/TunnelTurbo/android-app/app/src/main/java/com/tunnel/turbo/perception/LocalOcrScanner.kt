package com.tunnel.turbo.perception

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LocalOcrScanner {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun scanBitmap(
        sourceBitmap: Bitmap,
        cropRect: Rect? = null,
        targetWidth: Int = 720
    ): List<OcrElement> = withContext(Dispatchers.Default) {
        val t0 = System.currentTimeMillis()

        // 1. Crop if requested (Gap-First strategy)
        val workingBitmap = if (cropRect != null) {
            val safeLeft = cropRect.left.coerceIn(0, sourceBitmap.width - 1)
            val safeTop = cropRect.top.coerceIn(0, sourceBitmap.height - 1)
            val safeWidth = cropRect.width().coerceIn(1, sourceBitmap.width - safeLeft)
            val safeHeight = cropRect.height().coerceIn(1, sourceBitmap.height - safeTop)
            Bitmap.createBitmap(sourceBitmap, safeLeft, safeTop, safeWidth, safeHeight)
        } else {
            sourceBitmap
        }

        val originalW = workingBitmap.width
        val originalH = workingBitmap.height

        // 2. Downscale to 720p-equivalent preserving aspect ratio if necessary
        val scaleFactor = if (originalW > targetWidth) {
            targetWidth.toFloat() / originalW.toFloat()
        } else {
            1.0f
        }

        val scaledBitmap = if (scaleFactor < 1.0f) {
            val scaledH = (originalH * scaleFactor).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(workingBitmap, targetWidth, scaledH, true)
        } else {
            workingBitmap
        }

        val inputImage = InputImage.fromBitmap(scaledBitmap, 0)

        // 3. Execute ML Kit synchronous task on Dispatchers.Default
        val ocrElements = mutableListOf<OcrElement>()
        try {
            val result = Tasks.await(recognizer.process(inputImage))
            var elemIdx = 0

            for (block in result.textBlocks) {
                for (line in block.lines) {
                    val box = line.boundingBox
                    if (box != null && line.text.isNotBlank()) {
                        // Map coordinates back to original display space
                        val unscaledLeft = (box.left / scaleFactor).toInt() + (cropRect?.left ?: 0)
                        val unscaledTop = (box.top / scaleFactor).toInt() + (cropRect?.top ?: 0)
                        val unscaledRight = (box.right / scaleFactor).toInt() + (cropRect?.left ?: 0)
                        val unscaledBottom = (box.bottom / scaleFactor).toInt() + (cropRect?.top ?: 0)

                        val mappedBox = Rect(unscaledLeft, unscaledTop, unscaledRight, unscaledBottom)
                        elemIdx++
                        ocrElements.add(
                            OcrElement(
                                id = "ocr_$elemIdx",
                                text = line.text.trim(),
                                boundingBox = mappedBox,
                                confidence = null, // ML Kit Latin TextBlock does not expose uniform confidence; null per Section 16
                                rotation = 0
                            )
                        )
                    }
                }
            }
        } catch (t: Throwable) {
            android.util.Log.e("LocalOcrScanner", "ML Kit OCR failed: ${t.message}")
        } finally {
            if (scaledBitmap != workingBitmap) {
                scaledBitmap.recycle()
            }
            if (workingBitmap != sourceBitmap) {
                workingBitmap.recycle()
            }
        }

        android.util.Log.d("LocalOcrScanner", "Local OCR completed in ${System.currentTimeMillis() - t0}ms, found ${ocrElements.size} elements")
        return@withContext ocrElements
    }

    fun close() {
        try {
            recognizer.close()
        } catch (ignored: Throwable) {}
    }
}
