package com.tunnel.turbo.agent

import org.json.JSONObject
import java.util.UUID

enum class DecisionSource {
    DETERMINISTIC,
    LOCAL_HEURISTIC,
    LOCAL_MODEL,
    SKILL,
    REAL_PROVIDER,
    USER,
    TEST_FIXTURE,
    MOCK;

    companion object {
        // Compatibility aliases for previous references
        val LOCAL get() = LOCAL_HEURISTIC
        val AI get() = REAL_PROVIDER
    }
}

enum class GoalOutcome {
    ANSWERED,
    COMPLETED_VERIFIED,
    COMPLETED_UNVERIFIED,
    PARTIAL,
    NEEDS_USER,
    NOT_UNDERSTOOD,
    NOT_POSSIBLE,
    FAILED,
    CANCELLED
}

enum class SuccessType {
    SUCCESS_VERIFIED,
    SUCCESS_UNVERIFIED,
    PARTIAL_SUCCESS,
    FAILED
}

enum class FailureReason {
    NONE,
    APP_NOT_FOUND,
    UI_NOT_FOUND,
    AMBIGUOUS,
    PROVIDER_LIMITED,
    STEP_FAILED,
    TIMEOUT,
    GOAL_NOT_VERIFIABLE,
    USER_INPUT_REQUIRED,
    BUDGET_EXCEEDED,
    STALE_STATE
}

data class AgentStep(
    val stepId: String,
    val goalId: String,
    val stepIndex: Int,
    val decisionSource: DecisionSource,
    val capability: String,
    val arguments: Map<String, Any?>,
    val executionResult: Map<String, Any?>,
    val observationBefore: String,
    val observationAfter: String,
    val verification: String,
    val durationMs: Double,
    val providerCallId: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("stepId", stepId)
        put("goalId", goalId)
        put("stepIndex", stepIndex)
        put("decisionSource", decisionSource.name)
        if (providerCallId != null) put("providerCallId", providerCallId)
        put("capability", capability)
        val aObj = JSONObject()
        arguments.forEach { (k, v) -> aObj.put(k, v) }
        put("arguments", aObj)
        val rObj = JSONObject()
        executionResult.forEach { (k, v) -> rObj.put(k, v) }
        put("executionResult", rObj)
        put("observationBefore", observationBefore)
        put("observationAfter", observationAfter)
        put("verification", verification)
        put("durationMs", durationMs)
    }
}

data class AgentTaskResult(
    val goalId: String,
    val sessionId: String = "session_${UUID.randomUUID().toString().take(8)}",
    val goal: Goal,
    val success: Boolean,
    val successType: SuccessType,
    val failureReason: FailureReason = FailureReason.NONE,
    val message: String,
    val steps: List<AgentStep>,
    val aiRounds: Int,
    val aiRoundReasons: List<String>,
    val replansCount: Int,
    val skillUsed: String? = null,
    val candidateAppSelected: CandidateApp? = null,
    val skillCandidateCreated: SkillCandidate? = null,
    val totalElapsedMs: Double,
    val hardcodedShortcutsUsed: Int = 0, // Stays strictly 0 for general agent tests
    val diagnostic: com.tunnel.turbo.devtools.FailureDiagnostic? = null,
    val budget: AgentBudget? = null,
    val outcome: GoalOutcome = when (successType) {
        SuccessType.SUCCESS_VERIFIED -> GoalOutcome.COMPLETED_VERIFIED
        SuccessType.SUCCESS_UNVERIFIED -> GoalOutcome.COMPLETED_UNVERIFIED
        SuccessType.PARTIAL_SUCCESS -> GoalOutcome.PARTIAL
        SuccessType.FAILED -> when (failureReason) {
            FailureReason.USER_INPUT_REQUIRED -> GoalOutcome.NEEDS_USER
            else -> GoalOutcome.FAILED
        }
    },
    val decisionSource: DecisionSource = DecisionSource.LOCAL_HEURISTIC,
    val providerCallId: String? = null,
    val proofNonce: String? = null,
    val goalEvidence: GoalEvidence? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("goalId", goalId)
        put("sessionId", sessionId)
        put("goal", goal.toJson())
        put("success", success)
        put("successType", successType.name)
        put("outcome", outcome.name)
        put("failureReason", failureReason.name)
        put("message", message)
        put("decisionSource", decisionSource.name)
        if (providerCallId != null) put("providerCallId", providerCallId)
        if (proofNonce != null) put("proofNonce", proofNonce)
        val sArr = org.json.JSONArray()
        steps.forEach { sArr.put(it.toJson()) }
        put("steps", sArr)
        put("stepsCount", steps.size)
        put("aiRounds", aiRounds)
        val airArr = org.json.JSONArray()
        aiRoundReasons.forEach { airArr.put(it) }
        put("aiRoundReasons", airArr)
        put("replansCount", replansCount)
        if (skillUsed != null) put("skillUsed", skillUsed)
        if (candidateAppSelected != null) put("candidateAppSelected", candidateAppSelected.toJson())
        if (skillCandidateCreated != null) put("skillCandidateCreated", skillCandidateCreated.toJson())
        put("totalElapsedMs", totalElapsedMs)
        put("hardcodedShortcutsUsed", hardcodedShortcutsUsed)
        if (diagnostic != null) put("diagnostic", diagnostic.toJson())
        if (budget != null) put("budget", budget.toJson())
        if (goalEvidence != null) put("goalEvidence", goalEvidence.toJson())
    }
}
