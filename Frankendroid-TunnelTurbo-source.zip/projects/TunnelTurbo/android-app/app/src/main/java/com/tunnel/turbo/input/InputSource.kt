package com.tunnel.turbo.input

/**
 * Abstraction for user input sources in Tunnel Turbo.
 * Allows Phase 8 to operate purely on TEXT while preparing future phases
 * for VOICE, AUDIO_FILE, and EXTERNAL_INTENT without re-architecting the pipeline.
 */
enum class InputSource {
    TEXT,
    VOICE,
    AUDIO_FILE,
    EXTERNAL_INTENT
}
