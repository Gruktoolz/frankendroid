package com.tunnel.turbo.chat

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Thin in-memory Conversation Runtime managing conversational state, message history,
 * bounded context, and local generation.
 *
 * Technical Invariant:
 * ConversationRuntime holds ZERO references to Android capability executors,
 * mutation arbiters, or AgentSession. It is technically incapable of mutating the device.
 */
class ConversationRuntime(
    val chatEngine: LocalChatEngine,
    val maxHistoryTurns: Int = 10,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) : AutoCloseable {

    companion object {
        private const val TAG = "ConversationRuntime"
    }

    val threadId: String = UUID.randomUUID().toString()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _sessionState = MutableStateFlow(ChatSessionState.IDLE)
    val sessionState: StateFlow<ChatSessionState> = _sessionState.asStateFlow()

    var activeProfile: LocalChatProfile = LocalChatProfile.FAST

    var lastBenchmarkInfo: SessionBenchmark? = null
        private set

    var lastTurnMetrics: TurnMetrics? = null
        private set

    private var activeChatSession: LocalChatSession? = null
    private var activeGenerationJob: Job? = null

    /**
     * Ensures an active chat session is initialized with the specified profile.
     */
    suspend fun getOrCreateSession(
        profile: LocalChatProfile = activeProfile,
        systemPrompt: String? = null
    ): LocalChatSession = withContext(Dispatchers.Default) {
        activeChatSession?.let { return@withContext it }

        if (!chatEngine.isModelLoaded) {
            _sessionState.value = ChatSessionState.ERROR
            error("Cannot start chat session: Model is not loaded in LocalChatEngine.")
        }

        val session = chatEngine.startSession(profile, systemPrompt)
        activeChatSession = session
        _sessionState.value = ChatSessionState.READY
        session
    }

    /**
     * Submits a user message, updates conversation state, and streams the assistant response.
     * Guaranteed: Chat processing does NOT invoke any Android actions.
     */
    suspend fun submitTurn(
        userText: String,
        profile: LocalChatProfile = activeProfile,
        onChunk: ((String) -> Unit)? = null,
        systemPrompt: String? = null
    ): Result<String> = withContext(Dispatchers.Default) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Message cannot be blank"))
        }

        // Append USER message
        val userMsg = ChatMessage(role = ChatMessage.MessageRole.USER, text = trimmed)
        appendMessageBounded(userMsg)

        val session = try {
            getOrCreateSession(profile = profile, systemPrompt = systemPrompt)
        } catch (e: Exception) {
            _sessionState.value = ChatSessionState.ERROR
            val errMsg = ChatMessage(role = ChatMessage.MessageRole.ASSISTANT, text = "Error: Modelo local no disponible.")
            appendMessageBounded(errMsg)
            return@withContext Result.failure(e)
        }

        _sessionState.value = ChatSessionState.GENERATING

        val assistantMsgId = UUID.randomUUID().toString()
        val fullResponse = StringBuilder()
        var genError: Throwable? = null
        var firstTokenTime: Long? = null
        var tokenCount = 0
        val tStart = System.currentTimeMillis()

        val generationJob = launch {
            try {
                session.sendMessage(trimmed).collect { chunk ->
                    if (chunk.isNotEmpty()) {
                        if (firstTokenTime == null) {
                            firstTokenTime = System.currentTimeMillis()
                        }
                        tokenCount++
                        fullResponse.append(chunk)
                        onChunk?.invoke(chunk)
                    }
                }
            } catch (ce: CancellationException) {
                Log.d(TAG, "Generation cancelled by user for turn.")
                throw ce
            } catch (e: Throwable) {
                Log.e(TAG, "Error during chat generation", e)
                genError = e
            }
        }
        activeGenerationJob = generationJob

        try {
            generationJob.join()

            val tEnd = System.currentTimeMillis()
            val ttft = if (firstTokenTime != null) (firstTokenTime!! - tStart).toDouble() else (tEnd - tStart).toDouble()
            val decodeDuration = if (firstTokenTime != null) (tEnd - firstTokenTime!!).toDouble() else 0.0
            lastTurnMetrics = TurnMetrics(
                // LiteRT-LM emits text chunks, not token IDs. Token counts/rates
                // must come from the native benchmark API or remain unavailable.
                outputChunks = tokenCount,
                ttftMs = ttft,
                decodeMs = decodeDuration,
                totalMs = (tEnd - tStart).toDouble(),
                outputTokens = null,
                decodeTokensPerSecond = null
            )

            lastBenchmarkInfo = session.getBenchmarkInfo()

            if (generationJob.isCancelled) {
                _sessionState.value = ChatSessionState.READY
                val partialText = if (fullResponse.isNotEmpty()) fullResponse.toString() else "[Generación cancelada]"
                appendMessageBounded(ChatMessage(id = assistantMsgId, role = ChatMessage.MessageRole.ASSISTANT, text = partialText))
                return@withContext Result.success(partialText)
            }

            if (genError != null) {
                _sessionState.value = ChatSessionState.ERROR
                activeChatSession?.close()
                activeChatSession = null
                val errText = "Error al generar respuesta local: ${genError?.message ?: "error desconocido"}"
                appendMessageBounded(ChatMessage(id = assistantMsgId, role = ChatMessage.MessageRole.ASSISTANT, text = errText))
                return@withContext Result.failure(genError!!)
            }

            val finalText = fullResponse.toString()
            appendMessageBounded(ChatMessage(id = assistantMsgId, role = ChatMessage.MessageRole.ASSISTANT, text = finalText))
            _sessionState.value = ChatSessionState.READY
            Result.success(finalText)
        } catch (ce: CancellationException) {
            _sessionState.value = ChatSessionState.READY
            val partialText = if (fullResponse.isNotEmpty()) fullResponse.toString() else "[Generación cancelada]"
            appendMessageBounded(ChatMessage(id = assistantMsgId, role = ChatMessage.MessageRole.ASSISTANT, text = partialText))
            Result.success(partialText)
        } catch (e: Exception) {
            _sessionState.value = ChatSessionState.ERROR
            val errText = "Error al generar respuesta local."
            appendMessageBounded(ChatMessage(id = assistantMsgId, role = ChatMessage.MessageRole.ASSISTANT, text = errText))
            Result.failure(e)
        } finally {
            activeGenerationJob = null
        }
    }

    /**
     * Cancels active generation gracefully without destroying conversation session.
     */
    fun cancelGeneration() {
        activeGenerationJob?.let { job ->
            if (job.isActive) {
                job.cancel()
                _sessionState.value = ChatSessionState.READY
            }
        }
        activeGenerationJob = null
    }

    /**
     * Appends message while maintaining bounded turn history.
     */
    private fun appendMessageBounded(msg: ChatMessage) {
        val current = _messages.value.toMutableList()
        current.add(msg)
        // Bounded retention: keep at most maxHistoryTurns * 2 messages (user + assistant pairs)
        val maxMessages = maxHistoryTurns * 2
        val bounded = if (current.size > maxMessages) {
            current.takeLast(maxMessages)
        } else {
            current
        }
        _messages.value = bounded
    }

    fun clearConversation() {
        cancelGeneration()
        activeChatSession?.close()
        activeChatSession = null
        _messages.value = emptyList()
        _sessionState.value = if (chatEngine.isModelLoaded) ChatSessionState.READY else ChatSessionState.IDLE
    }

    /** Recreate the model conversation on the next turn while preserving the persisted UI transcript. */
    suspend fun resetActiveSessionPreservingHistory() = withContext(Dispatchers.Default) {
        cancelGeneration()
        activeChatSession?.close()
        activeChatSession = null
        _sessionState.value = if (chatEngine.isModelLoaded) ChatSessionState.READY else ChatSessionState.IDLE
    }

    override fun close() {
        cancelGeneration()
        activeChatSession?.close()
        activeChatSession = null
        chatEngine.close()
        _sessionState.value = ChatSessionState.IDLE
    }
}

data class TurnMetrics(
    val outputChunks: Int,
    val ttftMs: Double,
    val decodeMs: Double,
    val totalMs: Double,
    val outputTokens: Int? = null,
    val decodeTokensPerSecond: Double? = null
)

