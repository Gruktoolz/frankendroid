package com.tunnel.turbo.devtools

import org.json.JSONArray
import org.json.JSONObject

data class RequestTrace(
    val requestId: String,
    val input: String,
    val route: String,
    val provider: String,
    val planType: String,
    val capabilitiesUsed: List<String> = emptyList(),
    val stepResults: List<Map<String, Any?>> = emptyList(),
    val initialRevision: Long = 0L,
    val finalRevision: Long = 0L,
    val verification: String = "SUCCESS",
    val totalMs: Double = 0.0,
    val error: String? = null,
    val diagnostic: FailureDiagnostic? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val interactionMode: String = "ACTION",
    val localChatEngineUsed: Boolean = false,
    val agentSessionUsed: Boolean = false,
    val capabilityCalls: Int = 0,
    val mutationLeaseAcquisitions: Int = 0,
    val inferenceTelemetry: com.tunnel.turbo.chat.InferenceTelemetry? = null
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("requestId", requestId)
        obj.put("input", input)
        obj.put("route", route)
        obj.put("provider", provider)
        obj.put("planType", planType)
        val capsArr = JSONArray()
        for (c in capabilitiesUsed) capsArr.put(c)
        obj.put("capabilitiesUsed", capsArr)
        val stepsArr = JSONArray()
        for (s in stepResults) {
            val sObj = JSONObject()
            for ((k, v) in s) sObj.put(k, v)
            stepsArr.put(sObj)
        }
        obj.put("stepResults", stepsArr)
        obj.put("initialRevision", initialRevision)
        obj.put("finalRevision", finalRevision)
        obj.put("verification", verification)
        obj.put("totalMs", totalMs)
        if (error != null) obj.put("error", error)
        if (diagnostic != null) obj.put("diagnostic", diagnostic.toJson())
        obj.put("timestamp", timestamp)
        obj.put("interactionMode", interactionMode)
        obj.put("localChatEngineUsed", localChatEngineUsed)
        obj.put("agentSessionUsed", agentSessionUsed)
        obj.put("capabilityCalls", capabilityCalls)
        obj.put("mutationLeaseAcquisitions", mutationLeaseAcquisitions)
        if (inferenceTelemetry != null) obj.put("inferenceTelemetry", inferenceTelemetry.toJson())
        return obj
    }
}
