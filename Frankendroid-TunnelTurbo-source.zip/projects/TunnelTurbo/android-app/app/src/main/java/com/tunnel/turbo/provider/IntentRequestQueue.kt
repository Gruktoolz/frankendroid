package com.tunnel.turbo.provider

import com.tunnel.turbo.model.StructuredPlan
import java.util.concurrent.ConcurrentLinkedQueue

enum class RequestState {
    QUEUED,
    ROUTING,
    WAITING_PROVIDER,
    PLANNED,
    EXECUTING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class IntentRequest(
    val requestId: String,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
    val priority: Int = 0,
    var provider: String = "chatgpt",
    var state: RequestState = RequestState.QUEUED,
    var attempts: Int = 0,
    var plan: StructuredPlan? = null,
    var error: String? = null
)

class IntentRequestQueue {
    private val queue = ConcurrentLinkedQueue<IntentRequest>()
    private val activeRequests = mutableMapOf<String, IntentRequest>()

    fun enqueue(request: IntentRequest): IntentRequest {
        queue.add(request)
        activeRequests[request.requestId] = request
        return request
    }

    fun pollNext(): IntentRequest? {
        return queue.poll()
    }

    fun peek(): IntentRequest? {
        return queue.peek()
    }

    fun getRequest(id: String): IntentRequest? {
        return activeRequests[id]
    }

    val size: Int
        get() = queue.size

    val isEmpty: Boolean
        get() = queue.isEmpty()

    fun updateState(id: String, newState: RequestState, plan: StructuredPlan? = null, error: String? = null) {
        val req = activeRequests[id] ?: return
        req.state = newState
        if (plan != null) req.plan = plan
        if (error != null) req.error = error
    }
}
