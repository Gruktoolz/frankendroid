package com.tunnel.turbo.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.tunnel.turbo.accessibility.AccessibilitySnapshot
import com.tunnel.turbo.accessibility.UiNodeInfo
import com.tunnel.turbo.perception.OcrElement
import kotlin.math.max
import kotlin.math.min

/**
 * SemanticDisplayMapView:
 * Native Android View for comparing a captured display with accessibility and OCR results.
 *
 * Conforms to North Star Principles:
 * - Single snapshot ownership: Consumes identical snapshot revision as the Agent.
 * - Captures only on explicit refresh; pixels remain in memory and are never persisted here.
 * - Simple scaled display outline maintaining real display aspect ratio.
 * - Distinct window layer borders.
 * - Selectable numbered node bounds (1-indexed badges).
 * - Non-overlapping optional text/description labels.
 * - Single-tap hit-testing to select a node and notify adjacent inspector.
 */
class SemanticDisplayMapView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class ViewMode { SCREEN, ACCESSIBILITY, OCR, COMBINED }

    var viewMode: ViewMode = ViewMode.ACCESSIBILITY
        set(value) { field = value; invalidate() }

    var screenBitmap: Bitmap? = null
        set(value) { field = value; invalidate() }

    var ocrElements: List<OcrElement> = emptyList()
        set(value) { field = value; invalidate() }

    var snapshot: AccessibilitySnapshot? = null
        set(value) {
            field = value
            if (value != null && selectedNodeId != null) {
                // Verify if selected node is still present in fresh snapshot
                val stillExists = value.nodes.any { it.nodeId == selectedNodeId }
                if (!stillExists) {
                    selectedNodeId = null
                    onNodeSelectedListener?.invoke(null)
                }
            }
            invalidate()
        }

    var showLabels: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var selectedNodeId: String? = null
        private set

    var onNodeSelectedListener: ((UiNodeInfo?) -> Unit)? = null

    // Paints
    private val bgPaint = Paint().apply {
        color = Color.parseColor("#121212")
        style = Paint.Style.FILL
    }

    private val displayBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#37474F")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val displayFillPaint = Paint().apply {
        color = Color.parseColor("#181818")
        style = Paint.Style.FILL
    }

    private val windowBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
    }

    private val nodeBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#546E7A") // Default inactive node border
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val actionableNodeBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676") // Actionable node (clickable/editable)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val selectedNodePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD600") // Selected node
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val selectedNodeFillPaint = Paint().apply {
        color = Color.parseColor("#33FFD600")
        style = Paint.Style.FILL
    }

    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC212121")
        style = Paint.Style.FILL
    }

    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676")
        textSize = 22f
        typeface = Typeface.MONOSPACE
        isFakeBoldText = true
    }

    private val selectedBadgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD600")
        textSize = 24f
        typeface = Typeface.MONOSPACE
        isFakeBoldText = true
    }

    private val labelTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFFFFF")
        textSize = 20f
        typeface = Typeface.DEFAULT
    }

    private val labelBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EE263238")
        style = Paint.Style.FILL
    }

    private val messageTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#90A4AE")
        textSize = 28f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT
    }

    // Geometry calculations
    private val displayBoundsRectF = RectF()
    private var scaleFactor: Float = 1.0f
    private var offsetX: Float = 0f
    private var offsetY: Float = 0f

    // Window layer distinct color palette
    private val windowColors = intArrayOf(
        Color.parseColor("#42A5F5"), // Window layer 0: Blue
        Color.parseColor("#AB47BC"), // Window layer 1: Purple
        Color.parseColor("#26A69A"), // Window layer 2: Teal
        Color.parseColor("#FFA726"), // Window layer 3: Orange
        Color.parseColor("#EC407A")  // Window layer 4: Pink
    )

    fun selectNode(nodeId: String?) {
        selectedNodeId = nodeId
        val foundNode = snapshot?.nodes?.firstOrNull { it.nodeId == nodeId }
        onNodeSelectedListener?.invoke(foundNode)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val currentSnap = snapshot
        if (currentSnap == null || (currentSnap.nodes.isEmpty() && viewMode == ViewMode.ACCESSIBILITY)) {
            val emptyMsg = if (currentSnap == null) {
                "Sin snapshot cargado.\nToca 'Actualizar' para consultar la pantalla."
            } else {
                "Snapshot vacío (0 nodos).\nVerifica que el servicio esté activo y en una app interactiva."
            }
            val lines = emptyMsg.split("\n")
            val midY = height / 2f
            for ((i, line) in lines.withIndex()) {
                canvas.drawText(line, width / 2f, midY + (i * 36f) - (lines.size * 18f), messageTextPaint)
            }
            return
        }

        // Calculate scaling preserving aspect ratio
        val dWidth = if (currentSnap.displayWidth > 0) currentSnap.displayWidth.toFloat() else 1080f
        val dHeight = if (currentSnap.displayHeight > 0) currentSnap.displayHeight.toFloat() else 2400f

        val padding = 16f
        val availWidth = width - (padding * 2)
        val availHeight = height - (padding * 2)

        scaleFactor = min(availWidth / dWidth, availHeight / dHeight)
        val scaledW = dWidth * scaleFactor
        val scaledH = dHeight * scaleFactor

        offsetX = padding + (availWidth - scaledW) / 2f
        offsetY = padding + (availHeight - scaledH) / 2f

        displayBoundsRectF.set(offsetX, offsetY, offsetX + scaledW, offsetY + scaledH)

        // 1. Draw captured pixels for modes that expose visual input.
        val bitmap = screenBitmap
        if (viewMode != ViewMode.ACCESSIBILITY && bitmap != null && !bitmap.isRecycled) {
            canvas.save()
            canvas.clipRect(displayBoundsRectF)
            canvas.drawBitmap(bitmap, null, displayBoundsRectF, null)
            canvas.restore()
        } else {
            canvas.drawRoundRect(displayBoundsRectF, 12f, 12f, displayFillPaint)
        }
        canvas.drawRoundRect(displayBoundsRectF, 12f, 12f, displayBorderPaint)
        if (viewMode == ViewMode.SCREEN) return
        if (viewMode == ViewMode.OCR || viewMode == ViewMode.COMBINED) drawOcr(canvas)
        if (viewMode == ViewMode.OCR) return

        // 2. Draw distinct window boundaries if available
        if (currentSnap.windows.isNotEmpty()) {
            for ((wIdx, win) in currentSnap.windows.withIndex()) {
                val color = windowColors[wIdx % windowColors.size]
                windowBorderPaint.color = color
                val wRect = toViewRectF(win.bounds)
                if (wRect.intersect(displayBoundsRectF)) {
                    canvas.drawRect(wRect, windowBorderPaint)
                }
            }
        }

        // 3. Draw nodes: unselected first, then selected on top
        var selectedNode: UiNodeInfo? = null
        var selectedIndex = -1

        for ((index, node) in currentSnap.nodes.withIndex()) {
            if (node.nodeId == selectedNodeId) {
                selectedNode = node
                selectedIndex = index
                continue
            }
            drawNode(canvas, node, index + 1, isSelected = false)
        }

        // Draw selected node highlighted on top
        if (selectedNode != null && selectedIndex >= 0) {
            drawNode(canvas, selectedNode, selectedIndex + 1, isSelected = true)
        }
    }

    private fun drawOcr(canvas: Canvas) {
        val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFCA28")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#3328CAFF")
            style = Paint.Style.FILL
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 18f
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
        }
        for ((index, element) in ocrElements.withIndex()) {
            val b = element.boundingBox
            val rect = toViewRectF(listOf(b.left, b.top, b.right, b.bottom))
            if (rect.width() <= 1f || rect.height() <= 1f || !RectF.intersects(rect, displayBoundsRectF)) continue
            canvas.drawRect(rect, fillPaint)
            canvas.drawRect(rect, boxPaint)
            val labelTop = max(displayBoundsRectF.top, rect.top - 21f)
            canvas.drawText("O${index + 1}", rect.left + 2f, labelTop + 17f, textPaint)
        }
    }

    private fun toViewRectF(bounds: List<Int>): RectF {
        if (bounds.size < 4) return RectF()
        return RectF(
            offsetX + (bounds[0] * scaleFactor),
            offsetY + (bounds[1] * scaleFactor),
            offsetX + (bounds[2] * scaleFactor),
            offsetY + (bounds[3] * scaleFactor)
        )
    }

    private fun drawNode(canvas: Canvas, node: UiNodeInfo, badgeNumber: Int, isSelected: Boolean) {
        val nodeBounds = toViewRectF(node.bounds)

        // Skip degenerate bounds outside display
        if (nodeBounds.width() <= 2f || nodeBounds.height() <= 2f) return
        if (!RectF.intersects(nodeBounds, displayBoundsRectF)) return

        // Node bounding box
        if (isSelected) {
            canvas.drawRect(nodeBounds, selectedNodeFillPaint)
            canvas.drawRect(nodeBounds, selectedNodePaint)
        } else {
            val paint = if (node.clickable || node.editable || node.scrollable) actionableNodeBorderPaint else nodeBorderPaint
            canvas.drawRect(nodeBounds, paint)
        }

        // Badge [N]
        val badgeText = "[$badgeNumber]"
        val textPaint = if (isSelected) selectedBadgeTextPaint else badgeTextPaint
        val textWidth = textPaint.measureText(badgeText)
        val badgeHeight = 26f
        val badgeWidth = textWidth + 8f

        val badgeLeft = nodeBounds.left
        val badgeTop = max(displayBoundsRectF.top, nodeBounds.top - badgeHeight)
        val badgeRect = RectF(badgeLeft, badgeTop, badgeLeft + badgeWidth, badgeTop + badgeHeight)

        canvas.drawRoundRect(badgeRect, 4f, 4f, badgeBgPaint)
        canvas.drawText(badgeText, badgeLeft + 4f, badgeTop + badgeHeight - 6f, textPaint)

        // Non-overlapping optional label
        if (showLabels) {
            val labelStr = node.text.ifBlank {
                node.contentDescription.ifBlank {
                    node.resourceId.substringAfterLast('/')
                }
            }.trim().take(18)

            if (labelStr.isNotEmpty()) {
                val labelWidth = labelTextPaint.measureText(labelStr)
                val labelHeight = 24f
                val labelLeft = badgeRect.right + 4f
                val labelTop = badgeTop
                val labelRight = min(displayBoundsRectF.right, labelLeft + labelWidth + 8f)

                if (labelRight > labelLeft + 16f) {
                    val labelRect = RectF(labelLeft, labelTop, labelRight, labelTop + labelHeight)
                    canvas.drawRoundRect(labelRect, 4f, 4f, labelBgPaint)
                    canvas.save()
                    canvas.clipRect(labelRect)
                    canvas.drawText(labelStr, labelLeft + 4f, labelTop + labelHeight - 6f, labelTextPaint)
                    canvas.restore()
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            if (viewMode != ViewMode.ACCESSIBILITY && viewMode != ViewMode.COMBINED) return true
            val currentSnap = snapshot ?: return super.onTouchEvent(event)
            val touchX = event.x
            val touchY = event.y

            if (!displayBoundsRectF.contains(touchX, touchY)) {
                return super.onTouchEvent(event)
            }

            // Convert view coordinate to screen coordinate
            val screenX = ((touchX - offsetX) / scaleFactor).toInt()
            val screenY = ((touchY - offsetY) / scaleFactor).toInt()

            // Find all nodes whose bounds contain the touch point
            val hitNodes = currentSnap.nodes.filter {
                it.bounds.size >= 4 && screenX >= it.bounds[0] && screenX <= it.bounds[2] && screenY >= it.bounds[1] && screenY <= it.bounds[3]
            }

            if (hitNodes.isNotEmpty()) {
                // If multiple nodes contain the tap:
                // If current selected node is in hitNodes, cycle to the next one;
                // otherwise pick the smallest node (deepest leaf in tree).
                val chosenNode = if (selectedNodeId != null && hitNodes.any { it.nodeId == selectedNodeId }) {
                    val currIdx = hitNodes.indexOfFirst { it.nodeId == selectedNodeId }
                    hitNodes[(currIdx + 1) % hitNodes.size]
                } else {
                    hitNodes.minByOrNull { (it.bounds[2] - it.bounds[0]).coerceAtLeast(0) * (it.bounds[3] - it.bounds[1]).coerceAtLeast(0) } ?: hitNodes.first()
                }

                selectedNodeId = chosenNode.nodeId
                onNodeSelectedListener?.invoke(chosenNode)
                invalidate()
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
