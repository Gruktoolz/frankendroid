package com.tunnel.turbo.agent

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.media.AudioManager
import android.net.wifi.WifiManager
import com.tunnel.turbo.accessibility.AccessibilityBridge
import org.json.JSONArray
import org.json.JSONObject

enum class MediaEvidenceStatus {
    AVAILABLE,
    NO_ACTIVE_SESSION,
    PERMISSION_UNAVAILABLE,
    METADATA_UNAVAILABLE,
    UNSUPPORTED
}

data class MediaEvidenceResult(
    val status: MediaEvidenceStatus,
    val evidence: MediaPlaybackEvidence? = null,
    val reason: String? = null
)

interface MediaEvidenceSource {
    fun getCurrentEvidence(): MediaEvidenceResult
}

class AndroidMediaSessionEvidenceSource(
    private val context: Context?
) : MediaEvidenceSource {
    override fun getCurrentEvidence(): MediaEvidenceResult {
        if (context == null) {
            return MediaEvidenceResult(MediaEvidenceStatus.UNSUPPORTED, reason = "Context unavailable")
        }
        try {
            val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? android.media.session.MediaSessionManager
                ?: return MediaEvidenceResult(MediaEvidenceStatus.UNSUPPORTED, reason = "MediaSessionManager unavailable")

            val sessions = try {
                msm.getActiveSessions(null)
            } catch (se: SecurityException) {
                return MediaEvidenceResult(MediaEvidenceStatus.PERMISSION_UNAVAILABLE, reason = "Lacks permission for getActiveSessions: ${se.message}")
            }

            if (sessions.isNullOrEmpty()) {
                return MediaEvidenceResult(MediaEvidenceStatus.NO_ACTIVE_SESSION, reason = "No active media sessions")
            }

            for (controller in sessions) {
                val pbState = controller.playbackState
                val isPlaying = pbState?.state == android.media.session.PlaybackState.STATE_PLAYING
                val metadata = controller.metadata
                if (metadata != null) {
                    val title = metadata.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
                    val artist = metadata.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
                    val album = metadata.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM)
                    val mediaId = metadata.getString(android.media.MediaMetadata.METADATA_KEY_MEDIA_ID)
                    val pkg = controller.packageName

                    val evidence = MediaPlaybackEvidence(
                        playbackActive = isPlaying,
                        sessionPackage = pkg,
                        title = title,
                        artist = artist,
                        album = album,
                        mediaId = mediaId,
                        evidenceSource = "MEDIA_SESSION_CONTROLLER",
                        observedAtMs = System.currentTimeMillis()
                    )
                    return MediaEvidenceResult(MediaEvidenceStatus.AVAILABLE, evidence = evidence)
                }
            }
            return MediaEvidenceResult(MediaEvidenceStatus.METADATA_UNAVAILABLE, reason = "Active session found but metadata unavailable")
        } catch (t: Throwable) {
            return MediaEvidenceResult(MediaEvidenceStatus.UNSUPPORTED, reason = t.message)
        }
    }
}

data class MediaPlaybackEvidence(
    val playbackActive: Boolean,
    val sessionPackage: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val mediaId: String? = null,
    val evidenceSource: String = "AUDIO_MANAGER",
    val observedAtMs: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("playbackActive", playbackActive)
        if (sessionPackage != null) put("sessionPackage", sessionPackage)
        if (title != null) put("title", title)
        if (artist != null) put("artist", artist)
        if (album != null) put("album", album)
        if (mediaId != null) put("mediaId", mediaId)
        put("evidenceSource", evidenceSource)
        put("observedAtMs", observedAtMs)
    }
}

data class ExecutionReceipt(
    val routeId: String,
    val entityMatched: Boolean,
    val details: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("routeId", routeId)
        put("entityMatched", entityMatched)
        if (details != null) put("details", details)
        put("timestamp", timestamp)
    }
}

data class GoalEvidence(
    val foregroundPackage: String = "",
    val foregroundActivity: String = "",
    val visibleTexts: List<String> = emptyList(),
    val isMusicActive: Boolean = false,
    val isBluetoothEnabled: Boolean? = null,
    val isWifiEnabled: Boolean? = null,
    val mediaEvidence: MediaPlaybackEvidence? = null,
    val executionReceipts: List<ExecutionReceipt> = emptyList(),
    val displayId: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("foregroundPackage", foregroundPackage)
        put("foregroundActivity", foregroundActivity)
        val tArr = JSONArray()
        visibleTexts.forEach { tArr.put(it) }
        put("visibleTexts", tArr)
        put("isMusicActive", isMusicActive)
        if (isBluetoothEnabled != null) put("isBluetoothEnabled", isBluetoothEnabled)
        if (isWifiEnabled != null) put("isWifiEnabled", isWifiEnabled)
        if (mediaEvidence != null) put("mediaEvidence", mediaEvidence.toJson())
        if (executionReceipts.isNotEmpty()) {
            val rArr = JSONArray()
            executionReceipts.forEach { rArr.put(it.toJson()) }
            put("executionReceipts", rArr)
        }
        put("displayId", displayId)
        put("timestamp", timestamp)
    }
}

data class GoalVerificationResult(
    val outcome: GoalOutcome,
    val confidence: Double,
    val satisfied: Boolean,
    val explanation: String,
    val evidenceUsed: GoalEvidence
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("outcome", outcome.name)
        put("confidence", confidence)
        put("satisfied", satisfied)
        put("explanation", explanation)
        put("evidenceUsed", evidenceUsed.toJson())
    }
}

class GoalVerifier(
    private val context: Context? = null,
    private val accessibilityBridge: AccessibilityBridge? = null,
    private val mediaEvidenceSource: MediaEvidenceSource? = null
) {
    companion object {
        const val MAX_MEDIA_FRESHNESS_MS = 30000L // 30s freshness window relative to verification boundary (Section 17)
        var lastVerification: GoalVerificationResult? = null
            private set
    }

    private val effectiveMediaSource: MediaEvidenceSource =
        mediaEvidenceSource ?: AndroidMediaSessionEvidenceSource(context)

    private val packageRegex = Regex("^[a-zA-Z0-9_]+(\\.[a-zA-Z0-9_]+)+$")

    private fun canonicalNormalize(s: String): String =
        s.trim().lowercase().replace(Regex("[^a-z0-9áéíóúñ ]"), " ").replace(Regex("\\s+"), " ")

    private fun matchesEntityCanonical(expected: String, actual: String?): Boolean {
        if (actual.isNullOrBlank()) return false
        val expNorm = canonicalNormalize(expected)
        val actNorm = canonicalNormalize(actual)
        if (expNorm == actNorm) return true
        val pattern = Regex("\\b${Regex.escape(expNorm)}\\b")
        return pattern.containsMatchIn(actNorm)
    }

    fun gatherEvidence(displayId: Int = 0): GoalEvidence {
        var fgPkg = ""
        var fgAct = ""
        val texts = mutableListOf<String>()

        if (accessibilityBridge != null && accessibilityBridge.isEnabled()) {
            fgPkg = accessibilityBridge.getForegroundPackage(displayId)
            val nodes = accessibilityBridge.getUiNodes(displayId)
            for (n in nodes) {
                if (n.text.isNotBlank()) texts.add(n.text.trim())
                else if (n.contentDescription.isNotBlank()) texts.add(n.contentDescription.trim())
            }
        }

        var musicActive = false
        var btEnabled: Boolean? = null
        var wifiEnabled: Boolean? = null

        if (context != null) {
            try {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                musicActive = am?.isMusicActive == true
            } catch (t: Throwable) {}

            try {
                val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
                val adapter = bm?.adapter ?: BluetoothAdapter.getDefaultAdapter()
                btEnabled = adapter?.isEnabled
            } catch (t: Throwable) {}

            try {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                wifiEnabled = wm?.isWifiEnabled
            } catch (t: Throwable) {}
        }

        // Section 15: Gather independent media evidence from MediaEvidenceSource
        val mediaResult = effectiveMediaSource.getCurrentEvidence()
        val mediaEv = mediaResult.evidence

        return GoalEvidence(
            foregroundPackage = fgPkg,
            foregroundActivity = fgAct,
            visibleTexts = texts.distinct().take(50),
            isMusicActive = musicActive || (mediaEv?.playbackActive == true),
            isBluetoothEnabled = btEnabled,
            isWifiEnabled = wifiEnabled,
            mediaEvidence = mediaEv,
            displayId = displayId
        )
    }

    fun verify(
        goal: Goal,
        evidence: GoalEvidence,
        stepsExecuted: List<AgentStep>
    ): GoalVerificationResult {
        // Rule B: COMPLETED_VERIFIED strictly requires:
        // 1. desiredState defined
        // 2. observable evidence gathered
        // 3. GoalVerifier evaluates that evidence
        // 4. evidence strictly satisfies desiredState

        val result = when {
            goal.categoryHint == "CONVERSATIONAL_NON_OPERATIONAL" -> {
                GoalVerificationResult(
                    outcome = GoalOutcome.NOT_UNDERSTOOD,
                    confidence = 1.0,
                    satisfied = false,
                    explanation = "Frase no operativa detectada. No se ejecutó ninguna acción en el dispositivo.",
                    evidenceUsed = evidence
                )
            }

            goal.categoryHint == "INCOMPLETE_REQUEST" -> {
                GoalVerificationResult(
                    outcome = GoalOutcome.NEEDS_USER,
                    confidence = 1.0,
                    satisfied = false,
                    explanation = "Instrucción incompleta. Se requiere destinatario y contenido del mensaje.",
                    evidenceUsed = evidence
                )
            }

            goal.categoryHint == "MEDIA_PLAYBACK" || goal.desiredState.contains("reproduciéndose", ignoreCase = true) -> {
                val media = evidence.mediaEvidence
                val executionProved = evidence.executionReceipts.any { it.entityMatched }

                val hasAnyEntities = goal.entities.isNotEmpty()
                val isGeneric = !hasAnyEntities && (goal.objective.isBlank() || goal.objective.equals("reproducir música", ignoreCase = true))

                if (isGeneric) {
                    if (evidence.isMusicActive) {
                        GoalVerificationResult(
                            outcome = GoalOutcome.COMPLETED_VERIFIED,
                            confidence = 1.0,
                            satisfied = true,
                            explanation = "Reproducción de música activa en el sistema.",
                            evidenceUsed = evidence
                        )
                    } else {
                        GoalVerificationResult(
                            outcome = GoalOutcome.FAILED,
                            confidence = 0.0,
                            satisfied = false,
                            explanation = "No se detectó reproducción de música activa en el sistema.",
                            evidenceUsed = evidence
                        )
                    }
                } else {
                    // Check for playlist or unsupported entity types (Section 18 & 20)
                    val hasUnsupportedOrPlaylist = goal.entities.any {
                        it.type !in listOf("track", "song", "artist", "album", "query", "app") || it.type == "playlist"
                    }

                    if (hasUnsupportedOrPlaylist) {
                        // Section 18 & 20: Playlist or unsupported specific entity must NEVER verify from track metadata alone!
                        val outcome = if (evidence.isMusicActive || (media != null && media.playbackActive)) {
                            GoalOutcome.COMPLETED_UNVERIFIED
                        } else {
                            GoalOutcome.PARTIAL
                        }
                        GoalVerificationResult(
                            outcome = outcome,
                            confidence = 0.6,
                            satisfied = false,
                            explanation = "Objetivo de tipo playlist o entidad no observable de forma independiente en metadatos estándar de Android.",
                            evidenceUsed = evidence
                        )
                    } else if (media != null && media.playbackActive) {
                        // Section 17: Freshness validation
                        val isFresh = Math.abs(evidence.timestamp - media.observedAtMs) <= MAX_MEDIA_FRESHNESS_MS
                        if (!isFresh) {
                            GoalVerificationResult(
                                outcome = GoalOutcome.PARTIAL,
                                confidence = 0.4,
                                satisfied = false,
                                explanation = "Metadatos de medios obsoletos (${Math.abs(evidence.timestamp - media.observedAtMs)}ms de antigüedad, límite ${MAX_MEDIA_FRESHNESS_MS}ms).",
                                evidenceUsed = evidence
                            )
                        } else {
                            // Section 21: ALL required media entities must match! (AND semantics)
                            val trackEntities = goal.entities.filter { it.type in listOf("track", "song") }
                            val artistEntities = goal.entities.filter { it.type == "artist" }
                            val albumEntities = goal.entities.filter { it.type == "album" }
                            val appEntities = goal.entities.filter { it.type == "app" }
                            val queryEntities = goal.entities.filter { it.type == "query" }

                            var allMatched = true
                            if (trackEntities.isNotEmpty()) {
                                val trackMatch = trackEntities.all { matchesEntityCanonical(it.value, media.title) || matchesEntityCanonical(it.value, media.mediaId) }
                                if (!trackMatch) allMatched = false
                            }
                            if (artistEntities.isNotEmpty()) {
                                val artistMatch = artistEntities.all { matchesEntityCanonical(it.value, media.artist) }
                                if (!artistMatch) allMatched = false
                            }
                            if (albumEntities.isNotEmpty()) {
                                val albumMatch = albumEntities.all { matchesEntityCanonical(it.value, media.album) }
                                if (!albumMatch) allMatched = false
                            }
                            if (appEntities.isNotEmpty()) {
                                val appMatch = appEntities.all { appEntity ->
                                    val raw = appEntity.value.trim()
                                    val isPackage = packageRegex.matches(raw)
                                    if (isPackage) {
                                        media.sessionPackage != null && raw.equals(media.sessionPackage.trim(), ignoreCase = true)
                                    } else {
                                        // Section 15: Human app label without resolved package identity cannot be independently verified
                                        false
                                    }
                                }
                                if (!appMatch) allMatched = false
                            }
                            // Section 17: If structured track/artist/album exist, query is derived/non-binding.
                            // If ONLY query exists, it must match title or artist.
                            if (queryEntities.isNotEmpty() && trackEntities.isEmpty() && artistEntities.isEmpty() && albumEntities.isEmpty()) {
                                val queryMatch = queryEntities.all {
                                    matchesEntityCanonical(it.value, media.title) || matchesEntityCanonical(it.value, media.artist)
                                }
                                if (!queryMatch) allMatched = false
                            }

                            if (allMatched) {
                                GoalVerificationResult(
                                    outcome = GoalOutcome.COMPLETED_VERIFIED,
                                    confidence = 1.0,
                                    satisfied = true,
                                    explanation = "Reproducción activa y metadatos verificados coincidentes: '${media.title}' por '${media.artist}' (origen: ${media.evidenceSource})",
                                    evidenceUsed = evidence
                                )
                            } else {
                                GoalVerificationResult(
                                    outcome = GoalOutcome.PARTIAL,
                                    confidence = 0.5,
                                    satisfied = false,
                                    explanation = "Audio activo, pero los metadatos observados ('${media.title}' - '${media.artist}') no coinciden con todas las entidades requeridas.",
                                    evidenceUsed = evidence
                                )
                            }
                        }
                    } else if (evidence.isMusicActive) {
                        // Section 7: NO METADATA must NOT mean SUCCESS.
                        // AudioManager.isMusicActive proves audio is playing, but cannot prove the requested entity.
                        if (executionProved) {
                            GoalVerificationResult(
                                outcome = GoalOutcome.COMPLETED_UNVERIFIED,
                                confidence = 0.8,
                                satisfied = false,
                                explanation = "Audio activo en sistema y confirmación de ruta de ejecución, pero sin metadatos independientes de la entidad observada.",
                                evidenceUsed = evidence
                            )
                        } else {
                            GoalVerificationResult(
                                outcome = GoalOutcome.COMPLETED_UNVERIFIED,
                                confidence = 0.6,
                                satisfied = false,
                                explanation = "Audio de música activo en el sistema, pero metadatos de pista/artista no disponibles para verificar de forma independiente la entidad solicitada.",
                                evidenceUsed = evidence
                            )
                        }
                    } else {
                        val isMediaAppInForeground = evidence.foregroundPackage.contains("music", ignoreCase = true) ||
                                evidence.foregroundPackage.contains("audio", ignoreCase = true) ||
                                evidence.foregroundPackage.contains("player", ignoreCase = true) ||
                                goal.entities.any { it.type == "app" && evidence.foregroundPackage.contains(it.value, ignoreCase = true) }
                        if (isMediaAppInForeground) {
                            GoalVerificationResult(
                                outcome = GoalOutcome.PARTIAL,
                                confidence = 0.5,
                                satisfied = false,
                                explanation = "Aplicación de medios visible (${evidence.foregroundPackage}), pero la reproducción de audio no está activa.",
                                evidenceUsed = evidence
                            )
                        } else {
                            GoalVerificationResult(
                                outcome = GoalOutcome.FAILED,
                                confidence = 0.0,
                                satisfied = false,
                                explanation = "No se detectó reproducción de música ni aplicación de medios en primer plano para el objetivo solicitado.",
                                evidenceUsed = evidence
                            )
                        }
                    }
                }
            }

            goal.categoryHint == "CONNECTIVITY_BLUETOOTH" || goal.desiredState.contains("bluetooth", ignoreCase = true) -> {
                if (evidence.isBluetoothEnabled == true) {
                    GoalVerificationResult(
                        outcome = GoalOutcome.COMPLETED_VERIFIED,
                        confidence = 1.0,
                        satisfied = true,
                        explanation = "Bluetooth confirmado encendido en el sistema (BluetoothAdapter.isEnabled=true)",
                        evidenceUsed = evidence
                    )
                } else {
                    GoalVerificationResult(
                        outcome = GoalOutcome.FAILED,
                        confidence = 0.0,
                        satisfied = false,
                        explanation = "Bluetooth no se encuentra encendido en el sistema.",
                        evidenceUsed = evidence
                    )
                }
            }

            goal.categoryHint == "PHOTOS_GALLERY" || goal.desiredState.contains("foto", ignoreCase = true) || goal.desiredState.contains("galería", ignoreCase = true) -> {
                val isGallery = evidence.foregroundPackage.contains("gallery") ||
                        evidence.foregroundPackage.contains("photos") ||
                        evidence.foregroundPackage.contains("google.android.apps.photos") ||
                        evidence.foregroundPackage.contains("miui.gallery")
                if (isGallery) {
                    GoalVerificationResult(
                        outcome = GoalOutcome.COMPLETED_VERIFIED,
                        confidence = 0.95,
                        satisfied = true,
                        explanation = "Galería de fotos visible en primer plano (${evidence.foregroundPackage})",
                        evidenceUsed = evidence
                    )
                } else {
                    GoalVerificationResult(
                        outcome = GoalOutcome.FAILED,
                        confidence = 0.0,
                        satisfied = false,
                        explanation = "No se encontró aplicación de fotos en primer plano.",
                        evidenceUsed = evidence
                    )
                }
            }

            goal.categoryHint == "SYSTEM_SETTINGS" || goal.desiredState.contains("fuente", ignoreCase = true) || goal.desiredState.contains("letra", ignoreCase = true) -> {
                if (evidence.foregroundPackage == "com.android.settings") {
                    val hasTextRelated = evidence.visibleTexts.any {
                        it.contains("Pantalla", ignoreCase = true) ||
                        it.contains("Texto", ignoreCase = true) ||
                        it.contains("Fuente", ignoreCase = true) ||
                        it.contains("Tamaño", ignoreCase = true)
                    }
                    if (hasTextRelated) {
                        GoalVerificationResult(
                            outcome = GoalOutcome.COMPLETED_VERIFIED,
                            confidence = 0.9,
                            satisfied = true,
                            explanation = "Ajuste de pantalla/fuente localizado en Ajustes del sistema.",
                            evidenceUsed = evidence
                        )
                    } else {
                        GoalVerificationResult(
                            outcome = GoalOutcome.PARTIAL,
                            confidence = 0.5,
                            satisfied = false,
                            explanation = "Ajustes abiertos, pero sección de tamaño de letra aún no alcanzada.",
                            evidenceUsed = evidence
                        )
                    }
                } else {
                    GoalVerificationResult(
                        outcome = GoalOutcome.FAILED,
                        confidence = 0.0,
                        satisfied = false,
                        explanation = "Ajustes del sistema no visibles en primer plano.",
                        evidenceUsed = evidence
                    )
                }
            }

            goal.categoryHint == "SEMANTIC_NODE_ACTION" -> {
                val clickStep = stepsExecuted.firstOrNull { it.capability == "click_node" }
                if (clickStep != null && (clickStep.executionResult["status"] == "SUCCESS" || clickStep.executionResult["success"] == true || clickStep.verification.contains("Clic", ignoreCase = true))) {
                    GoalVerificationResult(
                        outcome = GoalOutcome.COMPLETED_VERIFIED,
                        confidence = 1.0,
                        satisfied = true,
                        explanation = "Acción semántica completada sobre nodo y verificada post-ejecución: ${clickStep.verification}",
                        evidenceUsed = evidence
                    )
                } else if (clickStep != null) {
                    GoalVerificationResult(
                        outcome = GoalOutcome.FAILED,
                        confidence = 0.0,
                        satisfied = false,
                        explanation = "Fallo al ejecutar la acción sobre el nodo seleccionado: ${clickStep.executionResult["error"] ?: "error de despacho"}",
                        evidenceUsed = evidence
                    )
                } else if (stepsExecuted.isNotEmpty()) {
                    GoalVerificationResult(
                        outcome = GoalOutcome.PARTIAL,
                        confidence = 0.3,
                        satisfied = false,
                        explanation = "Se ejecutaron pasos pero no se confirmó la acción de clic sobre el nodo seleccionado.",
                        evidenceUsed = evidence
                    )
                } else {
                    GoalVerificationResult(
                        outcome = GoalOutcome.FAILED,
                        confidence = 0.0,
                        satisfied = false,
                        explanation = "No se ejecutó ninguna acción sobre el nodo seleccionado.",
                        evidenceUsed = evidence
                    )
                }
            }

            else -> {
                // Rule B: Fallback cannot declare success without explicit evidence
                if (stepsExecuted.isNotEmpty()) {
                    GoalVerificationResult(
                        outcome = GoalOutcome.PARTIAL,
                        confidence = 0.3,
                        satisfied = false,
                        explanation = "Se ejecutaron pasos pero no existe evidencia observable verificada para: ${goal.desiredState}",
                        evidenceUsed = evidence
                    )
                } else {
                    GoalVerificationResult(
                        outcome = GoalOutcome.NOT_UNDERSTOOD,
                        confidence = 0.0,
                        satisfied = false,
                        explanation = "No se pudo interpretar una condición observable de éxito para el objetivo.",
                        evidenceUsed = evidence
                    )
                }
            }
        }

        lastVerification = result
        return result
    }
}
