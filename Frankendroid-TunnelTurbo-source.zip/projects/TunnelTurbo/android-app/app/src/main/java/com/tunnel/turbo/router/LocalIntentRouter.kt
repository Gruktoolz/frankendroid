package com.tunnel.turbo.router

import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.model.SequencePlan
import com.tunnel.turbo.model.StructuredPlan
import com.tunnel.turbo.model.UnsupportedPlan

enum class RouteDecision {
    DIRECT,
    AI_REQUIRED,
    NEEDS_OBSERVATION,
    UNSUPPORTED
}

data class RouteResult(
    val decision: RouteDecision,
    val directPlan: StructuredPlan? = null,
    val reason: String = "",
    val routingElapsedMs: Double = 0.0
)

open class LocalIntentRouter(
    private val appManager: com.tunnel.turbo.app.AppManager? = null
) {

    fun normalize(text: String): String {
        return text.trim().lowercase()
            .replace(Regex("[.,;:!¡?¿\"'()]"), "")
            .replace(Regex("\\s+"), " ")
    }

    open fun route(text: String): RouteResult {
        val t0 = System.nanoTime()
        val cleaned = normalize(text)

        // 1. Explicit Attacks / Shell / Dangerous commands -> UNSUPPORTED
        if (cleaned.contains("rm -rf") || cleaned.contains("input tap") || cleaned.contains("input text") ||
            cleaned.contains("sh ") || cleaned.contains("bash ") || cleaned.contains("su ") ||
            cleaned.contains("chmod ") || cleaned.contains("reboot") || cleaned.contains("x=") ||
            cleaned.contains("dump") || cleaned.contains("curl ") || cleaned.contains("wget ")) {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return RouteResult(
                decision = RouteDecision.UNSUPPORTED,
                directPlan = UnsupportedPlan("Comando peligroso o fuera de la allowlist segura"),
                reason = "attack_or_shell_detected",
                routingElapsedMs = elapsed
            )
        }

        // 2. Generic Navigation Test: "Abre Ajustes y entra a Bluetooth" (Fase 10 Section 21 & 39)
        if (cleaned == "abre ajustes y entra a bluetooth" ||
            cleaned == "abrir ajustes y entrar a bluetooth" ||
            cleaned == "abre configuracion y entra a bluetooth" ||
            cleaned == "abrir configuracion y entrar a bluetooth") {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return RouteResult(
                decision = RouteDecision.DIRECT,
                directPlan = com.tunnel.turbo.model.TaskPlan(
                    steps = listOf(
                        com.tunnel.turbo.model.ToolStep(tool = "open_settings"),
                        com.tunnel.turbo.model.ToolStep(
                            tool = "wait_for",
                            arguments = mapOf("condition" to "foreground_package", "value" to "com.android.settings", "timeoutMs" to 5000L)
                        ),
                        com.tunnel.turbo.model.ToolStep(
                            tool = "click_node",
                            arguments = mapOf("selector" to mapOf("text" to "Bluetooth"))
                        ),
                        com.tunnel.turbo.model.ToolStep(
                            tool = "wait_for",
                            arguments = mapOf("condition" to "text_exists", "value" to "Bluetooth", "timeoutMs" to 5000L)
                        )
                    )
                ),
                reason = "generic_navigation_settings_bluetooth",
                routingElapsedMs = elapsed
            )
        }

        // Generic Task Test: "Abre Spotify y entra a Buscar" (Fase 10 Section 20 & 38)
        if (cleaned == "abre spotify y entra a buscar" ||
            cleaned == "abrir spotify y entrar a buscar" ||
            cleaned == "abre spotify y busca" ||
            cleaned == "abre spotify y buscar") {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return RouteResult(
                decision = RouteDecision.DIRECT,
                directPlan = com.tunnel.turbo.model.TaskPlan(
                    steps = listOf(
                        com.tunnel.turbo.model.ToolStep(
                            tool = "open_app",
                            arguments = mapOf("package" to "com.spotify.music")
                        ),
                        com.tunnel.turbo.model.ToolStep(
                            tool = "wait_for",
                            arguments = mapOf("condition" to "foreground_package", "value" to "com.spotify.music", "timeoutMs" to 5000L)
                        ),
                        com.tunnel.turbo.model.ToolStep(
                            tool = "click_node",
                            arguments = mapOf("selector" to mapOf("text" to "Buscar"))
                        ),
                        com.tunnel.turbo.model.ToolStep(
                            tool = "wait_for",
                            arguments = mapOf("condition" to "text_exists", "value" to "Buscar", "timeoutMs" to 5000L)
                        )
                    )
                ),
                reason = "generic_task_spotify_search",
                routingElapsedMs = elapsed
            )
        }

        // 3. Exact deterministic commands -> DIRECT
        val directPlan: StructuredPlan? = when (cleaned) {
            "abre wi-fi", "abre wifi", "abrir wi-fi", "abrir wifi", "open wifi", "open wi-fi", "wi-fi", "wifi" ->
                ActionPlan(action = "open_wifi_settings")

            "abre bluetooth", "abrir bluetooth", "open bluetooth", "bluetooth" ->
                ActionPlan(action = "open_bluetooth_settings")

            "abre ajustes", "abrir ajustes", "ajustes", "abre configuracion", "abrir configuracion", "abre configuración", "abrir configuración", "configuracion", "configuración", "open settings", "settings" ->
                ActionPlan(action = "open_settings")

            "regresa", "regresar", "volver", "atras", "atrás", "back", "press back" ->
                ActionPlan(action = "press_back")

            "inicio", "ir a inicio", "home", "pantalla de inicio", "go home", "press home" ->
                ActionPlan(action = "press_home")

            "abre wi-fi vuelve atrás y abre bluetooth", "abre wifi vuelve atras y abre bluetooth",
            "abre wi-fi vuelve atras y abre bluetooth", "abre wifi vuelve atrás y abre bluetooth",
            "secuencia", "test secuencia" ->
                SequencePlan(
                    steps = listOf(
                        ActionPlan(action = "open_wifi_settings"),
                        ActionPlan(action = "press_key", arguments = mapOf("key" to "BACK")),
                        ActionPlan(action = "open_bluetooth_settings")
                    )
                )

            else -> null
        }

        if (directPlan != null) {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return RouteResult(
                decision = RouteDecision.DIRECT,
                directPlan = directPlan,
                reason = "exact_deterministic_match",
                routingElapsedMs = elapsed
            )
        }

        // 4. Resolve App Pattern ("Abre [app]" / "Abrir [app]")
        val openPrefixes = listOf("abre ", "abrir ", "open ")
        for (prefix in openPrefixes) {
            if (cleaned.startsWith(prefix)) {
                val candidateName = cleaned.removePrefix(prefix).trim()
                if (candidateName.isNotEmpty() && appManager != null) {
                    val res = appManager.resolveApp(candidateName)
                    val elapsed = (System.nanoTime() - t0) / 1_000_000.0
                    when (res) {
                        is com.tunnel.turbo.app.ResolveAppResult.Found -> {
                            return RouteResult(
                                decision = RouteDecision.DIRECT,
                                directPlan = com.tunnel.turbo.model.TaskPlan(
                                    steps = listOf(
                                        com.tunnel.turbo.model.ToolStep(
                                            tool = "open_app",
                                            arguments = mapOf("package" to res.packageName)
                                        ),
                                        com.tunnel.turbo.model.ToolStep(
                                            tool = "wait_for",
                                            arguments = mapOf("condition" to "foreground_package", "value" to res.packageName)
                                        )
                                    )
                                ),
                                reason = "resolved_app_direct_${res.packageName}",
                                routingElapsedMs = elapsed
                            )
                        }
                        is com.tunnel.turbo.app.ResolveAppResult.Ambiguous -> {
                            return RouteResult(
                                decision = RouteDecision.UNSUPPORTED,
                                directPlan = UnsupportedPlan("Múltiples apps coinciden con '$candidateName': ${res.candidates.map { it.label }.joinToString()}"),
                                reason = "ambiguous_app_resolution",
                                routingElapsedMs = elapsed
                            )
                        }
                        com.tunnel.turbo.app.ResolveAppResult.NotFound -> {
                            // Defer to AI
                        }
                    }
                }
            }
        }

        val elapsed = (System.nanoTime() - t0) / 1_000_000.0
        return RouteResult(
            decision = RouteDecision.AI_REQUIRED,
            directPlan = null,
            reason = "complex_or_multi_step_requires_ai",
            routingElapsedMs = elapsed
        )
    }
}
