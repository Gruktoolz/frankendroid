package com.tunnel.turbo.app

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import org.json.JSONObject

data class AppInfo(
    val packageName: String,
    val label: String
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("packageName", packageName)
        obj.put("label", label)
        return obj
    }
}

sealed class ResolveAppResult {
    data class Found(val packageName: String, val label: String) : ResolveAppResult()
    data class Ambiguous(val candidates: List<AppInfo>) : ResolveAppResult()
    object NotFound : ResolveAppResult()
}

open class AppManager(private val context: Context? = null) {

    open fun listInstalledApps(): List<AppInfo> {
        val ctx = context ?: return emptyList()
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveList = pm.queryIntentActivities(intent, 0)
        val seen = mutableSetOf<String>()
        val list = mutableListOf<AppInfo>()

        for (ri in resolveList) {
            val pkg = ri.activityInfo.packageName
            if (pkg.isNotEmpty() && seen.add(pkg)) {
                val label = ri.loadLabel(pm).toString()
                list.add(AppInfo(packageName = pkg, label = label))
            }
        }
        return list.sortedBy { it.label.lowercase() }
    }

    fun resolveApp(query: String): ResolveAppResult {
        val cleaned = query.trim().lowercase()
        if (cleaned.isEmpty()) return ResolveAppResult.NotFound

        val all = listInstalledApps()

        // 1. Exact package match
        val exactPkg = all.firstOrNull { it.packageName.lowercase() == cleaned }
        if (exactPkg != null) return ResolveAppResult.Found(exactPkg.packageName, exactPkg.label)

        // 2. Exact label match
        val exactLabel = all.firstOrNull { it.label.lowercase() == cleaned }
        if (exactLabel != null) return ResolveAppResult.Found(exactLabel.packageName, exactLabel.label)

        // 3. Substring / Prefix match
        val matches = all.filter {
            it.label.lowercase().contains(cleaned) ||
            it.packageName.lowercase().contains(cleaned)
        }

        return when {
            matches.size == 1 -> ResolveAppResult.Found(matches[0].packageName, matches[0].label)
            matches.size > 1 -> {
                // If one of the candidates is an exact word in label, prefer it
                val wordMatch = matches.filter {
                    val words = it.label.lowercase().split(" ", "_", "-")
                    words.contains(cleaned)
                }
                if (wordMatch.size == 1) {
                    ResolveAppResult.Found(wordMatch[0].packageName, wordMatch[0].label)
                } else {
                    ResolveAppResult.Ambiguous(matches)
                }
            }
            else -> ResolveAppResult.NotFound
        }
    }

    fun openApp(packageName: String, displayId: Int = 0): Boolean {
        val ctx = context ?: return false
        return try {
            val pm = ctx.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (displayId > 0) {
                val opts = ActivityOptions.makeBasic()
                opts.launchDisplayId = displayId
                ctx.startActivity(intent, opts.toBundle())
            } else {
                ctx.startActivity(intent)
            }
            true
        } catch (t: Throwable) {
            android.util.Log.e("AppManager", "Error launching app $packageName: ${t.message}")
            false
        }
    }
}
