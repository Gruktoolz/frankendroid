package com.tunnel.turbo.perception

import android.graphics.Rect

class SemanticCoverageDetector {

    fun detectCoverage(
        displayId: Int,
        foregroundPackage: String,
        elements: List<SemanticElement>,
        screenWidth: Int = 1220,
        screenHeight: Int = 2712,
        goalText: String? = null
    ): CoverageStatus {
        // Fast Path 1: Worker Display 28 (ChatGPT)
        if (displayId > 0 || foregroundPackage == "com.openai.chatgpt") {
            val hasInput = elements.any { it.editable || it.role.contains("EditText") || it.role.contains("Compose") }
            val hasAction = elements.any { it.clickable }
            if (hasInput && hasAction) return CoverageStatus.SUFFICIENT
        }

        // Fast Path 2: Standard Android Settings
        if (foregroundPackage == "com.android.settings") {
            val hasControls = elements.any { it.clickable || it.checkable }
            if (hasControls && elements.size >= 3) return CoverageStatus.SUFFICIENT
        }

        // Gap & Spatial Analysis
        val mask = CoverageMask(screenWidth, screenHeight)
        for (el in elements) {
            mask.markCovered(el.bounds)
        }

        val coverageRatio = mask.calculateCoverageRatio()
        val majorGaps = mask.getUncoveredGaps(minHeightPx = 400)

        // Case 3: Spotify Search Blind Spot
        // Characteristic: Very few nodes (<= 4), all located in the bottom navigation bar (top >= 2400)
        // while the entire viewport (0 to 2400) is a void in Accessibility
        if (foregroundPackage.contains("spotify")) {
            val allInBottomNav = elements.isNotEmpty() && elements.all { it.bounds.top >= 2200 }
            if (allInBottomNav && majorGaps.isNotEmpty()) {
                return CoverageStatus.INSUFFICIENT
            }
        }

        // Case 4: Google Maps / Canvas
        if (foregroundPackage.contains("maps")) {
            val hasSurfaceView = elements.any { it.role.contains("SurfaceView") || it.role.contains("View") && it.bounds.width() >= screenWidth * 0.9 }
            if (hasSurfaceView || majorGaps.isNotEmpty()) {
                // If goal is map interaction, coverage is partial/insufficient for map markers
                return CoverageStatus.PARTIAL
            }
        }

        // Case 5: Goal expects search/input, but no editable element exists in accessibility
        if (goalText != null) {
            val wantsSearch = goalText.contains("busca", ignoreCase = true) ||
                              goalText.contains("search", ignoreCase = true) ||
                              goalText.contains("escuchar", ignoreCase = true) ||
                              goalText.contains("pon", ignoreCase = true)
            val hasEditable = elements.any { it.editable }
            if (wantsSearch && !hasEditable && majorGaps.isNotEmpty()) {
                return CoverageStatus.INSUFFICIENT
            }
        }

        // General heuristic
        return when {
            majorGaps.isNotEmpty() && coverageRatio < 0.20f -> CoverageStatus.INSUFFICIENT
            elements.isEmpty() -> CoverageStatus.UNKNOWN
            elements.none { it.clickable } -> CoverageStatus.PARTIAL
            else -> CoverageStatus.SUFFICIENT
        }
    }
}
