package com.tunnel.turbo.chat

import android.content.Context
import com.tunnel.turbo.coordinator.ConversationMessage
import com.tunnel.turbo.coordinator.MessageRole
import com.tunnel.turbo.coordinator.MessageFeedback
import com.tunnel.turbo.coordinator.Route
import com.tunnel.turbo.coordinator.TurnStatus
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Bounded local transcript, excluded from Android cloud backup. */
class ConversationHistoryStore(context: Context) {
    private val file = File(context.noBackupFilesDir, "conversation-history-v1.json")

    @Synchronized fun read(): List<ConversationMessage> = runCatching {
        if (!file.isFile) return emptyList()
        val array = JSONArray(file.readText())
        (0 until array.length()).mapNotNull { i ->
            val obj = array.optJSONObject(i) ?: return@mapNotNull null
            val role = runCatching { MessageRole.valueOf(obj.optString("role")) }.getOrNull() ?: return@mapNotNull null
            ConversationMessage(
                id = obj.optString("id"), role = role, text = obj.optString("text"), timestamp = obj.optLong("timestamp"),
                route = enumOrNull<Route>(obj.optString("route")), turnStatus = enumOrNull<TurnStatus>(obj.optString("turnStatus")),
                provenance = obj.optString("provenance").takeUnless { it.isBlank() || it == "null" },
                latencyMs = if (obj.isNull("latencyMs")) null else obj.optDouble("latencyMs"),
                actionSummary = obj.optString("actionSummary").takeUnless { it.isBlank() || it == "null" },
                verificationExplanation = obj.optString("verificationExplanation").takeUnless { it.isBlank() || it == "null" },
                isSimulated = obj.optBoolean("isSimulated"),
                feedback = obj.optString("feedback").takeIf { it.isNotBlank() && it != "null" }?.let { runCatching { MessageFeedback.valueOf(it) }.getOrNull() }
            )
        }.takeLast(MAX_MESSAGES)
    }.getOrDefault(emptyList())

    @Synchronized fun save(messages: List<ConversationMessage>) {
        file.parentFile?.mkdirs()
        val array = JSONArray()
        messages.takeLast(MAX_MESSAGES).forEach { msg -> array.put(JSONObject().apply {
            put("id", msg.id); put("role", msg.role.name); put("text", msg.text); put("timestamp", msg.timestamp)
            put("route", msg.route?.name ?: JSONObject.NULL); put("turnStatus", msg.turnStatus?.name ?: JSONObject.NULL)
            put("provenance", msg.provenance ?: JSONObject.NULL); put("latencyMs", msg.latencyMs ?: JSONObject.NULL)
            put("actionSummary", msg.actionSummary ?: JSONObject.NULL); put("verificationExplanation", msg.verificationExplanation ?: JSONObject.NULL)
            put("isSimulated", msg.isSimulated)
            put("feedback", msg.feedback?.name ?: JSONObject.NULL)
        }) }
        val temp = File(file.parentFile, "${file.name}.tmp")
        temp.writeText(array.toString())
        if (!temp.renameTo(file)) { temp.copyTo(file, overwrite = true); temp.delete() }
    }

    @Synchronized fun clear() { file.delete(); File(file.parentFile, "${file.name}.tmp").delete() }

    private inline fun <reified T : Enum<T>> enumOrNull(value: String): T? =
        value.takeIf { it.isNotBlank() && it != "null" }?.let { runCatching { enumValueOf<T>(it) }.getOrNull() }

    private companion object { const val MAX_MESSAGES = 40 }
}
