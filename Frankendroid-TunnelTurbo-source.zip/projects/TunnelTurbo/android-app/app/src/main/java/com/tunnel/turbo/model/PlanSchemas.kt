package com.tunnel.turbo.model

import org.json.JSONArray
import org.json.JSONObject

sealed interface StructuredPlan {
    val type: String
    fun toJson(): JSONObject
}

data class ActionPlan(
    val action: String,
    val arguments: Map<String, Any> = emptyMap()
) : StructuredPlan {
    override val type: String = "action"

    override fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("type", type)
        obj.put("action", action)
        val argsObj = JSONObject()
        for ((k, v) in arguments) {
            argsObj.put(k, v)
        }
        obj.put("arguments", argsObj)
        return obj
    }
}

data class SequencePlan(
    val steps: List<ActionPlan>
) : StructuredPlan {
    override val type: String = "sequence"

    override fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("type", type)
        val arr = JSONArray()
        for (s in steps) {
            arr.put(s.toJson())
        }
        obj.put("steps", arr)
        return obj
    }
}

data class NeedsObservationPlan(
    val reason: String
) : StructuredPlan {
    override val type: String = "needs_observation"

    override fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("type", type)
        obj.put("reason", reason)
        return obj
    }
}

data class UnsupportedPlan(
    val reason: String
) : StructuredPlan {
    override val type: String = "unsupported"

    override fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("type", type)
        obj.put("reason", reason)
        return obj
    }
}

// --- Plan Schema V2 (Fase 10) ---

data class ToolStep(
    val tool: String,
    val arguments: Map<String, Any?> = emptyMap()
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("tool", tool)
        val argsObj = JSONObject()
        for ((k, v) in arguments) {
            argsObj.put(k, v)
        }
        obj.put("arguments", argsObj)
        return obj
    }
}

data class TaskPlan(
    val steps: List<ToolStep>
) : StructuredPlan {
    override val type: String = "task"

    override fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("type", type)
        val arr = JSONArray()
        for (s in steps) {
            arr.put(s.toJson())
        }
        obj.put("steps", arr)
        return obj
    }
}
