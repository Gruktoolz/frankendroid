package com.tunnel.turbo.provider

import com.tunnel.turbo.model.StructuredPlan

data class IntentResult(
    val success: Boolean,
    val plan: StructuredPlan? = null,
    val rawResponse: String = "",
    val error: String? = null,
    val providerMs: Double = 0.0
)

interface IntentProvider {
    val name: String
    suspend fun plan(userText: String, requestId: String): IntentResult
    suspend fun healthCheck(): Boolean
}
