package com.tunnel.turbo.local

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicInteger

/**
 * ShadowCognitiveDispatcher
 *
 * Runs LocalCognitiveEngine asynchronously in SHADOW MODE.
 * Rules (Phase 13B-1.2a Hardened):
 * - Bounded retention capacity: history uses a thread-safe ring buffer (capacity: DEFAULT_RETENTION_CAPACITY).
 * - Bounded timeout: asynchronous shadow assessment times out at SHADOW_TIMEOUT_MS.
 * - Non-blocking & fails open: any error or timeout is absorbed without affecting the authoritative caller.
 * - Fail-closed assessment ingestion: invalid assessments are logged as failures and dropped, not ingested.
 * - Truthful coverage denominator: tracks agentSessionsObserved vs completed, and separates DevTools calls.
 * - Renamed potential savings: tracks estimatedLocalizableDecisions rather than claiming factual cloud savings.
 */
object ShadowCognitiveDispatcher {
    const val DEFAULT_RETENTION_CAPACITY = 100
    const val SHADOW_TIMEOUT_MS = 2000L

    private val scope = CoroutineScope(Dispatchers.Default)
    private val historyLock = Any()
    private val boundedHistory = ArrayDeque<LocalCognitiveAssessment>(DEFAULT_RETENTION_CAPACITY)

    @Volatile
    var lastAssessment: LocalCognitiveAssessment? = null
        private set

    // Truthful operational lifetime counters
    val shadowIngressEventsSeen = AtomicInteger(0)
    val shadowEligible = AtomicInteger(0)
    val shadowAttemptsStarted = AtomicInteger(0)
    val shadowCompleted = AtomicInteger(0)
    val shadowEngineFailed = AtomicInteger(0)
    val shadowTimedOut = AtomicInteger(0)
    val shadowDroppedDisabled = AtomicInteger(0)
    val shadowCallbackFailures = AtomicInteger(0)
    val devtoolsDirectCallsCount = AtomicInteger(0)

    // Backwards-compatible aliases for existing callers and tests
    val agentSessionsObserved: AtomicInteger get() = shadowIngressEventsSeen
    val agentSessionsCompleted: AtomicInteger get() = shadowCompleted
    val agentSessionsFailed: AtomicInteger get() = shadowEngineFailed
    val agentSessionsTimedOut: AtomicInteger get() = shadowTimedOut
    val agentSessionsDropped: AtomicInteger get() = shadowDroppedDisabled

    val history: List<LocalCognitiveAssessment>
        get() = synchronized(historyLock) {
            boundedHistory.toList()
        }

    fun clear() {
        synchronized(historyLock) {
            boundedHistory.clear()
        }
        lastAssessment = null
        shadowIngressEventsSeen.set(0)
        shadowEligible.set(0)
        shadowAttemptsStarted.set(0)
        shadowCompleted.set(0)
        shadowEngineFailed.set(0)
        shadowTimedOut.set(0)
        shadowDroppedDisabled.set(0)
        shadowCallbackFailures.set(0)
        devtoolsDirectCallsCount.set(0)
    }

    private fun recordAssessment(assessment: LocalCognitiveAssessment) {
        synchronized(historyLock) {
            if (boundedHistory.size >= DEFAULT_RETENTION_CAPACITY) {
                boundedHistory.removeFirst()
            }
            boundedHistory.addLast(assessment)
        }
        lastAssessment = assessment
    }

    /**
     * Dispatch shadow assessment asynchronously.
     * Returns immediately; does NOT block the calling thread or coroutine.
     */
    fun dispatchShadowAssessmentAsync(
        userMessage: String,
        conversationContextSummary: String? = null,
        activeGoalSummary: String? = null,
        currentForegroundPackage: String? = null,
        locale: String = "es-ES",
        onCompleted: ((LocalCognitiveAssessment) -> Unit)? = null
    ) {
        shadowIngressEventsSeen.incrementAndGet()

        if (!LocalCognitiveEngineRegistry.shadowModeEnabled) {
            shadowDroppedDisabled.incrementAndGet()
            return
        }

        shadowEligible.incrementAndGet()

        val input = LocalCognitiveInput(
            userMessage = userMessage,
            conversationContextSummary = conversationContextSummary,
            activeGoalSummary = activeGoalSummary,
            currentForegroundPackage = currentForegroundPackage,
            locale = locale
        )

        shadowAttemptsStarted.incrementAndGet()

        scope.launch {
            var completedSuccessfully = false
            var finalAssessment: LocalCognitiveAssessment? = null

            try {
                finalAssessment = withTimeoutOrNull(SHADOW_TIMEOUT_MS) {
                    LocalCognitiveEngineRegistry.activeEngine.assessTurn(input)
                }

                if (finalAssessment == null) {
                    shadowTimedOut.incrementAndGet()
                    android.util.Log.w("ShadowCognitiveDispatcher", "Shadow assessment timed out after ${SHADOW_TIMEOUT_MS}ms")
                    return@launch
                }

                // Invariant validation: Fail closed on malformed output
                val violations = LocalCognitiveAssessmentValidator.validateInvariants(finalAssessment)
                if (violations.isNotEmpty()) {
                    shadowEngineFailed.incrementAndGet()
                    android.util.Log.w(
                        "ShadowCognitiveDispatcher",
                        "Shadow assessment failed invariant validation: ${violations.joinToString("; ")}"
                    )
                    return@launch
                }

                recordAssessment(finalAssessment)
                shadowCompleted.incrementAndGet()
                completedSuccessfully = true
                android.util.Log.d(
                    "ShadowCognitiveDispatcher",
                    "Shadow assessment complete: mode=${finalAssessment.interactionMode}, domain=${finalAssessment.taskDomain}, latency=${finalAssessment.telemetry.tinyInferenceMs}ms"
                )
            } catch (t: Throwable) {
                // Fail open: never disrupt host application
                shadowEngineFailed.incrementAndGet()
                android.util.Log.w("ShadowCognitiveDispatcher", "Shadow assessment error: ${t.message}")
                return@launch
            }

            // Callback delivery is isolated from engine assessment outcome
            if (completedSuccessfully && finalAssessment != null && onCompleted != null) {
                try {
                    onCompleted.invoke(finalAssessment)
                } catch (cbEx: Throwable) {
                    shadowCallbackFailures.incrementAndGet()
                    android.util.Log.w("ShadowCognitiveDispatcher", "Shadow onCompleted callback error: ${cbEx.message}")
                }
            }
        }
    }

    /**
     * Synchronous assessment for deterministic testing, benchmarks, and DevTools endpoints.
     * Explicitly separated from production turn coverage.
     */
    suspend fun assessDirect(input: LocalCognitiveInput): LocalCognitiveAssessment {
        devtoolsDirectCallsCount.incrementAndGet()
        val assessment = LocalCognitiveEngineRegistry.activeEngine.assessTurn(input)
        val violations = LocalCognitiveAssessmentValidator.validateInvariants(assessment)
        if (violations.isNotEmpty()) {
            throw IllegalArgumentException("Direct assessment violated invariants: ${violations.joinToString("; ")}")
        }
        recordAssessment(assessment)
        return assessment
    }

    fun getStats(): JSONObject = JSONObject().apply {
        val currentHistory = history
        val inFlight = shadowAttemptsStarted.get() - shadowCompleted.get() - shadowEngineFailed.get() - shadowTimedOut.get()

        put("coverageScope", "AGENT_SESSION_START_ONLY")
        put("shadowIngressEventsSeen", shadowIngressEventsSeen.get())
        put("shadowEligible", shadowEligible.get())
        put("shadowAttemptsStarted", shadowAttemptsStarted.get())
        put("shadowCompleted", shadowCompleted.get())
        put("shadowEngineFailed", shadowEngineFailed.get())
        put("shadowTimedOut", shadowTimedOut.get())
        put("shadowInFlight", inFlight.coerceAtLeast(0))
        put("shadowDroppedDisabled", shadowDroppedDisabled.get())
        put("shadowCallbackFailures", shadowCallbackFailures.get())

        // Legacy compatibility keys
        put("agentSessionsObserved", shadowIngressEventsSeen.get())
        put("agentSessionsCompleted", shadowCompleted.get())
        put("agentSessionsFailed", shadowEngineFailed.get())
        put("agentSessionsTimedOut", shadowTimedOut.get())
        put("agentSessionsDropped", shadowDroppedDisabled.get())
        put("devtoolsDirectCallsCount", devtoolsDirectCallsCount.get())

        // Bounded retention semantics
        put("retentionCapacity", DEFAULT_RETENTION_CAPACITY)
        put("retainedHistoryCount", currentHistory.size)
        put("historySize", currentHistory.size)

        val modeCounts = JSONObject()
        val domainCounts = JSONObject()
        var totalEstimatedLocalizableDecisions = 0

        for (a in currentHistory) {
            modeCounts.put(a.interactionMode.name, modeCounts.optInt(a.interactionMode.name, 0) + 1)
            domainCounts.put(a.taskDomain.name, domainCounts.optInt(a.taskDomain.name, 0) + 1)
            totalEstimatedLocalizableDecisions += a.telemetry.estimatedLocalizableDecisions
        }

        put("modeDistribution", modeCounts)
        put("domainDistribution", domainCounts)
        put("estimatedLocalizableDecisions", totalEstimatedLocalizableDecisions)
        if (lastAssessment != null) {
            put("lastAssessment", lastAssessment?.toJson())
        }
    }
}
