package com.tunnel.turbo.capability

class CapabilityRegistry {

    private val catalog = listOf(
        // OBSERVATION (Read Only)
        Capability(
            id = "get_device_state",
            category = CapabilityCategory.OBSERVATION,
            description = "Obtiene el estado actual del dispositivo (paquete y actividad en primer plano, orientación, pantalla interactiva)",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = false
        ),
        Capability(
            id = "get_foreground_app",
            category = CapabilityCategory.OBSERVATION,
            description = "Devuelve el nombre del paquete y la actividad actualmente al frente",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = false
        ),
        Capability(
            id = "get_windows",
            category = CapabilityCategory.OBSERVATION,
            description = "Lista las ventanas visibles en el display especificado",
            argumentSchema = mapOf("displayId" to "Int?"),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = true,
            supportsVerification = false
        ),
        Capability(
            id = "get_ui_nodes",
            category = CapabilityCategory.OBSERVATION,
            description = "Extrae y normaliza el árbol de nodos de interfaz en el display objetivo (sin OCR ni capturas)",
            argumentSchema = mapOf("displayId" to "Int?"),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = true,
            supportsVerification = false
        ),
        Capability(
            id = "find_ui_nodes",
            category = CapabilityCategory.OBSERVATION,
            description = "Busca nodos semánticos por texto, descripción o identificador de recurso",
            argumentSchema = mapOf("selector" to "Map<String, Any>", "displayId" to "Int?", "match" to "String?"),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = true,
            supportsVerification = false
        ),
        Capability(
            id = "get_visible_text",
            category = CapabilityCategory.OBSERVATION,
            description = "Extrae todo el texto legible visible en la pantalla actual",
            argumentSchema = mapOf("displayId" to "Int?"),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = true,
            supportsVerification = false
        ),

        // NAVIGATION (System & Shortcuts)
        Capability(
            id = "open_settings",
            category = CapabilityCategory.NAVIGATION,
            description = "Abre los ajustes generales del sistema",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = true
        ),
        Capability(
            id = "open_wifi_settings",
            category = CapabilityCategory.NAVIGATION,
            description = "Abre directamente la pantalla de configuración de Wi-Fi",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = true
        ),
        Capability(
            id = "open_bluetooth_settings",
            category = CapabilityCategory.NAVIGATION,
            description = "Abre directamente la pantalla de configuración de Bluetooth",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = true
        ),
        Capability(
            id = "press_back",
            category = CapabilityCategory.NAVIGATION,
            description = "Simula la tecla Atrás del sistema",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = true
        ),
        Capability(
            id = "press_home",
            category = CapabilityCategory.NAVIGATION,
            description = "Simula la tecla Inicio (Home) del sistema",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = true
        ),

        // APP MANAGEMENT
        Capability(
            id = "list_installed_apps",
            category = CapabilityCategory.APP,
            description = "Lista aplicaciones ejecutables instaladas (etiqueta y nombre de paquete)",
            argumentSchema = emptyMap(),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = false
        ),
        Capability(
            id = "resolve_app",
            category = CapabilityCategory.APP,
            description = "Resuelve el nombre común de una app a su nombre de paquete formal",
            argumentSchema = mapOf("name" to "String"),
            riskLevel = RiskLevel.READ_ONLY,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = false
        ),
        Capability(
            id = "open_app",
            category = CapabilityCategory.APP,
            description = "Inicia una aplicación en el display objetivo mediante su paquete",
            argumentSchema = mapOf("package" to "String", "displayId" to "Int?"),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = true
        ),

        // UI INTERACTION
        Capability(
            id = "click_node",
            category = CapabilityCategory.UI,
            description = "Hace clic semántico sobre un elemento identificado por su selector",
            argumentSchema = mapOf("selector" to "Map<String, Any>", "displayId" to "Int?"),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = true,
            requiresForeground = true,
            supportsVerification = true
        ),
        Capability(
            id = "set_text",
            category = CapabilityCategory.UI,
            description = "Escribe texto dentro de un campo editable localizado semánticamente",
            argumentSchema = mapOf("selector" to "Map<String, Any>", "text" to "String", "displayId" to "Int?"),
            riskLevel = RiskLevel.TEXT_INPUT,
            requiresShizuku = false,
            requiresAccessibility = true,
            requiresForeground = true,
            supportsVerification = true
        ),
        Capability(
            id = "scroll",
            category = CapabilityCategory.UI,
            description = "Desplaza el contenido de una lista en la dirección indicada (UP, DOWN, LEFT, RIGHT)",
            argumentSchema = mapOf("direction" to "String", "selector" to "Map<String, Any>?", "displayId" to "Int?"),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = true,
            requiresForeground = true,
            supportsVerification = true
        ),
        Capability(
            id = "wait_for",
            category = CapabilityCategory.UI,
            description = "Espera asíncronamente a que se cumpla una condición en la interfaz o estado",
            argumentSchema = mapOf("condition" to "String", "value" to "String", "timeoutMs" to "Long?"),
            riskLevel = RiskLevel.NAVIGATION,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = true
        ),

        // SYSTEM
        Capability(
            id = "set_brightness",
            category = CapabilityCategory.SYSTEM,
            description = "Ajusta el brillo de pantalla (0-255) mediante canal del sistema",
            argumentSchema = mapOf("value" to "Int"),
            riskLevel = RiskLevel.SYSTEM_CHANGE,
            requiresShizuku = true,
            requiresAccessibility = false,
            supportsVerification = false
        ),
        Capability(
            id = "set_media_volume",
            category = CapabilityCategory.SYSTEM,
            description = "Ajusta el volumen multimedia del dispositivo",
            argumentSchema = mapOf("value" to "Int"),
            riskLevel = RiskLevel.SYSTEM_CHANGE,
            requiresShizuku = false,
            requiresAccessibility = false,
            supportsVerification = false
        )
    )

    fun getAllCapabilities(): List<Capability> = catalog

    fun getCapabilities(shizukuReady: Boolean, accessibilityReady: Boolean): List<Capability> {
        return catalog.map { cap ->
            var avail = true
            if (cap.requiresShizuku && !shizukuReady) avail = false
            if (cap.requiresAccessibility && !accessibilityReady) avail = false
            cap.copy(available = avail)
        }
    }

    fun getAvailableCapabilities(shizukuReady: Boolean, accessibilityReady: Boolean): List<Capability> {
        return getCapabilities(shizukuReady, accessibilityReady).filter { it.available }
    }

    fun getCapability(id: String): Capability? {
        return catalog.firstOrNull { it.id == id }
    }

    fun isAvailable(id: String, shizukuReady: Boolean, accessibilityReady: Boolean): Boolean {
        val cap = getCapability(id) ?: return false
        if (cap.requiresShizuku && !shizukuReady) return false
        if (cap.requiresAccessibility && !accessibilityReady) return false
        return true
    }

    fun isExecutable(id: String): Boolean {
        return com.tunnel.turbo.task.NativeTaskExecutor.SUPPORTED_TOOLS.contains(id)
    }

    fun getAdvertisedCapabilities(shizukuReady: Boolean, accessibilityReady: Boolean): List<Capability> {
        return getAvailableCapabilities(shizukuReady, accessibilityReady).filter { isExecutable(it.id) }
    }

    fun getContractMismatches(executorTools: Set<String> = com.tunnel.turbo.task.NativeTaskExecutor.SUPPORTED_TOOLS, shizukuReady: Boolean = false, accessibilityReady: Boolean = false): List<String> {
        val mismatches = mutableListOf<String>()
        for (cap in catalog) {
            if (!executorTools.contains(cap.id)) {
                mismatches.add("Registered capability '${cap.id}' is not in NativeTaskExecutor.SUPPORTED_TOOLS")
            }
        }
        return mismatches
    }
}


