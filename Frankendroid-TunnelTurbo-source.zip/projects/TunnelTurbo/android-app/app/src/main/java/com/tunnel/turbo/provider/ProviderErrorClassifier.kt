package com.tunnel.turbo.provider

enum class ProviderErrorKind {
    RATE_LIMITED,
    NETWORK_ERROR,
    AUTH_REQUIRED,
    PROVIDER_ERROR,
    UNKNOWN_ERROR
}

data class ProviderError(
    val kind: ProviderErrorKind,
    val rawMessage: String,
    val retryable: Boolean = false
) : Exception("[$kind] $rawMessage")

class ProviderErrorClassifier {

    companion object {
        private val RATE_LIMIT_PATTERNS = listOf(
            "too many requests",
            "rate limit",
            "try again later",
            "you've reached a limit",
            "has alcanzado el límite",
            "demasiadas solicitudes",
            "inténtalo de nuevo más tarde",
            "slow down"
        )

        private val AUTH_PATTERNS = listOf(
            "unauthorized",
            "login required",
            "iniciar sesión",
            "auth_required",
            "session expired"
        )

        private val NETWORK_PATTERNS = listOf(
            "network error",
            "connection timeout",
            "sin conexión",
            "unable to resolve host"
        )
    }

    fun classify(raw: String): ProviderError {
        val lower = raw.trim().lowercase()

        for (p in RATE_LIMIT_PATTERNS) {
            if (lower.contains(p)) {
                return ProviderError(
                    kind = ProviderErrorKind.RATE_LIMITED,
                    rawMessage = raw,
                    retryable = true
                )
            }
        }

        for (p in AUTH_PATTERNS) {
            if (lower.contains(p)) {
                return ProviderError(
                    kind = ProviderErrorKind.AUTH_REQUIRED,
                    rawMessage = raw,
                    retryable = false
                )
            }
        }

        for (p in NETWORK_PATTERNS) {
            if (lower.contains(p)) {
                return ProviderError(
                    kind = ProviderErrorKind.NETWORK_ERROR,
                    rawMessage = raw,
                    retryable = true
                )
            }
        }

        if (lower.contains("error") || lower.contains("failed")) {
            return ProviderError(
                kind = ProviderErrorKind.PROVIDER_ERROR,
                rawMessage = raw,
                retryable = false
            )
        }

        return ProviderError(
            kind = ProviderErrorKind.UNKNOWN_ERROR,
            rawMessage = raw,
            retryable = false
        )
    }
}
