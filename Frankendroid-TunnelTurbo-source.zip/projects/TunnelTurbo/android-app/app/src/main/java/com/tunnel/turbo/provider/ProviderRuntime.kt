package com.tunnel.turbo.provider

import com.tunnel.turbo.adapter.ExecutionResult
import com.tunnel.turbo.adapter.TunnelCoreAdapter
import com.tunnel.turbo.input.InputSource
import com.tunnel.turbo.model.PlanValidationError
import com.tunnel.turbo.model.PlanValidator
import com.tunnel.turbo.model.StructuredPlan
import com.tunnel.turbo.router.LocalIntentRouter
import com.tunnel.turbo.router.RouteDecision
import com.tunnel.turbo.router.RouteResult
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

data class ProviderHealth(
    var state: ProviderState = ProviderState.READY,
    var lastSuccessAt: Long = 0L,
    var lastErrorAt: Long = 0L,
    var lastLatencyMs: Double = 0.0,
    var consecutiveErrors: Int = 0,
    var rateLimited: Boolean = false,
    var cooldownUntil: Long = 0L
)

data class ProcessResult(
    val success: Boolean,
    val routeDecision: RouteDecision,
    val requestId: String,
    val plan: StructuredPlan? = null,
    val executionResult: ExecutionResult? = null,
    val error: String? = null,
    val providerState: ProviderState = ProviderState.READY,
    val routingMs: Double = 0.0,
    val providerMs: Double = 0.0,
    val coreMs: Double = 0.0,
    val totalMs: Double = 0.0
)

class ProviderRuntime(
    var activeProvider: IntentProvider? = null,
    val router: LocalIntentRouter = LocalIntentRouter(),
    val validator: PlanValidator = PlanValidator(),
    val coreAdapter: TunnelCoreAdapter = TunnelCoreAdapter(),
    val rateLimitPolicy: RateLimitPolicy = RateLimitPolicy(),
    val errorClassifier: ProviderErrorClassifier = ProviderErrorClassifier(),
    val queue: IntentRequestQueue = IntentRequestQueue()
) {
    val health = ProviderHealth()
    private val aiMutex = Mutex()
    private var requestCounter = 0

    fun nextRequestId(): String {
        requestCounter++
        return String.format("TT_%06d", requestCounter)
    }

    suspend fun processUserIntent(
        userText: String,
        inputSource: InputSource = InputSource.TEXT,
        precomputedRoute: RouteResult? = null
    ): ProcessResult {
        val t0 = System.nanoTime()
        val reqId = nextRequestId()

        // 1. Fast Local Intent Routing (Single-Pass: reuse precomputed route if already determined)
        val routeRes = precomputedRoute ?: router.route(userText)
        val routingMs = routeRes.routingElapsedMs

        when (routeRes.decision) {
            RouteDecision.DIRECT -> {
                // Execute DIRECT plan without touching AI provider
                val plan = routeRes.directPlan!!
                val tCore0 = System.nanoTime()
                val execRes = coreAdapter.executePlan(plan)
                val coreMs = (System.nanoTime() - tCore0) / 1_000_000.0
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0

                return ProcessResult(
                    success = execRes.success,
                    routeDecision = RouteDecision.DIRECT,
                    requestId = reqId,
                    plan = plan,
                    executionResult = execRes,
                    error = if (!execRes.success) (execRes.details.ifEmpty { "Execution failed" }) else null,
                    providerState = health.state,
                    routingMs = routingMs,
                    coreMs = coreMs,
                    totalMs = totalMs
                )
            }

            RouteDecision.UNSUPPORTED -> {
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                return ProcessResult(
                    success = false,
                    routeDecision = RouteDecision.UNSUPPORTED,
                    requestId = reqId,
                    plan = routeRes.directPlan,
                    error = routeRes.reason,
                    providerState = health.state,
                    routingMs = routingMs,
                    totalMs = totalMs
                )
            }

            RouteDecision.NEEDS_OBSERVATION -> {
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                return ProcessResult(
                    success = false,
                    routeDecision = RouteDecision.NEEDS_OBSERVATION,
                    requestId = reqId,
                    plan = routeRes.directPlan,
                    error = "Requiere observación visual interactiva previa",
                    providerState = health.state,
                    routingMs = routingMs,
                    totalMs = totalMs
                )
            }

            RouteDecision.AI_REQUIRED -> {
                // Route to AI Provider under strict rate-limit and concurrency management
                return processWithAiProvider(userText, reqId, routingMs, t0)
            }
        }
    }

    private suspend fun processWithAiProvider(
        userText: String,
        reqId: String,
        routingMs: Double,
        t0: Long
    ): ProcessResult {
        // Enqueue request
        val req = queue.enqueue(
            IntentRequest(requestId = reqId, text = userText, state = RequestState.WAITING_PROVIDER)
        )

        // 1. Check Rate Limit status first
        if (!rateLimitPolicy.canAttempt() || health.state == ProviderState.RATE_LIMITED) {
            health.state = ProviderState.RATE_LIMITED
            health.rateLimited = true
            health.cooldownUntil = rateLimitPolicy.nextAllowedAttemptAt
            queue.updateState(reqId, RequestState.FAILED, error = "PROVIDER_RATE_LIMITED")
            val totalMs = (System.nanoTime() - t0) / 1_000_000.0

            return ProcessResult(
                success = false,
                routeDecision = RouteDecision.AI_REQUIRED,
                requestId = reqId,
                error = "RATE_LIMITED: Proveedor temporalmente limitado. Reintentando tras cooldown de ${rateLimitPolicy.remainingCooldownMs()}ms",
                providerState = ProviderState.RATE_LIMITED,
                routingMs = routingMs,
                totalMs = totalMs
            )
        }

        // 2. Check Provider availability
        val provider = activeProvider
        if (provider == null || health.state == ProviderState.OFFLINE) {
            queue.updateState(reqId, RequestState.FAILED, error = "AI_PROVIDER_UNAVAILABLE")
            val totalMs = (System.nanoTime() - t0) / 1_000_000.0
            return ProcessResult(
                success = false,
                routeDecision = RouteDecision.AI_REQUIRED,
                requestId = reqId,
                error = "AI_PROVIDER_UNAVAILABLE: Proveedor de IA desconectado o no disponible",
                providerState = ProviderState.OFFLINE,
                routingMs = routingMs,
                totalMs = totalMs
            )
        }

        // Concurrency = 1 for AI Provider
        aiMutex.withLock {
            health.state = ProviderState.BUSY
            queue.updateState(reqId, RequestState.EXECUTING)

            val intentResult = try {
                provider.plan(userText, reqId)
            } catch (t: Throwable) {
                IntentResult(
                    success = false,
                    error = t.message ?: t.javaClass.simpleName,
                    providerMs = 0.0
                )
            }

            if (!intentResult.success) {
                val classified = errorClassifier.classify(intentResult.error ?: intentResult.rawResponse)
                health.lastErrorAt = System.currentTimeMillis()
                health.consecutiveErrors++

                if (classified.kind == ProviderErrorKind.RATE_LIMITED) {
                    rateLimitPolicy.recordRateLimit()
                    health.state = ProviderState.RATE_LIMITED
                    health.rateLimited = true
                    health.cooldownUntil = rateLimitPolicy.nextAllowedAttemptAt
                } else {
                    health.state = ProviderState.ERROR
                }

                queue.updateState(reqId, RequestState.FAILED, error = classified.message)
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0

                return ProcessResult(
                    success = false,
                    routeDecision = RouteDecision.AI_REQUIRED,
                    requestId = reqId,
                    error = classified.message,
                    providerState = health.state,
                    routingMs = routingMs,
                    providerMs = intentResult.providerMs,
                    totalMs = totalMs
                )
            }

            // Success path
            rateLimitPolicy.recordSuccess()
            health.state = ProviderState.READY
            health.rateLimited = false
            health.lastSuccessAt = System.currentTimeMillis()
            health.lastLatencyMs = intentResult.providerMs
            health.consecutiveErrors = 0

            // Validate structured plan
            val plan = intentResult.plan
            if (plan == null) {
                queue.updateState(reqId, RequestState.FAILED, error = "PLAN_IS_NULL")
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                return ProcessResult(
                    success = false,
                    routeDecision = RouteDecision.AI_REQUIRED,
                    requestId = reqId,
                    error = "Plan recibido nulo del proveedor",
                    providerState = health.state,
                    routingMs = routingMs,
                    providerMs = intentResult.providerMs,
                    totalMs = totalMs
                )
            }

            // Execute on Core
            val tCore0 = System.nanoTime()
            val execRes = coreAdapter.executePlan(plan)
            val coreMs = (System.nanoTime() - tCore0) / 1_000_000.0
            val totalMs = (System.nanoTime() - t0) / 1_000_000.0

            queue.updateState(reqId, RequestState.COMPLETED, plan = plan)

            return ProcessResult(
                success = execRes.success,
                routeDecision = RouteDecision.AI_REQUIRED,
                requestId = reqId,
                plan = plan,
                executionResult = execRes,
                providerState = health.state,
                routingMs = routingMs,
                providerMs = intentResult.providerMs,
                coreMs = coreMs,
                totalMs = totalMs
            )
        }
    }
}
