package com.tunnel.turbo.core

data class JournalEntry(
    val revision: Long,
    val timestamp: Long,
    val type: String,
    val payload: Map<String, Any> = emptyMap()
)

class NativeEventJournal(val capacity: Int = 1000) {

    private val lock = Any()
    private val buffer = ArrayList<JournalEntry>(capacity)
    private var head = 0
    private var currentSize = 0
    private var revisionCounter = 0L

    fun recordEvent(type: String, payload: Map<String, Any> = emptyMap()): JournalEntry {
        synchronized(lock) {
            revisionCounter++
            val entry = JournalEntry(
                revision = revisionCounter,
                timestamp = System.currentTimeMillis(),
                type = type,
                payload = payload
            )

            if (buffer.size < capacity) {
                buffer.add(entry)
            } else {
                buffer[head] = entry
                head = (head + 1) % capacity
            }
            if (currentSize < capacity) {
                currentSize++
            }
            return entry
        }
    }

    fun getEvents(sinceRevision: Long = 0L, limit: Int = 100): List<JournalEntry> {
        synchronized(lock) {
            val all = getAllInOrder()
            return all.filter { it.revision > sinceRevision }.takeLast(limit)
        }
    }

    fun getAllInOrder(): List<JournalEntry> {
        synchronized(lock) {
            if (buffer.size < capacity) {
                return ArrayList(buffer)
            }
            val result = ArrayList<JournalEntry>(capacity)
            for (i in 0 until capacity) {
                val idx = (head + i) % capacity
                result.add(buffer[idx])
            }
            return result
        }
    }

    fun latestRevision(): Long {
        synchronized(lock) {
            return revisionCounter
        }
    }

    fun size(): Int {
        synchronized(lock) {
            return currentSize
        }
    }

    fun clear() {
        synchronized(lock) {
            buffer.clear()
            head = 0
            currentSize = 0
        }
    }
}
