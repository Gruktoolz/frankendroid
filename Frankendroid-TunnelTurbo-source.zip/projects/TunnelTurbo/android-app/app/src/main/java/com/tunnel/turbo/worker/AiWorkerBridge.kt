package com.tunnel.turbo.worker

import com.tunnel.turbo.accessibility.AccessibilityBridge

data class BridgeResponse(
    val success: Boolean,
    val rawText: String = "",
    val error: String? = null,
    val errorCode: String? = null,
    val elapsedMs: Double = 0.0,
    val requestId: String = "",
    val proofNonce: String = "",
    val turnBefore: Int = 0,
    val turnAfter: Int = 0,
    val injectionTimestamp: Long? = null,
    val responseTimestamp: Long? = null,
    val failureClass: String = "NONE"
)

open class AiWorkerBridge(
    val displayManager: WorkerDisplayManager = PcBackendWorkerDisplayManager(),
    val accessibilityBridge: AccessibilityBridge? = null,
    val context: android.content.Context? = null
) {
    val session = WorkerSession()
    val promptBuffer = WorkerPromptBuffer()
    var lifecycle: WorkerLifecycle = WorkerLifecycle.STOPPED
        private set

    private var recoveryAttemptsForCurrentGoal = 0

    fun start(): Boolean {
        lifecycle = WorkerLifecycle.CREATING_DISPLAY
        val dispId = displayManager.createWorkerDisplay()
        if (dispId == null) {
            lifecycle = WorkerLifecycle.STOPPED
            return false
        }
        session.displayId = dispId

        lifecycle = WorkerLifecycle.LAUNCHING_PROVIDER
        val launched = displayManager.launchProviderApp(session.packageId)
        if (!launched) {
            lifecycle = WorkerLifecycle.STOPPED
            return false
        }

        lifecycle = WorkerLifecycle.WAITING_UI
        val ok = waitForUiReady(timeoutMs = 5000L)
        lifecycle = if (ok) WorkerLifecycle.READY else WorkerLifecycle.STOPPED
        return ok
    }

    var lastInjectionTimestamp: Long? = null
        private set

    fun stop() {
        displayManager.destroyWorkerDisplay()
        session.displayId = null
        promptBuffer.clear()
        lifecycle = WorkerLifecycle.STOPPED
    }

    fun isReady(): Boolean = checkOperationalHealth().isReady

    fun healthCheck(): Boolean = checkOperationalHealth().isReady

    fun resetRecoveryCounter() {
        recoveryAttemptsForCurrentGoal = 0
    }

    open fun checkOperationalHealth(): ProviderHealthReport {
        // Synchronize displayId if known
        var dispId = session.displayId
        val actualId = displayManager.getDisplayId()
        if (dispId == null && actualId != null) {
            session.displayId = actualId
            dispId = actualId
        } else if (actualId != null && dispId != actualId) {
            session.displayId = actualId
            dispId = actualId
        }

        val displayExists = displayManager.healthCheck()
        if (!displayExists || dispId == null) {
            lifecycle = WorkerLifecycle.STOPPED
            return ProviderHealthReport(
                state = ProviderHealthState.UI_UNAVAILABLE,
                isReady = false,
                displayExists = false,
                displayId = dispId,
                providerRunning = false,
                providerForeground = false,
                inputNodeAvailable = false,
                sendNodeAvailable = false,
                accessibilityReadable = false,
                message = "Virtual display is missing or inactive in DisplayManager"
            )
        }

        val acc = accessibilityBridge
        if (acc == null || !acc.isEnabled()) {
            lifecycle = WorkerLifecycle.STOPPED
            return ProviderHealthReport(
                state = ProviderHealthState.UI_UNAVAILABLE,
                isReady = false,
                displayExists = true,
                displayId = dispId,
                providerRunning = false,
                providerForeground = false,
                inputNodeAvailable = false,
                sendNodeAvailable = false,
                accessibilityReadable = false,
                message = "Accessibility service is not bound or enabled"
            )
        }

        val root = acc.findRootForDisplay(dispId)
        if (root == null) {
            lifecycle = WorkerLifecycle.WAITING_UI
            return ProviderHealthReport(
                state = ProviderHealthState.WARMING_UP,
                isReady = false,
                displayExists = true,
                displayId = dispId,
                providerRunning = false,
                providerForeground = false,
                inputNodeAvailable = false,
                sendNodeAvailable = false,
                accessibilityReadable = false,
                message = "Accessibility cannot inspect root window on display $dispId"
            )
        }

        val pkg = root.packageName?.toString() ?: ""
        val isProviderApp = pkg == session.packageId

        // Check authentication requirement
        val authNode = acc.findNode(dispId) {
            val txt = it.text?.toString() ?: ""
            txt.contains("Inicia sesión", ignoreCase = true) || txt.contains("Log in", ignoreCase = true)
        }
        if (authNode != null) {
            lifecycle = WorkerLifecycle.FAILED
            return ProviderHealthReport(
                state = ProviderHealthState.AUTH_REQUIRED,
                isReady = false,
                displayExists = true,
                displayId = dispId,
                providerRunning = isProviderApp,
                providerForeground = isProviderApp,
                inputNodeAvailable = false,
                sendNodeAvailable = false,
                accessibilityReadable = true,
                message = "Provider app requires authentication"
            )
        }

        // Check rate limit
        val rateLimitNode = acc.findNode(dispId) {
            val txt = it.text?.toString() ?: ""
            txt.contains("límite", ignoreCase = true) || txt.contains("rate limit", ignoreCase = true)
        }
        if (rateLimitNode != null) {
            lifecycle = WorkerLifecycle.RATE_LIMITED
            return ProviderHealthReport(
                state = ProviderHealthState.RATE_LIMITED,
                isReady = false,
                displayExists = true,
                displayId = dispId,
                providerRunning = isProviderApp,
                providerForeground = isProviderApp,
                inputNodeAvailable = false,
                sendNodeAvailable = false,
                accessibilityReadable = true,
                message = "Provider app is rate limited"
            )
        }

        val editNode = acc.findNode(dispId) {
            it.isEditable || it.className?.contains("EditText", ignoreCase = true) == true ||
            it.contentDescription?.contains("Preguntar", ignoreCase = true) == true ||
            it.contentDescription?.contains("Responder", ignoreCase = true) == true
        }

        val sendNode = acc.findNode(dispId) {
            val d = it.contentDescription?.toString() ?: ""
            d.contains("Enviar", ignoreCase = true) ||
            d.contains("Send", ignoreCase = true) ||
            d.contains("voz", ignoreCase = true) ||
            d.contains("Dictado", ignoreCase = true)
        }

        if (!isProviderApp) {
            lifecycle = WorkerLifecycle.LAUNCHING_PROVIDER
            return ProviderHealthReport(
                state = ProviderHealthState.STARTING,
                isReady = false,
                displayExists = true,
                displayId = dispId,
                providerRunning = false,
                providerForeground = false,
                inputNodeAvailable = editNode != null,
                sendNodeAvailable = sendNode != null,
                accessibilityReadable = true,
                message = "Provider package ($pkg) is not foreground on display $dispId (expected ${session.packageId})"
            )
        }

        if (editNode == null) {
            lifecycle = WorkerLifecycle.WAITING_UI
            return ProviderHealthReport(
                state = ProviderHealthState.WARMING_UP,
                isReady = false,
                displayExists = true,
                displayId = dispId,
                providerRunning = true,
                providerForeground = true,
                inputNodeAvailable = false,
                sendNodeAvailable = sendNode != null,
                accessibilityReadable = true,
                message = "Input node not yet available on display $dispId"
            )
        }

        lifecycle = WorkerLifecycle.READY
        return ProviderHealthReport(
            state = ProviderHealthState.READY,
            isReady = true,
            displayExists = true,
            displayId = dispId,
            providerRunning = true,
            providerForeground = true,
            inputNodeAvailable = true,
            sendNodeAvailable = sendNode != null,
            accessibilityReadable = true,
            message = "Provider is operationally ready on display $dispId"
        )
    }

    open fun preflight(timeoutMs: Long = 3000L): ProviderHealthReport {
        val deadline = System.currentTimeMillis() + timeoutMs
        var report = checkOperationalHealth()
        if (report.isReady) {
            return report.copy(checkedAt = System.currentTimeMillis())
        }

        var delayMs = 150L
        while (System.currentTimeMillis() < deadline) {
            if (report.state == ProviderHealthState.AUTH_REQUIRED || report.state == ProviderHealthState.RATE_LIMITED) {
                break
            }
            try { Thread.sleep(delayMs) } catch (ignored: Throwable) {}
            delayMs = (delayMs * 1.5).toLong().coerceAtMost(500L)
            report = checkOperationalHealth()
            if (report.isReady) {
                break
            }
        }
        return report
    }

    fun performHealthCheck(): AiWorkerHealthCheck {
        if (session.displayId == null) {
            session.displayId = displayManager.getDisplayId()
        }
        val storedId = session.displayId
        val actualId = displayManager.getDisplayId()
        val displayExists = displayManager.healthCheck()
        val sessionValid = storedId != null && storedId == actualId && displayExists

        val acc = accessibilityBridge
        val a11yReadable = if (acc != null && acc.isEnabled() && actualId != null) {
            acc.findRootForDisplay(actualId) != null
        } else false

        var inputAvail = false
        var sendAvail = false
        var providerFg = false
        var providerRunning = false

        if (acc != null && acc.isEnabled() && actualId != null) {
            val root = acc.findRootForDisplay(actualId)
            val pkg = root?.packageName?.toString() ?: ""
            providerRunning = pkg == session.packageId
            providerFg = providerRunning

            val edit = acc.findNode(actualId) {
                it.isEditable || it.className?.contains("EditText", ignoreCase = true) == true ||
                it.contentDescription?.contains("Preguntar", ignoreCase = true) == true ||
                it.contentDescription?.contains("Responder", ignoreCase = true) == true
            }
            inputAvail = edit != null

            val sendOrVoice = acc.findNode(actualId) {
                val d = it.contentDescription?.toString() ?: ""
                d.contains("Enviar", ignoreCase = true) ||
                d.contains("Send", ignoreCase = true) ||
                d.contains("voz", ignoreCase = true) ||
                d.contains("Dictado", ignoreCase = true)
            }
            sendAvail = sendOrVoice != null
        }

        val ready = displayExists && sessionValid && a11yReadable && inputAvail

        return AiWorkerHealthCheck(
            displayExists = displayExists,
            providerRunning = providerRunning,
            providerForegroundOnWorker = providerFg,
            inputNodeAvailable = inputAvail,
            sendNodeAvailable = sendAvail,
            accessibilityReadable = a11yReadable,
            sessionValid = sessionValid,
            ready = ready,
            storedDisplayId = storedId,
            actualDisplayId = actualId,
            details = "stored=$storedId, actual=$actualId, dispOk=$displayExists, a11y=$a11yReadable, input=$inputAvail"
        )
    }

    fun recoverWorkerDisplay(): Boolean {
        if (recoveryAttemptsForCurrentGoal >= 1) {
            return false // Max 1 recovery per goal
        }
        recoveryAttemptsForCurrentGoal++
        lifecycle = WorkerLifecycle.RECOVERING

        // 1. Invalidate stale session
        session.displayId = null

        // 2. Discover or create active display
        val actualId = displayManager.getDisplayId() ?: displayManager.createWorkerDisplay()
        if (actualId == null) {
            lifecycle = WorkerLifecycle.FAILED
            return false
        }
        session.displayId = actualId

        // 3. Ensure provider app is launched
        displayManager.launchProviderApp(session.packageId)

        // 4. Wait for UI
        lifecycle = WorkerLifecycle.WAITING_UI
        val ok = waitForUiReady(timeoutMs = 6000L)
        lifecycle = if (ok) WorkerLifecycle.READY else WorkerLifecycle.FAILED
        return ok
    }

    private fun waitForUiReady(timeoutMs: Long): Boolean {
        val tEnd = System.currentTimeMillis() + timeoutMs
        val acc = accessibilityBridge ?: return session.displayId != null
        val dispId = session.displayId ?: return false

        while (System.currentTimeMillis() < tEnd) {
            val editNode = acc.findNode(dispId) {
                it.isEditable || it.className?.contains("EditText", ignoreCase = true) == true ||
                it.contentDescription?.contains("Preguntar", ignoreCase = true) == true ||
                it.contentDescription?.contains("Responder", ignoreCase = true) == true
            }
            if (editNode != null) return true
            try { Thread.sleep(250) } catch (ignored: Throwable) {}
        }
        return false
    }

    open fun countConversationTurns(dispId: Int): Int {
        val acc = accessibilityBridge ?: return 0
        val nodes = acc.getUiNodes(dispId)
        return nodes.count { it.className == "android.widget.TextView" && it.text.isNotBlank() }
    }

    open fun sendRequest(prompt: String, requestId: String, proofNonce: String): Boolean {
        val hc = performHealthCheck()
        if (!hc.ready) {
            // Attempt controlled 1-time recovery
            val recovered = recoverWorkerDisplay()
            if (!recovered) {
                lifecycle = WorkerLifecycle.FAILED
                return false
            }
        }

        val dispId = session.displayId ?: return false
        val acc = accessibilityBridge ?: return true
        if (!acc.isEnabled()) return true

        promptBuffer.setPrompt(requestId, prompt)
        val fullPrompt = "REQUEST_ID: $requestId\nPROOF_NONCE: $proofNonce\n$prompt"

        val editNode = acc.findNode(dispId) {
            it.isEditable || it.className?.contains("EditText", ignoreCase = true) == true
        } ?: acc.findNode(dispId) {
            it.contentDescription?.contains("Preguntar", ignoreCase = true) == true ||
            it.contentDescription?.contains("Responder", ignoreCase = true) == true
        } ?: return false

        val ok = acc.performSetText(editNode, fullPrompt)
        if (!ok) return false

        lastInjectionTimestamp = System.currentTimeMillis()
        lifecycle = WorkerLifecycle.BUSY

        // Wait up to 1.5s for the Send button to become active
        var sendClicked = false
        for (i in 0 until 6) {
            val sendNode = acc.findNode(dispId) {
                val d = it.contentDescription?.toString() ?: ""
                d.contains("Enviar", ignoreCase = true) || d.contains("Send", ignoreCase = true)
            }
            if (sendNode != null) {
                sendClicked = acc.performClick(sendNode, dispId)
                if (sendClicked) break
            }
            try { Thread.sleep(250) } catch (ignored: Throwable) {}
        }

        if (!sendClicked) {
            val sendNode = acc.findNode(dispId) {
                it.contentDescription?.contains("Enviar") == true || it.contentDescription?.contains("Send") == true
            }
            if (sendNode != null) {
                acc.performClick(sendNode, dispId)
            }
        }

        return true
    }

    // Overload for backward compatibility
    open fun sendRequest(prompt: String, requestId: String): Boolean =
        sendRequest(prompt, requestId, "TT_PROOF_${System.currentTimeMillis() % 100000}")

    open fun readResponse(
        requestId: String,
        proofNonce: String,
        turnBefore: Int,
        timeoutMs: Long = 25000L
    ): BridgeResponse {
        val t0 = System.nanoTime()
        val acc = accessibilityBridge
        val dispId = session.displayId

        if (acc == null || dispId == null || !acc.isEnabled()) {
            val elapsed = (System.nanoTime() - t0) / 1_000_000.0
            return BridgeResponse(
                success = false,
                error = "WORKER_DISPLAY_LOST: AccessibilityBridge no está habilitado o display es nulo",
                errorCode = "WORKER_DISPLAY_LOST",
                elapsedMs = elapsed,
                requestId = requestId,
                proofNonce = proofNonce,
                turnBefore = turnBefore,
                injectionTimestamp = lastInjectionTimestamp,
                responseTimestamp = System.currentTimeMillis(),
                failureClass = ProviderFailureClass.PROVIDER_UI_NOT_READY.name
            )
        }

        val deadline = System.currentTimeMillis() + timeoutMs
        var detectedGenerating = false

        while (System.currentTimeMillis() < deadline) {
            // Check if worker display still exists
            if (!displayManager.healthCheck()) {
                val elapsed = (System.nanoTime() - t0) / 1_000_000.0
                lifecycle = WorkerLifecycle.FAILED
                return BridgeResponse(
                    success = false,
                    error = "WORKER_DISPLAY_LOST: El display del worker se desconectó",
                    errorCode = "WORKER_DISPLAY_LOST",
                    elapsedMs = elapsed,
                    requestId = requestId,
                    proofNonce = proofNonce,
                    turnBefore = turnBefore,
                    injectionTimestamp = lastInjectionTimestamp,
                    responseTimestamp = System.currentTimeMillis(),
                    failureClass = ProviderFailureClass.PROVIDER_UI_NOT_READY.name
                )
            }

            // Check for rate limit or auth required in UI
            val rateLimitNode = acc.findNode(dispId) {
                val txt = it.text?.toString() ?: ""
                txt.contains("límite", ignoreCase = true) || txt.contains("rate limit", ignoreCase = true)
            }
            if (rateLimitNode != null) {
                val elapsed = (System.nanoTime() - t0) / 1_000_000.0
                lifecycle = WorkerLifecycle.RATE_LIMITED
                return BridgeResponse(
                    success = false,
                    error = "PROVIDER_RATE_LIMITED: Límite de tasa alcanzado en el proveedor",
                    errorCode = "PROVIDER_RATE_LIMITED",
                    elapsedMs = elapsed,
                    requestId = requestId,
                    proofNonce = proofNonce,
                    turnBefore = turnBefore,
                    injectionTimestamp = lastInjectionTimestamp,
                    responseTimestamp = System.currentTimeMillis(),
                    failureClass = ProviderFailureClass.PROVIDER_RATE_LIMITED.name
                )
            }

            val authNode = acc.findNode(dispId) {
                val txt = it.text?.toString() ?: ""
                txt.contains("Inicia sesión", ignoreCase = true) || txt.contains("Log in", ignoreCase = true)
            }
            if (authNode != null) {
                val elapsed = (System.nanoTime() - t0) / 1_000_000.0
                lifecycle = WorkerLifecycle.FAILED
                return BridgeResponse(
                    success = false,
                    error = "AUTH_REQUIRED: Sesión requerida en app de IA",
                    errorCode = "AUTH_REQUIRED",
                    elapsedMs = elapsed,
                    requestId = requestId,
                    proofNonce = proofNonce,
                    turnBefore = turnBefore,
                    injectionTimestamp = lastInjectionTimestamp,
                    responseTimestamp = System.currentTimeMillis(),
                    failureClass = ProviderFailureClass.PROVIDER_AUTH_REQUIRED.name
                )
            }

            // Check if stop generation button is present (meaning ChatGPT is currently generating)
            val stopGenNode = acc.findNode(dispId) {
                val d = it.contentDescription?.toString() ?: ""
                d.contains("Detener", ignoreCase = true) || d.contains("Stop", ignoreCase = true)
            }
            if (stopGenNode != null) {
                detectedGenerating = true
            }

            // Look for matching response node with proofNonce and requestId
            val nodes = acc.getUiNodes(dispId)
            val currentTurns = nodes.count { it.className == "android.widget.TextView" && it.text.isNotBlank() }
            for (n in nodes) {
                val txt = n.text
                if (txt.contains("{") && txt.contains("}") && txt.contains(proofNonce)) {
                    val sIdx = txt.indexOf('{')
                    val eIdx = txt.lastIndexOf('}')
                    if (sIdx >= 0 && eIdx > sIdx) {
                        val candidateJson: String = txt.substring(sIdx, eIdx + 1)
                        try {
                            val parsed = org.json.JSONObject(candidateJson)
                            val respNonce = parsed.optString("proof_nonce")
                            val respReqId = parsed.optString("request_id")
                            if (respNonce == proofNonce && respReqId == requestId) {
                                val elapsed = (System.nanoTime() - t0) / 1_000_000.0
                                promptBuffer.clear()
                                lifecycle = WorkerLifecycle.READY
                                return BridgeResponse(
                                    success = true,
                                    rawText = candidateJson,
                                    requestId = requestId,
                                    proofNonce = proofNonce,
                                    turnBefore = turnBefore,
                                    turnAfter = if (currentTurns > turnBefore) currentTurns else turnBefore + 1,
                                    elapsedMs = elapsed,
                                    injectionTimestamp = lastInjectionTimestamp,
                                    responseTimestamp = System.currentTimeMillis(),
                                    failureClass = ProviderFailureClass.NONE.name
                                )
                            }
                        } catch (ignored: Throwable) {}
                    }
                }
            }

            try { Thread.sleep(400) } catch (ignored: Throwable) {}
        }

        val elapsed = (System.nanoTime() - t0) / 1_000_000.0
        val finalErrorCode = if (detectedGenerating) "PROVIDER_GENERATING" else "RESPONSE_NOT_DETECTED"
        val finalErrorMsg = if (detectedGenerating) {
            "PROVIDER_GENERATING: El modelo seguía generando respuesta tras ${timeoutMs}ms"
        } else {
            "RESPONSE_NOT_DETECTED: No se detectó respuesta válida con proof_nonce $proofNonce en display $dispId tras ${timeoutMs}ms"
        }

        lifecycle = if (detectedGenerating) WorkerLifecycle.WAITING_UI else WorkerLifecycle.STOPPED
        val finalTurns = countConversationTurns(dispId)
        return BridgeResponse(
            success = false,
            error = finalErrorMsg,
            errorCode = finalErrorCode,
            elapsedMs = elapsed,
            requestId = requestId,
            proofNonce = proofNonce,
            turnBefore = turnBefore,
            turnAfter = finalTurns,
            injectionTimestamp = lastInjectionTimestamp,
            responseTimestamp = System.currentTimeMillis(),
            failureClass = ProviderFailureClass.PROVIDER_RESPONSE_TIMEOUT.name
        )
    }

    // Overload for backward compatibility
    fun readResponse(requestId: String, timeoutMs: Long = 18000L): BridgeResponse =
        readResponse(requestId, "", 0, timeoutMs)
}
