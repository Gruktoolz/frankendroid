package com.tunnel.turbo.agent

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class GoalRisk {
    READ_ONLY,
    LOW_RISK,
    REVERSIBLE,
    EXTERNAL_EFFECT,
    DESTRUCTIVE
}

data class GoalEntity(
    val type: String, // e.g. "artist", "app", "setting", "query", "activity"
    val value: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", type)
        put("value", value)
    }

    companion object {
        fun fromJson(json: JSONObject): GoalEntity = GoalEntity(
            type = json.optString("type", "unknown"),
            value = json.optString("value", "")
        )
    }
}

data class Goal(
    val goalId: String = "goal_${UUID.randomUUID().toString().substring(0, 8)}",
    val originalText: String,
    val objective: String,
    val entities: List<GoalEntity> = emptyList(),
    val constraints: List<String> = emptyList(),
    val desiredState: String = "",
    val risk: GoalRisk = GoalRisk.LOW_RISK,
    val categoryHint: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("goalId", goalId)
        put("originalText", originalText)
        put("objective", objective)
        val eArr = JSONArray()
        entities.forEach { eArr.put(it.toJson()) }
        put("entities", eArr)
        val cArr = JSONArray()
        constraints.forEach { cArr.put(it) }
        put("constraints", cArr)
        put("desiredState", desiredState)
        put("risk", risk.name)
        if (categoryHint != null) put("categoryHint", categoryHint)
        put("createdAt", createdAt)
    }

    companion object {
        fun fromJson(json: JSONObject): Goal {
            val entitiesList = mutableListOf<GoalEntity>()
            val eArr = json.optJSONArray("entities")
            if (eArr != null) {
                for (i in 0 until eArr.length()) {
                    val obj = eArr.optJSONObject(i)
                    if (obj != null) entitiesList.add(GoalEntity.fromJson(obj))
                }
            }
            val constraintsList = mutableListOf<String>()
            val cArr = json.optJSONArray("constraints")
            if (cArr != null) {
                for (i in 0 until cArr.length()) {
                    constraintsList.add(cArr.optString(i))
                }
            }
            return Goal(
                goalId = json.optString("goalId", "goal_${UUID.randomUUID().toString().substring(0, 8)}"),
                originalText = json.optString("originalText", ""),
                objective = json.optString("objective", ""),
                entities = entitiesList,
                constraints = constraintsList,
                desiredState = json.optString("desiredState", ""),
                risk = if (json.has("risk")) {
                    val rStr = json.getString("risk")
                    try {
                        GoalRisk.valueOf(rStr)
                    } catch (t: Throwable) {
                        throw IllegalArgumentException("Unknown or invalid risk level '$rStr' at trust boundary")
                    }
                } else {
                    throw IllegalArgumentException("Missing required 'risk' field at trust boundary")
                },
                categoryHint = if (json.has("categoryHint")) json.optString("categoryHint") else null,
                createdAt = json.optLong("createdAt", System.currentTimeMillis())
            )
        }
    }
}

class GoalInterpreter {
    fun interpret(userText: String): Goal {
        val trimmed = userText.trim()
        val lower = trimmed.lowercase()

        // 0. Non-Operational Conversational / Slang / Frustration (Section 12)
        val nonOperationalPhrases = listOf(
            "no mames", "no sirve", "jaja", "xd", "chale", "wey", "chinga", "mierda", "que onda", "que tal", "hola"
        )
        val hasOperationalAction = lower.contains("abre") || lower.contains("pon ") || lower.contains("manda") ||
                lower.contains("enciende") || lower.contains("apaga") || lower.contains("busca") ||
                lower.contains("ver ") || lower.contains("reproduce") || lower.contains("configura")
        if (nonOperationalPhrases.any { lower.contains(it) } && !hasOperationalAction) {
            return Goal(
                originalText = trimmed,
                objective = "NON_OPERATIONAL",
                entities = emptyList(),
                desiredState = "",
                risk = GoalRisk.READ_ONLY,
                categoryHint = "CONVERSATIONAL_NON_OPERATIONAL"
            )
        }

        // 1. Incomplete Messaging Requests (Section 13)
        // e.g. "manda mensaje por WhatsApp" missing recipient and message content
        if ((lower.contains("manda mensaje") || lower.contains("envia mensaje") || lower.contains("enviar mensaje") || lower.contains("manda un mensaje")) &&
            lower.contains("whatsapp")
        ) {
            val hasRecipient = lower.contains(" a ") || lower.contains(" para ")
            val hasContent = lower.contains(" que diga ") || lower.contains(" diciendo ") || lower.contains(" texto ")
            if (!hasRecipient || !hasContent) {
                return Goal(
                    originalText = trimmed,
                    objective = "Mandar mensaje por WhatsApp",
                    entities = listOf(GoalEntity(type = "app", value = "WhatsApp")),
                    desiredState = "Mensaje enviado a destinatario",
                    risk = GoalRisk.EXTERNAL_EFFECT,
                    categoryHint = "INCOMPLETE_REQUEST"
                )
            }
        }

        // 2. Fuzzy / Typo Bluetooth (Section 14)
        // e.g. "enciende blueytyohn", "prende bluetooh", etc.
        if (lower.contains("blueytyohn") || lower.contains("bluetoot") || lower.contains("bluetoth") || lower.contains("blue tooth")) {
            val isTurnOn = lower.contains("enciende") || lower.contains("prende") || lower.contains("activa") || lower.contains("conecta")
            return Goal(
                originalText = trimmed,
                objective = if (isTurnOn) "Encender Bluetooth" else "Configurar Bluetooth",
                entities = listOf(GoalEntity(type = "setting", value = "bluetooth")),
                desiredState = if (isTurnOn) "Bluetooth encendido" else "Bluetooth configurado",
                risk = GoalRisk.LOW_RISK,
                categoryHint = "CONNECTIVITY_BLUETOOTH"
            )
        }

        // 3. Photos / Gallery (Section 15)
        if (lower.contains("mis fotos") || lower.contains("ver fotos") || lower.contains("las fotos") || lower.contains("galería") || lower.contains("galeria")) {
            return Goal(
                originalText = trimmed,
                objective = "Ver fotos",
                entities = listOf(GoalEntity(type = "app", value = "fotos")),
                desiredState = "Galería de fotos visible",
                risk = GoalRisk.READ_ONLY,
                categoryHint = "PHOTOS_GALLERY"
            )
        }

        // 4. Music / Audio Goals
        if (lower.contains("escuchar") || lower.contains("reproduce") || lower.contains("pon ") || lower.contains("musica") || lower.contains("música")) {
            val artistOrTrack = when {
                lower.startsWith("quiero escuchar a ") -> trimmed.substring(18).trim()
                lower.startsWith("quiero escuchar ") -> trimmed.substring(16).trim()
                lower.startsWith("escuchar a ") -> trimmed.substring(11).trim()
                lower.startsWith("escuchar ") -> trimmed.substring(9).trim()
                lower.startsWith("reproducir a ") -> trimmed.substring(13).trim()
                lower.startsWith("reproducir ") -> trimmed.substring(11).trim()
                lower.startsWith("reproduce a ") -> trimmed.substring(12).trim()
                lower.startsWith("reproduce ") -> trimmed.substring(10).trim()
                lower.startsWith("pon a ") -> trimmed.substring(6).trim()
                lower.startsWith("pon ") -> trimmed.substring(4).trim()
                else -> trimmed
            }
            return Goal(
                originalText = trimmed,
                objective = "Reproducir música de $artistOrTrack",
                entities = listOf(GoalEntity(type = "artist", value = artistOrTrack)),
                desiredState = "Música de $artistOrTrack reproduciéndose",
                risk = GoalRisk.LOW_RISK,
                categoryHint = "MEDIA_PLAYBACK"
            )
        }

        // 5. Settings / Configuration Search Goals
        if (lower.contains("tamaño de letra") || lower.contains("tamano de letra") || lower.contains("fuente") || lower.contains("font size")) {
            return Goal(
                originalText = trimmed,
                objective = "Encontrar ajuste de tamaño de letra",
                entities = listOf(GoalEntity(type = "setting", value = "tamaño de letra")),
                desiredState = "Pantalla de configuración de tamaño de fuente visible",
                risk = GoalRisk.READ_ONLY,
                categoryHint = "SYSTEM_SETTINGS"
            )
        }

        // Extract negative constraints (e.g. "sin abrir", "sin escribir")
        val extractedConstraints = mutableListOf<String>()
        val sinMatch = Regex("""\bsin\s+([^,.;]+)""", RegexOption.IGNORE_CASE).find(trimmed)
        if (sinMatch != null) {
            extractedConstraints.add("sin ${sinMatch.groupValues[1].trim()}")
        }

        // 6. Productivity / Notes Goals
        // Match ONLY when the primary imperative is explicitly creating/taking notes,
        // and NOT when the user is opening another app or specifying "sin escribir".
        val isExplicitNoteCreation = (lower.startsWith("toma una nota") || lower.startsWith("tomar nota") ||
                lower.startsWith("escribe una nota") || lower.startsWith("escribir una nota") ||
                lower.startsWith("crear nota") || lower.startsWith("nueva nota") ||
                lower.startsWith("crea una nota") || lower.startsWith("nuevo apunte")) &&
                !lower.contains("sin escribir")

        if (isExplicitNoteCreation) {
            return Goal(
                originalText = trimmed,
                objective = "Tomar notas",
                entities = listOf(GoalEntity(type = "activity", value = "notas")),
                constraints = extractedConstraints,
                desiredState = "Aplicación de notas lista para escribir",
                risk = GoalRisk.LOW_RISK,
                categoryHint = "PRODUCTIVITY"
            )
        }

        // 7. Open General Intent / Unknown Goal (General reasoning with semantic preservation)
        val extractedEntities = mutableListOf<GoalEntity>()
        val appMatch = Regex("""\babre\s+([A-Za-z0-9_.\s]+?)(?:\s+(?:y|para)\b|,|$)""", RegexOption.IGNORE_CASE).find(trimmed)
        if (appMatch != null) {
            val candidate = appMatch.groupValues[1].trim()
            if (candidate.isNotBlank() && candidate.length <= 40) {
                extractedEntities.add(GoalEntity(type = "app", value = candidate))
            }
        }

        return Goal(
            originalText = trimmed,
            objective = trimmed,
            entities = extractedEntities,
            constraints = extractedConstraints,
            desiredState = "Objetivo completado: $trimmed",
            risk = if (lower.contains("eliminar") || lower.contains("borrar")) GoalRisk.DESTRUCTIVE else GoalRisk.LOW_RISK,
            categoryHint = null
        )
    }
}
