package com.tunnel.turbo.agent

import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.capability.CapabilityRegistry
import com.tunnel.turbo.core.NativeStateEngine
import com.tunnel.turbo.core.NativeTunnelCore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

data class AgentRuntimeState(
    val isBusy: Boolean = false,
    val currentGoal: Goal? = null,
    val lastResult: AgentTaskResult? = null,
    val activeSkill: String? = null,
    val lastAiRounds: Int = 0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("isBusy", isBusy)
        if (currentGoal != null) put("currentGoal", currentGoal.toJson())
        if (lastResult != null) put("lastResult", lastResult.toJson())
        if (activeSkill != null) put("activeSkill", activeSkill)
        put("lastAiRounds", lastAiRounds)
    }
}

class GeneralAgentRuntime(
    val core: NativeTunnelCore,
    val appManager: AppManager,
    val capabilityRegistry: CapabilityRegistry,
    val accessibilityBridge: AccessibilityBridge,
    val stateEngine: NativeStateEngine,
    val skillMemory: SkillMemory = SkillMemory(core.context),
    reasoningProvider: ReasoningProvider = AndroidAiAppReasoningProvider()
) {
    private val defaultReasoningProvider = reasoningProvider
    @Volatile var reasoningProvider: ReasoningProvider = reasoningProvider
        private set

    fun setReasoningProvider(provider: ReasoningProvider) {
        reasoningProvider = provider
    }

    fun useDefaultReasoningProvider() {
        reasoningProvider = defaultReasoningProvider
    }

    companion object {
        var strictRealProviderMode: Boolean = false
    }
    val goalInterpreter = GoalInterpreter()
    val worldModel = WorldModel(
        appManager = appManager,
        capabilityRegistry = capabilityRegistry,
        accessibilityBridge = accessibilityBridge,
        stateEngine = stateEngine,
        skillMemory = skillMemory
    )

    val adaptivePlanner = AdaptivePlanner(
        core = core,
        worldModel = worldModel,
        skillMemory = skillMemory,
        reasoningProvider = reasoningProvider
    )

    private val _runtimeState = MutableStateFlow(AgentRuntimeState())
    val runtimeState: StateFlow<AgentRuntimeState> = _runtimeState.asStateFlow()

    val sessionsById = java.util.concurrent.ConcurrentHashMap<String, AgentSession>()

    var activeSession: AgentSession? = null
        private set

    fun getSession(sessionId: String): AgentSession? {
        return sessionsById[sessionId] ?: if (activeSession?.sessionId == sessionId) activeSession else null
    }

    suspend fun executeGoal(
        goal: Goal,
        displayId: Int = 0,
        budget: AgentBudget = AgentBudget()
    ): AgentTaskResult {
        val session = AgentSession(
            goal = goal,
            core = core,
            worldModel = worldModel,
            skillMemory = skillMemory,
            reasoningProvider = reasoningProvider,
            displayId = displayId,
            budget = budget
        )
        activeSession = session
        sessionsById[session.sessionId] = session

        _runtimeState.value = _runtimeState.value.copy(
            isBusy = true,
            currentGoal = goal
        )

        try {
            val result = session.execute()
            _runtimeState.value = _runtimeState.value.copy(
                lastResult = result,
                activeSkill = result.skillUsed,
                lastAiRounds = result.aiRounds
            )
            return result
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val elapsedMs = (System.nanoTime() - session.t0) / 1_000_000.0
            val errResult = AgentTaskResult(
                goalId = goal.goalId,
                sessionId = session.sessionId,
                goal = goal,
                success = false,
                successType = SuccessType.FAILED,
                failureReason = FailureReason.STEP_FAILED,
                message = "Excepción en runtime de agente: ${t.message}",
                steps = session.recordedSteps,
                aiRounds = session.budget.providerRounds,
                aiRoundReasons = session.aiReasons,
                replansCount = session.replansCount,
                totalElapsedMs = elapsedMs,
                hardcodedShortcutsUsed = 0
            )
            _runtimeState.value = _runtimeState.value.copy(
                lastResult = errResult
            )
            return errResult
        } finally {
            _runtimeState.value = _runtimeState.value.copy(isBusy = false)
        }
    }

    suspend fun executeUserGoal(
        userText: String,
        displayId: Int = 0,
        budget: AgentBudget = AgentBudget()
    ): AgentTaskResult {
        val goal = goalInterpreter.interpret(userText)
        return executeGoal(goal, displayId, budget)
    }

    suspend fun resumeSession(sessionId: String, userResponse: String): AgentTaskResult {
        val session = getSession(sessionId)
            ?: throw IllegalArgumentException("Unknown sessionId: $sessionId")
        if (session.status != SessionStatus.PAUSED_NEEDS_USER) {
            throw IllegalStateException("Session $sessionId is not in PAUSED_NEEDS_USER state (status=${session.status})")
        }

        _runtimeState.value = _runtimeState.value.copy(
            isBusy = true,
            currentGoal = session.effectiveGoal
        )

        try {
            val result = session.resume(userResponse)
            _runtimeState.value = _runtimeState.value.copy(
                lastResult = result,
                activeSkill = result.skillUsed,
                lastAiRounds = result.aiRounds
            )
            return result
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val elapsedMs = (System.nanoTime() - session.t0) / 1_000_000.0
            val errResult = AgentTaskResult(
                goalId = session.effectiveGoal.goalId,
                sessionId = session.sessionId,
                goal = session.effectiveGoal,
                success = false,
                successType = SuccessType.FAILED,
                failureReason = FailureReason.STEP_FAILED,
                message = "Excepción al reanudar sesión: ${t.message}",
                steps = session.recordedSteps,
                aiRounds = session.budget.providerRounds,
                aiRoundReasons = session.aiReasons,
                replansCount = session.replansCount,
                totalElapsedMs = elapsedMs,
                hardcodedShortcutsUsed = 0
            )
            _runtimeState.value = _runtimeState.value.copy(
                lastResult = errResult
            )
            return errResult
        } finally {
            _runtimeState.value = _runtimeState.value.copy(isBusy = false)
        }
    }
}
