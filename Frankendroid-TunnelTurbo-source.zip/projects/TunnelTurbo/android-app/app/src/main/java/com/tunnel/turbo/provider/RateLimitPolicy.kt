package com.tunnel.turbo.provider

class RateLimitPolicy(
    val baseCooldownMs: Long = 10_000L,
    val maxCooldownMs: Long = 60_000L,
    val maxAutoRetries: Int = 1
) {
    var consecutiveRateLimits: Int = 0
        private set
    var lastRateLimitAt: Long = 0L
        private set
    var nextAllowedAttemptAt: Long = 0L
        private set

    fun canAttempt(): Boolean {
        val now = System.currentTimeMillis()
        return now >= nextAllowedAttemptAt
    }

    fun remainingCooldownMs(): Long {
        val now = System.currentTimeMillis()
        return (nextAllowedAttemptAt - now).coerceAtLeast(0L)
    }

    fun recordRateLimit() {
        val now = System.currentTimeMillis()
        consecutiveRateLimits++
        lastRateLimitAt = now

        // Exponential backoff: baseCooldown * 2^(consecutive - 1) up to maxCooldown
        val multiplier = 1 shl (consecutiveRateLimits - 1).coerceIn(0, 5)
        val computedCooldown = (baseCooldownMs * multiplier).coerceAtMost(maxCooldownMs)
        nextAllowedAttemptAt = now + computedCooldown
    }

    fun recordSuccess() {
        consecutiveRateLimits = 0
        lastRateLimitAt = 0L
        nextAllowedAttemptAt = 0L
    }

    fun shouldAutoRetry(attemptCount: Int): Boolean {
        // Strict guard: Maximum 1 auto-retry, and ONLY if canAttempt is true
        return attemptCount <= maxAutoRetries && canAttempt()
    }
}
