package com.tunnel.turbo.accessibility

import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

open class AccessibilityBridge(private val context: Context? = null) {

    open fun isConnected(): Boolean {
        return TunnelTurboAccessibilityService.instance != null
    }

    open fun isEnabled(): Boolean {
        val ctx = context
        if (ctx != null) {
            val enabledServices = Settings.Secure.getString(
                ctx.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            val a11yOn = try {
                Settings.Secure.getInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
            } catch (_: Throwable) {
                false
            }
            if (a11yOn && enabledServices.contains("com.tunnel.turbo")) return true
        }
        return TunnelTurboAccessibilityService.instance != null
    }

    open fun getHistoricalExitReason(): String? {
        val ctx = context ?: return null
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            try {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
                val reasons = am?.getHistoricalProcessExitReasons(ctx.packageName, 0, 1)
                val top = reasons?.firstOrNull()
                if (top != null) {
                    return "reason=${top.reason},desc=${top.description}"
                }
            } catch (_: Throwable) {}
        }
        return null
    }

    open fun getServiceState(): AccessibilityServiceState {
        val connected = isConnected()
        val enabled = isEnabled()
        val exit = getHistoricalExitReason()
        val status = when {
            connected -> "CONNECTED"
            enabled && exit != null && (exit.contains("reason=4") || exit.contains("reason=5") || exit.contains("reason=6") || exit.contains("reason=10") || exit.contains("reason=13") || exit.contains("reason=16")) -> "CRASHED_OR_BLOCKED"
            enabled -> "ENABLED_NOT_BOUND"
            else -> "DISABLED"
        }
        return AccessibilityServiceState(
            isEnabled = enabled,
            isConnected = connected,
            status = status,
            connectedAtMs = TunnelTurboAccessibilityService.connectedAtMs,
            disconnectedAtMs = TunnelTurboAccessibilityService.disconnectedAtMs,
            connectionCount = TunnelTurboAccessibilityService.connectionCount,
            lastEventAtMs = TunnelTurboAccessibilityService.lastEventAtMs,
            lastEventType = TunnelTurboAccessibilityService.lastEventType,
            lastEventPackage = TunnelTurboAccessibilityService.lastEventPackage,
            flags = TunnelTurboAccessibilityService.serviceFlags,
            capabilities = TunnelTurboAccessibilityService.serviceCapabilities,
            exitReason = exit
        )
    }

    open fun getWindowsForDisplay(displayId: Int): List<AccessibilityWindowInfo> {
        val s = TunnelTurboAccessibilityService.instance ?: return emptyList()
        return s.getWindowsForDisplay(displayId)
    }

    open fun findRootForDisplay(displayId: Int): AccessibilityNodeInfo? {
        val s = TunnelTurboAccessibilityService.instance ?: return null
        return s.findRootForDisplay(displayId)
    }

    open fun findNode(displayId: Int, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val s = TunnelTurboAccessibilityService.instance ?: return null
        return s.findNode(displayId, predicate)
    }

    open fun performSetText(node: AccessibilityNodeInfo, text: String): Boolean {
        val s = TunnelTurboAccessibilityService.instance ?: return false
        return s.performSetText(node, text)
    }

    open fun performClick(node: AccessibilityNodeInfo, displayId: Int = 0): Boolean {
        val s = TunnelTurboAccessibilityService.instance ?: return false
        return s.performClick(node, displayId)
    }

    open fun performGlobalAction(action: Int): Boolean {
        val s = TunnelTurboAccessibilityService.instance ?: return false
        return s.performGlobalAction(action)
    }

    // --- General Capability Primitives (Fase 10) ---

    open fun getUiNodes(displayId: Int = 0): List<UiNodeInfo> {
        val s = TunnelTurboAccessibilityService.instance ?: return emptyList()
        return s.getUiNodes(displayId)
    }

    open fun getUiSnapshot(displayId: Int = 0, includeVisibleText: Boolean = true, windowId: Int? = null): AccessibilitySnapshot {
        val s = TunnelTurboAccessibilityService.instance ?: return AccessibilitySnapshot(
            nodes = getUiNodes(displayId),
            visibleText = if (includeVisibleText) getVisibleText(displayId) else "",
            possibleTruncation = false,
            foregroundPackage = getForegroundPackage(displayId),
            foregroundActivity = getForegroundActivity(displayId)
        )
        return s.getUiSnapshot(displayId, includeVisibleText = includeVisibleText, windowId = windowId)
    }

    open fun getUiSnapshotForWindow(
        window: AccessibilityWindowInfo,
        displayId: Int = 0,
        maxNodes: Int = 120,
        includeVisibleText: Boolean = false
    ): AccessibilitySnapshot? {
        val s = TunnelTurboAccessibilityService.instance ?: return null
        return s.getUiSnapshotForWindow(window, displayId, maxNodes, includeVisibleText)
    }

    open fun findUiNodes(selector: SemanticSelector, displayId: Int = 0, match: String = "first"): List<UiNodeInfo> {
        val s = TunnelTurboAccessibilityService.instance ?: return emptyList()
        return s.findUiNodes(selector, displayId, match)
    }

    open fun getVisibleText(displayId: Int = 0): String {
        val s = TunnelTurboAccessibilityService.instance ?: return ""
        return s.getVisibleText(displayId)
    }

    open fun getForegroundPackage(displayId: Int = 0): String {
        val s = TunnelTurboAccessibilityService.instance ?: return ""
        return s.findRootForDisplay(displayId)?.packageName?.toString() ?: ""
    }

    open fun getForegroundActivity(displayId: Int = 0): String {
        val s = TunnelTurboAccessibilityService.instance ?: return ""
        return s.findRootForDisplay(displayId)?.className?.toString() ?: ""
    }

    fun clickNode(selector: SemanticSelector, displayId: Int = 0): Boolean {
        val s = TunnelTurboAccessibilityService.instance ?: return false
        return s.clickNode(selector, displayId)
    }

    fun setText(selector: SemanticSelector, text: String, displayId: Int = 0): Boolean {
        val s = TunnelTurboAccessibilityService.instance ?: return false
        return s.setText(selector, text, displayId)
    }

    fun scroll(direction: String, selector: SemanticSelector? = null, displayId: Int = 0): Boolean {
        val s = TunnelTurboAccessibilityService.instance ?: return false
        return s.scroll(direction, selector, displayId)
    }

    fun takeScreenshot(displayId: Int = 0, timeoutMs: Long = 1500L): android.graphics.Bitmap? {
        val s = TunnelTurboAccessibilityService.instance ?: return null
        return s.takeScreenshotAsync(displayId, timeoutMs)
    }
}

