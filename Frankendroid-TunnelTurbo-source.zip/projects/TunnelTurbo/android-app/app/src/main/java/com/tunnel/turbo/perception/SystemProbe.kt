package com.tunnel.turbo.perception

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.PowerManager
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.core.NativeStateEngine

class SystemProbe(
    private val context: Context?,
    private val stateEngine: NativeStateEngine,
    private val appManager: AppManager
) {

    fun probeSystemState(displayId: Int = 0): Map<String, Any> {
        val stateMap = mutableMapOf<String, Any>()
        val curr = stateEngine.currentState

        stateMap["displayId"] = displayId
        stateMap["orientation"] = curr.orientation
        stateMap["screenInteractive"] = curr.screenInteractive
        stateMap["stateRevision"] = curr.revision

        // Bluetooth State (Read Only)
        try {
            @Suppress("DEPRECATION")
            val btAdapter = BluetoothAdapter.getDefaultAdapter()
            stateMap["bluetoothEnabled"] = btAdapter?.isEnabled ?: false
        } catch (t: Throwable) {
            stateMap["bluetoothEnabled"] = false
        }

        // Wi-Fi State
        try {
            if (context != null) {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                stateMap["wifiEnabled"] = wm?.isWifiEnabled ?: false
            }
        } catch (t: Throwable) {
            stateMap["wifiEnabled"] = false
        }

        // Audio Media Volume
        try {
            if (context != null) {
                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                val vol = am?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: -1
                val maxVol = am?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: -1
                stateMap["mediaVolume"] = vol
                stateMap["maxMediaVolume"] = maxVol
                stateMap["musicActive"] = am?.isMusicActive ?: false
            }
        } catch (t: Throwable) {
            stateMap["mediaVolume"] = -1
        }

        // Power State
        try {
            if (context != null) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                stateMap["isInteractive"] = pm?.isInteractive ?: true
            }
        } catch (t: Throwable) {
            stateMap["isInteractive"] = true
        }

        return stateMap
    }
}
