package com.tunnel.turbo.core

import android.content.Context
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.adapter.ExecutionResult
import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.model.NeedsObservationPlan
import com.tunnel.turbo.model.SequencePlan
import com.tunnel.turbo.model.StructuredPlan
import com.tunnel.turbo.model.UnsupportedPlan

class NativeTunnelCore(
    val context: Context? = null,
    val workerBridge: com.tunnel.turbo.worker.AiWorkerBridge? = null,
    customStateEngine: NativeStateEngine? = null,
    customAccessibilityBridge: AccessibilityBridge? = null,
    customPerceptionRouter: com.tunnel.turbo.perception.PerceptionRouter? = null
) {
    val journal = NativeEventJournal(capacity = 1000)
    val stateEngine = customStateEngine ?: NativeStateEngine(context = context, journal = journal)
    val verifier = NativeVerifier(stateEngine = stateEngine, journal = journal)
    val displayPolicy = DisplayTargetPolicy()
    val displayMutationArbiter = DisplayMutationArbiter()
    val actionEngine = NativeActionEngine(
        context = context,
        stateEngine = stateEngine,
        verifier = verifier,
        journal = journal,
        displayPolicy = displayPolicy,
        arbiter = displayMutationArbiter
    )
    val sequenceExecutor = NativeSequenceExecutor(
        actionEngine = actionEngine,
        journal = journal
    )
    val accessibilityBridge = customAccessibilityBridge ?: AccessibilityBridge(context)
    val shizukuBridge: com.tunnel.turbo.shizuku.ShizukuBridge? = if (context != null) com.tunnel.turbo.shizuku.ShizukuBridge(context) else null
    val appManager = AppManager(context)
    val capabilityRegistry = com.tunnel.turbo.capability.CapabilityRegistry()
    val taskExecutor = com.tunnel.turbo.task.NativeTaskExecutor(
        context = context,
        actionEngine = actionEngine,
        stateEngine = stateEngine,
        verifier = verifier,
        accessibilityBridge = accessibilityBridge,
        appManager = appManager,
        journal = journal,
        arbiter = displayMutationArbiter
    )
    val skillMemory = com.tunnel.turbo.agent.SkillMemory(context)
    val effectiveWorkerBridge = workerBridge ?: com.tunnel.turbo.worker.AiWorkerBridge(
        displayManager = com.tunnel.turbo.worker.PcBackendWorkerDisplayManager(context = context),
        accessibilityBridge = accessibilityBridge,
        context = context
    )
    val agentRuntime = com.tunnel.turbo.agent.GeneralAgentRuntime(
        core = this,
        appManager = appManager,
        capabilityRegistry = capabilityRegistry,
        accessibilityBridge = accessibilityBridge,
        stateEngine = stateEngine,
        skillMemory = skillMemory,
        reasoningProvider = com.tunnel.turbo.agent.AndroidAiAppReasoningProvider(
            workerBridge = effectiveWorkerBridge
        )
    )

    val perceptionRouter: com.tunnel.turbo.perception.PerceptionRouter? = customPerceptionRouter ?: if (context != null) {
        com.tunnel.turbo.perception.PerceptionRouter(
            context = context,
            accessibilityBridge = accessibilityBridge,
            shizukuBridge = shizukuBridge
        )
    } else null

    private val displaySnapshots = java.util.concurrent.ConcurrentHashMap<Int, com.tunnel.turbo.perception.WorldSnapshot>()

    val currentWorldSnapshot: com.tunnel.turbo.perception.WorldSnapshot?
        get() = displaySnapshots[0] ?: displaySnapshots.values.firstOrNull()

    fun getSnapshotForDisplay(displayId: Int): com.tunnel.turbo.perception.WorldSnapshot? =
        displaySnapshots[displayId]

    suspend fun getOrRefreshWorldSnapshot(
        displayId: Int = 0,
        force: Boolean = false,
        goalContext: String? = null
    ): com.tunnel.turbo.perception.WorldSnapshot? {
        val router = perceptionRouter ?: return null
        val existing = displaySnapshots[displayId]
        if (!force && existing != null) {
            val age = System.currentTimeMillis() - existing.capturedAtMs
            if (age < 1500L) {
                return existing
            }
        }
        val snap = router.observeWorld(displayId = displayId, goalContext = goalContext)
        if (snap != null) {
            displaySnapshots[displayId] = snap
        }
        return snap
    }

    init {
        taskExecutor.currentSnapshotProvider = { currentWorldSnapshot }
        taskExecutor.snapshotForDisplayProvider = { dispId -> displaySnapshots[dispId] }
    }



    suspend fun executePlan(plan: StructuredPlan): ExecutionResult {
        val t0 = System.nanoTime()
        return when (plan) {
            is ActionPlan -> {
                val actRes = actionEngine.executeAction(plan, verify = true)
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                ExecutionResult(
                    success = actRes.success,
                    actionSummary = actRes.action,
                    details = actRes.details + if (actRes.verified) " [Verified in ${String.format("%.1f", actRes.verificationMs)}ms]" else "",
                    executionMs = totalMs
                )
            }

            is SequencePlan -> {
                val seqRes = sequenceExecutor.executeSequence(plan, stopOnFailure = true)
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                val summaries = seqRes.stepResults.map { "${it.action}:${it.success}" }.joinToString(", ")
                ExecutionResult(
                    success = seqRes.success,
                    actionSummary = "sequence_${seqRes.executedSteps}_of_${seqRes.totalSteps}_steps",
                    details = if (seqRes.success) summaries else "${seqRes.error} (ejecutados: $summaries)",
                    executionMs = totalMs
                )
            }

            is com.tunnel.turbo.model.TaskPlan -> {
                val taskRes = taskExecutor.executeTask(plan, stopOnFailure = true)
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                val summaries = taskRes.stepResults.map { "${it.tool}:${it.success}" }.joinToString(", ")
                ExecutionResult(
                    success = taskRes.success,
                    actionSummary = "task_${taskRes.executedSteps}_of_${taskRes.totalSteps}_steps",
                    details = if (taskRes.success) summaries else "${taskRes.error} (ejecutados: $summaries)",
                    executionMs = totalMs
                )
            }

            is NeedsObservationPlan -> {
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                journal.recordEvent("ui_invalidated", mapOf("reason" to plan.reason))
                ExecutionResult(
                    success = true,
                    actionSummary = "needs_observation",
                    details = plan.reason,
                    executionMs = totalMs
                )
            }

            is UnsupportedPlan -> {
                val totalMs = (System.nanoTime() - t0) / 1_000_000.0
                ExecutionResult(
                    success = false,
                    actionSummary = "unsupported",
                    details = plan.reason,
                    executionMs = totalMs
                )
            }
        }
    }
}
