package com.tunnel.turbo.ui

import com.tunnel.turbo.agent.SessionEvent
import com.tunnel.turbo.agent.SessionEventType
import com.tunnel.turbo.capability.CapabilityRegistry

data class AgentProgressItem(val label: String, val detail: String)

object AgentProgressPresenter {
    fun present(events: List<SessionEvent>, capabilities: CapabilityRegistry): List<AgentProgressItem> =
        events.takeLast(MAX_VISIBLE_EVENTS).mapNotNull { event ->
            val actionDescription = event.capabilityId
                ?.let(capabilities::getCapability)
                ?.description
                ?: "Se está realizando una acción disponible."
            when (event.type) {
                SessionEventType.SESSION_STARTED -> AgentProgressItem("Entendiendo el objetivo", "Se inició una sesión de agente.")
                SessionEventType.OBSERVATION_CAPTURED -> AgentProgressItem("Observando el dispositivo", "Se actualizó la observación disponible.")
                SessionEventType.PROVIDER_REQUESTED -> AgentProgressItem("Decidiendo el siguiente paso", "Evalúa el estado actual y las opciones disponibles.")
                SessionEventType.PROVIDER_DECISION -> AgentProgressItem("Siguiente paso preparado", "Se eligió una opción dentro de las capacidades disponibles.")
                SessionEventType.ACTION_STARTED -> AgentProgressItem("Ejecutando acción", actionDescription)
                SessionEventType.ACTION_COMPLETED -> AgentProgressItem("Acción enviada", "Se observará el estado antes de confirmar el resultado.")
                SessionEventType.VERIFICATION -> AgentProgressItem("Verificando el resultado", "GoalVerifier compara la evidencia disponible con el objetivo.")
                SessionEventType.PROGRESS_DETECTED, SessionEventType.OPERATIONAL_PROGRESS -> AgentProgressItem("Se observó un cambio", "La observación actual muestra avance operativo.")
                SessionEventType.INFORMATION_PROGRESS -> AgentProgressItem("Nueva información", "La observación aportó información distinta.")
                SessionEventType.PROGRESS_UNKNOWN -> AgentProgressItem("Avance sin confirmar", "Todavía no hay evidencia suficiente para medir el cambio.")
                SessionEventType.NO_PROGRESS -> AgentProgressItem("Sin cambio observado", "El estado observado no cambió en este ciclo.")
                SessionEventType.STUCK_DETECTED -> AgentProgressItem("Revisando el siguiente paso", "La ruta actual no mostró avance suficiente.")
                SessionEventType.PROVIDER_FAILOVER -> AgentProgressItem("Cambiando de ruta", "El proveedor actual no pudo continuar.")
                SessionEventType.ASK_USER -> AgentProgressItem("Necesita tu respuesta", "La sesión requiere una aclaración antes de continuar.")
                SessionEventType.INVESTIGATE -> AgentProgressItem("Investigando", "Reuniendo información necesaria para la tarea.")
                SessionEventType.SESSION_COMPLETED -> AgentProgressItem("Objetivo verificado", "La sesión reportó que GoalVerifier confirmó el objetivo.")
                SessionEventType.SESSION_FAILED -> AgentProgressItem("No se completó", "La sesión terminó sin confirmar el objetivo.")
                SessionEventType.SESSION_CANCELLED -> AgentProgressItem("Tarea cancelada", "La sesión se detuvo antes de terminar.")
            }
        }

    private const val MAX_VISIBLE_EVENTS = 8
}
