package com.tunnel.turbo.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

class TunnelTurboAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TunnelTurboAccessibilityService? = null
            private set

        val isServiceEnabled: Boolean
            get() = instance != null

        @Volatile var connectedAtMs: Long? = null
            private set
        @Volatile var disconnectedAtMs: Long? = null
            private set
        @Volatile var connectionCount: Int = 0
            private set
        @Volatile var lastEventAtMs: Long? = null
            private set
        @Volatile var lastEventType: Int? = null
            private set
        @Volatile var lastEventPackage: String? = null
            private set
        @Volatile var serviceFlags: Int = 0
            private set
        @Volatile var serviceCapabilities: Int = 0
            private set

        private val eventListeners = java.util.concurrent.CopyOnWriteArrayList<(AccessibilityEvent) -> Unit>()

        fun addEventListener(listener: (AccessibilityEvent) -> Unit) {
            eventListeners.add(listener)
        }

        fun removeEventListener(listener: (AccessibilityEvent) -> Unit) {
            eventListeners.remove(listener)
        }

        fun filterWindowsForDisplay(all: List<AccessibilityWindowInfo>?, targetDisplay: Int): List<AccessibilityWindowInfo> {
            if (all.isNullOrEmpty()) return emptyList()
            return all.filter { it.displayId == targetDisplay }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        connectedAtMs = System.currentTimeMillis()
        connectionCount++
        try {
            val info = serviceInfo
            serviceFlags = info?.flags ?: 0
            serviceCapabilities = info?.capabilities ?: 0
        } catch (_: Throwable) {}
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        disconnectedAtMs = System.currentTimeMillis()
        if (instance == this) {
            instance = null
        }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnectedAtMs = System.currentTimeMillis()
        if (instance == this) {
            instance = null
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null) {
            lastEventAtMs = System.currentTimeMillis()
            lastEventType = event.eventType
            lastEventPackage = event.packageName?.toString()
            for (listener in eventListeners) {
                try {
                    listener(event)
                } catch (ignored: Throwable) {}
            }
        }
    }

    override fun onInterrupt() {
        // No-op
    }

    fun getAllWindows(): List<AccessibilityWindowInfo> {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val sparse = windowsOnAllDisplays
            if (sparse != null && sparse.size() > 0) {
                val list = mutableListOf<AccessibilityWindowInfo>()
                for (i in 0 until sparse.size()) {
                    val wList = sparse.valueAt(i)
                    if (wList != null) list.addAll(wList)
                }
                return list
            }
        }
        return windows ?: emptyList()
    }

    fun getWindowsForDisplay(displayId: Int): List<AccessibilityWindowInfo> {
        val result = mutableListOf<AccessibilityWindowInfo>()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            try {
                val sparse = windowsOnAllDisplays
                if (sparse != null && sparse.size() > 0) {
                    val list = sparse.get(displayId)
                    if (!list.isNullOrEmpty()) {
                        result.addAll(list)
                    }
                }
            } catch (ignored: Throwable) {}
        }
        if (result.isEmpty()) {
            val all = windows
            val filtered = filterWindowsForDisplay(all, displayId)
            if (filtered.isNotEmpty()) {
                result.addAll(filtered)
            }
        }
        return result
    }

    fun findRootForDisplay(displayId: Int): AccessibilityNodeInfo? {
        val dispWindows = getWindowsForDisplay(displayId)
        // 1. Prefer focused/active application window on this specific display
        for (w in dispWindows) {
            if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION && w.isActive) {
                val r = w.root
                if (r != null) return r
            }
        }
        // 2. Prefer any application window on this specific display
        for (w in dispWindows) {
            if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                val r = w.root
                if (r != null) return r
            }
        }
        // 3. Fallback to any window on this specific display
        for (w in dispWindows) {
            val r = w.root
            if (r != null) return r
        }

        // 4. Ultimate fallback for display 0 only if rootInActiveWindow belongs provably to display 0
        if (displayId == 0) {
            val active = rootInActiveWindow
            if (active != null) {
                val activeDisplayId = try { active.window?.displayId } catch (t: Throwable) { null }
                if (activeDisplayId == 0) {
                    return active
                }
            }
        }
        return null
    }

    fun findNode(displayId: Int, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val root = findRootForDisplay(displayId) ?: return null
        return searchRecursive(root, predicate)
    }

    private fun searchRecursive(
        node: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val res = searchRecursive(child, predicate)
            if (res != null) return res
        }
        return null
    }

    fun performSetText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun performClick(node: AccessibilityNodeInfo, displayId: Int = 0): Boolean {
        if (node.isClickable) {
            val ok = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (ok) return true
        }
        var curr = node.parent
        while (curr != null) {
            if (curr.isClickable) {
                val ok = curr.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (ok) return true
            }
            curr = curr.parent
        }
        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.width() > 0 && bounds.height() > 0) {
            val cx = bounds.centerX().toFloat()
            val cy = bounds.centerY().toFloat()
            return clickCoordinates(cx, cy, displayId)
        }
        return false
    }

    // --- General Capability Primitives (Fase 10) ---

    fun getUiNodes(displayId: Int, maxNodes: Int = 120): List<UiNodeInfo> =
        getUiSnapshot(displayId, maxNodes, includeVisibleText = false).nodes

    fun getUiSnapshot(
        displayId: Int,
        maxNodes: Int = 120,
        includeVisibleText: Boolean = true,
        windowId: Int? = null
    ): AccessibilitySnapshot {
        // Query display metrics
        var dWidth = 0
        var dHeight = 0
        var dRotation = 0
        try {
            val dm = getSystemService(android.content.Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager
            val disp = dm?.getDisplay(displayId)
            if (disp != null) {
                val metrics = android.util.DisplayMetrics()
                disp.getRealMetrics(metrics)
                dWidth = metrics.widthPixels
                dHeight = metrics.heightPixels
                dRotation = disp.rotation
            }
        } catch (_: Throwable) {}

        // Query windows metadata and unexposed/protected regions
        val dispWindows = getWindowsForDisplay(displayId)
        val windowMetas = mutableListOf<AccessibilityWindowMeta>()
        val unknownRegions = mutableListOf<UnknownRegion>()

        for (w in dispWindows) {
            val rect = android.graphics.Rect()
            try { w.getBoundsInScreen(rect) } catch (_: Throwable) {}
            val rootNode = try { w.root } catch (_: Throwable) { null }
            val rootAvailable = rootNode != null
            val typeName = when (w.type) {
                AccessibilityWindowInfo.TYPE_APPLICATION -> "APPLICATION"
                AccessibilityWindowInfo.TYPE_INPUT_METHOD -> "INPUT_METHOD"
                AccessibilityWindowInfo.TYPE_SYSTEM -> "SYSTEM"
                AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY -> "ACCESSIBILITY_OVERLAY"
                AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER -> "SPLIT_SCREEN_DIVIDER"
                AccessibilityWindowInfo.TYPE_MAGNIFICATION_OVERLAY -> "MAGNIFICATION_OVERLAY"
                else -> "UNKNOWN"
            }
            val pkg = rootNode?.packageName?.toString().orEmpty()
            val title = try { w.title?.toString().orEmpty() } catch (_: Throwable) { "" }
            val status = if (rootAvailable) "read" else "root_unavailable"
            val unknownReason = if (!rootAvailable) "ROOT_UNAVAILABLE: Window ${w.id} ($typeName) does not expose root node" else null

            windowMetas.add(
                AccessibilityWindowMeta(
                    id = w.id,
                    type = w.type,
                    typeName = typeName,
                    displayId = w.displayId,
                    layer = w.layer,
                    bounds = listOf(rect.left, rect.top, rect.right, rect.bottom),
                    rootAvailable = rootAvailable,
                    packageName = pkg,
                    title = title,
                    isFocused = w.isFocused,
                    isActive = w.isActive,
                    inspectionStatus = status,
                    unknownReason = unknownReason
                )
            )

            if (!rootAvailable) {
                unknownRegions.add(
                    UnknownRegion(
                        bounds = listOf(rect.left, rect.top, rect.right, rect.bottom),
                        reason = unknownReason ?: "ROOT_UNAVAILABLE",
                        windowId = w.id,
                        displayId = w.displayId
                    )
                )
            }
        }

        if (dispWindows.isEmpty() && dWidth > 0 && dHeight > 0) {
            unknownRegions.add(
                UnknownRegion(
                    bounds = listOf(0, 0, dWidth, dHeight),
                    reason = "NO_ACCESSIBLE_WINDOWS: No interactive windows exposed for display $displayId",
                    displayId = displayId
                )
            )
        }

        val root = if (windowId == null) {
            findRootForDisplay(displayId)
        } else {
            dispWindows.firstOrNull { it.id == windowId }?.root
        }

        if (root == null) {
            return AccessibilitySnapshot(
                nodes = emptyList(),
                visibleText = "",
                possibleTruncation = false,
                foregroundPackage = "",
                foregroundActivity = "",
                displayId = displayId,
                displayWidth = dWidth,
                displayHeight = dHeight,
                displayRotation = dRotation,
                windows = windowMetas,
                serviceStatus = "CONNECTED",
                unknownRegions = unknownRegions
            )
        }

        val partial = getUiSnapshotFromRoot(root, displayId, maxNodes, includeVisibleText)
        return partial.copy(
            displayId = displayId,
            displayWidth = dWidth,
            displayHeight = dHeight,
            displayRotation = dRotation,
            windows = windowMetas,
            unknownRegions = unknownRegions,
            serviceStatus = "CONNECTED"
        )
    }

    fun getUiSnapshotForWindow(
        window: AccessibilityWindowInfo,
        displayId: Int,
        maxNodes: Int = 120,
        includeVisibleText: Boolean = false
    ): AccessibilitySnapshot? {
        if (window.displayId != displayId) return null
        val root = try { window.root } catch (_: Throwable) { null } ?: return null
        return getUiSnapshotFromRoot(root, displayId, maxNodes, includeVisibleText)
    }

    private fun getUiSnapshotFromRoot(
        root: AccessibilityNodeInfo,
        displayId: Int,
        maxNodes: Int,
        includeVisibleText: Boolean
    ): AccessibilitySnapshot {
        val list = mutableListOf<UiNodeInfo>()
        val visibleText = StringBuilder()
        val boundsRect = android.graphics.Rect()

        fun collect(node: AccessibilityNodeInfo) {
            if (list.size >= maxNodes) return
            node.getBoundsInScreen(boundsRect)
            val nId = "node_${boundsRect.left}_${boundsRect.top}_${list.size}"
            val txt = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            val resId = node.viewIdResourceName ?: ""
            val cls = node.className?.toString() ?: ""

            if (includeVisibleText) {
                if (txt.isNotBlank()) visibleText.append(txt).append('\n')
                else if (desc.isNotBlank()) visibleText.append(desc).append('\n')
            }

            // Only retain nodes that have some semantic relevance
            if (txt.isNotEmpty() || desc.isNotEmpty() || resId.isNotEmpty() || node.isClickable || node.isEditable || node.isScrollable) {
                list.add(
                    UiNodeInfo(
                        nodeId = nId,
                        className = cls,
                        text = txt,
                        contentDescription = desc,
                        resourceId = resId,
                        clickable = node.isClickable,
                        editable = node.isEditable,
                        scrollable = node.isScrollable,
                        enabled = node.isEnabled,
                        checked = node.isChecked,
                        selected = node.isSelected,
                        bounds = listOf(boundsRect.left, boundsRect.top, boundsRect.right, boundsRect.bottom),
                        displayId = displayId
                    )
                )
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collect(child)
            }
        }

        collect(root)
        return AccessibilitySnapshot(
            nodes = list,
            visibleText = visibleText.toString().trim(),
            possibleTruncation = list.size >= maxNodes,
            foregroundPackage = root.packageName?.toString().orEmpty(),
            foregroundActivity = root.className?.toString().orEmpty()
        )
    }

    fun findUiNodes(selector: SemanticSelector, displayId: Int, match: String = "first"): List<UiNodeInfo> {
        val all = getUiNodes(displayId)
        val filtered = all.filter { selector.matchesUiNode(it) }
        return when (match) {
            "first" -> filtered.take(1)
            "single" -> if (filtered.size == 1) filtered else emptyList()
            else -> filtered
        }
    }

    fun getVisibleText(displayId: Int): String {
        return getUiSnapshot(displayId, includeVisibleText = true).visibleText
    }

    fun clickCoordinates(x: Float, y: Float, displayId: Int = 0): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val path = android.graphics.Path().apply {
                moveTo(x, y)
            }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 80)
            val builder = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(stroke)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R && displayId > 0) {
                builder.setDisplayId(displayId)
            }
            val gesture = builder.build()

            val latch = java.util.concurrent.CountDownLatch(1)
            var success = false
            dispatchGesture(gesture, object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    success = true
                    latch.countDown()
                }
                override fun onCancelled(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    success = false
                    latch.countDown()
                }
            }, null)
            latch.await(600, java.util.concurrent.TimeUnit.MILLISECONDS)
            return success
        }
        return false
    }

    fun swipeCoordinates(fromX: Float, fromY: Float, toX: Float, toY: Float, durationMs: Long = 300): Boolean {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val path = android.graphics.Path().apply {
                moveTo(fromX, fromY)
                lineTo(toX, toY)
            }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, durationMs)
            val gesture = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(stroke)
                .build()

            val latch = java.util.concurrent.CountDownLatch(1)
            var success = false
            dispatchGesture(gesture, object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    success = true
                    latch.countDown()
                }
                override fun onCancelled(gestureDescription: android.accessibilityservice.GestureDescription?) {
                    success = false
                    latch.countDown()
                }
            }, null)
            latch.await(durationMs + 300, java.util.concurrent.TimeUnit.MILLISECONDS)
            return success
        }
        return false
    }

    fun clickNode(selector: SemanticSelector, displayId: Int): Boolean {
        val matchMode = selector.match
        // clickNode is a single-target mutation; "all" needs a separate explicit API.
        if (matchMode == "all") return false

        val root = findRootForDisplay(displayId) ?: return false
        val matches = mutableListOf<AccessibilityNodeInfo>()

        fun search(node: AccessibilityNodeInfo): Boolean {
            if (selector.matchesNode(node)) {
                if (matches.size < 2) matches.add(node)
                if (SemanticMatchPolicy.shouldStopSearch(matchMode, matches.size)) return true
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                if (search(child)) return true
            }
            return false
        }

        search(root)
        val node = SemanticMatchPolicy.selectOne(matchMode, matches) ?: return false

        // Prefer direct node click if node is explicitly marked clickable
        if (node.isClickable) {
            val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (clicked) return true
        }

        val nodeBounds = android.graphics.Rect()
        node.getBoundsInScreen(nodeBounds)

        // Fallback 1: if parent is clickable and roughly the same size (wrapper), try parent
        var curr = node.parent
        val parentBounds = android.graphics.Rect()
        while (curr != null) {
            curr.getBoundsInScreen(parentBounds)
            val sameSize = (parentBounds.width() <= nodeBounds.width() * 1.5) && (parentBounds.height() <= nodeBounds.height() * 1.5)
            if (curr.isClickable && sameSize) {
                val clicked = curr.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (clicked) return true
            }
            if (!sameSize) break
            curr = curr.parent
        }

        // Fallback 2: internal bounds center tap via dispatchGesture (no shell, clean public API)
        val cx = nodeBounds.centerX().toFloat()
        val cy = nodeBounds.centerY().toFloat()
        if (cx > 0f && cy > 0f) {
            return clickCoordinates(cx, cy, displayId)
        }
        return false
    }

    fun setText(selector: SemanticSelector, text: String, displayId: Int): Boolean {
        val root = findRootForDisplay(displayId) ?: return false
        var targetNode: AccessibilityNodeInfo? = null

        fun search(node: AccessibilityNodeInfo): Boolean {
            if (node.isEditable && selector.matchesNode(node)) {
                targetNode = node
                return true
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                if (search(child)) return true
            }
            return false
        }

        search(root)
        val node = targetNode ?: return false
        return performSetText(node, text)
    }

    fun scroll(direction: String, selector: SemanticSelector? = null, displayId: Int): Boolean {
        val root = findRootForDisplay(displayId) ?: return false
        var scrollTarget: AccessibilityNodeInfo? = null

        fun search(node: AccessibilityNodeInfo): Boolean {
            val matches = if (selector != null) selector.matchesNode(node) && node.isScrollable else node.isScrollable
            if (matches) {
                scrollTarget = node
                return true
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                if (search(child)) return true
            }
            return false
        }

        search(root)
        val node = scrollTarget
        val action = when (direction.uppercase()) {
            "DOWN", "RIGHT" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            "UP", "LEFT" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }

        if (node != null && node.performAction(action)) {
            return true
        }

        // Fallback: swipe gesture on display center
        val screenBounds = android.graphics.Rect()
        if (node != null) {
            node.getBoundsInScreen(screenBounds)
        } else {
            root.getBoundsInScreen(screenBounds)
        }
        val midX = if (screenBounds.width() > 0) screenBounds.centerX().toFloat() else 500f
        val midY = if (screenBounds.height() > 0) screenBounds.centerY().toFloat() else 1000f

        return when (direction.uppercase()) {
            "DOWN" -> swipeCoordinates(midX, midY + 400f, midX, midY - 400f)
            "UP" -> swipeCoordinates(midX, midY - 400f, midX, midY + 400f)
            "RIGHT" -> swipeCoordinates(midX + 400f, midY, midX - 400f, midY)
            "LEFT" -> swipeCoordinates(midX - 400f, midY, midX + 400f, midY)
            else -> swipeCoordinates(midX, midY + 400f, midX, midY - 400f)
        }
    }

    fun takeScreenshotAsync(displayId: Int = 0, timeoutMs: Long = 1500L): android.graphics.Bitmap? {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) return null
        val latch = java.util.concurrent.CountDownLatch(1)
        var resultBitmap: android.graphics.Bitmap? = null
        val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
        try {
            takeScreenshot(displayId, executor, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    try {
                        val hwBuffer = result.hardwareBuffer
                        val colorSpace = result.colorSpace
                        val hwBitmap = android.graphics.Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                        if (hwBitmap != null) {
                            resultBitmap = hwBitmap.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                            hwBitmap.recycle()
                        }
                        hwBuffer.close()
                    } catch (e: Throwable) {
                        android.util.Log.e("TunnelTurboA11y", "Failed to wrap hardware buffer: ${e.message}")
                    } finally {
                        latch.countDown()
                    }
                }

                override fun onFailure(errorCode: Int) {
                    android.util.Log.w("TunnelTurboA11y", "takeScreenshot failed code: $errorCode")
                    latch.countDown()
                }
            })
            latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
        } catch (e: Throwable) {
            android.util.Log.e("TunnelTurboA11y", "takeScreenshot threw exception: ${e.message}")
        } finally {
            executor.shutdown()
        }
        return resultBitmap
    }
}

