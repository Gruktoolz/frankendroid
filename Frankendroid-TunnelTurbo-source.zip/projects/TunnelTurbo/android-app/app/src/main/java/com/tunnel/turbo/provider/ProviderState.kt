package com.tunnel.turbo.provider

enum class ProviderState {
    DISCONNECTED,
    STARTING,
    READY,
    BUSY,
    RATE_LIMITED,
    COOLDOWN,
    OFFLINE,
    ERROR
}
