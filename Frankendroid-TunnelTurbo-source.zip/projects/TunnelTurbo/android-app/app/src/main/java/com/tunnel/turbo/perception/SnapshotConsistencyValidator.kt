package com.tunnel.turbo.perception

class SnapshotConsistencyValidator {

    fun validate(snapshot: WorldSnapshot): WorldSnapshot {
        var status = ConsistencyStatus.VALID
        var valid = true

        // 1. Display ID validation: windows must belong to snapshot.displayId
        val wrongDisplayWindows = snapshot.windows.filter { it.displayId != snapshot.displayId }
        if (wrongDisplayWindows.isNotEmpty() && snapshot.displayId > 0) {
            status = ConsistencyStatus.DISPLAY_MISMATCH
            valid = false
        }

        // 2. Cross-app package mismatch check
        if (snapshot.foregroundPackage.isNotBlank()) {
            val windowPackagesMismatch = snapshot.windows
                .filter { it.isActive || it.isFocused }
                .any { it.title.contains(".") && !it.title.contains(snapshot.foregroundPackage) }

            // Check if top semantic elements strongly belong to an entirely different package
            val foreignNodes = snapshot.semanticElements
                .filter { it.id.contains(":") }
                .map { it.id.substringBefore(":") }
                .filter { it.isNotBlank() && !it.equals(snapshot.foregroundPackage, ignoreCase = true) && !it.startsWith("android") }

            if (windowPackagesMismatch && foreignNodes.size > 5) {
                status = ConsistencyStatus.PACKAGE_MISMATCH
                valid = false
            }
        }

        // 3. Staleness check: snapshot must be fresh (< 1500 ms)
        val ageMs = System.currentTimeMillis() - snapshot.capturedAtMs
        if (ageMs > 2500) {
            status = ConsistencyStatus.STALE
            valid = false
        }

        return snapshot.copy(
            consistencyStatus = status,
            isValid = valid
        )
    }
}
