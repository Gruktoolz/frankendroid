package com.tunnel.turbo.accessibility

import org.json.JSONArray
import org.json.JSONObject

data class UiNodeInfo(
    val nodeId: String,
    val className: String,
    val text: String,
    val contentDescription: String,
    val resourceId: String,
    val clickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val enabled: Boolean,
    val checked: Boolean,
    val selected: Boolean,
    val bounds: List<Int>, // [left, top, right, bottom]
    val displayId: Int
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("nodeId", nodeId)
        obj.put("className", className)
        obj.put("text", text)
        obj.put("contentDescription", contentDescription)
        obj.put("resourceId", resourceId)
        obj.put("clickable", clickable)
        obj.put("editable", editable)
        obj.put("scrollable", scrollable)
        obj.put("enabled", enabled)
        obj.put("checked", checked)
        obj.put("selected", selected)
        val boundsArr = JSONArray()
        for (b in bounds) {
            boundsArr.put(b)
        }
        obj.put("bounds", boundsArr)
        obj.put("displayId", displayId)
        return obj
    }
}

data class AccessibilityWindowMeta(
    val id: Int,
    val type: Int,
    val typeName: String,
    val displayId: Int,
    val layer: Int,
    val bounds: List<Int>, // [left, top, right, bottom]
    val rootAvailable: Boolean,
    val packageName: String = "",
    val title: String = "",
    val isFocused: Boolean = false,
    val isActive: Boolean = false,
    val inspectionStatus: String = "read", // "read", "root_unavailable", "unexposed", "protected"
    val unknownReason: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type)
        put("typeName", typeName)
        put("displayId", displayId)
        put("layer", layer)
        val bArr = JSONArray()
        for (b in bounds) bArr.put(b)
        put("bounds", bArr)
        put("rootAvailable", rootAvailable)
        put("packageName", packageName)
        put("title", title)
        put("isFocused", isFocused)
        put("isActive", isActive)
        put("inspectionStatus", inspectionStatus)
        if (unknownReason != null) put("unknownReason", unknownReason)
    }
}

data class UnknownRegion(
    val bounds: List<Int>, // [left, top, right, bottom]
    val reason: String, // "PROTECTED_WINDOW", "ROOT_UNAVAILABLE", "UNEXPOSED_CONTENT", etc.
    val windowId: Int? = null,
    val displayId: Int = 0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        val bArr = JSONArray()
        for (b in bounds) bArr.put(b)
        put("bounds", bArr)
        put("reason", reason)
        put("windowId", windowId ?: JSONObject.NULL)
        put("displayId", displayId)
    }
}

data class AccessibilityServiceState(
    val isEnabled: Boolean,
    val isConnected: Boolean,
    val status: String, // "CONNECTED", "ENABLED_NOT_BOUND", "CRASHED_OR_BLOCKED", "DISABLED"
    val connectedAtMs: Long? = null,
    val disconnectedAtMs: Long? = null,
    val connectionCount: Int = 0,
    val lastEventAtMs: Long? = null,
    val lastEventType: Int? = null,
    val lastEventPackage: String? = null,
    val flags: Int = 0,
    val capabilities: Int = 0,
    val exitReason: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("isEnabled", isEnabled)
        put("isConnected", isConnected)
        put("status", status)
        put("connectedAtMs", connectedAtMs ?: JSONObject.NULL)
        put("disconnectedAtMs", disconnectedAtMs ?: JSONObject.NULL)
        put("connectionCount", connectionCount)
        put("lastEventAtMs", lastEventAtMs ?: JSONObject.NULL)
        put("lastEventType", lastEventType ?: JSONObject.NULL)
        put("lastEventPackage", lastEventPackage ?: "")
        put("flags", flags)
        put("capabilities", capabilities)
        put("exitReason", exitReason ?: JSONObject.NULL)
    }
}

/** One accessibility traversal, with actionable nodes, windows, and visible text. */
data class AccessibilitySnapshot(
    val nodes: List<UiNodeInfo>,
    val visibleText: String = "",
    val possibleTruncation: Boolean = false,
    val foregroundPackage: String = "",
    val foregroundActivity: String = "",
    val snapshotId: String = java.util.UUID.randomUUID().toString().replace("-", "").take(8),
    val capturedAtMs: Long = System.currentTimeMillis(),
    val displayId: Int = 0,
    val displayWidth: Int = 0,
    val displayHeight: Int = 0,
    val displayRotation: Int = 0,
    val windows: List<AccessibilityWindowMeta> = emptyList(),
    val actionableCount: Int = nodes.count { it.clickable || it.editable || it.scrollable },
    val serviceStatus: String = "CONNECTED",
    val unknownRegions: List<UnknownRegion> = emptyList()
) {
    fun getSnapshotAgeMs(): Long = System.currentTimeMillis() - capturedAtMs
    fun isStale(maxAgeMs: Long = 10_000L): Boolean = getSnapshotAgeMs() > maxAgeMs

    fun toJson(): JSONObject = JSONObject().apply {
        put("snapshotId", snapshotId)
        put("capturedAtMs", capturedAtMs)
        put("snapshotAgeMs", getSnapshotAgeMs())
        put("displayId", displayId)
        put("displayWidth", displayWidth)
        put("displayHeight", displayHeight)
        put("displayRotation", displayRotation)
        put("windowCount", windows.size)
        val wArr = JSONArray()
        for (w in windows) wArr.put(w.toJson())
        put("windows", wArr)
        put("totalNodes", nodes.size)
        put("actionableCount", actionableCount)
        put("possibleNodeTruncation", possibleTruncation)
        put("foregroundPackage", foregroundPackage)
        put("foregroundActivity", foregroundActivity)
        put("serviceStatus", serviceStatus)
        put("visibleText", visibleText)
        val nArr = JSONArray()
        for (n in nodes) nArr.put(n.toJson())
        put("ui_nodes", nArr)
        val uArr = JSONArray()
        for (u in unknownRegions) uArr.put(u.toJson())
        put("unknownRegions", uArr)
    }
}
