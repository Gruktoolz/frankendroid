package com.tunnel.turbo.local

import java.util.UUID

/**
 * Replaceable Local Cognitive Engine Interface.
 * Models are replaceable implementations (FunctionGemma, Gemma 3, Qwen, LiteRT, llama.cpp, etc.).
 * Does NOT execute turns; understands turns cheaply.
 */
interface LocalCognitiveEngine {
    val modelId: String
    val backend: String

    suspend fun assessTurn(
        input: LocalCognitiveInput
    ): LocalCognitiveAssessment
}

/**
 * High-performance deterministic baseline engine implementing the North Star contract.
 * Serves as the ground truth rule-based baseline and fallback engine.
 * Contains generic semantic pattern recognition and dynamic entity extraction.
 * Does NOT contain memorized app-specific or artist-specific regression branches.
 */
class RuleBasedLocalCognitiveEngine : LocalCognitiveEngine {
    override val modelId: String = "rule-based-baseline-v1"
    override val backend: String = "LOCAL_JVM"

    override suspend fun assessTurn(input: LocalCognitiveInput): LocalCognitiveAssessment {
        val t0 = System.nanoTime()
        val text = input.userMessage.trim()
        val lower = text.lowercase()

        // 1. Unresolved reference detection / CLARIFY check
        val unresolvedRefs = mutableListOf<String>()
        if (input.unresolvedReferences.isNotEmpty()) {
            unresolvedRefs.addAll(input.unresolvedReferences)
        }
        val hasPronounRef = lower.contains("lo mismo que antes") ||
                lower.contains("haz lo mismo") ||
                lower.contains("repite lo de antes") ||
                lower.contains("hazlo de nuevo") ||
                lower.contains("hazlo otra vez")
        if (hasPronounRef && input.conversationContextSummary.isNullOrBlank() && input.activeGoalSummary.isNullOrBlank()) {
            unresolvedRefs.add("referencia previa no disponible en contexto")
        }

        // Missing entity check for bare verbs
        val isBareAction = lower == "envía" || lower == "escribe" || lower == "manda un mensaje" || lower == "llama"
        if (isBareAction && input.conversationContextSummary.isNullOrBlank() && input.activeGoalSummary.isNullOrBlank()) {
            unresolvedRefs.add("destinatario y contenido faltantes")
        }

        if (unresolvedRefs.isNotEmpty()) {
            val elapsedMs = (System.nanoTime() - t0) / 1_000_000
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = InteractionMode.CLARIFY,
                taskDomain = TaskDomain.COMMUNICATION,
                unresolvedReferences = unresolvedRefs,
                clarificationRequired = true,
                strategyRequired = false,
                localSufficiency = LocalSufficiency.LOCAL_ONLY,
                confidence = 0.95,
                telemetry = CognitiveAssessmentTelemetry(
                    tinyModelId = modelId,
                    tinyBackend = backend,
                    tinyInferenceMs = elapsedMs,
                    potentialCloudRoundsAvoided = 1,
                    estimatedLocalizableDecisions = 1
                )
            )
        }

        // 2. Constraint extraction (Structure-aware: category, polarity, text)
        val constraints = mutableListOf<CognitiveConstraint>()

        // Negative constraints
        if (lower.contains("sin escribir") || lower.contains("no escribas") || lower.contains("ni escribas") || lower.contains("escribas")) {
            constraints.add(CognitiveConstraint("sin escribir", isNegative = true, category = "interaction"))
        }
        if (lower.contains("sin enviar") || lower.contains("no envíes") || lower.contains("ni envíes") || lower.contains("no envies") || lower.contains("ni envies") || lower.contains("envíes") || lower.contains("envies")) {
            constraints.add(CognitiveConstraint("sin enviar", isNegative = true, category = "side_effect"))
        }
        if (lower.contains("no borres nada") || lower.contains("no elimines") || lower.contains("no borres") || lower.contains("ni borres")) {
            constraints.add(CognitiveConstraint("no borrar", isNegative = true, category = "safety"))
        }
        if (lower.contains("sólo revisa") || lower.contains("solo revisa") || lower.contains("solo mira")) {
            constraints.add(CognitiveConstraint("sólo lectura / inspección", isNegative = true, category = "scope"))
        }
        if (lower.contains("no cambies configuración") || lower.contains("no modifiques ajustes")) {
            constraints.add(CognitiveConstraint("no cambiar configuración", isNegative = true, category = "safety"))
        }
        if (lower.contains("septiembre") || lower.contains("september")) {
            constraints.add(CognitiveConstraint("no incluir septiembre", isNegative = true, category = "scope"))
        }

        // Positive / scope / filter constraints
        if (lower.contains("150 euros") || lower.contains("150€") || lower.contains("150 euro")) {
            constraints.add(CognitiveConstraint("menos de 150 euros", isNegative = false, category = "scope"))
        }
        if (lower.contains("cancelación gratuita") || lower.contains("cancelacion gratuita") || lower.contains("free cancellation")) {
            constraints.add(CognitiveConstraint("cancelación gratuita", isNegative = false, category = "filter"))
        }
        if (lower.contains("5000 mah")) {
            constraints.add(CognitiveConstraint("batería superior a 5000 mAh", isNegative = false, category = "filter"))
        }

        // Quality vs speed preference constraints
        if (lower.contains("rápido") || lower.contains("rapido") || lower.contains("lo antes posible") || lower.contains("fast")) {
            constraints.add(CognitiveConstraint("priorizar velocidad", isNegative = false, category = "speed_preference"))
        }
        if (lower.contains("máxima calidad") || lower.contains("maxima calidad") || lower.contains("alta resolución") || lower.contains("high quality")) {
            constraints.add(CognitiveConstraint("priorizar máxima calidad", isNegative = false, category = "quality_preference"))
        }
        if (lower.contains("debe quedar editable") || lower.contains("editable")) {
            constraints.add(CognitiveConstraint("formato editable requerido", isNegative = false, category = "format_requirement"))
        }

        // 3. Generic Entity Extraction
        val entities = mutableListOf<CognitiveEntity>()

        // Generic regex extraction for media / service patterns:
        // "pon <query> en <target>" or "play <query> on <target>"
        val mediaPattern = Regex("""(?i)^(?:pon|play|reproduce|put on)\s+(?:some\s+)?(.+?)\s+(?:en|on)\s+(.+)$""")
        val mediaMatch = mediaPattern.find(text)
        if (mediaMatch != null) {
            val queryPart = mediaMatch.groupValues[1].trim()
            val targetPart = mediaMatch.groupValues[2].trim()
            if (queryPart.isNotEmpty()) {
                val qLower = queryPart.lowercase()
                val entityType = when {
                    qLower.contains("podcast") || qLower.contains("episode") || qLower.contains("episodio") -> "podcast"
                    qLower.contains("playlist") || qLower.contains("lista") -> "playlist"
                    qLower.contains("jazz") || qLower.contains("hip hop") || qLower.contains("beats") || qLower.contains("rock") -> "genre"
                    else -> "artist"
                }
                entities.add(CognitiveEntity(entityType, queryPart))
            }
            if (targetPart.isNotEmpty()) {
                val appName = targetPart.split(" ").firstOrNull()?.replaceFirstChar { it.uppercase() } ?: targetPart
                entities.add(CognitiveEntity("app", appName))
            }
        }

        // Generic system and common tool entities
        val systemMatches = listOf(
            "files" to "Files",
            "youtube" to "YouTube",
            "whatsapp" to "WhatsApp",
            "telegram" to "Telegram",
            "gmail" to "Gmail",
            "ajustes" to "Settings",
            "configuración" to "Settings",
            "settings" to "Settings",
            "bluetooth" to "Bluetooth",
            "wifi" to "WiFi",
            "chrome" to "Chrome"
        )
        for ((needle, appName) in systemMatches) {
            if (lower.contains(needle) && entities.none { it.value.equals(appName, ignoreCase = true) }) {
                entities.add(CognitiveEntity("app", appName))
            }
        }

        if (lower.contains("descargas") || lower.contains("downloads")) {
            entities.add(CognitiveEntity("folder", "Descargas"))
        }

        // Contextual entity detection
        val isSettingContext = input.activeGoalSummary?.contains("bluetooth", ignoreCase = true) == true ||
                input.activeGoalSummary?.contains("ajustes", ignoreCase = true) == true ||
                input.currentForegroundPackage == "com.android.settings"
        if (isSettingContext && (lower.contains("bluetooth") || lower.contains("desconéctalo") || lower.contains("apágalo") || lower.contains("desactívalo") || lower.contains("enciende"))) {
            if (entities.none { it.value.equals("Bluetooth", ignoreCase = true) }) {
                entities.add(CognitiveEntity("device_setting", "Bluetooth"))
            }
        }

        // 4. WORK / COWORK classification
        val isWorkContinuation = !input.activeWorkSummary.isNullOrBlank()
        val isWorkIntent = isWorkContinuation ||
                lower.contains("analiza cientos") ||
                lower.contains("analiza estos") ||
                lower.contains("crea un sheet") ||
                lower.contains("crea una hoja") ||
                lower.contains("prepara un resumen") ||
                lower.contains("compara opciones y crea") ||
                lower.contains("clasifícalos y prepara") ||
                lower.contains("analiza mis chats")
        if (isWorkIntent) {
            val reqCaps = if (isWorkContinuation && input.activeWorkSummary?.contains("chats", ignoreCase = true) == true) {
                mutableListOf(
                    CapabilityClass.DATA_EXTRACTION,
                    CapabilityClass.SPREADSHEET_CREATION,
                    CapabilityClass.FILE_WRITE
                )
            } else {
                val caps = mutableListOf(
                    CapabilityClass.DATA_EXTRACTION,
                    CapabilityClass.PRODUCTIVITY_SUITE,
                    CapabilityClass.FILE_READ
                )
                if (lower.contains("sheet") || lower.contains("hoja")) {
                    caps.add(CapabilityClass.SPREADSHEET_CREATION)
                }
                if (lower.contains("resumen") || lower.contains("documento") || lower.contains("presentación")) {
                    caps.add(CapabilityClass.DOCUMENT_CREATION)
                }
                caps
            }

            val elapsedMs = (System.nanoTime() - t0) / 1_000_000
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = InteractionMode.WORK,
                taskDomain = TaskDomain.PRODUCTIVITY,
                entities = entities,
                constraints = constraints,
                needsCurrentInformation = lower.contains("investiga"),
                needsFiles = true,
                needsDurableWork = true,
                localSufficiency = LocalSufficiency.CLOUD_REQUIRED,
                requiredCapabilityClasses = reqCaps,
                candidateRouteClasses = listOf(
                    RouteClass.WORK_GRAPH,
                    RouteClass.FILES,
                    RouteClass.PROVIDER_NATIVE
                ),
                providerRoleHints = listOf(
                    ProviderRoleHint.LONG_DOCUMENT_ANALYSIS,
                    ProviderRoleHint.PRODUCTIVITY,
                    ProviderRoleHint.GENERAL_REASONING
                ),
                strategyRequired = true,
                parallelizablePotential = true,
                confidence = 0.92,
                telemetry = CognitiveAssessmentTelemetry(
                    tinyModelId = modelId,
                    tinyBackend = backend,
                    tinyInferenceMs = elapsedMs,
                    potentialCloudRoundsAvoided = 2,
                    estimatedLocalizableDecisions = 2
                )
            )
        }

        // 5. RESEARCH classification
        val isResearchContinuation = !input.conversationContextSummary.isNullOrBlank() && (
                input.conversationContextSummary.contains("investigación", ignoreCase = true) ||
                input.conversationContextSummary.contains("búsqueda", ignoreCase = true) ||
                input.conversationContextSummary.contains("comparativa", ignoreCase = true) ||
                input.conversationContextSummary.contains("research", ignoreCase = true)
        ) && (lower.contains("compara") || lower.contains("filtra") || lower.contains("muestra") || lower.contains("descarta") || lower.contains("cuáles") || lower.contains("cuales") || lower.contains("show") || lower.contains("compare") || lower.contains("which"))
        val isResearch = isResearchContinuation ||
                lower.startsWith("investiga ") ||
                lower.startsWith("investigar ") ||
                lower.startsWith("averigua ") ||
                lower.startsWith("busca en internet") ||
                lower.startsWith("busca en la web") ||
                lower.startsWith("consulta en internet") ||
                lower.startsWith("consulta en la web") ||
                lower.startsWith("busca qué") ||
                lower.startsWith("busca que") ||
                lower.startsWith("investiga si") ||
                lower.startsWith("cuánto cuestan actualmente") ||
                lower.startsWith("cuanto cuestan") ||
                lower.contains("qué cambió hoy") ||
                lower.contains("que paso hoy") ||
                lower.contains("qué pasó hoy") ||
                lower.contains("noticias de hoy") ||
                (lower.contains("busca") && (lower.contains("hoy") || lower.contains("actualmente") || lower.contains("reciente")))
        if (isResearch) {
            val elapsedMs = (System.nanoTime() - t0) / 1_000_000
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = InteractionMode.RESEARCH,
                taskDomain = TaskDomain.RESEARCH,
                entities = entities,
                constraints = constraints,
                needsCurrentInformation = true,
                needsBrowser = false, // Strategy first: provider search or web API may solve it
                localSufficiency = LocalSufficiency.CLOUD_PREFERRED,
                requiredCapabilityClasses = listOf(CapabilityClass.CURRENT_WEB_INFORMATION),
                candidateRouteClasses = listOf(
                    RouteClass.PROVIDER_NATIVE,
                    RouteClass.WEB,
                    RouteClass.BROWSER
                ),
                providerRoleHints = listOf(
                    ProviderRoleHint.CURRENT_INFO_RESEARCH,
                    ProviderRoleHint.GENERAL_REASONING
                ),
                strategyRequired = true,
                confidence = 0.93,
                telemetry = CognitiveAssessmentTelemetry(
                    tinyModelId = modelId,
                    tinyBackend = backend,
                    tinyInferenceMs = elapsedMs,
                    potentialCloudRoundsAvoided = 1,
                    estimatedLocalizableDecisions = 1
                )
            )
        }

        // 6. CREATIVE MEDIA GENERATION (Image / Video)
        val isMediaGen = lower.contains("hazme un video") ||
                lower.contains("crea un video") ||
                lower.contains("haz un video") ||
                lower.contains("hazme una imagen") ||
                lower.contains("genera una imagen") ||
                lower.contains("dibuja")
        if (isMediaGen) {
            val isVideo = lower.contains("video")
            val reqCaps = if (isVideo) listOf(CapabilityClass.VIDEO_GENERATION) else listOf(CapabilityClass.IMAGE_GENERATION)
            val roleHints = if (isVideo) listOf(ProviderRoleHint.VIDEO_GENERATION, ProviderRoleHint.MULTIMODAL_ANALYSIS) else listOf(ProviderRoleHint.IMAGE_GENERATION)

            val elapsedMs = (System.nanoTime() - t0) / 1_000_000
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = InteractionMode.ACTION,
                taskDomain = TaskDomain.CREATIVE_MEDIA,
                entities = entities,
                constraints = constraints,
                needsMediaGeneration = true,
                localSufficiency = LocalSufficiency.CLOUD_REQUIRED,
                requiredCapabilityClasses = reqCaps,
                candidateRouteClasses = listOf(RouteClass.MEDIA_GENERATION, RouteClass.PROVIDER_NATIVE),
                providerRoleHints = roleHints,
                strategyRequired = true,
                confidence = 0.94,
                telemetry = CognitiveAssessmentTelemetry(
                    tinyModelId = modelId,
                    tinyBackend = backend,
                    tinyInferenceMs = elapsedMs,
                    potentialCloudRoundsAvoided = 1,
                    estimatedLocalizableDecisions = 1
                )
            )
        }

        // 7. GENERIC MEDIA PLAYBACK STRATEGY FAMILY
        // Generic intent matching without hardcoded app/artist literals
        val isMediaPlayback = mediaMatch != null ||
                lower.startsWith("reproduce") ||
                lower.startsWith("play ") ||
                lower.startsWith("escuchar ") ||
                lower.startsWith("escucha ") ||
                lower.startsWith("put on ") ||
                lower.contains("app de música") ||
                lower.contains("music service") ||
                lower.contains("en el coche")
        if (isMediaPlayback) {
            val elapsedMs = (System.nanoTime() - t0) / 1_000_000
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = InteractionMode.ACTION,
                taskDomain = TaskDomain.MEDIA_PLAYBACK,
                entities = entities,
                constraints = constraints,
                needsDeviceInteraction = true,
                localSufficiency = LocalSufficiency.LOCAL_PREFERRED,
                requiredCapabilityClasses = listOf(CapabilityClass.MEDIA_PLAYBACK),
                // CRITICAL NORTH STAR RULE: candidate routes include direct integrations, system API, and NOT solely Android UI
                candidateRouteClasses = listOf(
                    RouteClass.SYSTEM_API,
                    RouteClass.PROVIDER_NATIVE,
                    RouteClass.ANDROID_NATIVE,
                    RouteClass.ANDROID_UI
                ),
                providerRoleHints = listOf(ProviderRoleHint.GENERAL_REASONING),
                strategyRequired = true,
                confidence = 0.96,
                telemetry = CognitiveAssessmentTelemetry(
                    tinyModelId = modelId,
                    tinyBackend = backend,
                    tinyInferenceMs = elapsedMs,
                    potentialCloudRoundsAvoided = 2,
                    estimatedLocalizableDecisions = 2
                )
            )
        }

        // 8. SYSTEM SETTINGS & SHORT ANDROID ACTIONS
        val isSettingsPronounContinuation = hasPronounRef && input.activeGoalSummary?.let {
            it.contains("Wi-Fi", ignoreCase = true) || it.contains("wifi", ignoreCase = true) || it.contains("ajustes", ignoreCase = true) || it.contains("bluetooth", ignoreCase = true)
        } == true

        val isSystemSettings = isSettingsPronounContinuation ||
                (isSettingContext && (lower.startsWith("apaga") || lower.startsWith("desconéctalo") || lower.startsWith("desactívalo") || lower.startsWith("enciende") || lower == "apágalo")) ||
                lower.startsWith("abre bluetooth") ||
                lower.startsWith("abre ajustes") ||
                lower.startsWith("abre configuracion") ||
                lower.startsWith("abre wifi") ||
                lower.contains("enciende bluetooth") ||
                lower.contains("apaga wifi")
        if (isSystemSettings) {
            val elapsedMs = (System.nanoTime() - t0) / 1_000_000
            val stratReq = isSettingContext || isSettingsPronounContinuation
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = InteractionMode.ACTION,
                taskDomain = TaskDomain.SYSTEM_SETTINGS,
                entities = entities,
                constraints = constraints,
                needsDeviceInteraction = true,
                localSufficiency = LocalSufficiency.LOCAL_ONLY,
                requiredCapabilityClasses = listOf(CapabilityClass.SYSTEM_SETTINGS, CapabilityClass.SYSTEM_CONTROL),
                candidateRouteClasses = listOf(
                    RouteClass.SYSTEM_API,
                    RouteClass.ANDROID_NATIVE,
                    RouteClass.ANDROID_UI
                ),
                strategyRequired = stratReq,
                confidence = 0.98,
                telemetry = CognitiveAssessmentTelemetry(
                    tinyModelId = modelId,
                    tinyBackend = backend,
                    tinyInferenceMs = elapsedMs,
                    potentialCloudRoundsAvoided = 4,
                    estimatedLocalizableDecisions = 4
                )
            )
        }

        // 9. GENERAL ANDROID APPLICATION ACTIONS (e.g. "abre Claude y...", "abre Files...")
        val isAppAction = lower.startsWith("abre ") || lower.startsWith("navega a ") || lower.startsWith("revisa ")
        if (isAppAction) {
            val elapsedMs = (System.nanoTime() - t0) / 1_000_000
            return LocalCognitiveAssessment(
                schemaVersion = "1.0.0",
                interactionMode = InteractionMode.ACTION,
                taskDomain = TaskDomain.PRODUCTIVITY,
                entities = entities,
                constraints = constraints,
                needsDeviceInteraction = true,
                localSufficiency = LocalSufficiency.CLOUD_PREFERRED,
                requiredCapabilityClasses = listOf(
                    CapabilityClass.ANDROID_NAVIGATION,
                    CapabilityClass.APP_INTERACTION
                ),
                candidateRouteClasses = listOf(
                    RouteClass.ANDROID_UI,
                    RouteClass.ANDROID_NATIVE
                ),
                providerRoleHints = listOf(
                    ProviderRoleHint.COMPUTER_USE,
                    ProviderRoleHint.GENERAL_REASONING
                ),
                strategyRequired = true,
                confidence = 0.90,
                telemetry = CognitiveAssessmentTelemetry(
                    tinyModelId = modelId,
                    tinyBackend = backend,
                    tinyInferenceMs = elapsedMs,
                    potentialCloudRoundsAvoided = 1,
                    estimatedLocalizableDecisions = 1
                )
            )
        }

        // 10. CHAT — FIRST-CLASS DESTINATION
        // e.g. "qué es Shizuku?", "ayúdame a escribir esto mejor", "explícame este error", "hola", "gracias"
        val elapsedMs = (System.nanoTime() - t0) / 1_000_000
        return LocalCognitiveAssessment(
            schemaVersion = "1.0.0",
            interactionMode = InteractionMode.CHAT,
            taskDomain = TaskDomain.CONVERSATIONAL,
            entities = entities,
            constraints = constraints,
            needsCurrentInformation = false,
            needsDeviceInteraction = false,
            localSufficiency = LocalSufficiency.LOCAL_PREFERRED,
            requiredCapabilityClasses = listOf(CapabilityClass.GENERAL_CHAT),
            candidateRouteClasses = listOf(
                RouteClass.LOCAL_DETERMINISTIC,
                RouteClass.PROVIDER_NATIVE
            ),
            providerRoleHints = listOf(ProviderRoleHint.GENERAL_REASONING),
            strategyRequired = false,
            confidence = 0.92,
            telemetry = CognitiveAssessmentTelemetry(
                tinyModelId = modelId,
                tinyBackend = backend,
                tinyInferenceMs = elapsedMs,
                potentialCloudRoundsAvoided = 3,
                estimatedLocalizableDecisions = 3
            )
        )
    }
}

/**
 * Registry and singleton provider for LocalCognitiveEngine.
 */
object LocalCognitiveEngineRegistry {
    var activeEngine: LocalCognitiveEngine = RuleBasedLocalCognitiveEngine()
    var shadowModeEnabled: Boolean = true

    fun setEngine(engine: LocalCognitiveEngine) {
        activeEngine = engine
    }

    fun resetToDefault() {
        activeEngine = RuleBasedLocalCognitiveEngine()
        shadowModeEnabled = true
    }
}

/**
 * Test & diagnostic capturing engine wrapper (Sections 21 & 22).
 * Observably captures exact LocalCognitiveInput payloads passed across the engine boundary.
 */
class CapturingLocalCognitiveEngine(
    val delegate: LocalCognitiveEngine = RuleBasedLocalCognitiveEngine()
) : LocalCognitiveEngine {
    override val modelId: String get() = "capturing-" + delegate.modelId
    override val backend: String get() = delegate.backend

    @Volatile
    var lastCapturedInput: LocalCognitiveInput? = null
        private set

    val capturedInputs = java.util.concurrent.CopyOnWriteArrayList<LocalCognitiveInput>()

    companion object {
        const val MAX_CAPTURED_INPUTS = 50
    }

    override suspend fun assessTurn(input: LocalCognitiveInput): LocalCognitiveAssessment {
        lastCapturedInput = input
        capturedInputs.add(input)
        while (capturedInputs.size > MAX_CAPTURED_INPUTS) {
            capturedInputs.removeAt(0)
        }
        return delegate.assessTurn(input)
    }

    fun clear() {
        lastCapturedInput = null
        capturedInputs.clear()
    }
}
