package com.tunnel.turbo.perception

import android.graphics.Rect
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class ElementSource {
    SYSTEM,
    ACCESSIBILITY,
    FUSED,
    OCR,
    VISUAL_REGION
}

enum class ConsistencyStatus {
    VALID,
    STALE,
    DISPLAY_MISMATCH,
    PACKAGE_MISMATCH,
    PARTIAL
}

enum class CoverageStatus {
    SUFFICIENT,
    PARTIAL,
    INSUFFICIENT,
    UNKNOWN
}

data class WindowSummary(
    val id: Int,
    val title: String,
    val displayId: Int,
    val isActive: Boolean,
    val isFocused: Boolean,
    val bounds: Rect
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("displayId", displayId)
        put("isActive", isActive)
        put("isFocused", isFocused)
        put("bounds", "[${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}]")
    }
}

data class SemanticElement(
    val id: String,
    val text: String,
    val contentDescription: String,
    val role: String,
    val bounds: Rect,
    val clickable: Boolean,
    val editable: Boolean = false,
    val checkable: Boolean = false,
    val checked: Boolean = false
) {
    fun effectiveLabel(): String {
        if (text.isNotBlank()) return text.trim()
        if (contentDescription.isNotBlank()) return contentDescription.trim()
        return ""
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("text", text)
        put("contentDescription", contentDescription)
        put("effectiveLabel", effectiveLabel())
        put("role", role)
        put("bounds", "[${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}]")
        put("clickable", clickable)
        put("editable", editable)
        put("checkable", checkable)
        put("checked", checked)
    }
}

data class OcrElement(
    val id: String,
    val text: String,
    val boundingBox: Rect,
    val confidence: Float? = null,
    val rotation: Int = 0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("text", text)
        put("boundingBox", "[${boundingBox.left},${boundingBox.top},${boundingBox.right},${boundingBox.bottom}]")
        if (confidence != null) put("confidence", confidence) else put("confidence", JSONObject.NULL)
        put("rotation", rotation)
    }
}

data class ElementRef(
    val token: String,
    val displayId: Int,
    val revision: Long,
    val source: ElementSource,
    val bounds: Rect
)

data class UnifiedElement(
    val ref: String,
    val label: String,
    val roleHint: String,
    val source: ElementSource,
    val confidence: Float,
    val boundsInternal: Rect,
    val actionableHint: String,
    val displayId: Int = 0,
    val revision: Long = 0L
) {
    fun toElementRef(): ElementRef = ElementRef(
        token = ref,
        displayId = displayId,
        revision = revision,
        source = source,
        bounds = boundsInternal
    )

    fun toJson(): JSONObject = JSONObject().apply {
        put("ref", ref)
        put("label", label)
        put("roleHint", roleHint)
        put("source", source.name)
        put("confidence", confidence)
        put("actionableHint", actionableHint)
        put("displayId", displayId)
        put("revision", revision)
        // Notice: boundsInternal kept for debug inspection, but provider prompt will only see symbolic label
        put("bounds", "[${boundsInternal.left},${boundsInternal.top},${boundsInternal.right},${boundsInternal.bottom}]")
    }
}

data class WorldSnapshot(
    val snapshotId: String = UUID.randomUUID().toString().take(8),
    val revision: Long,
    val capturedAtMs: Long = System.currentTimeMillis(),
    val displayId: Int,
    val foregroundPackage: String,
    val foregroundActivity: String,
    val systemState: Map<String, Any> = emptyMap(),
    val windows: List<WindowSummary> = emptyList(),
    val semanticElements: List<SemanticElement> = emptyList(),
    val unifiedElements: List<UnifiedElement> = emptyList(),
    val visibleText: String = "",
    val perceptionSources: List<String> = emptyList(),
    val consistencyStatus: ConsistencyStatus = ConsistencyStatus.VALID,
    val coverageStatus: CoverageStatus = CoverageStatus.SUFFICIENT,
    val isValid: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("snapshotId", snapshotId)
        put("revision", revision)
        put("capturedAtMs", capturedAtMs)
        put("displayId", displayId)
        put("foregroundPackage", foregroundPackage)
        put("foregroundActivity", foregroundActivity)
        put("consistencyStatus", consistencyStatus.name)
        put("coverageStatus", coverageStatus.name)
        put("isValid", isValid)

        val srcArr = JSONArray()
        perceptionSources.forEach { srcArr.put(it) }
        put("perceptionSources", srcArr)

        val sysObj = JSONObject()
        systemState.forEach { (k, v) -> sysObj.put(k, v) }
        put("systemState", sysObj)

        val winArr = JSONArray()
        windows.forEach { winArr.put(it.toJson()) }
        put("windows", winArr)

        val elemArr = JSONArray()
        unifiedElements.forEach { elemArr.put(it.toJson()) }
        put("unifiedElements", elemArr)
        put("totalElements", unifiedElements.size)
        put("visibleTextSnippet", visibleText.take(200))
    }
}
