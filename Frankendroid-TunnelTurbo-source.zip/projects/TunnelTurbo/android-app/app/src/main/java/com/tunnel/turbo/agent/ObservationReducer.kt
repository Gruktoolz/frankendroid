package com.tunnel.turbo.agent

import com.tunnel.turbo.accessibility.UiNodeInfo
import org.json.JSONArray
import org.json.JSONObject

data class ReductionMetrics(
    val nodesBefore: Int,
    val nodesAfter: Int,
    val bytesBefore: Int,
    val bytesAfter: Int,
    val reductionPercent: Double
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("nodesBefore", nodesBefore)
        put("nodesAfter", nodesAfter)
        put("bytesBefore", bytesBefore)
        put("bytesAfter", bytesAfter)
        put("reductionPercent", reductionPercent)
    }
}

data class ReducedObservation(
    val foregroundPackage: String,
    val foregroundActivity: String,
    val interactiveNodes: List<UiNodeInfo>,
    val informativeText: String,
    val metrics: ReductionMetrics
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("foregroundPackage", foregroundPackage)
        put("foregroundActivity", foregroundActivity)
        val nArr = JSONArray()
        interactiveNodes.forEach { nArr.put(it.toJson()) }
        put("interactiveNodes", nArr)
        put("informativeText", informativeText)
        put("metrics", metrics.toJson())
    }
}

class ObservationReducer {

    fun reduce(
        foregroundPackage: String,
        foregroundActivity: String,
        allNodes: List<UiNodeInfo>,
        fullVisibleText: String
    ): ReducedObservation {
        val nodesBefore = allNodes.size
        val rawNodesJson = JSONArray().apply { allNodes.forEach { put(it.toJson()) } }.toString()
        val bytesBefore = rawNodesJson.toByteArray(Charsets.UTF_8).size + fullVisibleText.toByteArray(Charsets.UTF_8).size

        // 1. Filter out empty container nodes that have no text/contentDescription and are not interactive
        val filtered = allNodes.filter { node ->
            val hasContent = node.text.isNotBlank() || node.contentDescription.isNotBlank()
            val isInteractive = node.clickable || node.editable || node.scrollable
            val isValuableIdentifier = node.resourceId.isNotBlank() && (isInteractive || hasContent)

            // Retain if interactive OR if it carries human-readable content
            isInteractive || hasContent || isValuableIdentifier
        }

        // 2. Remove purely duplicate identical-bounds text nodes (e.g. nested TextViews with same label)
        val seenSignatures = mutableSetOf<String>()
        val deduplicated = mutableListOf<UiNodeInfo>()
        for (n in filtered) {
            val sig = "${n.text}_${n.contentDescription}_${n.bounds.joinToString(",")}"
            if (seenSignatures.add(sig)) {
                deduplicated.add(n)
            }
        }

        // 3. Compact visible text: remove empty lines and deduplicate adjacent lines
        val lines = fullVisibleText.split("\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }
        val distinctLines = linkedSetOf<String>()
        lines.forEach { distinctLines.add(it) }
        val reducedText = distinctLines.joinToString("\n")

        val nodesAfter = deduplicated.size
        val reducedNodesJson = JSONArray().apply { deduplicated.forEach { put(it.toJson()) } }.toString()
        val bytesAfter = reducedNodesJson.toByteArray(Charsets.UTF_8).size + reducedText.toByteArray(Charsets.UTF_8).size

        val reduction = if (bytesBefore > 0) {
            ((bytesBefore - bytesAfter).toDouble() / bytesBefore.toDouble()) * 100.0
        } else 0.0

        val metrics = ReductionMetrics(
            nodesBefore = nodesBefore,
            nodesAfter = nodesAfter,
            bytesBefore = bytesBefore,
            bytesAfter = bytesAfter,
            reductionPercent = maxOf(0.0, reduction)
        )

        return ReducedObservation(
            foregroundPackage = foregroundPackage,
            foregroundActivity = foregroundActivity,
            interactiveNodes = deduplicated,
            informativeText = reducedText,
            metrics = metrics
        )
    }
}
