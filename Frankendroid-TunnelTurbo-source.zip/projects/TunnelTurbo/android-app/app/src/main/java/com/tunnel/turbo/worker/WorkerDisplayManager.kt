package com.tunnel.turbo.worker

enum class DisplayBackendType {
    PC_BACKEND,
    ANDROID_SHIZUKU_BACKEND
}

enum class WorkerLifecycle {
    STOPPED,
    CREATING_DISPLAY,
    LAUNCHING_PROVIDER,
    WAITING_UI,
    READY,
    BUSY,
    RECOVERING,
    RATE_LIMITED,
    FAILED
}

enum class ProviderHealthState {
    UNINITIALIZED,
    STARTING,
    WARMING_UP,
    READY,
    BUSY,
    AUTH_REQUIRED,
    RATE_LIMITED,
    UI_UNAVAILABLE,
    TIMED_OUT,
    FAILED
}

enum class ProviderFailureClass {
    NONE,
    PROVIDER_START_FAILURE,
    PROVIDER_AUTH_REQUIRED,
    PROVIDER_UI_NOT_READY,
    PROMPT_INJECTION_FAILURE,
    PROVIDER_RESPONSE_TIMEOUT,
    PROVIDER_RATE_LIMITED,
    PROVIDER_RESPONSE_PARSE_FAILURE,
    PROVIDER_PROOF_MISMATCH,
    PROVIDER_UNKNOWN_FAILURE
}

data class ProviderHealthReport(
    val state: ProviderHealthState,
    val isReady: Boolean,
    val displayExists: Boolean = false,
    val displayId: Int? = null,
    val providerRunning: Boolean = false,
    val providerForeground: Boolean = false,
    val inputNodeAvailable: Boolean = false,
    val sendNodeAvailable: Boolean = false,
    val accessibilityReadable: Boolean = false,
    val message: String = "",
    val checkedAt: Long = System.currentTimeMillis()
) {
    fun toJson(): org.json.JSONObject = org.json.JSONObject().apply {
        put("state", state.name)
        put("isReady", isReady)
        put("displayExists", displayExists)
        if (displayId != null) put("displayId", displayId)
        put("providerRunning", providerRunning)
        put("providerForeground", providerForeground)
        put("inputNodeAvailable", inputNodeAvailable)
        put("sendNodeAvailable", sendNodeAvailable)
        put("accessibilityReadable", accessibilityReadable)
        put("message", message)
        put("checkedAt", checkedAt)
    }
}

data class AiWorkerHealthCheck(
    val displayExists: Boolean = false,
    val providerRunning: Boolean = false,
    val providerForegroundOnWorker: Boolean = false,
    val inputNodeAvailable: Boolean = false,
    val sendNodeAvailable: Boolean = false,
    val accessibilityReadable: Boolean = false,
    val sessionValid: Boolean = false,
    val ready: Boolean = false,
    val storedDisplayId: Int? = null,
    val actualDisplayId: Int? = null,
    val details: String = ""
)

interface WorkerDisplayManager {
    val backendType: DisplayBackendType
    fun createWorkerDisplay(width: Int = 1080, height: Int = 1920, dpi: Int = 420): Int?
    fun destroyWorkerDisplay()
    fun getDisplayId(): Int?
    fun launchProviderApp(packageId: String): Boolean
    fun healthCheck(): Boolean
}

class PcBackendWorkerDisplayManager(
    private var attachedDisplayId: Int? = null,
    private val context: android.content.Context? = null
) : WorkerDisplayManager {
    override val backendType: DisplayBackendType = DisplayBackendType.PC_BACKEND

    fun discoverActualDisplayId(): Int? {
        val ctx = context
        val id = attachedDisplayId
        if (ctx != null && id != null) {
            val dm = ctx.getSystemService(android.content.Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager
            if (dm != null) {
                val exists = dm.displays.any { it.displayId == id && it.isValid }
                if (exists) {
                    return id
                }
            }
        }
        return attachedDisplayId
    }

    override fun createWorkerDisplay(width: Int, height: Int, dpi: Int): Int? {
        val discovered = discoverActualDisplayId()
        attachedDisplayId = discovered
        return discovered
    }

    override fun destroyWorkerDisplay() {
        attachedDisplayId = null
    }

    override fun getDisplayId(): Int? {
        val discovered = discoverActualDisplayId()
        attachedDisplayId = discovered
        return attachedDisplayId
    }

    override fun launchProviderApp(packageId: String): Boolean = true

    override fun healthCheck(): Boolean {
        val id = getDisplayId() ?: return false
        val ctx = context ?: return true
        val dm = ctx.getSystemService(android.content.Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager ?: return true
        return dm.displays.any { it.displayId == id && it.isValid }
    }
}

class ShizukuWorkerDisplayManager(
    private val context: android.content.Context? = null
) : WorkerDisplayManager {
    override val backendType: DisplayBackendType = DisplayBackendType.ANDROID_SHIZUKU_BACKEND
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var virtualDisplayId: Int? = null

    fun discoverActualDisplayId(): Int? {
        val id = virtualDisplayId ?: return null
        val ctx = context ?: return id
        val dm = ctx.getSystemService(android.content.Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager ?: return id
        val exists = dm.displays.any { it.displayId == id && it.isValid }
        return if (exists) id else null
    }

    override fun createWorkerDisplay(width: Int, height: Int, dpi: Int): Int? {
        val dm = context?.getSystemService(android.content.Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager
            ?: return null
        return try {
            virtualDisplay = dm.createVirtualDisplay(
                "TunnelTurboWorkerDisplay",
                width,
                height,
                dpi,
                null,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or
                    android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            )
            val id = virtualDisplay?.display?.displayId
            virtualDisplayId = id
            id
        } catch (t: Throwable) {
            virtualDisplay = null
            virtualDisplayId = null
            null
        }
    }

    override fun destroyWorkerDisplay() {
        try {
            virtualDisplay?.release()
        } catch (ignored: Throwable) {}
        virtualDisplay = null
        virtualDisplayId = null
    }

    override fun getDisplayId(): Int? {
        return discoverActualDisplayId()
    }

    override fun launchProviderApp(packageId: String): Boolean {
        val dispId = getDisplayId() ?: return false
        val ctx = context
        if (ctx != null) {
            return try {
                val intent = ctx.packageManager.getLaunchIntentForPackage(packageId) ?: return false
                intent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                val options = android.app.ActivityOptions.makeBasic()
                options.launchDisplayId = dispId
                ctx.startActivity(intent, options.toBundle())
                true
            } catch (t: Throwable) {
                false
            }
        }
        return true
    }

    override fun healthCheck(): Boolean {
        val id = getDisplayId() ?: return false
        val ctx = context ?: return true
        val dm = ctx.getSystemService(android.content.Context.DISPLAY_SERVICE) as? android.hardware.display.DisplayManager ?: return true
        return dm.displays.any { it.displayId == id && it.isValid }
    }
}
