package com.tunnel.turbo.chat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class GeminiTextResult(
    val text: String,
    val elapsedMs: Long,
    val model: String,
    val sources: List<Pair<String, String>> = emptyList(),
    val truncated: Boolean = false
)

/** Minimal direct REST adapter for explicit, user-owned Gemini API calls. */
class GeminiFreeApiClient {
    suspend fun generateChatTurnStream(
        apiKey: String,
        prompt: String,
        history: List<Pair<String, String>>,
        useGoogleSearch: Boolean,
        onTextChunk: (String) -> Unit
    ): GeminiTextResult = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Falta configurar la clave de API." }
        val start = System.nanoTime()
        val contents = org.json.JSONArray()
        history.takeLast(12).forEach { (role, text) ->
            if (role == "user" || role == "model") contents.put(JSONObject().put("role", role).put("parts", org.json.JSONArray().put(JSONObject().put("text", text))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt))))
        val body = JSONObject().put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", MAX_CHAT_OUTPUT_TOKENS).put("temperature", 0.5))
        if (useGoogleSearch) body.put("tools", org.json.JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val connection = URL("$BASE_URL/models/$DEFAULT_FREE_TEST_MODEL:streamGenerateContent?alt=sse").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = 60_000
            connection.doOutput = true
            connection.setRequestProperty("x-goog-api-key", apiKey)
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "text/event-stream")
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val responseText = connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val error = runCatching { JSONObject(responseText).optJSONObject("error") }.getOrNull()
                val detail = error?.optString("message")?.takeIf { it.isNotBlank() }?.replace(apiKey, "[clave protegida]") ?: "HTTP $code"
                throw GeminiApiException(code, detail.take(240), error?.optString("status").orEmpty())
            }

            val fullText = StringBuilder()
            val sources = linkedMapOf<String, Pair<String, String>>()
            var truncated = false
            val coroutineContext = currentCoroutineContext()
            connection.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { line ->
                    coroutineContext.ensureActive()
                    if (!line.startsWith("data:")) return@forEach
                    val payload = line.removePrefix("data:").trim()
                    if (payload.isBlank() || payload == "[DONE]") return@forEach
                    val json = runCatching { JSONObject(payload) }.getOrNull() ?: return@forEach
                    if (GeminiSseChunkParser.finishReason(json) == "MAX_TOKENS") truncated = true
                    val delta = GeminiSseChunkParser.text(json)
                    if (delta.isNotEmpty()) {
                        fullText.append(delta)
                        onTextChunk(delta)
                    }
                    GeminiSseChunkParser.sources(json).forEach { (title, uri) -> sources.putIfAbsent(uri, title to uri) }
                }
            }
            val answer = fullText.toString()
            if (answer.isBlank()) throw IllegalStateException("Google respondió sin texto visible.")
            GeminiTextResult(answer, (System.nanoTime() - start) / 1_000_000L, DEFAULT_FREE_TEST_MODEL, sources.values.toList(), truncated)
        } finally {
            connection.disconnect()
        }
    }

    suspend fun generateChatTurn(
        apiKey: String,
        prompt: String,
        history: List<Pair<String, String>>,
        useGoogleSearch: Boolean
    ): GeminiTextResult = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Falta configurar la clave de API." }
        val start = System.nanoTime()
        val contents = org.json.JSONArray()
        history.takeLast(12).forEach { (role, text) ->
            if (role == "user" || role == "model") contents.put(JSONObject().put("role", role).put("parts", org.json.JSONArray().put(JSONObject().put("text", text))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt))))
        val body = JSONObject().put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", MAX_CHAT_OUTPUT_TOKENS).put("temperature", 0.5))
        if (useGoogleSearch) body.put("tools", org.json.JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val connection = URL("$BASE_URL/models/$DEFAULT_FREE_TEST_MODEL:generateContent").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = 60_000
            connection.doOutput = true
            connection.setRequestProperty("x-goog-api-key", apiKey)
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val responseText = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val error = runCatching { JSONObject(responseText).optJSONObject("error") }.getOrNull()
                val detail = error?.optString("message")
                    ?.takeIf { it.isNotBlank() }?.replace(apiKey, "[clave protegida]") ?: "HTTP $code"
                throw GeminiApiException(code, detail.take(240), error?.optString("status").orEmpty())
            }
            val json = JSONObject(responseText)
            val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val answer = buildString { if (parts != null) for (i in 0 until parts.length()) parts.optJSONObject(i)?.optString("text")?.takeIf { it.isNotBlank() }?.let { append(it) } }
            if (answer.isBlank()) throw IllegalStateException("Google respondió sin texto visible.")
            val metadata = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("groundingMetadata")
            val chunks = metadata?.optJSONArray("groundingChunks")
            val sources = if (chunks == null) emptyList() else (0 until chunks.length()).mapNotNull { i ->
                val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: return@mapNotNull null
                val uri = web.optString("uri").takeIf { it.startsWith("https://") } ?: return@mapNotNull null
                web.optString("title", uri) to uri
            }.distinctBy { it.second }
            val truncated = json.optJSONArray("candidates")?.optJSONObject(0)?.optString("finishReason") == "MAX_TOKENS"
            GeminiTextResult(answer, (System.nanoTime() - start) / 1_000_000L, DEFAULT_FREE_TEST_MODEL, sources, truncated)
        } finally { connection.disconnect() }
    }

    suspend fun generateShortCheck(apiKey: String, model: String = DEFAULT_FREE_TEST_MODEL): GeminiTextResult =
        withContext(Dispatchers.IO) {
            require(apiKey.isNotBlank()) { "Falta configurar la clave de API." }
            require(model.matches(Regex("[A-Za-z0-9._-]+"))) { "Identificador de modelo no válido." }
            val start = System.nanoTime()
            val connection = URL("$BASE_URL/models/$model:generateContent").openConnection() as HttpURLConnection
            try {
                connection.requestMethod = "POST"
                connection.connectTimeout = CONNECT_TIMEOUT_MS
                connection.readTimeout = READ_TIMEOUT_MS
                connection.doOutput = true
                connection.setRequestProperty("x-goog-api-key", apiKey)
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                val contentParts = org.json.JSONArray().put(JSONObject().put("text", "Responde exactamente: conexión lista"))
                val contents = org.json.JSONArray().put(JSONObject().put("parts", contentParts))
                val body = JSONObject()
                    .put("contents", contents)
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 24).put("temperature", 0.0))
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val responseText = (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val error = runCatching { JSONObject(responseText).optJSONObject("error") }.getOrNull()
                    val detail = error?.optString("message")
                        ?.takeIf { !it.isNullOrBlank() }?.replace(apiKey, "[clave protegida]") ?: "HTTP $code"
                    throw GeminiApiException(code, detail.take(240), error?.optString("status").orEmpty())
                }
                val json = JSONObject(responseText)
                val candidates = json.optJSONArray("candidates")
                val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val answer = buildString {
                    if (parts != null) for (i in 0 until parts.length()) {
                        parts.optJSONObject(i)?.optString("text")?.takeIf { it.isNotBlank() }?.let { append(it) }
                    }
                }
                if (answer.isBlank()) throw IllegalStateException("Google respondió sin texto visible.")
                GeminiTextResult(answer, (System.nanoTime() - start) / 1_000_000L, model)
            } finally {
                connection.disconnect()
            }
        }

    companion object {
        const val DEFAULT_FREE_TEST_MODEL = "gemini-3.5-flash-lite"
        const val MAX_CHAT_OUTPUT_TOKENS = 4096
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        private const val CONNECT_TIMEOUT_MS = 10_000
        private const val READ_TIMEOUT_MS = 180_000
    }
}

object GeminiSseChunkParser {
    fun finishReason(json: JSONObject): String? =
        json.optJSONArray("candidates")?.optJSONObject(0)?.optString("finishReason")?.takeIf(String::isNotBlank)

    fun text(json: JSONObject): String {
        val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return ""
        return buildString {
            for (index in 0 until parts.length()) {
                parts.optJSONObject(index)?.optString("text")?.takeIf(String::isNotEmpty)?.let(::append)
            }
        }
    }

    fun sources(json: JSONObject): List<Pair<String, String>> {
        val chunks = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
            ?: return emptyList()
        return (0 until chunks.length()).mapNotNull { index ->
            val web = chunks.optJSONObject(index)?.optJSONObject("web") ?: return@mapNotNull null
            val uri = web.optString("uri").takeIf { it.startsWith("https://") } ?: return@mapNotNull null
            web.optString("title", uri).takeIf(String::isNotBlank)?.let { it to uri }
        }.distinctBy { it.second }
    }
}

class GeminiApiException(val httpStatus: Int, message: String, val apiStatus: String = "") : Exception(message)

object GeminiApiFailurePresenter {
    fun describe(httpStatus: Int, apiStatus: String, rawDetail: String): String = when {
        httpStatus == 403 -> "Google rechazó la clave o el acceso del proyecto (HTTP 403). Revisa la clave y sus restricciones en AI Studio."
        apiStatus == "FAILED_PRECONDITION" -> "Google rechazó la solicitud por un requisito del proyecto o la región (HTTP $httpStatus). Revisa el estado del proyecto en AI Studio."
        httpStatus == 429 -> "Se alcanzó una cuota o límite temporal de Gemini (HTTP 429). Revisa la cuota en AI Studio y vuelve a intentarlo más tarde."
        httpStatus == 408 || httpStatus >= 500 -> "Gemini no respondió temporalmente (HTTP $httpStatus). Comprueba la conexión y vuelve a intentarlo."
        httpStatus == 400 -> "Google rechazó la solicitud (HTTP 400). Revisa el modelo y la configuración en AI Studio."
        else -> "No se pudo completar la solicitud de Gemini (HTTP $httpStatus). Revisa la conexión de API en Ajustes."
    }
}
