package com.tunnel.turbo.worker

class WorkerPromptBuffer {
    var requestId: String? = null
        private set
    var prompt: String? = null
        private set
    var createdAt: Long = 0L
        private set

    fun setPrompt(id: String, text: String) {
        requestId = id
        prompt = text
        createdAt = System.currentTimeMillis()
    }

    fun clear() {
        requestId = null
        prompt = null
        createdAt = 0L
    }

    val hasPrompt: Boolean
        get() = prompt != null
}
