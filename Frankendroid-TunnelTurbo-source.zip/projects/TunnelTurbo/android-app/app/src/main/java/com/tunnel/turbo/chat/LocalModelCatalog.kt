package com.tunnel.turbo.chat

import android.content.Context
import java.io.File

enum class LocalModelRole { CHAT, TOOL_ROUTING_SPECIALIST }

data class LocalModelSpec(
    val id: String,
    val displayName: String,
    val repository: String,
    val fileName: String,
    val bytes: Long,
    val sha256: String,
    val role: LocalModelRole,
    val downloadUrl: String,
    val gated: Boolean = false
)

/** Local artifacts known to be packaged for LiteRT-LM. Device execution must still be measured. */
object LocalModelCatalog {
    const val DEFAULT_MODEL_ID = "qwen3-0.6b"

    val models: List<LocalModelSpec> = listOf(
        LocalModelSpec(
            id = "qwen3-0.6b", displayName = "Qwen3 0.6B",
            repository = "litert-community/Qwen3-0.6B", fileName = "Qwen3-0.6B.litertlm",
            bytes = 614_000_000L, sha256 = "c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108",
            role = LocalModelRole.CHAT,
            downloadUrl = ""
        ),
        LocalModelSpec(
            id = "gemma3-1b", displayName = "Gemma 3 1B IT INT4",
            repository = "litert-community/Gemma3-1B-IT", fileName = "gemma3-1b-it-int4.litertlm",
            bytes = 584_417_280L, sha256 = "1325ae366d31950f137c9c357b9fa89448b176d76998180c08ceaca78bba98be",
            role = LocalModelRole.CHAT,
            downloadUrl = "",
            gated = true
        ),
        LocalModelSpec(
            id = "qwen3-1.7b-int4", displayName = "Qwen3 1.7B INT4",
            repository = "litert-community/Qwen3-1.7B", fileName = "Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm",
            bytes = 977_184_032L, sha256 = "2a72330b504a6596d53a2c00923c57173b10f1b83e6a541213ffec08d1fc5de8",
            role = LocalModelRole.CHAT,
            downloadUrl = ""
        ),
        LocalModelSpec(
            id = "gemma4-e2b", displayName = "Gemma 4 E2B IT (2.59 GB)",
            repository = "litert-community/gemma-4-E2B-it-litert-lm", fileName = "gemma-4-E2B-it.litertlm",
            bytes = 2_588_147_712L, sha256 = "181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c",
            role = LocalModelRole.CHAT,
            downloadUrl = ""
        ),
        LocalModelSpec(
            id = "functiongemma-mobile-270m", displayName = "FunctionGemma Mobile Actions 270M",
            repository = "litert-community/functiongemma-270m-ft-mobile-actions", fileName = "mobile_actions_q8_ekv1024.litertlm",
            bytes = 288_964_608L, sha256 = "33e295cbd996b419bb1de8f3f85c5b6b01ee058a2c89bdb2173cf3e6ff4ce9d0",
            role = LocalModelRole.TOOL_ROUTING_SPECIALIST,
            downloadUrl = "",
            gated = true
        ),
        LocalModelSpec(
            id = "qwen3-0.6b-q4", displayName = "Qwen3 0.6B Q4 · no calibrado",
            repository = "local-file-unverified", fileName = "qwen3_0.6b_q4_block32_ekv1280.litertlm",
            bytes = 347_251_840L, sha256 = "UNAVAILABLE", role = LocalModelRole.CHAT, downloadUrl = ""
        ),
        LocalModelSpec(
            id = "qwen3-0.6b-q4-nothink", displayName = "Qwen3 0.6B Q4 no-think · no calibrado",
            repository = "local-file-unverified", fileName = "qwen3_0.6b_nothink_q4_block32_ekv1280.litertlm",
            bytes = 347_251_840L, sha256 = "UNAVAILABLE", role = LocalModelRole.CHAT, downloadUrl = ""
        ),
        LocalModelSpec(
            id = "qwen3.5-0.8b-int8", displayName = "Qwen3.5 0.8B INT8 · no calibrado",
            repository = "local-file-unverified", fileName = "Qwen3.5-0.8B_int8.litertlm",
            bytes = 964_566_992L, sha256 = "UNAVAILABLE", role = LocalModelRole.CHAT, downloadUrl = ""
        ),
        LocalModelSpec(
            id = "qwen3.5-0.8b-vl-int8", displayName = "Qwen3.5 0.8B VL INT8 · no calibrado",
            repository = "local-file-unverified", fileName = "Qwen3.5-0.8B-VL_int8.litertlm",
            bytes = 1_303_671_472L, sha256 = "UNAVAILABLE", role = LocalModelRole.CHAT, downloadUrl = ""
        ),
        LocalModelSpec(
            id = "qwen3-4b-int4", displayName = "Qwen3 4B mixed INT4 · no calibrado",
            repository = "local-file-unverified", fileName = "qwen3_4b_mixed_int4.litertlm",
            bytes = 2_659_053_760L, sha256 = "UNAVAILABLE", role = LocalModelRole.CHAT, downloadUrl = ""
        ),
        LocalModelSpec(
            id = "qwen3-4b-int8", displayName = "Qwen3 4B INT8 · no calibrado",
            repository = "local-file-unverified", fileName = "qwen3_4b_channelwise_int8_float32kv.litertlm",
            bytes = 5_672_367_472L, sha256 = "UNAVAILABLE", role = LocalModelRole.CHAT, downloadUrl = ""
        ),
        LocalModelSpec(
            id = "gemma4-e2b-gpu", displayName = "Gemma 4 E2B GPU · no calibrado",
            repository = "local-file-unverified", fileName = "gemma-4-E2B-it-gpu.litertlm",
            bytes = 2_008_432_640L, sha256 = "UNAVAILABLE", role = LocalModelRole.CHAT, downloadUrl = ""
        ),
        LocalModelSpec(
            id = "functiongemma-mobile-270m-q8", displayName = "FunctionGemma Mobile Actions Q8 · no calibrado",
            repository = "local-file-unverified", fileName = "mobile-actions_q8_ekv1024.litertlm",
            bytes = 284_426_240L, sha256 = "UNAVAILABLE", role = LocalModelRole.TOOL_ROUTING_SPECIALIST, downloadUrl = ""
        )
    )

    fun get(id: String): LocalModelSpec? = models.firstOrNull { it.id == id }

    /** Merge known models with local .litertlm artifacts that are actually present. */
    fun modelsFor(context: Context): List<LocalModelSpec> {
        val knownNames = models.map { it.fileName }.toSet()
        val localFiles: List<File> = (
            File(context.filesDir, "models").listFiles()?.toList().orEmpty() +
                File("/sdcard/Download/TunnelTurboModels").listFiles()?.toList().orEmpty()
            ).filter(::isModelArtifact)
        val discovered = localFiles.asSequence()
            .filter { it.name !in knownNames }
            .sortedBy { it.name.lowercase() }
            .map { file ->
                val id = "local-" + file.nameWithoutExtension.lowercase()
                    .replace(Regex("[^a-z0-9]+"), "-").trim('-')
                LocalModelSpec(
                    id = id,
                    displayName = "${file.nameWithoutExtension.replace('_', ' ')} · artefacto local",
                    repository = "local-file-unverified",
                    fileName = file.name,
                    bytes = file.length(),
                    sha256 = "",
                    role = LocalModelRole.CHAT,
                    downloadUrl = ""
                )
            }
            .toList()
        return models + discovered
    }

    /**
     * Models offered by the in-chat picker must be chat models from the maintained
     * catalog, with a readable local artifact and a verifiable artifact identity.
     * Developer Lab can still inspect/import other artifacts without presenting
     * them as ready for normal chat.
     */
    fun availableForChat(context: Context): List<LocalModelSpec> = modelsFor(context).filter { model ->
        isSelectableChatModel(model, candidateFiles(context, model).any { it.isFile && it.canRead() })
    }

    internal fun isSelectableChatModel(model: LocalModelSpec, hasReadableArtifact: Boolean): Boolean =
        hasReadableArtifact &&
            model.role == LocalModelRole.CHAT &&
            model.repository != "local-file-unverified" &&
            model.fileName.endsWith(".litertlm", ignoreCase = true) &&
            model.bytes > 0L &&
            model.sha256.matches(Regex("[a-fA-F0-9]{64}"))

    fun get(context: Context, id: String): LocalModelSpec? =
        models.firstOrNull { it.id == id } ?: modelsFor(context).firstOrNull { it.id == id }

    fun candidateFiles(context: Context, model: LocalModelSpec): List<File> {
        val privateModel = File(File(context.filesDir, "models"), model.fileName)
        val sharedModel = File("/sdcard/Download/TunnelTurboModels", model.fileName)
        val legacyDownload = if (model.id == DEFAULT_MODEL_ID) File("/sdcard/Download", model.fileName) else null
        return listOfNotNull(privateModel, sharedModel, legacyDownload).distinctBy { it.absolutePath }
    }

    internal fun isModelArtifact(file: File): Boolean = file.isFile && file.extension.equals("litertlm", ignoreCase = true)
}
