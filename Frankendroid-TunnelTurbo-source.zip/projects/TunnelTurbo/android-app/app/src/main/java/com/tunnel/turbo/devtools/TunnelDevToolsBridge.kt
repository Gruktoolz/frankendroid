package com.tunnel.turbo.devtools

import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.accessibility.SemanticSelector
import com.tunnel.turbo.coordinator.IntentCoordinator
import com.tunnel.turbo.core.NativeTunnelCore
import com.tunnel.turbo.model.ActionPlan
import com.tunnel.turbo.model.PlanValidator
import com.tunnel.turbo.model.TaskPlan
import com.tunnel.turbo.model.ToolStep
import com.tunnel.turbo.provider.ProviderRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap

enum class EffectClass {
    READ_ONLY,
    MUTATING
}

enum class AuthPolicy {
    NONE,
    REQUIRED
}

enum class BuildAvailability {
    ALL,
    DEBUG_ONLY
}

enum class Sensitivity {
    PUBLIC_DIAGNOSTIC,
    SENSITIVE
}

data class EndpointDescriptor(
    val path: String,
    val method: String,
    val effectClass: EffectClass,
    val authPolicy: AuthPolicy,
    val sensitivity: Sensitivity = Sensitivity.PUBLIC_DIAGNOSTIC,
    val availability: BuildAvailability = BuildAvailability.DEBUG_ONLY,
    val description: String = ""
)

class TunnelDevToolsBridge(
    coordinator: IntentCoordinator? = null,
    core: NativeTunnelCore? = null,
    val providerRuntime: ProviderRuntime? = null,
    accessibilityBridge: AccessibilityBridge? = null,
    val port: Int = 8765,
    val isDebug: Boolean = false,
    val tokenStorageDir: File? = null,
    val idleTimeoutMs: Int = SOCKET_READ_TIMEOUT_MS,
    val maxRequestDurationMs: Long = DEFAULT_MAX_REQUEST_DURATION_MS,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    companion object {
        const val MAX_HEADER_SIZE_BYTES = 8192
        const val MAX_BODY_SIZE_BYTES = 65536
        const val SOCKET_READ_TIMEOUT_MS = 2000
        const val DEFAULT_MAX_REQUEST_DURATION_MS = 5000L
        const val MAX_CONCURRENT_CLIENTS = 4

        val ENDPOINTS: Map<String, EndpointDescriptor> = listOf(
            // Diagnostic Read-Only (Public vs Sensitive)
            EndpointDescriptor("/", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Runtime state summary"),
            EndpointDescriptor("/debug_get_runtime_state", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Full runtime state"),
            EndpointDescriptor("/debug_get_current_request", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Current request metadata"),
            EndpointDescriptor("/debug_get_last_request_trace", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Last recorded trace"),
            EndpointDescriptor("/debug_get_event_journal", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "State event journal"),
            EndpointDescriptor("/debug_get_windows", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Display window list"),
            EndpointDescriptor("/debug_get_ui_nodes", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Accessibility node tree"),
            EndpointDescriptor("/debug_get_live_accessibility_snapshot", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Synchronized visual frame and accessibility nodes for local development viewer"),
            EndpointDescriptor("/debug_find_ui_nodes", "POST", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Filtered UI nodes search"),
            EndpointDescriptor("/debug_get_visible_text", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Screen visible text"),
            EndpointDescriptor("/debug_get_accessibility_health", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Accessibility service lifecycle health and diagnosis"),
            EndpointDescriptor("/debug_get_provider_health", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Provider health state"),
            EndpointDescriptor("/debug_get_worker_state", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Worker runtime state"),
            EndpointDescriptor("/debug_get_display_state", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Display state"),
            EndpointDescriptor("/debug_get_capabilities", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Registered capabilities"),
            EndpointDescriptor("/debug_get_metrics", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Telemetry metrics"),
            EndpointDescriptor("/debug_export_trace", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Trace export"),
            EndpointDescriptor("/debug_get_world_snapshot", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Perception world snapshot"),
            EndpointDescriptor("/debug_get_snapshot_consistency", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Snapshot consistency check"),
            EndpointDescriptor("/debug_get_perception_sources", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Perception sources active"),
            EndpointDescriptor("/debug_get_semantic_coverage", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Semantic coverage metrics"),
            EndpointDescriptor("/debug_get_unified_elements", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Unified element refs"),
            EndpointDescriptor("/debug_get_capability_contract", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Capability contracts"),
            EndpointDescriptor("/debug_benchmark_screenshots", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Benchmark screenshots"),
            EndpointDescriptor("/debug_get_agent_state", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Agent runtime state"),
            EndpointDescriptor("/debug_get_current_goal", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Current goal details"),
            EndpointDescriptor("/debug_get_world_model", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "World model summary"),
            EndpointDescriptor("/debug_get_current_plan", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Current execution plan"),
            EndpointDescriptor("/debug_get_current_observation", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Current observation"),
            EndpointDescriptor("/debug_get_agent_steps", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Agent steps trace"),
            EndpointDescriptor("/debug_get_agent_budget", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Agent budget status"),
            EndpointDescriptor("/debug_get_skills", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Skill memory list"),
            EndpointDescriptor("/debug_get_skill", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Specific skill details"),
            EndpointDescriptor("/debug_get_skill_candidates", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Skill candidates"),
            EndpointDescriptor("/debug_get_failure_diagnostic", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Last failure diagnostic"),
            EndpointDescriptor("/debug_get_provider_calls", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Provider calls list"),
            EndpointDescriptor("/debug_get_provider_call", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Specific provider call"),
            EndpointDescriptor("/debug_get_last_provider_call", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Last provider call"),
            EndpointDescriptor("/debug_get_decision_provenance", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Decision provenance"),
            EndpointDescriptor("/debug_get_reasoning_provider", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Reasoning provider identity"),
            EndpointDescriptor("/debug_get_goal_evidence", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Goal evidence snapshot"),
            EndpointDescriptor("/debug_get_goal_verification", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Goal verification details"),
            EndpointDescriptor("/debug_get_session_events", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Session event stream"),
            EndpointDescriptor("/debug_get_action_results", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Action results history"),
            EndpointDescriptor("/debug_get_last_cognitive_assessment", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Last local cognitive assessment"),
            EndpointDescriptor("/debug_get_cognitive_shadow_stats", "GET", EffectClass.READ_ONLY, AuthPolicy.NONE, Sensitivity.PUBLIC_DIAGNOSTIC, description = "Shadow dispatcher stats"),
            EndpointDescriptor("/debug_assess_turn", "GET, POST", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Direct turn assessment test"),
            EndpointDescriptor("/debug_get_captured_cognitive_input", "GET", EffectClass.READ_ONLY, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Captured input inspection"),

            // Mutating Endpoints (EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE)
            EndpointDescriptor("/debug_execute_capability", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Direct capability execution"),
            EndpointDescriptor("/debug_submit_intent", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Submit intent into coordinator"),
            EndpointDescriptor("/debug_submit_agent_goal", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Submit agent goal"),
            EndpointDescriptor("/debug_skill_mutation", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Mutate skill memory"),
            EndpointDescriptor("/debug_resume_agent_session", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Resume agent session with answer"),
            EndpointDescriptor("/debug_set_strict_real_provider_mode", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Toggle strict provider mode"),
            EndpointDescriptor("/debug_enable_capturing_cognitive_engine", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Swap active engine to capturing wrapper"),
            EndpointDescriptor("/debug_reset_cognitive_engine", "POST", EffectClass.MUTATING, AuthPolicy.REQUIRED, Sensitivity.SENSITIVE, description = "Reset active engine to default")
        ).associateBy { it.path }
    }

    val coordinator: IntentCoordinator get() = _coordinator ?: throw IllegalStateException("IntentCoordinator not configured")
    val core: NativeTunnelCore get() = _core ?: throw IllegalStateException("NativeTunnelCore not configured")
    val accessibilityBridge: AccessibilityBridge get() = _accessibilityBridge ?: throw IllegalStateException("AccessibilityBridge not configured")

    private val _coordinator = coordinator
    private val _core = core
    private val _accessibilityBridge = accessibilityBridge
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    @Volatile var isRunning: Boolean = false
        private set

    // Section 28: DevSessionToken for mutating and sensitive endpoints
    val sessionToken: String = java.util.UUID.randomUUID().toString().replace("-", "").take(16)

    /** Development-only detail: preserve each independently exposed accessibility window. */
    private fun addWindowSnapshots(response: JSONObject, displayId: Int) {
        val windows = accessibilityBridge.getWindowsForDisplay(displayId)
        val windowArray = JSONArray()
        val flattenedNodes = JSONArray()
        val maxNodesPerWindow = 120
        val maxTotalNodes = 480
        var totalNodes = 0
        var possibleTruncation = false

        for (window in windows) {
            val bounds = android.graphics.Rect()
            try { window.getBoundsInScreen(bounds) } catch (_: Throwable) {}
            val windowJson = JSONObject().apply {
                put("id", window.id)
                put("type", window.type)
                put("typeName", when (window.type) {
                    android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION -> "APPLICATION"
                    android.view.accessibility.AccessibilityWindowInfo.TYPE_INPUT_METHOD -> "INPUT_METHOD"
                    android.view.accessibility.AccessibilityWindowInfo.TYPE_SYSTEM -> "SYSTEM"
                    android.view.accessibility.AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY -> "ACCESSIBILITY_OVERLAY"
                    android.view.accessibility.AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER -> "SPLIT_SCREEN_DIVIDER"
                    android.view.accessibility.AccessibilityWindowInfo.TYPE_MAGNIFICATION_OVERLAY -> "MAGNIFICATION_OVERLAY"
                    else -> "UNKNOWN"
                })
                put("displayId", window.displayId)
                put("layer", window.layer)
                put("isActive", window.isActive)
                put("isFocused", window.isFocused)
                put("title", window.title?.toString().orEmpty())
                put("bounds", JSONArray(listOf(bounds.left, bounds.top, bounds.right, bounds.bottom)))
            }

            val remaining = (maxTotalNodes - totalNodes).coerceAtLeast(0)
            val limit = minOf(maxNodesPerWindow, remaining)
            val snapshot = if (limit > 0) {
                try {
                    accessibilityBridge.getUiSnapshotForWindow(
                        window = window,
                        displayId = displayId,
                        maxNodes = limit,
                        includeVisibleText = false
                    )
                } catch (_: Throwable) {
                    null
                }
            } else null
            val rootAvailable = snapshot != null

            val nodes = JSONArray()
            snapshot?.nodes?.forEach { node ->
                val json = node.toJson().apply {
                    put("windowId", window.id)
                    put("windowType", window.type)
                    put("windowTypeName", windowJson.optString("typeName"))
                    put("windowLayer", window.layer)
                    put("windowTitle", window.title?.toString().orEmpty())
                }
                nodes.put(json)
                flattenedNodes.put(json)
            }
            val windowTruncated = snapshot?.possibleTruncation == true || (limit == 0 && totalNodes >= maxTotalNodes)
            possibleTruncation = possibleTruncation || windowTruncated
            totalNodes += nodes.length()
            windowJson.put("rootAvailable", if (limit > 0) rootAvailable else JSONObject.NULL)
            windowJson.put("inspectionStatus", if (limit == 0) "not_read_total_node_budget" else if (rootAvailable) "read" else "root_unavailable")
            windowJson.put("totalNodes", nodes.length())
            windowJson.put("possibleNodeTruncation", windowTruncated)
            windowArray.put(windowJson)
        }

        response.put("windows", windowArray)
        response.put("ui_nodes", flattenedNodes)
        response.put("totalNodes", totalNodes)
        response.put("nodeLimit", maxNodesPerWindow)
        response.put("totalNodeLimit", maxTotalNodes)
        response.put("possibleNodeTruncation", possibleTruncation)
        response.put("windowCount", windows.size)
        response.put("windowSnapshotMode", "all_accessible_windows")
    }

    private fun writeTokenToStorage(): Boolean {
        return try {
            val targetDir = tokenStorageDir ?: File(System.getProperty("java.io.tmpdir"), "tunnel_turbo_dev")
            if (!targetDir.exists() && !targetDir.mkdirs()) {
                return false
            }
            val tokenFile = File(targetDir, "dev_session_token.txt")
            tokenFile.writeText(sessionToken)
            try {
                tokenFile.setReadable(false, false)
                tokenFile.setReadable(true, true)
            } catch (_: Throwable) {}
            tokenFile.exists() && tokenFile.length() > 0
        } catch (t: Throwable) {
            android.util.Log.e("DevToolsBridge", "Failed to write token: ${t.message}")
            false
        }
    }

    fun isMutating(path: String): Boolean = ENDPOINTS[path]?.effectClass == EffectClass.MUTATING

    private val traces = ConcurrentHashMap<String, RequestTrace>()
    @Volatile var lastTrace: RequestTrace? = null

    fun recordTrace(trace: RequestTrace) {
        lastTrace = trace
        traces[trace.requestId] = trace
        // Retain max 50 traces in memory
        if (traces.size > 50) {
            val oldest = traces.keys.firstOrNull()
            if (oldest != null) traces.remove(oldest)
        }
    }

    private val clientSemaphore = java.util.concurrent.Semaphore(MAX_CONCURRENT_CLIENTS)

    @Synchronized
    fun start(): Boolean {
        if (isRunning) return true
        if (!isDebug) {
            android.util.Log.w("DevToolsBridge", "TunnelDevToolsBridge listener disabled in non-debug build")
            return false
        }
        var candidateSocket: ServerSocket? = null
        try {
            // Strictly bind to local loopback (127.0.0.1) ONLY. Never expose to LAN/Internet.
            val loopback = InetAddress.getByName("127.0.0.1")
            candidateSocket = ServerSocket(port, 50, loopback)
            // Do not rotate the shared credential until this instance owns the listener.
            // A duplicate start that fails to bind must not invalidate the active server token.
            if (!writeTokenToStorage()) {
                candidateSocket.close()
                android.util.Log.e("DevToolsBridge", "DevTools auth credential bootstrap failed; failing closed")
                return false
            }
            serverSocket = candidateSocket
            isRunning = true
            android.util.Log.i("DevToolsBridge", "TunnelDevToolsBridge listening on http://127.0.0.1:$port")

            serverJob = scope.launch {
                while (isRunning) {
                    try {
                        val client = serverSocket?.accept() ?: break
                        if (!clientSemaphore.tryAcquire()) {
                            // Concurrency limit reached! Reject predictably with 503 Service Unavailable (Section 12 & 23)
                            // Bounded rejection: respond synchronously without launching an unbounded coroutine!
                            try {
                                client.soTimeout = 500
                                val out = client.getOutputStream()
                                val resp = ("HTTP/1.1 503 Service Unavailable\r\n" +
                                        "Content-Type: application/json; charset=UTF-8\r\n" +
                                        "Content-Length: 53\r\n" +
                                        "Connection: close\r\n\r\n" +
                                        "{\"status\":\"error\",\"error\":\"MAX_CONCURRENT_CLIENTS\"}\n")
                                    .toByteArray(Charsets.UTF_8)
                                out.write(resp)
                                out.flush()
                            } catch (_: Throwable) {
                            } finally {
                                try { client.close() } catch (_: Throwable) {}
                            }
                            continue
                        }
                        // Bounded coroutine execution: at most MAX_CONCURRENT_CLIENTS concurrent handler coroutines
                        scope.launch {
                            try {
                                handleClient(client)
                            } finally {
                                clientSemaphore.release()
                            }
                        }
                    } catch (t: Throwable) {
                        if (!isRunning) break
                    }
                }
            }
            return true
        } catch (t: Throwable) {
            isRunning = false
            try { candidateSocket?.close() } catch (_: Throwable) {}
            if (serverSocket === candidateSocket) serverSocket = null
            try {
                val tokenFile = File(tokenStorageDir ?: File(System.getProperty("java.io.tmpdir"), "tunnel_turbo_dev"), "dev_session_token.txt")
                if (tokenFile.isFile && tokenFile.readText() == sessionToken) tokenFile.delete()
            } catch (_: Throwable) {}
            android.util.Log.e("DevToolsBridge", "Failed to start DevToolsBridge on port $port: ${t.message}")
            return false
        }
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (ignored: Throwable) {}
        serverJob?.cancel()
        serverSocket = null
        android.util.Log.i("DevToolsBridge", "TunnelDevToolsBridge stopped")
    }

    private fun handleClient(socket: Socket) {
        val startNano = System.nanoTime()
        val deadlineNano = startNano + maxRequestDurationMs * 1_000_000L

        fun applySocketDeadline() {
            val remainingNano = deadlineNano - System.nanoTime()
            if (remainingNano <= 0) {
                throw SocketTimeoutException("Absolute request deadline exceeded ($maxRequestDurationMs ms)")
            }
            val remainingMs = (remainingNano / 1_000_000L).coerceAtLeast(1L).toInt()
            socket.soTimeout = minOf(idleTimeoutMs, remainingMs)
        }

        try {
            applySocketDeadline()
            val input = socket.getInputStream()
            val headerSb = StringBuilder()
            var b: Int
            while (true) {
                applySocketDeadline()
                b = input.read()
                if (b == -1) break
                headerSb.append(b.toChar())
                if (headerSb.length > MAX_HEADER_SIZE_BYTES) {
                    respondError(socket, 431, "Request Header Fields Too Large")
                    return
                }
                if (headerSb.endsWith("\r\n\r\n") || headerSb.endsWith("\n\n")) break
            }
            val headerStr = headerSb.toString()
            if (headerStr.isEmpty()) return

            val lines = headerStr.split(Regex("\r?\n"))
            val requestLine = lines[0]
            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                respondError(socket, 400, "BAD_REQUEST: Malformed HTTP request line")
                return
            }
            val method = parts[0]
            val fullPath = parts[1]
            val path = fullPath.substringBefore("?")
            val queryParams = parseQueryParams(fullPath.substringAfter("?", ""))

            val headers = mutableMapOf<String, String>()
            for (l in lines.drop(1)) {
                val idx = l.indexOf(':')
                if (idx > 0) {
                    val k = l.substring(0, idx).trim().lowercase()
                    val v = l.substring(idx + 1).trim()
                    headers[k] = v
                }
            }

            var contentLength = 0
            for (l in lines) {
                if (l.startsWith("Content-Length:", ignoreCase = true)) {
                    val parsed = l.substringAfter(":").trim().toIntOrNull()
                    if (parsed == null || parsed < 0) {
                        // Section 13: Reject malformed or negative Content-Length
                        respondError(socket, 400, "BAD_REQUEST: Malformed or negative Content-Length")
                        return
                    }
                    contentLength = parsed
                }
            }

            if (contentLength > MAX_BODY_SIZE_BYTES) {
                respondError(socket, 413, "PAYLOAD_TOO_LARGE: Content-Length ($contentLength) exceeds maximum limit ($MAX_BODY_SIZE_BYTES)")
                return
            }

            var body = ""
            if (contentLength > 0) {
                val bodyBytes = ByteArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    applySocketDeadline()
                    val r = input.read(bodyBytes, read, contentLength - read)
                    if (r <= 0) break
                    read += r
                }
                if (read < contentLength) {
                    // Section 13: Reject truncated body
                    respondError(socket, 400, "BAD_REQUEST: Truncated request body (received $read of $contentLength bytes)")
                    return
                }
                body = String(bodyBytes, 0, read, Charsets.UTF_8)
            }

            val responseJson = handleEndpoint(method, path, queryParams, body, headers)
            val responseBytes = responseJson.toString(2).toByteArray(Charsets.UTF_8)

            val isError = responseJson.optString("status") == "error"
            val httpStatusCode = if (isError) responseJson.optInt("httpStatusCode", 400) else 200
            val statusText = when (httpStatusCode) {
                400 -> "400 Bad Request"
                401 -> "401 Unauthorized"
                404 -> "404 Not Found"
                405 -> "405 Method Not Allowed"
                413 -> "413 Payload Too Large"
                431 -> "431 Request Header Fields Too Large"
                500 -> "500 Internal Server Error"
                501 -> "501 Not Implemented"
                503 -> "503 Service Unavailable"
                else -> "200 OK"
            }

            val out = socket.getOutputStream()
            val headerOut = ("HTTP/1.1 $statusText\r\n" +
                    "Content-Type: application/json; charset=UTF-8\r\n" +
                    "Content-Length: ${responseBytes.size}\r\n" +
                    "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)
            out.write(headerOut)
            out.write(responseBytes)
            out.flush()
        } catch (_: SocketTimeoutException) {
            // Read or absolute deadline timeout: close socket cleanly
        } catch (t: Throwable) {
            android.util.Log.d("DevToolsBridge", "Socket error: ${t.message}")
        } finally {
            try { socket.close() } catch (ignored: Throwable) {}
        }
    }

    private fun respondError(socket: Socket, code: Int, message: String) {
        try {
            val statusText = when (code) {
                400 -> "400 Bad Request"
                401 -> "401 Unauthorized"
                404 -> "404 Not Found"
                405 -> "405 Method Not Allowed"
                413 -> "413 Payload Too Large"
                431 -> "431 Request Header Fields Too Large"
                503 -> "503 Service Unavailable"
                else -> "$code Error"
            }
            val errJson = JSONObject().apply {
                put("status", "error")
                put("error", message)
                put("httpStatusCode", code)
            }
            val errBytes = errJson.toString(2).toByteArray(Charsets.UTF_8)
            val out = socket.getOutputStream()
            val header = ("HTTP/1.1 $statusText\r\n" +
                    "Content-Type: application/json; charset=UTF-8\r\n" +
                    "Content-Length: ${errBytes.size}\r\n" +
                    "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)
            out.write(header)
            out.write(errBytes)
            out.flush()
        } catch (_: Throwable) {}
    }

    private fun parseQueryParams(queryStr: String): Map<String, String> {
        if (queryStr.isEmpty()) return emptyMap()
        val map = mutableMapOf<String, String>()
        for (pair in queryStr.split("&")) {
            val kv = pair.split("=", limit = 2)
            if (kv.size == 2) {
                map[kv[0]] = java.net.URLDecoder.decode(kv[1], "UTF-8")
            }
        }
        return map
    }

    // --- DevTools Tool Endpoints ---

    fun handleEndpoint(
        method: String,
        path: String,
        params: Map<String, String>,
        body: String,
        headers: Map<String, String> = emptyMap()
    ): JSONObject {
        val root = JSONObject()
        root.put("status", "ok")
        root.put("endpoint", path)

        val descriptor = ENDPOINTS[path]
        if (descriptor == null) {
            root.put("status", "error")
            root.put("error", "Unknown DevTools endpoint '$path'")
            root.put("httpStatusCode", 404)
            return root
        }

        // Method enforcement
        val allowedMethods = descriptor.method.split(",").map { it.trim().uppercase() }
        if (!allowedMethods.contains(method.trim().uppercase())) {
            root.put("status", "error")
            root.put("error", "METHOD_NOT_ALLOWED: Endpoint '$path' expects ${descriptor.method}, got $method")
            root.put("httpStatusCode", 405)
            return root
        }

        // Resource limits: Content-Length header verification
        val declaredLength = headers["content-length"]?.toIntOrNull() ?: 0
        if (declaredLength > MAX_BODY_SIZE_BYTES || body.length > MAX_BODY_SIZE_BYTES) {
            root.put("status", "error")
            root.put("error", "PAYLOAD_TOO_LARGE: Request body/length exceeds limit ($MAX_BODY_SIZE_BYTES bytes)")
            root.put("httpStatusCode", 413)
            return root
        }

        // Authentication enforcement (Section 8, 9, 16, 18, 19)
        // Tokens MUST be in x-dev-session-token header ONLY. Query parameter tokens are rejected.
        val requiresAuth = descriptor.authPolicy == AuthPolicy.REQUIRED ||
                           descriptor.effectClass == EffectClass.MUTATING ||
                           descriptor.sensitivity == Sensitivity.SENSITIVE
        if (requiresAuth) {
            val reqToken = headers["x-dev-session-token"]
            if (reqToken.isNullOrBlank() || reqToken != sessionToken) {
                root.put("status", "error")
                root.put("error", "UNAUTHORIZED: Valid x-dev-session-token header required for endpoint '$path'")
                root.put("httpStatusCode", 401)
                return root
            }
        }

        when (path) {
            "/" -> {
                val data = JSONObject()
                val coord = _coordinator
                if (coord != null) {
                    val state = coord.uiState.value
                    data.put("uiMode", state.uiMode.name)
                    data.put("isBusy", state.isBusy)
                    data.put("statusMessage", state.statusMessage)
                    data.put("shizukuStatus", state.debugState.shizukuStatusText)
                    data.put("accessibilityStatus", state.debugState.accessibilityStatusText)
                    data.put("providerStatus", state.debugState.providerStatusText)
                } else {
                    data.put("status", "ready")
                    data.put("mode", "unattached_diagnostic")
                }
                root.put("runtime_state", data)
            }

            "/debug_get_runtime_state" -> {
                val state = coordinator.uiState.value
                val data = JSONObject()
                data.put("uiMode", state.uiMode.name)
                data.put("isBusy", state.isBusy)
                data.put("statusMessage", state.statusMessage)
                data.put("foregroundPackage", core.stateEngine.currentState.foregroundPackage)
                data.put("foregroundActivity", core.stateEngine.currentState.foregroundActivity)
                data.put("stateRevision", core.stateEngine.currentState.revision)
                data.put("journalSize", core.journal.size())
                data.put("shizukuStatus", state.debugState.shizukuStatusText)
                data.put("accessibilityStatus", state.debugState.accessibilityStatusText)
                data.put("providerStatus", state.debugState.providerStatusText)
                root.put("runtime_state", data)
            }

            "/debug_get_current_request" -> {
                val lastReq = coordinator.uiState.value.debugState.lastRequestId
                val data = JSONObject()
                data.put("lastRequestId", lastReq)
                data.put("lastRoute", coordinator.uiState.value.debugState.lastRoute)
                data.put("lastPlan", coordinator.uiState.value.debugState.lastPlan)
                data.put("lastVerification", coordinator.uiState.value.debugState.lastVerification)
                data.put("lastLatencyMs", coordinator.uiState.value.debugState.lastLatencyMs)
                root.put("current_request", data)
            }

            "/debug_get_last_request_trace" -> {
                val t = lastTrace
                if (t != null) {
                    root.put("trace", t.toJson())
                } else {
                    root.put("trace", JSONObject.NULL)
                }
            }

            "/debug_get_event_journal" -> {
                val sinceRev = params["sinceRevision"]?.toLongOrNull() ?: 0L
                val events = core.journal.getEvents(sinceRevision = sinceRev)
                val arr = JSONArray()
                for (e in events) {
                    val eObj = JSONObject()
                    eObj.put("revision", e.revision)
                    eObj.put("type", e.type)
                    eObj.put("timestamp", e.timestamp)
                    val pObj = JSONObject()
                    for ((k, v) in e.payload) {
                        pObj.put(k, v.toString())
                    }
                    eObj.put("payload", pObj)
                    arr.put(eObj)
                }
                root.put("events", arr)
                root.put("totalReturned", events.size)
            }

            "/debug_get_windows" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val a11yState = getSafeAccessibilityState()
                root.put("serviceConnected", a11yState.isConnected)
                root.put("serviceStatus", a11yState.status)
                if (!a11yState.isConnected) {
                    root.put("status", "error")
                    root.put("error", "Accessibility service is not connected (${a11yState.status})")
                    root.put("windows", JSONArray())
                    root.put("displayId", disp)
                    return root
                }
                if (params["includeNodes"] == "true") {
                    addWindowSnapshots(root, disp)
                    root.put("displayId", disp)
                    return root
                }
                val windows = accessibilityBridge.getWindowsForDisplay(disp)
                val arr = JSONArray()
                for (w in windows) {
                    val wObj = JSONObject()
                    wObj.put("id", w.id)
                    wObj.put("type", w.type)
                    wObj.put("displayId", w.displayId)
                    wObj.put("isActive", w.isActive)
                    wObj.put("isFocused", w.isFocused)
                    wObj.put("title", w.title?.toString() ?: "")
                    arr.put(wObj)
                }
                root.put("windows", arr)
                root.put("displayId", disp)
            }

            "/debug_get_ui_nodes" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val a11yState = getSafeAccessibilityState()
                root.put("serviceConnected", a11yState.isConnected)
                root.put("serviceStatus", a11yState.status)
                if (!a11yState.isConnected) {
                    root.put("status", "error")
                    root.put("error", "Accessibility service is not connected (${a11yState.status})")
                    root.put("ui_nodes", JSONArray())
                    root.put("totalNodes", 0)
                    root.put("displayId", disp)
                    return root
                }
                if (params["allWindows"] == "true") {
                    addWindowSnapshots(root, disp)
                    root.put("displayId", disp)
                    return root
                }
                val snapshot = accessibilityBridge.getUiSnapshot(disp, includeVisibleText = false)
                val arr = JSONArray()
                for (n in snapshot.nodes) arr.put(n.toJson())
                root.put("ui_nodes", arr)
                root.put("totalNodes", snapshot.nodes.size)
                root.put("actionableCount", snapshot.actionableCount)
                root.put("nodeLimit", 120)
                root.put("possibleNodeTruncation", snapshot.possibleTruncation)
                root.put("foregroundPackage", snapshot.foregroundPackage)
                root.put("foregroundActivity", snapshot.foregroundActivity)
                root.put("displayId", disp)
                root.put("snapshotId", snapshot.snapshotId)
                root.put("capturedAtMs", snapshot.capturedAtMs)
                root.put("snapshotAgeMs", snapshot.getSnapshotAgeMs())
                if (snapshot.windows.isNotEmpty()) {
                    val wArr = JSONArray()
                    for (w in snapshot.windows) wArr.put(w.toJson())
                    root.put("windows", wArr)
                }
                if (snapshot.unknownRegions.isNotEmpty()) {
                    val uArr = JSONArray()
                    for (u in snapshot.unknownRegions) uArr.put(u.toJson())
                    root.put("unknownRegions", uArr)
                }
            }

            "/debug_get_live_accessibility_snapshot" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val captureStartedAtMs = System.currentTimeMillis()
                val screenshotStartedAtMs = System.currentTimeMillis()
                val bitmap = accessibilityBridge.takeScreenshot(disp, timeoutMs = 2000L)
                val screenshotCompletedAtMs = System.currentTimeMillis()
                val treeStartedAtMs = System.currentTimeMillis()
                val allWindows = params["allWindows"] == "true"
                val nodes = if (allWindows) emptyList() else accessibilityBridge.getUiNodes(disp)
                if (allWindows) addWindowSnapshots(root, disp)
                val treeCompletedAtMs = System.currentTimeMillis()

                root.put("displayId", disp)
                root.put("captureStartedAtMs", captureStartedAtMs)
                root.put("screenshotStartedAtMs", screenshotStartedAtMs)
                root.put("screenshotCompletedAtMs", screenshotCompletedAtMs)
                root.put("screenshotDurationMs", screenshotCompletedAtMs - screenshotStartedAtMs)
                root.put("treeStartedAtMs", treeStartedAtMs)
                root.put("treeCompletedAtMs", treeCompletedAtMs)
                root.put("treeDurationMs", treeCompletedAtMs - treeStartedAtMs)
                root.put("snapshotSkewUpperBoundMs", treeCompletedAtMs - screenshotStartedAtMs)
                val displayState = core.stateEngine.getStateForDisplay(disp)
                root.put("foregroundPackage", displayState.foregroundPackage)
                root.put("foregroundActivity", displayState.foregroundActivity)
                if (!allWindows) {
                    root.put("totalNodes", nodes.size)
                    root.put("nodeLimit", 120)
                    root.put("possibleNodeTruncation", nodes.size >= 120)
                    val arr = JSONArray()
                    for (n in nodes) arr.put(n.toJson())
                    root.put("ui_nodes", arr)
                }

                if (bitmap != null) {
                    try {
                        val imageBytes = java.io.ByteArrayOutputStream().use { output ->
                            val compressed = bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 78, output)
                            if (!compressed) throw IllegalStateException("Bitmap compression returned false")
                            output.toByteArray()
                        }
                        root.put("visualAvailable", true)
                        root.put("visualMimeType", "image/jpeg")
                        root.put("visualWidth", bitmap.width)
                        root.put("visualHeight", bitmap.height)
                        root.put("visualJpegBase64", android.util.Base64.encodeToString(imageBytes, android.util.Base64.NO_WRAP))
                    } catch (t: Throwable) {
                        root.put("visualAvailable", false)
                        root.put("visualError", "JPEG encoding failed: ${t.javaClass.simpleName}")
                    } finally {
                        try { bitmap.recycle() } catch (_: Throwable) {}
                    }
                } else {
                    root.put("visualAvailable", false)
                    root.put("visualError", "Accessibility screenshot unavailable (secure window, unsupported display, or capture failure)")
                }
            }

            "/debug_find_ui_nodes" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val match = params["match"] ?: "all"
                val selectorMap = if (body.isNotEmpty()) {
                    try {
                        val bObj = JSONObject(body)
                        val m = mutableMapOf<String, Any>()
                        val it = bObj.keys()
                        while (it.hasNext()) {
                            val k = it.next()
                            m[k] = bObj.get(k)
                        }
                        m
                    } catch (t: Throwable) {
                        emptyMap()
                    }
                } else {
                    params
                }
                val sel = SemanticSelector.fromMap(selectorMap)
                val nodes = accessibilityBridge.findUiNodes(sel, disp, match)
                val arr = JSONArray()
                for (n in nodes) arr.put(n.toJson())
                root.put("matched_nodes", arr)
                root.put("totalMatched", nodes.size)
            }

            "/debug_get_visible_text" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val a11yState = getSafeAccessibilityState()
                root.put("serviceConnected", a11yState.isConnected)
                root.put("serviceStatus", a11yState.status)
                if (!a11yState.isConnected) {
                    root.put("status", "error")
                    root.put("error", "Accessibility service is not connected (${a11yState.status})")
                    root.put("visible_text", "")
                    root.put("displayId", disp)
                    return root
                }
                val txt = accessibilityBridge.getVisibleText(disp)
                root.put("visible_text", txt)
                root.put("displayId", disp)
            }

            "/debug_get_accessibility_health" -> {
                val state = getSafeAccessibilityState()
                root.put("accessibility_health", state.toJson())
            }

            "/debug_get_provider_health" -> {
                val wb = core.effectiveWorkerBridge
                val rep = wb.checkOperationalHealth()
                val hc = wb.performHealthCheck()
                val data = JSONObject()
                data.put("state", rep.state.name)
                data.put("ready", rep.isReady)
                data.put("isReady", rep.isReady)
                data.put("rateLimited", rep.state == com.tunnel.turbo.worker.ProviderHealthState.RATE_LIMITED)
                data.put("displayExists", rep.displayExists)
                data.put("providerRunning", rep.providerRunning)
                data.put("providerForegroundOnWorker", rep.providerForeground)
                data.put("inputNodeAvailable", rep.inputNodeAvailable)
                data.put("sendNodeAvailable", rep.sendNodeAvailable)
                data.put("accessibilityReadable", rep.accessibilityReadable)
                data.put("sessionValid", hc.sessionValid)
                data.put("storedDisplayId", hc.storedDisplayId ?: rep.displayId ?: 0)
                data.put("actualDisplayId", hc.actualDisplayId ?: rep.displayId ?: 0)
                data.put("displayId", rep.displayId ?: 0)
                data.put("message", rep.message)
                data.put("details", rep.message.ifBlank { hc.details })
                root.put("provider_health", data)
            }

            "/debug_get_worker_state" -> {
                val wb = core.effectiveWorkerBridge
                val storedId = wb.session.displayId
                val actualId = wb.displayManager.getDisplayId()
                val data = JSONObject()
                data.put("providerClass", "AndroidAiAppReasoningProvider")
                data.put("lifecycle", wb.lifecycle.name)
                data.put("storedWorkerDisplayId", storedId ?: 0)
                data.put("actualWorkerDisplayId", actualId ?: 0)
                data.put("workerDisplayId", storedId ?: actualId ?: 0)
                data.put("match", storedId != null && storedId == actualId)
                root.put("worker_state", data)
            }

            "/debug_get_display_state" -> {
                val wb = core.effectiveWorkerBridge
                val storedId = wb.session.displayId
                val actualId = wb.displayManager.getDisplayId()
                val data = JSONObject()
                data.put("primaryDisplayId", 0)
                data.put("workerDisplayId", storedId ?: actualId ?: 0)
                data.put("storedWorkerDisplayId", storedId ?: 0)
                data.put("actualWorkerDisplayId", actualId ?: 0)
                data.put("match", storedId != null && storedId == actualId)
                data.put("isScreenInteractive", core.stateEngine.currentState.screenInteractive)
                data.put("orientation", core.stateEngine.currentState.orientation)
                root.put("display_state", data)
            }

            "/debug_get_capabilities" -> {
                val szReady = coordinator.shizukuBridge.checkState() == com.tunnel.turbo.shizuku.ShizukuState.READY
                val a11yReady = accessibilityBridge.isEnabled()
                val caps = core.capabilityRegistry.getCapabilities(szReady, a11yReady)
                val arr = JSONArray()
                for (c in caps) arr.put(c.toJson())
                root.put("capabilities", arr)
                root.put("totalCapabilities", caps.size)
            }

            "/debug_get_metrics" -> {
                val data = JSONObject()
                data.put("journalEvents", core.journal.size())
                data.put("stateRevision", core.stateEngine.currentState.revision)
                data.put("recordedTraces", traces.size)
                data.put("lastLatencyMs", coordinator.uiState.value.debugState.lastLatencyMs)
                root.put("metrics", data)
            }

            "/debug_execute_capability" -> {
                // Must pass through CapabilityRegistry + PlanValidator + Core + Verifier
                try {
                    val bObj = JSONObject(body)
                    val capId = bObj.optString("capabilityId").ifEmpty { bObj.optString("tool") }
                    val argsObj = bObj.optJSONObject("arguments") ?: JSONObject()
                    val argsMap = mutableMapOf<String, Any>()
                    val it = argsObj.keys()
                    while (it.hasNext()) {
                        val k = it.next()
                        argsMap[k] = argsObj.get(k)
                    }

                    // Check capability exists in registry
                    val cap = core.capabilityRegistry.getCapability(capId)
                    if (cap == null) {
                        root.put("status", "error")
                        root.put("error", "Capability '$capId' is not registered in CapabilityRegistry")
                    } else {
                        // Construct plan and validate
                        val taskPlan = TaskPlan(steps = listOf(ToolStep(tool = capId, arguments = argsMap)))
                        core.actionEngine.displayPolicy // Ensure validator runs
                        val vPlan = PlanValidator().validate(taskPlan.toJson())

                        // Execute through Core
                        val res = kotlinx.coroutines.runBlocking {
                            core.executePlan(vPlan)
                        }

                        root.put("capabilityId", capId)
                        root.put("success", res.success)
                        root.put("actionSummary", res.actionSummary)
                        root.put("details", res.details)
                        root.put("executionMs", res.executionMs)
                    }
                } catch (t: Throwable) {
                    root.put("status", "error")
                    root.put("error", "Validation or Execution failure: ${t.message}")
                }
            }

            "/debug_export_trace" -> {
                val reqId = params["requestId"] ?: lastTrace?.requestId ?: ""
                val t = traces[reqId] ?: lastTrace
                if (t != null) {
                    root.put("exported_trace", t.toJson())
                } else {
                    root.put("status", "not_found")
                    root.put("error", "No trace found for request ID '$reqId'")
                }
            }

            "/debug_get_world_snapshot" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val force = params["force"]?.toBoolean() ?: false
                val snap = kotlinx.coroutines.runBlocking {
                    core.getOrRefreshWorldSnapshot(displayId = disp, force = force)
                }
                if (snap != null) {
                    root.put("snapshot", snap.toJson())
                    val metrics = core.perceptionRouter?.lastMetrics
                    if (metrics != null) {
                        val mObj = JSONObject().apply {
                            put("systemProbeMs", metrics.systemProbeMs)
                            put("accessibilityMs", metrics.accessibilityMs)
                            put("coverageMs", metrics.coverageMs)
                            put("captureMs", metrics.captureMs)
                            put("ocrMs", metrics.ocrMs)
                            put("fusionMs", metrics.fusionMs)
                            put("totalPerceptionMs", metrics.totalPerceptionMs)
                            put("screenshotUsed", metrics.screenshotUsed)
                            put("ocrUsed", metrics.ocrUsed)
                            put("ocrElementCount", metrics.ocrElementCount)
                            put("fusedElementCount", metrics.fusedElementCount)
                        }
                        root.put("perception_metrics", mObj)
                    }
                } else {
                    root.put("status", "error")
                    root.put("error", "PerceptionRouter not available or snapshot capture failed")
                }
            }

            "/debug_get_snapshot_consistency" -> {
                val snap = core.currentWorldSnapshot
                if (snap != null) {
                    root.put("consistencyStatus", snap.consistencyStatus.name)
                    root.put("isValid", snap.isValid)
                    root.put("revision", snap.revision)
                    root.put("displayId", snap.displayId)
                    root.put("foregroundPackage", snap.foregroundPackage)
                    root.put("foregroundActivity", snap.foregroundActivity)
                } else {
                    root.put("status", "not_found")
                    root.put("error", "No active WorldSnapshot cached")
                }
            }

            "/debug_get_perception_sources" -> {
                val snap = core.currentWorldSnapshot
                val metrics = core.perceptionRouter?.lastMetrics
                val sourcesArr = JSONArray()
                snap?.perceptionSources?.forEach { sourcesArr.put(it) }
                root.put("activeSources", sourcesArr)
                if (metrics != null) {
                    val mObj = JSONObject().apply {
                        put("systemProbeMs", metrics.systemProbeMs)
                        put("accessibilityMs", metrics.accessibilityMs)
                        put("coverageMs", metrics.coverageMs)
                        put("captureMs", metrics.captureMs)
                        put("ocrMs", metrics.ocrMs)
                        put("fusionMs", metrics.fusionMs)
                        put("totalPerceptionMs", metrics.totalPerceptionMs)
                        put("screenshotUsed", metrics.screenshotUsed)
                        put("ocrUsed", metrics.ocrUsed)
                    }
                    root.put("metrics", mObj)
                }
            }

            "/debug_get_semantic_coverage" -> {
                val snap = core.currentWorldSnapshot
                if (snap != null) {
                    root.put("coverageStatus", snap.coverageStatus.name)
                    root.put("semanticElementCount", snap.semanticElements.size)
                    root.put("totalUnifiedElements", snap.unifiedElements.size)
                } else {
                    root.put("status", "not_found")
                    root.put("error", "No active WorldSnapshot cached")
                }
            }

            "/debug_get_unified_elements" -> {
                val snap = core.currentWorldSnapshot
                if (snap != null) {
                    val arr = JSONArray()
                    snap.unifiedElements.forEach { arr.put(it.toJson()) }
                    root.put("unifiedElements", arr)
                    root.put("totalElements", snap.unifiedElements.size)
                } else {
                    root.put("status", "not_found")
                    root.put("error", "No active WorldSnapshot cached")
                }
            }

            "/debug_get_capability_contract" -> {
                val szReady = coordinator.shizukuBridge.checkState() == com.tunnel.turbo.shizuku.ShizukuState.READY
                val a11yReady = accessibilityBridge.isEnabled()
                val registered = core.capabilityRegistry.getAllCapabilities().size
                val available = core.capabilityRegistry.getAvailableCapabilities(szReady, a11yReady).size
                val advertised = core.capabilityRegistry.getAdvertisedCapabilities(szReady, a11yReady).size
                val executable = com.tunnel.turbo.task.NativeTaskExecutor.SUPPORTED_TOOLS.size
                val mismatches = core.capabilityRegistry.getContractMismatches(shizukuReady = szReady, accessibilityReady = a11yReady)

                val data = JSONObject().apply {
                    put("registered", registered)
                    put("available", available)
                    put("advertised", advertised)
                    put("executable", executable)
                    put("contractMismatchCount", Integer.valueOf(mismatches.size))
                    val mArr = JSONArray()
                    mismatches.forEach { mArr.put(it) }
                    put("mismatches", mArr)
                }
                root.put("capability_contract", data)
            }

            "/debug_benchmark_screenshots" -> {
                val workerDisp = params["workerDisplayId"]?.toIntOrNull() ?: 29
                val iterations = params["iterations"]?.toIntOrNull() ?: 10

                fun benchmarkA11y(disp: Int): JSONObject {
                    val samples = mutableListOf<Long>()
                    var successCount = 0
                    var errorCount = 0
                    for (i in 1..iterations) {
                        val t0 = System.currentTimeMillis()
                        val bmp = accessibilityBridge.takeScreenshot(disp, timeoutMs = 2000L)
                        val elapsed = System.currentTimeMillis() - t0
                        if (bmp != null) {
                            successCount++
                            samples.add(elapsed)
                            bmp.recycle()
                        } else {
                            errorCount++
                            samples.add(elapsed)
                        }
                        Thread.sleep(50)
                    }
                    val sorted = samples.sorted()
                    val median = if (sorted.isNotEmpty()) sorted[sorted.size / 2] else 0L
                    val p95 = if (sorted.isNotEmpty()) sorted[(sorted.size * 0.95).toInt().coerceAtMost(sorted.size - 1)] else 0L

                    return JSONObject().apply {
                        put("displayId", disp)
                        put("iterations", iterations)
                        put("successCount", successCount)
                        put("errorCount", errorCount)
                        put("medianMs", median)
                        put("p95Ms", p95)
                        val sArr = JSONArray()
                        samples.forEach { sArr.put(it) }
                        put("rawSamplesMs", sArr)
                    }
                }

                fun benchmarkShizuku(disp: Int): JSONObject {
                    val samples = mutableListOf<Long>()
                    var successCount = 0
                    var errorCount = 0
                    val sz = coordinator.shizukuBridge
                    for (i in 1..iterations) {
                        val t0 = System.currentTimeMillis()
                        val bmp = sz.takeScreenshotBitmap(disp)
                        val elapsed = System.currentTimeMillis() - t0
                        if (bmp != null) {
                            successCount++
                            samples.add(elapsed)
                            bmp.recycle()
                        } else {
                            errorCount++
                            samples.add(elapsed)
                        }
                        Thread.sleep(50)
                    }
                    val sorted = samples.sorted()
                    val median = if (sorted.isNotEmpty()) sorted[sorted.size / 2] else 0L
                    val p95 = if (sorted.isNotEmpty()) sorted[(sorted.size * 0.95).toInt().coerceAtMost(sorted.size - 1)] else 0L

                    return JSONObject().apply {
                        put("displayId", disp)
                        put("iterations", iterations)
                        put("successCount", successCount)
                        put("errorCount", errorCount)
                        put("medianMs", median)
                        put("p95Ms", p95)
                        val sArr = JSONArray()
                        samples.forEach { sArr.put(it) }
                        put("rawSamplesMs", sArr)
                    }
                }

                root.put("accessibility_display_0", benchmarkA11y(0))
                root.put("accessibility_worker_display", benchmarkA11y(workerDisp))
                root.put("shizuku_display_0", benchmarkShizuku(0))
                root.put("shizuku_worker_display", benchmarkShizuku(workerDisp))
            }



            "/debug_submit_intent" -> {
                val inputJson = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                val text = inputJson.optString("input", params["input"] ?: "")
                val reqBackend = inputJson.optString("backend", params["backend"] ?: "")
                if (reqBackend.isNotBlank()) {
                    coordinator.preferredBackend = if (reqBackend.equals("GPU", ignoreCase = true)) {
                        com.tunnel.turbo.chat.ChatBackend.GPU
                    } else {
                        com.tunnel.turbo.chat.ChatBackend.CPU
                    }
                }
                val reqProfile = inputJson.optString("profile", params["profile"] ?: "")
                if (reqProfile.isNotBlank()) {
                    coordinator.conversationRuntime.activeProfile = if (reqProfile.equals("DEFAULT", ignoreCase = true)) {
                        com.tunnel.turbo.chat.LocalChatProfile.DEFAULT
                    } else {
                        com.tunnel.turbo.chat.LocalChatProfile.FAST
                    }
                }
                if (text.isBlank()) {
                    root.put("status", "error")
                    root.put("error", "Missing 'input' field")
                } else {
                    val job = coordinator.submitIntent(text, source = "DEVTOOLS_BRIDGE")
                    if (job != null) {
                        kotlinx.coroutines.runBlocking {
                            job.join()
                        }
                    }
                    root.put("input", text)
                    val lt = lastTrace
                    if (lt != null) {
                        root.put("trace", lt.toJson())
                        root.put("success", lt.error == null)
                    } else {
                        root.put("trace", JSONObject.NULL)
                    }
                }
            }


            "/debug_get_agent_state" -> {
                val state = core.agentRuntime.runtimeState.value
                root.put("agent_state", state.toJson())
            }

            "/debug_get_current_goal" -> {
                val goal = core.agentRuntime.runtimeState.value.currentGoal
                root.put("current_goal", goal?.toJson() ?: JSONObject.NULL)
            }

            "/debug_get_world_model" -> {
                val wm = core.agentRuntime.worldModel
                val data = JSONObject().apply {
                    put("static", wm.getStaticModelJson())
                    put("dynamic", wm.getDynamicModelJson())
                    put("learned", wm.getLearnedModelJson())
                }
                root.put("world_model", data)
            }

            "/debug_get_current_plan" -> {
                val lastRes = core.agentRuntime.runtimeState.value.lastResult
                val arr = JSONArray()
                lastRes?.steps?.forEach { arr.put(it.toJson()) }
                root.put("current_plan_steps", arr)
                root.put("last_goal_id", lastRes?.goalId ?: "")
                root.put("success_type", lastRes?.successType?.name ?: "")
            }

            "/debug_get_current_observation" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val accessibilitySnapshot = accessibilityBridge.getUiSnapshot(disp)
                val redObs = com.tunnel.turbo.agent.ObservationReducer().reduce(
                    foregroundPackage = core.stateEngine.currentState.foregroundPackage,
                    foregroundActivity = core.stateEngine.currentState.foregroundActivity,
                    allNodes = accessibilitySnapshot.nodes,
                    fullVisibleText = accessibilitySnapshot.visibleText
                )
                root.put("current_observation", redObs.toJson())
            }

            "/debug_get_agent_steps" -> {
                val lastRes = core.agentRuntime.runtimeState.value.lastResult
                val arr = JSONArray()
                lastRes?.steps?.forEach { arr.put(it.toJson()) }
                root.put("agent_steps", arr)
                root.put("total_steps", arr.length())
            }

            "/debug_get_agent_budget" -> {
                val lastRes = core.agentRuntime.runtimeState.value.lastResult
                val b = lastRes?.budget ?: com.tunnel.turbo.agent.AgentBudget()
                root.put("agent_budget", b.toJson())
            }

            "/debug_get_skills" -> {
                val skills = core.agentRuntime.skillMemory.getAllSkills()
                val arr = JSONArray()
                skills.forEach { arr.put(it.toJson()) }
                root.put("skills", arr)
                root.put("total_skills", skills.size)
            }

            "/debug_get_skill" -> {
                val sId = params["skillId"] ?: ""
                val skill = core.agentRuntime.skillMemory.getSkill(sId)
                if (skill != null) {
                    root.put("skill", skill.toJson())
                } else {
                    root.put("status", "not_found")
                    root.put("error", "Skill '$sId' no encontrada")
                }
            }

            "/debug_get_skill_candidates" -> {
                val candidates = core.agentRuntime.skillMemory.getAllCandidates()
                val arr = JSONArray()
                candidates.forEach { arr.put(it.toJson()) }
                root.put("skill_candidates", arr)
                root.put("total_candidates", candidates.size)
            }

            "/debug_skill_mutation" -> {
                val action = params["action"] ?: "clear"
                if (action == "remove") {
                    val skillId = params["skillId"] ?: ""
                    val removed = core.skillMemory.removeSkill(skillId)
                    root.put("removed", removed)
                    root.put("skillId", skillId)
                } else {
                    root.put("status", "ok")
                    root.put("message", "Skill memory mutation executed")
                }
            }

            "/debug_get_failure_diagnostic" -> {
                val lastRes = core.agentRuntime.runtimeState.value.lastResult
                val diag = lastRes?.diagnostic
                if (diag != null) {
                    root.put("diagnostic", diag.toJson())
                } else {
                    root.put("diagnostic", JSONObject.NULL)
                }
            }

            "/debug_submit_agent_goal" -> {
                val inputJson = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                val goalText = inputJson.optString("goal", params["goal"] ?: "")
                val disp = inputJson.optInt("displayId", params["displayId"]?.toIntOrNull() ?: 0)
                val profileStr = inputJson.optString("budgetProfile", inputJson.optString("profile", params["profile"] ?: "STANDARD_INTERACTIVE"))
                val profile = try {
                    com.tunnel.turbo.agent.BudgetProfile.valueOf(profileStr.uppercase())
                } catch (t: Throwable) {
                    com.tunnel.turbo.agent.BudgetProfile.STANDARD_INTERACTIVE
                }
                val budget = com.tunnel.turbo.agent.AgentBudget.forProfile(profile)
                if (goalText.isBlank()) {
                    root.put("status", "error")
                    root.put("error", "Missing 'goal' field")
                } else {
                    val result = kotlinx.coroutines.runBlocking {
                        core.agentRuntime.executeUserGoal(goalText, disp, budget)
                    }
                    root.put("goal", goalText)
                    root.put("result", result.toJson())
                    root.put("success", result.success)
                }
            }

            "/debug_resume_agent_session" -> {
                val inputJson = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
                val sessionId = inputJson.optString("sessionId", params["sessionId"] ?: "")
                val userResponse = inputJson.optString("userResponse", params["userResponse"] ?: "")
                if (sessionId.isBlank()) {
                    root.put("status", "error")
                    root.put("error", "Missing 'sessionId' field")
                } else if (userResponse.isBlank()) {
                    root.put("status", "error")
                    root.put("error", "Missing 'userResponse' field")
                } else {
                    val session = core.agentRuntime.getSession(sessionId)
                    if (session == null) {
                        root.put("status", "error")
                        root.put("error", "UNKNOWN_SESSION: Session '$sessionId' not found")
                    } else if (session.status != com.tunnel.turbo.agent.SessionStatus.PAUSED_NEEDS_USER) {
                        root.put("status", "error")
                        root.put("error", "INVALID_SESSION_STATE: Session '$sessionId' is in status '${session.status}', must be PAUSED_NEEDS_USER")
                    } else {
                        val result = kotlinx.coroutines.runBlocking {
                            core.agentRuntime.resumeSession(sessionId, userResponse)
                        }
                        root.put("sessionId", sessionId)
                        root.put("userResponse", userResponse)
                        root.put("result", result.toJson())
                        root.put("success", result.success)
                    }
                }
            }

            "/debug_get_provider_calls" -> {
                val calls = com.tunnel.turbo.agent.ProviderCallRepository.getAllTraces()
                val arr = JSONArray()
                calls.forEach { arr.put(it.toJson()) }
                root.put("provider_calls", arr)
                root.put("total_calls", calls.size)
            }

            "/debug_get_provider_call" -> {
                val callId = params["id"] ?: params["providerCallId"] ?: ""
                val trace = com.tunnel.turbo.agent.ProviderCallRepository.getTrace(callId)
                if (trace != null) {
                    root.put("provider_call", trace.toJson())
                } else {
                    root.put("status", "error")
                    root.put("error", "Provider call trace not found for id '$callId'")
                }
            }

            "/debug_get_last_provider_call" -> {
                val trace = com.tunnel.turbo.agent.ProviderCallRepository.getLastTrace()
                if (trace != null) {
                    root.put("provider_call", trace.toJson())
                } else {
                    root.put("provider_call", JSONObject.NULL)
                }
            }

            "/debug_get_decision_provenance" -> {
                val counts = com.tunnel.turbo.agent.ProviderCallRepository.getDecisionProvenance()
                val obj = JSONObject()
                counts.forEach { (k, v) -> obj.put(k, v) }
                root.put("decision_provenance", obj)
            }

            "/debug_get_reasoning_provider" -> {
                val rp = core.agentRuntime.reasoningProvider
                val data = JSONObject()
                data.put("providerName", rp.name)
                data.put("strictRealProviderMode", com.tunnel.turbo.agent.GeneralAgentRuntime.strictRealProviderMode)
                data.put("workerReady", core.effectiveWorkerBridge.isReady())
                data.put("workerDisplayId", core.effectiveWorkerBridge.session.displayId ?: 0)
                root.put("reasoning_provider", data)
            }

            "/debug_get_goal_evidence" -> {
                val disp = params["displayId"]?.toIntOrNull() ?: 0
                val verifier = com.tunnel.turbo.agent.GoalVerifier(core.context, accessibilityBridge)
                val ev = verifier.gatherEvidence(disp)
                root.put("goal_evidence", ev.toJson())
            }

            "/debug_get_goal_verification" -> {
                val lastVer = com.tunnel.turbo.agent.GoalVerifier.lastVerification
                if (lastVer != null) {
                    root.put("goal_verification", lastVer.toJson())
                } else {
                    root.put("goal_verification", JSONObject.NULL)
                }
            }

            "/debug_set_strict_real_provider_mode" -> {
                val enabledStr = params["enabled"] ?: try {
                    JSONObject(body).optString("enabled")
                } catch (t: Throwable) { "true" }
                val enabled = enabledStr.toBoolean()
                com.tunnel.turbo.agent.GeneralAgentRuntime.strictRealProviderMode = enabled
                root.put("strictRealProviderMode", enabled)
                root.put("message", "Strict Real Provider Mode set to $enabled")
            }

            "/debug_get_session_events" -> {
                val session = core.agentRuntime.activeSession
                if (session != null) {
                    val arr = JSONArray()
                    session.events.forEach { arr.put(it.toJson()) }
                    root.put("events", arr)
                    root.put("totalEvents", session.events.size)
                    root.put("sessionId", session.sessionId)
                } else {
                    root.put("events", JSONArray())
                    root.put("totalEvents", 0)
                }
            }

            "/debug_get_action_results" -> {
                val session = core.agentRuntime.activeSession
                if (session != null) {
                    val arr = JSONArray()
                    session.recordedActionResults.forEach { arr.put(it.toJson()) }
                    root.put("action_results", arr)
                    root.put("totalActionResults", session.recordedActionResults.size)
                    root.put("sessionId", session.sessionId)
                } else {
                    root.put("action_results", JSONArray())
                    root.put("totalActionResults", 0)
                }
            }

            "/debug_get_last_cognitive_assessment" -> {
                val assessment = com.tunnel.turbo.local.ShadowCognitiveDispatcher.lastAssessment
                if (assessment != null) {
                    root.put("assessment", assessment.toJson())
                } else {
                    root.put("assessment", JSONObject.NULL)
                }
            }

            "/debug_get_cognitive_shadow_stats" -> {
                val stats = com.tunnel.turbo.local.ShadowCognitiveDispatcher.getStats()
                root.put("shadow_stats", stats)
            }

            "/debug_assess_turn" -> {
                val input: com.tunnel.turbo.local.LocalCognitiveInput
                if (body.isNotBlank()) {
                    val bodyObj = try {
                        JSONObject(body)
                    } catch (t: Throwable) {
                        root.put("status", "error")
                        root.put("error", "MALFORMED_JSON_BODY: ${t.message}")
                        root.put("httpStatusCode", 400)
                        return root
                    }
                    try {
                        input = com.tunnel.turbo.local.LocalCognitiveInput.fromJson(bodyObj)
                    } catch (t: Throwable) {
                        root.put("status", "error")
                        root.put("error", "INVALID_COGNITIVE_INPUT: ${t.message}")
                        root.put("httpStatusCode", 400)
                        return root
                    }
                } else {
                    val userMsg = params["userMessage"]
                    if (userMsg.isNullOrBlank()) {
                        root.put("status", "error")
                        root.put("error", "MISSING_INPUT: Provide structured JSON body or 'userMessage' query parameter")
                        root.put("httpStatusCode", 400)
                        return root
                    }
                    input = com.tunnel.turbo.local.LocalCognitiveInput(userMessage = userMsg)
                }

                val assessment = try {
                    kotlinx.coroutines.runBlocking {
                        com.tunnel.turbo.local.ShadowCognitiveDispatcher.assessDirect(input)
                    }
                } catch (t: Throwable) {
                    root.put("status", "error")
                    root.put("error", "ENGINE_FAILURE: ${t.message}")
                    root.put("httpStatusCode", 500)
                    return root
                }

                root.put("assessment", assessment.toJson())
                root.put("receivedInput", input.toJson())
                val capturing = com.tunnel.turbo.local.LocalCognitiveEngineRegistry.activeEngine as? com.tunnel.turbo.local.CapturingLocalCognitiveEngine
                if (capturing != null) {
                    root.put("engineObservedInput", capturing.lastCapturedInput?.toJson() ?: JSONObject.NULL)
                }
            }

            "/debug_enable_capturing_cognitive_engine" -> {
                val current = com.tunnel.turbo.local.LocalCognitiveEngineRegistry.activeEngine
                val capturing = if (current is com.tunnel.turbo.local.CapturingLocalCognitiveEngine) {
                    current
                } else {
                    val newCap = com.tunnel.turbo.local.CapturingLocalCognitiveEngine(current)
                    com.tunnel.turbo.local.LocalCognitiveEngineRegistry.setEngine(newCap)
                    newCap
                }
                root.put("capturingEnabled", true)
                root.put("modelId", capturing.modelId)
            }

            "/debug_get_captured_cognitive_input" -> {
                val capturing = com.tunnel.turbo.local.LocalCognitiveEngineRegistry.activeEngine as? com.tunnel.turbo.local.CapturingLocalCognitiveEngine
                if (capturing != null) {
                    root.put("capturingActive", true)
                    root.put("capturedCount", capturing.capturedInputs.size)
                    if (capturing.lastCapturedInput != null) {
                        root.put("lastCapturedInput", capturing.lastCapturedInput!!.toJson())
                    } else {
                        root.put("lastCapturedInput", JSONObject.NULL)
                    }
                } else {
                    root.put("capturingActive", false)
                    root.put("lastCapturedInput", JSONObject.NULL)
                }
            }

            "/debug_reset_cognitive_engine" -> {
                com.tunnel.turbo.local.LocalCognitiveEngineRegistry.resetToDefault()
                root.put("reset", true)
                root.put("activeEngine", com.tunnel.turbo.local.LocalCognitiveEngineRegistry.activeEngine.modelId)
            }

            else -> {
                root.put("status", "not_found")
                root.put("error", "Unknown DevTools endpoint '$path'")
            }
        }

        return root
    }

    private fun getSafeAccessibilityState(): com.tunnel.turbo.accessibility.AccessibilityServiceState {
        return runCatching { accessibilityBridge.getServiceState() }.getOrNull()
            ?: com.tunnel.turbo.accessibility.AccessibilityServiceState(
                isEnabled = runCatching { accessibilityBridge.isEnabled() }.getOrDefault(false),
                isConnected = runCatching { accessibilityBridge.isConnected() }.getOrDefault(false),
                status = if (runCatching { accessibilityBridge.isConnected() }.getOrDefault(false)) "CONNECTED" else "DISCONNECTED"
            )
    }
}
