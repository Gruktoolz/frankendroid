package com.tunnel.turbo.perception

import android.graphics.Rect
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.accessibility.TunnelTurboAccessibilityService

class AccessibilityProbe(
    private val accessibilityBridge: AccessibilityBridge
) {

    fun probeWindows(displayId: Int): List<WindowSummary> {
        val windowInfos = accessibilityBridge.getWindowsForDisplay(displayId)
        return windowInfos.map { w ->
            val r = Rect()
            w.getBoundsInScreen(r)
            WindowSummary(
                id = w.id,
                title = w.title?.toString() ?: "",
                displayId = w.displayId,
                isActive = w.isActive,
                isFocused = w.isFocused,
                bounds = r
            )
        }
    }

    fun probeSemanticElements(displayId: Int): List<SemanticElement> {
        val nodes = accessibilityBridge.getUiNodes(displayId)
        return nodes.map { n ->
            val rect = if (n.bounds.size >= 4) {
                Rect(n.bounds[0], n.bounds[1], n.bounds[2], n.bounds[3])
            } else {
                Rect(0, 0, 0, 0)
            }
            SemanticElement(
                id = n.nodeId,
                text = n.text,
                contentDescription = n.contentDescription,
                role = n.className.substringAfterLast("."),
                bounds = rect,
                clickable = n.clickable,
                editable = n.editable,
                checkable = n.checked || n.className.contains("Switch") || n.className.contains("CheckBox"),
                checked = n.checked
            )
        }
    }

    fun probeVisibleText(displayId: Int): String {
        return accessibilityBridge.getVisibleText(displayId)
    }

    fun getForegroundPackage(displayId: Int): String {
        return accessibilityBridge.getForegroundPackage(displayId)
    }
}
