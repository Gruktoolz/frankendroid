package com.tunnel.turbo.perception

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.app.AppManager
import com.tunnel.turbo.core.NativeStateEngine
import com.tunnel.turbo.shizuku.ShizukuBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PerceptionMetrics(
    val systemProbeMs: Long = 0,
    val accessibilityMs: Long = 0,
    val coverageMs: Long = 0,
    val captureMs: Long = 0,
    val resizeMs: Long = 0,
    val ocrMs: Long = 0,
    val fusionMs: Long = 0,
    val totalPerceptionMs: Long = 0,
    val screenshotUsed: Boolean = false,
    val ocrUsed: Boolean = false,
    val ocrElementCount: Int = 0,
    val fusedElementCount: Int = 0,
    val coverageStatus: CoverageStatus = CoverageStatus.UNKNOWN
)

class PerceptionRouter(
    private val context: Context,
    private val accessibilityBridge: AccessibilityBridge,
    private val stateEngine: NativeStateEngine = NativeStateEngine(context),
    private val appManager: AppManager = AppManager(context),
    private val shizukuBridge: ShizukuBridge? = null
) {
    private val systemProbe = SystemProbe(context, stateEngine, appManager)
    private val accessibilityProbe = AccessibilityProbe(accessibilityBridge)
    private val coverageDetector = SemanticCoverageDetector()
    private val ocrScanner = LocalOcrScanner()
    private val fusionEngine = PerceptionFusionEngine()
    private val consistencyValidator = SnapshotConsistencyValidator()

    private var currentRevision: Long = 100L

    var lastMetrics: PerceptionMetrics = PerceptionMetrics()
        private set

    suspend fun observeWorld(
        displayId: Int = 0,
        goalContext: String? = null,
        displayWidth: Int = 1200,
        displayHeight: Int = 1920
    ): WorldSnapshot = withContext(Dispatchers.Default) {
        val tTotal0 = System.currentTimeMillis()
        val rev = ++currentRevision

        // S0: System Probe
        val tSys0 = System.currentTimeMillis()
        val sysState = systemProbe.probeSystemState(displayId)
        val tSysElapsed = System.currentTimeMillis() - tSys0

        // S1: Accessibility Probe
        val tA11y0 = System.currentTimeMillis()
        val windows = accessibilityProbe.probeWindows(displayId)
        val semanticElements = accessibilityProbe.probeSemanticElements(displayId)
        val fgPkg = accessibilityProbe.getForegroundPackage(displayId)
        val fgAct = stateEngine.currentState.foregroundActivity
        val tA11yElapsed = System.currentTimeMillis() - tA11y0

        // Semantic Coverage Detector
        val tCov0 = System.currentTimeMillis()
        val covStatus = coverageDetector.detectCoverage(
            displayId = displayId,
            foregroundPackage = fgPkg,
            elements = semanticElements,
            screenWidth = displayWidth,
            screenHeight = displayHeight,
            goalText = goalContext
        )
        val tCovElapsed = System.currentTimeMillis() - tCov0

        var screenshotUsed = false
        var ocrUsed = false
        var captureMs = 0L
        var ocrMs = 0L
        var fusionMs = 0L
        var ocrCount = 0
        var fusedCount = 0

        val unifiedElements: List<UnifiedElement>
        val perceptionSources = mutableListOf("S0_SYSTEM", "S1_ACCESSIBILITY")

        if (covStatus == CoverageStatus.SUFFICIENT) {
            // Fast Path: Pure Accessibility is sufficient
            var elemIdx = 0
            unifiedElements = semanticElements.map { s ->
                elemIdx++
                UnifiedElement(
                    ref = "a:$displayId:$rev:$elemIdx",
                    label = s.effectiveLabel().ifBlank { s.role },
                    roleHint = s.role,
                    source = ElementSource.ACCESSIBILITY,
                    confidence = 1.0f,
                    boundsInternal = s.bounds,
                    actionableHint = if (s.clickable) "click" else if (s.editable) "type" else "view",
                    displayId = displayId,
                    revision = rev
                )
            }
        } else {
            // Escalation Path: S3-OCR Gap-First
            screenshotUsed = true
            val tCap0 = System.currentTimeMillis()
            var screenshot: Bitmap? = accessibilityBridge.takeScreenshot(displayId)

            // Fallback to Shizuku capture if a11y screenshot returned null and Shizuku is ready
            if (screenshot == null && shizukuBridge?.isReady() == true) {
                screenshot = shizukuBridge.takeScreenshotBitmap(displayId)
            }
            captureMs = System.currentTimeMillis() - tCap0

            if (screenshot != null) {
                ocrUsed = true
                perceptionSources.add("S3_OCR_LOCAL")
                perceptionSources.add("FUSION_ENGINE")

                val mask = CoverageMask(displayWidth, displayHeight)
                for (el in semanticElements) {
                    mask.markCovered(el.bounds)
                }
                val gaps = mask.getUncoveredGaps(minHeightPx = 300)
                val cropRect = gaps.firstOrNull()

                val tOcr0 = System.currentTimeMillis()
                val ocrElements = ocrScanner.scanBitmap(screenshot, cropRect, targetWidth = 720)
                ocrMs = System.currentTimeMillis() - tOcr0
                ocrCount = ocrElements.size

                val tFus0 = System.currentTimeMillis()
                unifiedElements = fusionEngine.fuse(
                    a11yElements = semanticElements,
                    ocrElements = ocrElements,
                    displayId = displayId,
                    revision = rev
                )
                fusionMs = System.currentTimeMillis() - tFus0
                fusedCount = unifiedElements.count { it.source == ElementSource.FUSED }

                // Immediately recycle screenshot to enforce RAM-only, no persistence privacy policy
                screenshot.recycle()
            } else {
                // If screenshot failed, fallback to accessibility elements
                var elemIdx = 0
                unifiedElements = semanticElements.map { s ->
                    elemIdx++
                    UnifiedElement(
                        ref = "a:$displayId:$rev:$elemIdx",
                        label = s.effectiveLabel().ifBlank { s.role },
                        roleHint = s.role,
                        source = ElementSource.ACCESSIBILITY,
                        confidence = 0.8f,
                        boundsInternal = s.bounds,
                        actionableHint = if (s.clickable) "click" else if (s.editable) "type" else "view",
                        displayId = displayId,
                        revision = rev
                    )
                }
            }
        }

        val allVisibleText = StringBuilder().apply {
            unifiedElements.forEach {
                if (it.label.isNotBlank()) append(it.label).append(" | ")
            }
        }.toString()

        val rawSnapshot = WorldSnapshot(
            revision = rev,
            displayId = displayId,
            foregroundPackage = fgPkg,
            foregroundActivity = fgAct,
            systemState = sysState,
            windows = windows,
            semanticElements = semanticElements,
            unifiedElements = unifiedElements,
            visibleText = allVisibleText,
            perceptionSources = perceptionSources,
            consistencyStatus = ConsistencyStatus.VALID,
            coverageStatus = covStatus,
            isValid = true
        )

        val finalSnapshot = consistencyValidator.validate(rawSnapshot)

        val totalMs = System.currentTimeMillis() - tTotal0
        lastMetrics = PerceptionMetrics(
            systemProbeMs = tSysElapsed,
            accessibilityMs = tA11yElapsed,
            coverageMs = tCovElapsed,
            captureMs = captureMs,
            resizeMs = 0,
            ocrMs = ocrMs,
            fusionMs = fusionMs,
            totalPerceptionMs = totalMs,
            screenshotUsed = screenshotUsed,
            ocrUsed = ocrUsed,
            ocrElementCount = ocrCount,
            fusedElementCount = fusedCount,
            coverageStatus = covStatus
        )

        return@withContext finalSnapshot
    }

    fun close() {
        ocrScanner.close()
    }
}
