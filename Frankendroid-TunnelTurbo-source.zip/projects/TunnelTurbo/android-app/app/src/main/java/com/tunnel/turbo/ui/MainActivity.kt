package com.tunnel.turbo.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import com.tunnel.turbo.R
import com.tunnel.turbo.accessibility.AccessibilityBridge
import com.tunnel.turbo.adapter.TunnelCoreAdapter
import com.tunnel.turbo.coordinator.ConversationMessage
import com.tunnel.turbo.coordinator.IntentCoordinator
import com.tunnel.turbo.coordinator.MessageRole
import com.tunnel.turbo.coordinator.UiMode
import com.tunnel.turbo.provider.AndroidAiAppProvider
import com.tunnel.turbo.provider.ProviderRuntime
import com.tunnel.turbo.shizuku.ShizukuBridge
import com.tunnel.turbo.worker.AiWorkerBridge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import android.provider.OpenableColumns

class MainActivity : AppCompatActivity() {

    private lateinit var geminiKeyVault: com.tunnel.turbo.chat.ApiKeyVault
    private val geminiApiClient = com.tunnel.turbo.chat.GeminiFreeApiClient()
    private lateinit var modelPickerLauncher: ActivityResultLauncher<Array<String>>
    private lateinit var screenCapturePickerLauncher: ActivityResultLauncher<Array<String>>
    private var localModelSpecs: List<com.tunnel.turbo.chat.LocalModelSpec> = emptyList()
    private var pendingBenchmarkRun: com.tunnel.turbo.chat.LocalBenchmarkRun? = null
    private lateinit var benchmarkStore: com.tunnel.turbo.chat.LocalModelBenchmarkStore
    private lateinit var conversationHistoryStore: com.tunnel.turbo.chat.ConversationHistoryStore
    private var lastPersistedConversation: List<ConversationMessage>? = null
    private var textToSpeech: android.speech.tts.TextToSpeech? = null

    private lateinit var coordinator: IntentCoordinator
    private lateinit var shizukuBridge: ShizukuBridge
    private lateinit var accessibilityBridge: AccessibilityBridge

    // UI View References
    private lateinit var tvHeaderStatus: TextView
    private lateinit var btnToggleMode: Button
    private lateinit var layoutAppMode: View
    private lateinit var layoutDeviceMode: View
    private lateinit var layoutDebugMode: View
    private lateinit var scrollChat: ScrollView
    private lateinit var llChatMessages: LinearLayout
    private lateinit var etAppInput: EditText
    private lateinit var btnAppSend: Button
    private lateinit var btnComposerModel: Button
    private lateinit var agentProgressPanel: View
    private lateinit var btnProgressDisclosure: Button
    private lateinit var llProgressDetails: LinearLayout
    private lateinit var llActivityProgress: LinearLayout
    private lateinit var llActivityHistory: LinearLayout
    private var progressPollActive = false
    private var lastProgressKey: String = ""
    private var busyStartedAtMs: Long? = null
    private var isRegenerating = false
    private val streamingStatusViews = linkedMapOf<String, TextView>()
    private val messageTextViews = linkedMapOf<String, TextView>()
    private var lastRenderedTab: com.tunnel.turbo.coordinator.NavigationTab? = null
    private var lastComposerModelLabelKey: String? = null

    // Debug View References
    private lateinit var tvShizukuStatus: TextView
    private lateinit var tvAccessibilityStatus: TextView
    private lateinit var tvProviderStatus: TextView
    private lateinit var tvCoreStatus: TextView
    private lateinit var tvExecutionStatus: TextView
    private lateinit var tvDebugLogOutput: TextView
    private var tvAgentGoal: TextView? = null
    private var tvAgentWorld: TextView? = null
    private var tvAgentSkills: TextView? = null
    private var tvAgentBudget: TextView? = null

    // Semantic Visualizer & Inspector References (Phase 13 Alpha)
    private var btnRefreshSnapshot: Button? = null
    private var btnToggleLabels: Button? = null
    private var btnModePixels: Button? = null
    private var btnModeAccessibility: Button? = null
    private var btnModeOcr: Button? = null
    private var btnModeCombined: Button? = null
    private var btnImportScreen: Button? = null
    private var tvViewerModeHint: TextView? = null
    private var tvViewerOcrText: TextView? = null
    private var tvSnapshotMeta: TextView? = null
    private var mapViewSemantic: SemanticDisplayMapView? = null
    private var viewerScreenBitmap: android.graphics.Bitmap? = null
    private var viewerOcrScanner: com.tunnel.turbo.perception.LocalOcrScanner? = null
    private var tvInspectorNodeId: TextView? = null
    private var tvInspectorNodeDetails: TextView? = null
    private var tvInspectorNodeFlags: TextView? = null
    private var btnActOnSelectedNode: Button? = null
    private var tvActionOutcome: TextView? = null
    private var selectedUiNode: com.tunnel.turbo.accessibility.UiNodeInfo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modelPickerLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importSelectedModel(uri)
        }
        screenCapturePickerLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importScreenCapture(uri)
        }
        setContentView(R.layout.activity_main)

        bindViews()
        initializeArchitecture()
        textToSpeech = android.speech.tts.TextToSpeech(this) { status ->
            if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                textToSpeech?.language = java.util.Locale("es", "MX")
            }
        }
        restoreConversationState(savedInstanceState)
        setupListeners()
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when (coordinator.uiState.value.activeTab) {
                    com.tunnel.turbo.coordinator.NavigationTab.MODEL_CENTER,
                    com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS,
                    com.tunnel.turbo.coordinator.NavigationTab.DEVICE,
                    com.tunnel.turbo.coordinator.NavigationTab.SETTINGS_LAB -> selectTab(com.tunnel.turbo.coordinator.NavigationTab.SETTINGS)
                    com.tunnel.turbo.coordinator.NavigationTab.SETTINGS,
                    com.tunnel.turbo.coordinator.NavigationTab.ACTIVITY -> selectTab(com.tunnel.turbo.coordinator.NavigationTab.CONVERSATION)
                    com.tunnel.turbo.coordinator.NavigationTab.CONVERSATION -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
        observeUiState()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::coordinator.isInitialized) {
            val data = org.json.JSONArray()
            coordinator.uiState.value.conversation.takeLast(40).forEach { msg ->
                data.put(org.json.JSONObject().apply {
                    put("id", msg.id); put("role", msg.role.name); put("text", msg.text); put("timestamp", msg.timestamp)
                    put("route", msg.route?.name ?: org.json.JSONObject.NULL)
                    put("turnStatus", msg.turnStatus?.name ?: org.json.JSONObject.NULL)
                    put("provenance", msg.provenance ?: org.json.JSONObject.NULL)
                    put("latencyMs", msg.latencyMs ?: org.json.JSONObject.NULL)
                    put("actionSummary", msg.actionSummary ?: org.json.JSONObject.NULL)
                    put("verificationExplanation", msg.verificationExplanation ?: org.json.JSONObject.NULL)
                    put("isSimulated", msg.isSimulated)
                    put("feedback", msg.feedback?.name ?: org.json.JSONObject.NULL)
                })
            }
            outState.putString(STATE_CONVERSATION, data.toString())
        }
    }

    private fun restoreConversationState(state: Bundle?) {
        val raw = state?.getString(STATE_CONVERSATION)
        val restored = if (raw == null) conversationHistoryStore.read() else runCatching {
            val array = org.json.JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val role = runCatching { MessageRole.valueOf(item.optString("role")) }.getOrNull() ?: return@mapNotNull null
                com.tunnel.turbo.coordinator.ConversationMessage(
                    id = item.optString("id"), role = role, text = item.optString("text"), timestamp = item.optLong("timestamp"),
                    route = item.optString("route").takeIf { it.isNotBlank() && it != "null" }?.let { runCatching { com.tunnel.turbo.coordinator.Route.valueOf(it) }.getOrNull() },
                    turnStatus = item.optString("turnStatus").takeIf { it.isNotBlank() && it != "null" }?.let { runCatching { com.tunnel.turbo.coordinator.TurnStatus.valueOf(it) }.getOrNull() },
                    provenance = item.optString("provenance").takeUnless { it.isBlank() || it == "null" },
                    latencyMs = if (item.isNull("latencyMs")) null else item.optDouble("latencyMs"),
                    actionSummary = item.optString("actionSummary").takeUnless { it.isBlank() || it == "null" },
                    verificationExplanation = item.optString("verificationExplanation").takeUnless { it.isBlank() || it == "null" },
                    isSimulated = item.optBoolean("isSimulated"),
                    feedback = item.optString("feedback").takeIf { it.isNotBlank() && it != "null" }?.let { runCatching { com.tunnel.turbo.coordinator.MessageFeedback.valueOf(it) }.getOrNull() }
                )
            }
        }.getOrDefault(emptyList())
        coordinator.restoreConversation(restored)
        lastPersistedConversation = restored
    }

    private companion object {
        const val STATE_CONVERSATION = "tunnel_turbo_saved_conversation_v1"
        const val NAV_ASSISTANT = 101
        const val NAV_MODEL_CENTER = 104
        const val NAV_CONNECTIONS = 105
        const val NAV_LAB = 106
        const val NAV_ACTIVITY = 102
        const val NAV_SETTINGS = 103
    }

    private fun bindViews() {
        tvHeaderStatus = findViewById(R.id.tvHeaderStatus)
        btnToggleMode = findViewById(R.id.btnToggleMode)
        layoutAppMode = findViewById(R.id.layoutAppMode)
        layoutDeviceMode = findViewById(R.id.layoutDeviceMode)
        layoutDebugMode = findViewById(R.id.layoutDebugMode)
        scrollChat = findViewById(R.id.scrollChat)
        llChatMessages = findViewById(R.id.llChatMessages)
        etAppInput = findViewById(R.id.etAppInput)
        btnAppSend = findViewById(R.id.btnAppSend)
        btnComposerModel = findViewById(R.id.btnComposerModel)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layoutComposerSurface)) { _, insets ->
            val imeVisible = insets.isVisible(androidx.core.view.WindowInsetsCompat.Type.ime())
            btnComposerModel.visibility = if (imeVisible) View.VISIBLE else View.GONE
            insets
        }
        androidx.core.view.ViewCompat.requestApplyInsets(findViewById(R.id.layoutComposerSurface))
        agentProgressPanel = findViewById(R.id.agentProgressPanel)
        btnProgressDisclosure = findViewById(R.id.btnProgressDisclosure)
        llProgressDetails = findViewById(R.id.llProgressDetails)
        llActivityProgress = findViewById(R.id.llActivityProgress)
        llActivityHistory = findViewById(R.id.llActivityHistory)

        tvShizukuStatus = findViewById(R.id.tvShizukuStatus)
        tvAccessibilityStatus = findViewById(R.id.tvAccessibilityStatus)
        tvProviderStatus = findViewById(R.id.tvProviderStatus)
        tvCoreStatus = findViewById(R.id.tvCoreStatus)
        tvExecutionStatus = findViewById(R.id.tvExecutionStatus)
        tvDebugLogOutput = findViewById(R.id.tvDebugLogOutput)
        tvAgentGoal = findViewById(R.id.tvAgentGoal)
        tvAgentWorld = findViewById(R.id.tvAgentWorld)
        tvAgentSkills = findViewById(R.id.tvAgentSkills)
        tvAgentBudget = findViewById(R.id.tvAgentBudget)

        btnRefreshSnapshot = findViewById(R.id.btnRefreshSnapshot)
        btnToggleLabels = findViewById(R.id.btnToggleLabels)
        btnModePixels = findViewById(R.id.btnModePixels)
        btnModeAccessibility = findViewById(R.id.btnModeAccessibility)
        btnModeOcr = findViewById(R.id.btnModeOcr)
        btnModeCombined = findViewById(R.id.btnModeCombined)
        btnImportScreen = findViewById(R.id.btnImportScreen)
        tvViewerModeHint = findViewById(R.id.tvViewerModeHint)
        tvViewerOcrText = findViewById(R.id.tvViewerOcrText)
        tvSnapshotMeta = findViewById(R.id.tvSnapshotMeta)
        mapViewSemantic = findViewById(R.id.mapViewSemantic)
        tvInspectorNodeId = findViewById(R.id.tvInspectorNodeId)
        tvInspectorNodeDetails = findViewById(R.id.tvInspectorNodeDetails)
        tvInspectorNodeFlags = findViewById(R.id.tvInspectorNodeFlags)
        btnActOnSelectedNode = findViewById(R.id.btnActOnSelectedNode)
        tvActionOutcome = findViewById(R.id.tvActionOutcome)
    }

    private fun initializeArchitecture() {
        geminiKeyVault = com.tunnel.turbo.chat.ApiKeyVault(applicationContext)
        conversationHistoryStore = com.tunnel.turbo.chat.ConversationHistoryStore(applicationContext)
        shizukuBridge = ShizukuBridge(this)
        shizukuBridge.onStateChanged = {
            runOnUiThread { coordinator.refreshBridgesStatus() }
        }
        accessibilityBridge = AccessibilityBridge(this)

        val workerDisplayManager = com.tunnel.turbo.worker.PcBackendWorkerDisplayManager(context = applicationContext)
        val workerBridge = AiWorkerBridge(
            displayManager = workerDisplayManager,
            accessibilityBridge = accessibilityBridge,
            context = applicationContext
        )
        val coreAdapter = TunnelCoreAdapter(
            appContext = applicationContext,
            workerBridge = workerBridge
        )
        val aiProvider = AndroidAiAppProvider(workerBridge = workerBridge)
        val localRouter = com.tunnel.turbo.router.LocalIntentRouter(appManager = coreAdapter.nativeCore.appManager)
        val providerRuntime = ProviderRuntime(
            activeProvider = aiProvider,
            router = localRouter,
            coreAdapter = coreAdapter
        )

        coordinator = IntentCoordinator(
            context = applicationContext,
            providerRuntime = providerRuntime,
            shizukuBridge = shizukuBridge,
            accessibilityBridge = accessibilityBridge,
            scope = CoroutineScope(Dispatchers.Default)
        )
    }

    private fun setupListeners() {
        btnToggleMode.setOnClickListener {
            val menu = androidx.appcompat.widget.PopupMenu(this, btnToggleMode)
            menu.menu.add(0, NAV_ASSISTANT, 0, "Asistente")
            menu.menu.add(0, NAV_ACTIVITY, 1, "Actividad")
            menu.menu.add(0, NAV_SETTINGS, 2, "Ajustes")
            menu.setOnMenuItemClickListener { item ->
                val destination = when (item.itemId) {
                    NAV_ASSISTANT -> com.tunnel.turbo.coordinator.NavigationTab.CONVERSATION
                    NAV_ACTIVITY -> com.tunnel.turbo.coordinator.NavigationTab.ACTIVITY
                    NAV_SETTINGS -> com.tunnel.turbo.coordinator.NavigationTab.SETTINGS
                    else -> return@setOnMenuItemClickListener false
                }
                coordinator.selectNavigationTab(destination)
                true
            }
            menu.show()
        }
        btnProgressDisclosure.setOnClickListener {
            val expanded = llProgressDetails.visibility != View.VISIBLE
            llProgressDetails.visibility = if (expanded) View.VISIBLE else View.GONE
            renderProgress(coordinator.uiState.value)
        }
        btnComposerModel.setOnClickListener { anchor -> showAvailableModelSelector(anchor) }
        findViewById<Button>(R.id.btnSettingsModels).setOnClickListener { selectTab(com.tunnel.turbo.coordinator.NavigationTab.MODEL_CENTER) }
        findViewById<Button>(R.id.btnSettingsConnections).setOnClickListener { selectTab(com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS) }
        findViewById<Button>(R.id.btnSettingsDevice).setOnClickListener { selectTab(com.tunnel.turbo.coordinator.NavigationTab.DEVICE) }
        findViewById<Button>(R.id.btnSettingsMemory).setOnClickListener { showConversationMemoryDialog() }
        findViewById<Button>(R.id.btnSettingsLab).setOnClickListener { selectTab(com.tunnel.turbo.coordinator.NavigationTab.SETTINGS_LAB) }
        findViewById<Button>(R.id.navConversation).setOnClickListener { selectTab(com.tunnel.turbo.coordinator.NavigationTab.CONVERSATION) }
        findViewById<Button>(R.id.navDevice).setOnClickListener { selectTab(com.tunnel.turbo.coordinator.NavigationTab.DEVICE) }
        findViewById<Button>(R.id.navSettings).setOnClickListener { selectTab(com.tunnel.turbo.coordinator.NavigationTab.SETTINGS) }
        findViewById<Button>(R.id.btnDeviceRefresh).setOnClickListener { coordinator.refreshBridgesStatus() }
        findViewById<Button>(R.id.btnDeviceAccessibility).setOnClickListener {
            startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnDeviceShizuku).setOnClickListener {
            shizukuBridge.requestPermission()
            coordinator.refreshBridgesStatus()
        }
        findViewById<Button>(R.id.btnDeviceLab).setOnClickListener {
            coordinator.selectNavigationTab(com.tunnel.turbo.coordinator.NavigationTab.SETTINGS_LAB)
            btnRefreshSnapshot?.post { btnRefreshSnapshot?.performClick() }
        }
        findViewById<Button>(R.id.btnClearConversationHistory).setOnClickListener {
            conversationHistoryStore.clear()
            coordinator.clearConversationHistory()
            lastPersistedConversation = coordinator.uiState.value.conversation
            Toast.makeText(this, "Historial local borrado", Toast.LENGTH_SHORT).show()
        }

        // Product App Mode Composer
        btnAppSend.setOnClickListener {
            val text = etAppInput.text.toString().trim()
            if (text.isNotEmpty()) {
                val useGemini = findViewById<CheckBox>(R.id.cbUseGemini).isChecked
                val useGeminiSearch = findViewById<CheckBox>(R.id.cbUseGeminiSearch).isChecked
                val memoryCommand = com.tunnel.turbo.chat.MemoryCommandParser.parse(text)
                val needsAutomaticSearch = com.tunnel.turbo.chat.ResearchIntentPolicy.requiresWeb(text)
                if (memoryCommand != null || needsAutomaticSearch || !useGemini) {
                    etAppInput.setText("")
                    coordinator.submitIntent(text, source = if (needsAutomaticSearch) "AUTO_WEB_RESEARCH" else "APP_COMPOSER")
                } else if (!geminiKeyVault.hasKey()) {
                    Toast.makeText(this, "Configura primero tu clave en Ajustes · Conexiones", Toast.LENGTH_LONG).show()
                    coordinator.selectNavigationTab(com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS)
                } else if (!isGeminiReady()) {
                    Toast.makeText(this, "Verifica primero la conexión Gemini en Ajustes · Conexiones", Toast.LENGTH_LONG).show()
                    coordinator.selectNavigationTab(com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS)
                } else {
                    val apiKey = geminiKeyVault.read()
                    if (apiKey == null) {
                        Toast.makeText(this, "No pude descifrar la clave; vuelve a guardarla", Toast.LENGTH_LONG).show()
                        coordinator.selectNavigationTab(com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS)
                    } else {
                        val history = coordinator.uiState.value.conversation.takeLast(12).mapNotNull { message ->
                            when (message.role) {
                                MessageRole.USER -> "user" to message.text
                                MessageRole.ASSISTANT -> "model" to message.text
                                MessageRole.SYSTEM_STATUS -> null
                            }
                        }
                        val responseId = coordinator.beginCloudChatTurn(text, useGeminiSearch)
                        btnAppSend.isEnabled = false
                        lifecycleScope.launch {
                            val streamed = StringBuilder()
                            var lastPublishedAt = 0L
                            val result = runCatching {
                                geminiApiClient.generateChatTurnStream(apiKey, text, history, useGoogleSearch = useGeminiSearch) { chunk ->
                                    streamed.append(chunk)
                                    val now = android.os.SystemClock.elapsedRealtime()
                                    if (now - lastPublishedAt >= 300L) {
                                        lastPublishedAt = now
                                        coordinator.updateStreamingAssistant(responseId, streamed.toString())
                                    }
                                }
                            }
                            runOnUiThread {
                                btnAppSend.isEnabled = true
                                result.onSuccess { answer ->
                                    coordinator.recordGeminiApiCheck(true, "Respuesta de chat recibida")
                                    etAppInput.setText("")
                                    coordinator.appendCloudChatTurn(text, answer.text, answer.elapsedMs, searched = useGeminiSearch, sources = answer.sources, responseId = responseId, truncated = answer.truncated)
                                }.onFailure { error ->
                                    val friendly = (error as? com.tunnel.turbo.chat.GeminiApiException)?.let {
                                        com.tunnel.turbo.chat.GeminiApiFailurePresenter.describe(it.httpStatus, it.apiStatus, it.message.orEmpty())
                                    } ?: "No se pudo conectar con Gemini. Revisa internet y el estado de la clave en Ajustes · Conexiones."
                                    coordinator.recordGeminiApiCheck(false, friendly)
                                    coordinator.appendCloudChatFailure(text, friendly, responseId = responseId)
                                    Toast.makeText(this@MainActivity, friendly, Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }
                }
            }
        }

        setupDeviceLab()
        setupGeminiApiSettings()
        val geminiMode = findViewById<CheckBox>(R.id.cbUseGemini)
        val geminiSearch = findViewById<CheckBox>(R.id.cbUseGeminiSearch)
        fun updateGeminiControls() {
            geminiMode.visibility = View.GONE
            geminiSearch.visibility = View.GONE
            if (!geminiMode.isChecked) geminiSearch.isChecked = false
            findViewById<TextView>(R.id.tvGeminiSearchDisclosure).visibility = View.GONE
            updateProviderTitle()
            updateComposerModelLabel()
        }
        geminiMode.setOnCheckedChangeListener { _, _ -> updateGeminiControls() }
        geminiSearch.setOnCheckedChangeListener { _, _ -> updateGeminiControls() }
        updateGeminiControls()

        findViewById<TextView>(R.id.tvAppTitle).setOnClickListener(null)

        // Keep local input when Gemini is selected but no key exists so it can be sent after setup.
        findViewById<TextView>(R.id.tvGeminiSearchDisclosure).text =
            "El mensaje y el contexto reciente se enviarán a Google. La búsqueda web es opcional y puede usar cuota."

        tvShizukuStatus.setOnClickListener {
            shizukuBridge.requestPermission()
            coordinator.refreshBridgesStatus()
        }

        tvAccessibilityStatus.setOnClickListener {
            coordinator.refreshBridgesStatus()
        }
    }

    private fun setupGeminiApiSettings() {
        val keyField = findViewById<EditText>(R.id.etGeminiApiKey)
        val consent = findViewById<CheckBox>(R.id.cbGeminiTestConsent)
        val save = findViewById<Button>(R.id.btnSaveGeminiKey)
        val test = findViewById<Button>(R.id.btnTestGeminiApi)
        val clear = findViewById<Button>(R.id.btnClearGeminiKey)
        val state = findViewById<TextView>(R.id.tvGeminiApiState)
        state.text = if (geminiKeyVault.hasKey()) {
            "Clave cifrada guardada · nivel de cuenta no comprobado"
        } else {
            "API no configurada · puedes seguir con los modelos locales"
        }
        consent.setOnCheckedChangeListener { _, checked -> test.isEnabled = checked && geminiKeyVault.hasKey() }
        save.setOnClickListener {
            val entered = keyField.text?.toString().orEmpty().trim()
            if (entered.isBlank()) {
                Toast.makeText(this, "Pega primero la clave de AI Studio", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            runCatching { geminiKeyVault.save(entered) }
                .onSuccess {
                    keyField.text?.clear()
                    state.text = "Clave guardada cifrada en este teléfono · conexión pendiente"
                    test.isEnabled = consent.isChecked
                    coordinator.refreshBridgesStatus()
                }
                .onFailure { state.text = "No se pudo guardar la clave: ${it.message ?: "error local"}" }
        }
        clear.setOnClickListener {
            geminiKeyVault.clear()
            keyField.text?.clear()
            test.isEnabled = false
            state.text = "Clave borrada de este teléfono"
            coordinator.refreshBridgesStatus()
        }
        test.setOnClickListener {
            if (!consent.isChecked) {
                Toast.makeText(this, "Confirma el envío de la prueba a Google", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val key = geminiKeyVault.read()
            if (key == null) {
                state.text = "No se pudo descifrar la clave; bórrala y vuelve a guardarla"
                test.isEnabled = false
                return@setOnClickListener
            }
            test.isEnabled = false
            state.text = "Probando ${com.tunnel.turbo.chat.GeminiFreeApiClient.DEFAULT_FREE_TEST_MODEL}…"
            lifecycleScope.launch {
                val result = runCatching { geminiApiClient.generateShortCheck(key) }
                val outcome = result.getOrNull()
                val error = result.exceptionOrNull()
                coordinator.recordGeminiApiCheck(outcome != null, error?.message ?: "Sin detalle")
                runOnUiThread {
                    state.text = outcome?.let {
                        "Conexión verificada · ${it.model} · ${it.elapsedMs} ms\n${it.text}\nEl plan y la cuota se consultan en AI Studio."
                    } ?: "Prueba fallida · ${error?.message ?: "error de conexión"}"
                    test.isEnabled = consent.isChecked && geminiKeyVault.hasKey()
                    coordinator.refreshBridgesStatus()
                }
            }
        }
    }

    private fun setupDeviceLab() {
        benchmarkStore = com.tunnel.turbo.chat.LocalModelBenchmarkStore(this)
        val modelSpinner = findViewById<Spinner>(R.id.spinnerLabModel)
        val backendSpinner = findViewById<Spinner>(R.id.spinnerLabBackend)
        localModelSpecs = com.tunnel.turbo.chat.LocalModelCatalog.modelsFor(this)
        val modelSpecs = localModelSpecs
        modelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, localModelSpecs.map { it.displayName })
        backendSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("CPU · referencia", "GPU · experimental", "CPU→GPU · comparar secuencial"))
        val roundsSpinner = findViewById<Spinner>(R.id.spinnerLabStressRounds)
        roundsSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("1 medición (+ calentamiento)", "3 mediciones (+ calentamiento)", "5 mediciones (+ calentamiento)"))
        val selectedIndex = modelSpecs.indexOfFirst { it.id == coordinator.selectedLocalModelId }.coerceAtLeast(0)
        modelSpinner.setSelection(selectedIndex)
        findViewById<Button>(R.id.btnLabRunChat).isEnabled = coordinator.localChatEngine.isModelLoaded
        modelSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val spec = localModelSpecs.getOrNull(position) ?: return
                val file = com.tunnel.turbo.chat.LocalModelCatalog.candidateFiles(this@MainActivity, spec).firstOrNull { it.exists() && it.canRead() }
                val label = when {
                    coordinator.localChatEngine.isModelLoaded && coordinator.selectedLocalModelId == spec.id -> "Activo · ${spec.displayName}"
                    file != null -> "Disponible para cargar · ${(file.length() / 1_000_000)} MB"
                    spec.repository == "local-file-unverified" -> "Detectado en Descargas · ${(spec.bytes / 1_000_000)} MB · importa el archivo"
                    spec.gated -> "Requiere aceptar acceso y luego importar · ${(spec.bytes / 1_000_000)} MB"
                    else -> "No importado · ${(spec.bytes / 1_000_000)} MB · selecciona un archivo"
                }
                findViewById<TextView>(R.id.tvLabModelState).text = label
                val role = if (spec.role == com.tunnel.turbo.chat.LocalModelRole.CHAT) "Chat" else "Selección de acciones"
                val sizeMb = (spec.bytes / 1_000_000)
                val calibration = if (spec.sha256 == "UNAVAILABLE" || spec.sha256.isBlank()) "No calibrado en el proyecto" else "Artefacto catalogado · rendimiento en este teléfono aún no medido"
                findViewById<TextView>(R.id.tvModelRoleSummary).text = "$role · aprox. $sizeMb MB · $calibration"
                findViewById<Button>(R.id.btnOpenModelRepository).visibility =
                    if (spec.gated && spec.repository.contains('/')) View.VISIBLE else View.GONE
            }
        }
        findViewById<Button>(R.id.btnImportLocalModel).setOnClickListener {
            modelPickerLauncher.launch(arrayOf("*/*"))
        }
        findViewById<Button>(R.id.btnOpenModelRepository).setOnClickListener {
            val spec = localModelSpecs.getOrNull(modelSpinner.selectedItemPosition) ?: return@setOnClickListener
            if (!spec.gated || !spec.repository.matches(Regex("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))) return@setOnClickListener
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://huggingface.co/${spec.repository}")))
        }
        backendSpinner.setSelection(if (coordinator.preferredBackend == com.tunnel.turbo.chat.ChatBackend.GPU) 1 else 0)

        // --- Semantic Display Map & In-App Inspector Listeners (Phase 13 Alpha) ---
        mapViewSemantic?.onNodeSelectedListener = { node ->
            selectedUiNode = node
            if (node != null) {
                val indexInSnap = (mapViewSemantic?.snapshot?.nodes?.indexOfFirst { it.nodeId == node.nodeId } ?: -1) + 1
                tvInspectorNodeId?.text = "Nodo [#$indexInSnap] id=${node.nodeId} · ${node.className.substringAfterLast('.')}"
                val textStr = if (node.text.isNotBlank()) "Texto: \"${node.text}\"" else "Texto: (vacío)"
                val descStr = if (node.contentDescription.isNotBlank()) "Desc: \"${node.contentDescription}\"" else ""
                val idStr = if (node.resourceId.isNotBlank()) "id: ${node.resourceId}" else ""
                val details = listOf(textStr, descStr, idStr).filter { it.isNotBlank() }.joinToString(" · ")
                val b = node.bounds
                val boundsStr = if (b.size >= 4) "[${b[0]}, ${b[1]}, ${b[2]}, ${b[3]}]" else b.toString()
                tvInspectorNodeDetails?.text = "$details\nBounds: $boundsStr"
                tvInspectorNodeFlags?.text = "Clickable: ${node.clickable} · Checked: ${node.checked} · Editable: ${node.editable} · Enabled: ${node.enabled}"
                btnActOnSelectedNode?.isEnabled = true
                tvActionOutcome?.text = "Listo para actuar sobre el nodo #${node.nodeId}."
                tvActionOutcome?.setTextColor(Color.parseColor("#80D8FF"))
            } else {
                tvInspectorNodeId?.text = "Toca un nodo numerado en el mapa para seleccionarlo."
                tvInspectorNodeDetails?.text = "Texto: - | Id: - | Bounds: -"
                tvInspectorNodeFlags?.text = "Clickable: - | Checkable: - | Editable: -"
                btnActOnSelectedNode?.isEnabled = false
                tvActionOutcome?.text = "Estado: Selecciona un nodo en el visor semántico."
                tvActionOutcome?.setTextColor(Color.parseColor("#80D8FF"))
            }
        }

        btnToggleLabels?.setOnClickListener {
            val map = mapViewSemantic ?: return@setOnClickListener
            map.showLabels = !map.showLabels
            btnToggleLabels?.text = if (map.showLabels) "Etiquetas: ON" else "Etiquetas: OFF"
        }

        val modeButtons = listOf(
            btnModePixels to SemanticDisplayMapView.ViewMode.SCREEN,
            btnModeAccessibility to SemanticDisplayMapView.ViewMode.ACCESSIBILITY,
            btnModeOcr to SemanticDisplayMapView.ViewMode.OCR,
            btnModeCombined to SemanticDisplayMapView.ViewMode.COMBINED
        )
        modeButtons.forEach { (button, mode) ->
            button?.setOnClickListener {
                mapViewSemantic?.viewMode = mode
                modeButtons.forEach { (candidate, candidateMode) ->
                    candidate?.backgroundTintList = android.content.res.ColorStateList.valueOf(
                        if (candidateMode == mode) Color.parseColor("#00E676") else Color.parseColor("#37474F")
                    )
                    candidate?.setTextColor(if (candidateMode == mode) Color.BLACK else Color.WHITE)
                }
                tvViewerModeHint?.text = when (mode) {
                    SemanticDisplayMapView.ViewMode.SCREEN -> "Píxeles capturados del teléfono, sin capas."
                    SemanticDisplayMapView.ViewMode.ACCESSIBILITY -> "Controles y etiquetas expuestos por Android Accessibility."
                    SemanticDisplayMapView.ViewMode.OCR -> "Texto que ML Kit encuentra dentro de la captura."
                    SemanticDisplayMapView.ViewMode.COMBINED -> "Accesibilidad + OCR sobre la captura para comparar cobertura."
                }
            }
        }

        val refreshSnapshotAction: () -> Unit = {
            val perception = findViewById<TextView>(R.id.tvLabPerception)
            tvSnapshotMeta?.text = "Capturando snapshot semántico de Display 0…"
            lifecycleScope.launch(Dispatchers.IO) {
                val status = runCatching { coordinator.accessibilityBridge.getServiceState() }.getOrNull()
                if (status == null || !status.isConnected) {
                    val errMsg = "Percepción NO DISPONIBLE · servicio=${status?.status ?: "desconectado"}. No se interpreta como pantalla vacía."
                    runOnUiThread {
                        perception?.text = errMsg
                        tvSnapshotMeta?.text = errMsg
                        tvSnapshotMeta?.setTextColor(Color.parseColor("#FF5252"))
                        mapViewSemantic?.snapshot = null
                    }
                } else {
                    val started = android.os.SystemClock.elapsedRealtime()
                    val snapshot = coordinator.captureSemanticSnapshot(0)
                    val capturedScreen = coordinator.accessibilityBridge.takeScreenshot(0)
                    val capturedOcr = if (capturedScreen != null) {
                        runCatching { getViewerOcrScanner().scanBitmap(capturedScreen, targetWidth = 1200) }
                            .getOrDefault(emptyList())
                    } else emptyList()
                    val elapsed = android.os.SystemClock.elapsedRealtime() - started
                    val metaSummary = "Display ${snapshot.displayId} (${snapshot.displayWidth}x${snapshot.displayHeight}) · ${snapshot.nodes.size} nodos (${snapshot.actionableCount} accionables) · OCR ${capturedOcr.size} líneas · ${snapshot.windows.size} ventanas · ${elapsed}ms · RTT: ${snapshot.getSnapshotAgeMs()}ms"
                    val perceptionText = buildString {
                        append("Display ${snapshot.displayId} · ${snapshot.foregroundPackage.ifBlank { "paquete desconocido" }}")
                        append("\n${snapshot.nodes.size} nodos · ${snapshot.actionableCount} accionables · ${snapshot.windows.size} ventanas · ${elapsed} ms")
                        append("\nTruncado: ${snapshot.possibleTruncation} · desconocido: ${snapshot.unknownRegions.size} regiones · edad: ${snapshot.getSnapshotAgeMs()} ms")
                        val preview = snapshot.visibleText.replace('\n', ' ').take(180)
                        if (preview.isNotBlank()) append("\nTexto: $preview")
                    }
                    runOnUiThread {
                        val oldFrame = viewerScreenBitmap
                        viewerScreenBitmap = capturedScreen
                        if (oldFrame != null && oldFrame !== capturedScreen && !oldFrame.isRecycled) oldFrame.recycle()
                        mapViewSemantic?.screenBitmap = capturedScreen
                        mapViewSemantic?.ocrElements = capturedOcr
                        tvSnapshotMeta?.text = metaSummary
                        btnModeAccessibility?.isEnabled = true
                        btnModeCombined?.isEnabled = true
                        tvViewerModeHint?.text = "Captura, árbol de accesibilidad y OCR local obtenidos al actualizar; puede haber un pequeño desfase entre fuentes."
                        tvSnapshotMeta?.setTextColor(Color.parseColor("#80CBC4"))
                        perception?.text = perceptionText
                        tvViewerOcrText?.text = if (capturedScreen == null) {
                            "Captura visual no disponible. Revisa el servicio de accesibilidad y vuelve a actualizar."
                        } else if (capturedOcr.isEmpty()) {
                            "OCR: no se encontró texto en esta captura."
                        } else {
                            "OCR (${capturedOcr.size} líneas):\n" + capturedOcr.joinToString("\n") { "• ${it.text}" }.take(2200)
                        }
                        mapViewSemantic?.snapshot = snapshot
                    }
                }
            }
        }

        btnRefreshSnapshot?.setOnClickListener { refreshSnapshotAction() }
        btnImportScreen?.setOnClickListener { screenCapturePickerLauncher.launch(arrayOf("image/*")) }

        btnActOnSelectedNode?.setOnClickListener {
            val node = selectedUiNode
            val snap = mapViewSemantic?.snapshot
            if (node == null || snap == null) {
                tvActionOutcome?.text = "Error: no hay nodo o snapshot seleccionado."
                tvActionOutcome?.setTextColor(Color.parseColor("#FF5252"))
                return@setOnClickListener
            }

            btnActOnSelectedNode?.isEnabled = false
            tvActionOutcome?.text = "Enviando acción a AgentSession y verificando con GoalVerifier..."
            tvActionOutcome?.setTextColor(Color.parseColor("#FFD600"))

            lifecycleScope.launch(Dispatchers.IO) {
                val result = coordinator.actOnSelectedNode(node, snap)
                runOnUiThread {
                    btnActOnSelectedNode?.isEnabled = true
                    val outcomeColor = when (result.outcome) {
                        com.tunnel.turbo.agent.GoalOutcome.COMPLETED_VERIFIED -> Color.parseColor("#00E676")
                        com.tunnel.turbo.agent.GoalOutcome.COMPLETED_UNVERIFIED -> Color.parseColor("#FFB300")
                        com.tunnel.turbo.agent.GoalOutcome.PARTIAL -> Color.parseColor("#FFB300")
                        else -> Color.parseColor("#FF5252")
                    }
                    tvActionOutcome?.setTextColor(outcomeColor)
                    tvActionOutcome?.text = "[${result.outcome.name}] ${result.message} (${String.format("%.0f", result.totalElapsedMs)}ms)"
                    coordinator.currentSemanticSnapshot?.let { freshSnap ->
                        mapViewSemantic?.snapshot = freshSnap
                        tvSnapshotMeta?.text = "Display ${freshSnap.displayId} (${freshSnap.displayWidth}x${freshSnap.displayHeight}) · ${freshSnap.nodes.size} nodos · ${freshSnap.windows.size} ventanas · post-acción"
                    }
                }
            }
        }

        findViewById<Button>(R.id.btnLabLoadModel).setOnClickListener {
            val spec = localModelSpecs.getOrNull(modelSpinner.selectedItemPosition) ?: return@setOnClickListener
            val backend = if (backendSpinner.selectedItemPosition == 1) com.tunnel.turbo.chat.ChatBackend.GPU else com.tunnel.turbo.chat.ChatBackend.CPU
            val state = findViewById<TextView>(R.id.tvLabModelState)
            state.text = "Cargando ${spec.displayName} en $backend…"
            lifecycleScope.launch {
                val started = android.os.SystemClock.elapsedRealtime()
                val loaded = coordinator.selectLocalModel(spec.id, backend)
                val elapsed = android.os.SystemClock.elapsedRealtime() - started
                runOnUiThread {
                    state.text = if (loaded) "Activo · ${spec.displayName} · $backend · carga ${elapsed} ms"
                    else "No se cargó · ${coordinator.uiState.value.statusMessage}. Revisa el archivo o el acceso requerido."
                    findViewById<Button>(R.id.btnLabRunChat).isEnabled = loaded
                    findViewById<TextView>(R.id.tvModelRoleSummary).append(if (loaded) "\nModelo cargado en memoria." else "\nNo está disponible para responder todavía.")
                }
            }
        }

        findViewById<Button>(R.id.btnLabRunChat).setOnClickListener {
            val prompt = findViewById<EditText>(R.id.etLabPrompt).text.toString().trim()
            if (prompt.isEmpty()) {
                Toast.makeText(this, "Escribe una pregunta primero", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val result = findViewById<TextView>(R.id.tvLabResult)
            val runButton = findViewById<Button>(R.id.btnLabRunChat)
            runButton.isEnabled = false
            result.text = "Generando localmente… (sin ejecutar acciones Android)"
            lifecycleScope.launch {
                val started = android.os.SystemClock.elapsedRealtime()
                val loaded = coordinator.ensureModelLoaded()
                val response = if (loaded) {
                    coordinator.conversationRuntime.clearConversation()
                    coordinator.conversationRuntime.activeProfile = com.tunnel.turbo.chat.LocalChatProfile.FAST
                    coordinator.conversationRuntime.submitTurn(prompt, com.tunnel.turbo.chat.LocalChatProfile.FAST)
                } else Result.failure(IllegalStateException("No se pudo cargar el modelo seleccionado"))
                val elapsed = android.os.SystemClock.elapsedRealtime() - started
                val benchmark = coordinator.conversationRuntime.lastBenchmarkInfo
                val metrics = coordinator.conversationRuntime.lastTurnMetrics
                val spec = localModelSpecs.getOrNull(modelSpinner.selectedItemPosition)
                val output = response.getOrNull() ?: "ERROR: ${response.exceptionOrNull()?.message}"
                runOnUiThread {
                    result.text = "${spec?.displayName ?: "Modelo"} · ${backendSpinner.selectedItem} · perfil FAST (64 tokens)\nTiempo total: ${elapsed} ms · TTFT: ${benchmark?.timeToFirstTokenInSecond?.times(1000)?.toLong() ?: metrics?.ttftMs?.toLong() ?: -1} ms · decode tok/s: ${benchmark?.lastDecodeTokensPerSecond ?: "UNAVAILABLE"}\n\n$output"
                    runButton.isEnabled = loaded
                }
            }
        }

        val stressButton = findViewById<Button>(R.id.btnLabStressRun)
        val monitor = findViewById<TextView>(R.id.tvLabResourceMonitor)
        val saveButton = findViewById<Button>(R.id.btnLabSaveRun)
        stressButton.setOnClickListener {
            val spec = localModelSpecs.getOrNull(modelSpinner.selectedItemPosition)
            if (spec == null) {
                Toast.makeText(this, "Selecciona e importa un modelo primero", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val prompt = findViewById<EditText>(R.id.etLabPrompt).text.toString().trim().ifBlank { "Explica en una frase para qué sirve un asistente local." }
            val measuredRounds = listOf(1, 3, 5).getOrElse(roundsSpinner.selectedItemPosition) { 3 }
            val backends = when (backendSpinner.selectedItemPosition) {
                1 -> listOf(com.tunnel.turbo.chat.ChatBackend.GPU)
                2 -> listOf(com.tunnel.turbo.chat.ChatBackend.CPU, com.tunnel.turbo.chat.ChatBackend.GPU)
                else -> listOf(com.tunnel.turbo.chat.ChatBackend.CPU)
            }
            stressButton.isEnabled = false
            saveButton.isEnabled = false
            pendingBenchmarkRun = null
            lifecycleScope.launch {
                val samples = mutableListOf<com.tunnel.turbo.chat.LocalBenchmarkSample>()
                var stopReason: String? = null
                try {
                    for (backend in backends) {
                        monitor.text = "Cargando ${spec.displayName} en $backend… La carga se medirá aparte."
                        val loadStart = android.os.SystemClock.elapsedRealtime()
                        val loaded = coordinator.selectLocalModel(spec.id, backend)
                        val loadMs = android.os.SystemClock.elapsedRealtime() - loadStart
                        if (!loaded) {
                            samples += failedBenchmarkSample(spec.id, backend.name, loadMs, coordinator.uiState.value.statusMessage)
                            continue
                        }
                        // One warm-up is intentionally excluded from measured iterations.
                        coordinator.conversationRuntime.clearConversation()
                        coordinator.conversationRuntime.activeProfile = com.tunnel.turbo.chat.LocalChatProfile.FAST
                        val warmup = coordinator.conversationRuntime.submitTurn(prompt, com.tunnel.turbo.chat.LocalChatProfile.FAST)
                        if (warmup.isFailure) {
                            samples += failedBenchmarkSample(spec.id, backend.name, loadMs, warmup.exceptionOrNull()?.message ?: "Falló calentamiento")
                            continue
                        }
                        for (index in 0 until measuredRounds) {
                            val before = readLabResources()
                            monitor.text = "Prueba ${index + 1}/$measuredRounds · $backend · PSS ${before.pssKb / 1024} MB · térmico ${before.thermalLabel} · batería ${before.batteryPercent?.let { "$it%" } ?: "no disponible"} · uso GPU no disponible"
                            coordinator.conversationRuntime.clearConversation()
                            val started = android.os.SystemClock.elapsedRealtime()
                            val generated = coordinator.conversationRuntime.submitTurn(prompt, com.tunnel.turbo.chat.LocalChatProfile.FAST)
                            val total = android.os.SystemClock.elapsedRealtime() - started
                            val after = readLabResources()
                            val info = coordinator.conversationRuntime.lastBenchmarkInfo
                            val metrics = coordinator.conversationRuntime.lastTurnMetrics
                            val sample = com.tunnel.turbo.chat.LocalBenchmarkSample(
                                modelId = spec.id, backend = backend.name, totalMs = total, loadMs = loadMs,
                                ttftMs = info?.timeToFirstTokenInSecond?.times(1000)?.toLong() ?: metrics?.ttftMs?.toLong(),
                                decodeTokensPerSecond = info?.lastDecodeTokensPerSecond ?: metrics?.decodeTokensPerSecond,
                                pssKb = after.pssKb, nativeHeapKb = after.nativeHeapKb, thermalStatus = after.thermalStatus,
                                batteryPercent = after.batteryPercent, batteryTemperatureC = after.batteryTemperatureC,
                                success = generated.isSuccess, error = generated.exceptionOrNull()?.message
                            )
                            samples += sample
                            monitor.text = "$backend · ${index + 1}/$measuredRounds · ${if (sample.success) "OK" else "ERROR"} · ${total} ms · TTFT ${sample.ttftMs?.let { "$it ms" } ?: "no disponible"} · decode ${sample.decodeTokensPerSecond?.let { String.format("%.2f tok/s", it) } ?: "no disponible"}\nPSS ${after.pssKb / 1024} MB · heap nativo ${after.nativeHeapKb / 1024} MB · térmico ${after.thermalLabel} · batería ${after.batteryPercent?.let { "$it%" } ?: "no disponible"} (${after.batteryTemperatureC?.let { String.format("%.1f°C", it) } ?: "temp no disponible"}) · GPU uso: no disponible"
                            if (after.thermalStatus != null && after.thermalStatus >= android.os.PowerManager.THERMAL_STATUS_SEVERE) {
                                stopReason = "Parada segura: Android reporta estado térmico severo."
                                break
                            }
                            if (after.pssKb > 5_000_000L) {
                                stopReason = "Parada segura: PSS del proceso superó 5 GB."
                                break
                            }
                        }
                        if (stopReason != null) break
                    }
                    val run = com.tunnel.turbo.chat.LocalBenchmarkRun(java.util.UUID.randomUUID().toString(), System.currentTimeMillis(), samples)
                    pendingBenchmarkRun = run
                    saveButton.isEnabled = samples.isNotEmpty()
                    val summaryRows = com.tunnel.turbo.chat.LocalBenchmarkStatistics.summarize(samples)
                    val summary = summaryRows.joinToString("\n") { row ->
                        "${row.backend}: ${row.successfulRuns}/${row.totalRuns} OK · mediana ${row.medianTotalMs?.let { "$it ms" } ?: "no disponible"} · decode ${row.medianDecodeTokensPerSecond?.let { String.format("%.2f tok/s", it) } ?: "no disponible"}"
                    }
                    val older = benchmarkStore.history().lastOrNull()
                    val previousRows = older?.optJSONArray("samples")
                    val comparison = if (previousRows == null) "\nSin corrida anterior guardada para comparar." else summaryRows.joinToString("\n") { current ->
                        val oldValues = (0 until previousRows.length()).mapNotNull { previousRows.optJSONObject(it) }
                            .filter { it.optString("backend") == current.backend && it.optBoolean("success") }
                            .map { it.optLong("totalMs") }
                        val oldMedian = com.tunnel.turbo.chat.LocalBenchmarkStatistics.median(oldValues)
                        val change = if (oldMedian != null && current.medianTotalMs != null && oldMedian > 0) {
                            val pct = (current.medianTotalMs - oldMedian) * 100.0 / oldMedian
                            "${if (pct <= 0) "${String.format("%.1f", -pct)}% más rápido" else "${String.format("%.1f", pct)}% más lento"}"
                        } else "sin base comparable"
                        "Comparación ${current.backend}: ahora ${current.medianTotalMs?.let { "$it ms" } ?: "N/D"} vs anterior ${oldMedian?.let { "$it ms" } ?: "N/D"} · $change"
                    }
                    monitor.text = "${stopReason?.plus("\n") ?: ""}Prueba lista · ${spec.displayName}\n$summary$comparison\nConsumo: PSS/memoria nativa, batería y temperatura de batería; uso de GPU y energía exacta: no disponible vía API estándar.\nCorridas guardadas: ${benchmarkStore.history().size}. Pulsa Guardar para conservar esta corrida."
                } finally {
                    stressButton.isEnabled = true
                }
            }
        }
        saveButton.setOnClickListener {
            val run = pendingBenchmarkRun ?: return@setOnClickListener
            runCatching { benchmarkStore.save(run) }
                .onSuccess { file ->
                    monitor.append("\nGuardado en almacenamiento privado · ${file.name} · ${benchmarkStore.history().size} corridas guardadas.")
                    saveButton.isEnabled = false
                }
                .onFailure { monitor.append("\nNo se pudo guardar: ${it.message}") }
        }
    }

    private data class LabResourceSnapshot(val pssKb: Long, val nativeHeapKb: Long, val thermalStatus: Int?, val thermalLabel: String, val batteryPercent: Int?, val batteryTemperatureC: Double?)

    private fun readLabResources(): LabResourceSnapshot {
        val memory = android.os.Debug.MemoryInfo()
        android.os.Debug.getMemoryInfo(memory)
        val power = getSystemService(POWER_SERVICE) as? android.os.PowerManager
        val thermal = if (android.os.Build.VERSION.SDK_INT >= 29) power?.currentThermalStatus else null
        val thermalLabel = when (thermal) {
            android.os.PowerManager.THERMAL_STATUS_NONE -> "normal"
            android.os.PowerManager.THERMAL_STATUS_LIGHT -> "ligero"
            android.os.PowerManager.THERMAL_STATUS_MODERATE -> "moderado"
            android.os.PowerManager.THERMAL_STATUS_SEVERE -> "severo"
            android.os.PowerManager.THERMAL_STATUS_CRITICAL -> "crítico"
            android.os.PowerManager.THERMAL_STATUS_EMERGENCY -> "emergencia"
            android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "apagado"
            else -> "no disponible"
        }
        val battery = registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else null
        val tempTenths = battery?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        return LabResourceSnapshot(memory.totalPss.toLong(), android.os.Debug.getNativeHeapAllocatedSize() / 1024L, thermal, thermalLabel, percent, if (tempTenths >= 0) tempTenths / 10.0 else null)
    }

    private fun failedBenchmarkSample(modelId: String, backend: String, loadMs: Long, error: String) = com.tunnel.turbo.chat.LocalBenchmarkSample(modelId, backend, 0L, loadMs, null, null, readLabResources().pssKb, android.os.Debug.getNativeHeapAllocatedSize() / 1024L, null, null, null, false, error)

    private fun importSelectedModel(uri: android.net.Uri) {
        val state = findViewById<TextView>(R.id.tvLabModelState)
        val importButton = findViewById<Button>(R.id.btnImportLocalModel)
        lifecycleScope.launch {
            importButton.isEnabled = false
            state.text = "Leyendo archivo elegido…"
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                        ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
                        ?: uri.lastPathSegment?.substringAfterLast('/')
                        ?: error("No pude leer el nombre del archivo")
                    require(name.endsWith(".litertlm", ignoreCase = true)) { "Elige un archivo .litertlm" }
                    val modelDirectory = File(filesDir, "models").apply { check(mkdirs() || isDirectory) }
                    val destination = File(modelDirectory, name)
                    val temporary = File(modelDirectory, "$name.partial")
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(temporary).use { output ->
                            val buffer = ByteArray(1024 * 1024)
                            var copied = 0L
                            var lastReported = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                copied += count
                                if (copied - lastReported >= 128L * 1024 * 1024) {
                                    lastReported = copied
                                    withContext(Dispatchers.Main) {
                                        state.text = "Importando $name · ${copied / 1_000_000} MB copiados…"
                                    }
                                }
                            }
                            output.fd.sync()
                            check(copied > 0L) { "El archivo está vacío" }
                        }
                    } ?: error("Android no pudo abrir el archivo seleccionado")
                    if (destination.exists()) destination.delete()
                    check(temporary.renameTo(destination)) { "No se pudo completar la copia interna" }
                    name to destination.length()
                }.onFailure { File(filesDir, "models").listFiles()?.filter { it.name.endsWith(".partial") }?.forEach { it.delete() } }
            }
            importButton.isEnabled = true
            result.onSuccess { (name, bytes) ->
                localModelSpecs = com.tunnel.turbo.chat.LocalModelCatalog.modelsFor(this@MainActivity)
                val spinner = findViewById<Spinner>(R.id.spinnerLabModel)
                spinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, localModelSpecs.map { it.displayName })
                val selected = localModelSpecs.indexOfFirst { it.fileName == name }
                if (selected >= 0) spinner.setSelection(selected)
                state.text = "Importado en almacenamiento privado · ${bytes / 1_000_000} MB · listo para cargar por CPU o GPU"
            }.onFailure { state.text = "No se pudo importar: ${it.message ?: "error de archivo"}" }
        }
    }

    private fun selectTab(tab: com.tunnel.turbo.coordinator.NavigationTab) {
        coordinator.selectNavigationTab(tab)
    }

    private fun showConversationMemoryDialog() {
        val memory = coordinator.conversationMemory()
        val instructionInput = EditText(this).apply {
            hint = "Ej.: respóndeme en español, directo y con pasos claros"
            setText(memory.masterInstruction)
            minLines = 3
            maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val factsInput = EditText(this).apply {
            hint = "Un dato por línea. También puedes decir: Recuerda que…"
            setText(memory.rememberedFacts.joinToString("\n"))
            minLines = 4
            maxLines = 8
            gravity = Gravity.TOP or Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(TextView(this@MainActivity).apply {
                text = "Instrucción para este chat"
                textSize = 14f
                setTextColor(Color.WHITE)
            })
            addView(instructionInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
            addView(TextView(this@MainActivity).apply {
                text = "Recuerdos explícitos"
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(0, dp(16), 0, 0)
            })
            addView(factsInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
            addView(TextView(this@MainActivity).apply {
                text = "Se guarda solo en este teléfono. El chat local recibe estas instrucciones al iniciar una sesión nueva; las búsquedas web automáticas envían a Google solo el mensaje actual."
                textSize = 12f
                setTextColor(Color.LTGRAY)
                setPadding(0, dp(12), 0, dp(4))
            })
        }
        val scroll = ScrollView(this).apply { addView(content) }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Memoria e instrucciones")
            .setView(scroll)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Guardar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val facts = factsInput.text.toString().lineSequence().map { it.trim().removePrefix("- ") }.filter(String::isNotBlank).toList()
                val updated = com.tunnel.turbo.chat.ConversationMemory(
                    masterInstruction = instructionInput.text.toString().trim(),
                    rememberedFacts = facts
                )
                lifecycleScope.launch {
                    if (coordinator.saveConversationMemory(updated)) {
                        dialog.dismiss()
                        Toast.makeText(this@MainActivity, "Memoria local guardada", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, "Espera a que termine la respuesta para editar la memoria", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun observeUiState() {
        lifecycleScope.launch {
            coordinator.uiState.collect { state ->
                if (!state.isBusy && state.conversation != lastPersistedConversation) {
                    lastPersistedConversation = state.conversation
                    withContext(Dispatchers.IO) { runCatching { conversationHistoryStore.save(state.conversation) } }
                }
                runOnUiThread {
                    renderUiState(state)
                }
                if (state.isBusy) pollAgentProgressWhileBusy()
            }
        }
    }

    private fun pollAgentProgressWhileBusy() {
        if (progressPollActive) return
        progressPollActive = true
        lifecycleScope.launch {
            try {
                while (coordinator.uiState.value.isBusy) {
                    renderProgress(coordinator.uiState.value)
                    kotlinx.coroutines.delay(500)
                }
                renderProgress(coordinator.uiState.value)
            } finally {
                progressPollActive = false
            }
        }
    }

    private fun renderProgress(state: com.tunnel.turbo.coordinator.AppUiState) {
        if (!state.isBusy) lastProgressKey = ""
        val runtime = coordinator.providerRuntime.coreAdapter.nativeCore.agentRuntime
        val streamingChat = state.conversation.lastOrNull { it.role == MessageRole.ASSISTANT }?.turnStatus ==
            com.tunnel.turbo.coordinator.TurnStatus.GENERATING
        val events = if (streamingChat) emptyList() else runtime.activeSession?.snapshotEvents().orEmpty()
        val items = AgentProgressPresenter.present(events, coordinator.providerRuntime.coreAdapter.nativeCore.capabilityRegistry)
        val latestActivity = items.lastOrNull()?.label
        val statusWord = com.tunnel.turbo.coordinator.ProgressStatusPresenter.present(state.isBusy, state.statusMessage, latestActivity)
        val elapsedSeconds = busyStartedAtMs?.let { ((System.currentTimeMillis() - it).coerceAtLeast(0) / 1000L) } ?: 0L
        val statusWithElapsed = if (state.isBusy) "$statusWord desde hace ${elapsedSeconds}s" else statusWord
        streamingStatusViews.values.forEach { it.text = statusWithElapsed }
        agentProgressPanel.visibility = if (state.isBusy && items.isNotEmpty() && !streamingChat) View.VISIBLE else View.GONE
        val progressKey = "$statusWord|${items.joinToString { it.label + it.detail }}"
        if (state.isBusy && progressKey != lastProgressKey) {
            llProgressDetails.removeAllViews()
            if (items.isNotEmpty()) items.forEach { item ->
                addProgressLine(if (item.detail.isBlank()) item.label else "${item.label} · ${item.detail}")
            }
            lastProgressKey = progressKey
        }
        val latestLabel = items.lastOrNull()?.label?.substringBefore(" ·")?.ifBlank { "Procesando" } ?: statusWord
        btnProgressDisclosure.text = "$latestLabel ${if (llProgressDetails.visibility == View.VISIBLE) "▴" else "▾"}"
        btnProgressDisclosure.contentDescription = "$latestLabel. Toca para ${if (llProgressDetails.visibility == View.VISIBLE) "ocultar" else "ver"} el detalle del progreso."
        if (state.activeTab == com.tunnel.turbo.coordinator.NavigationTab.ACTIVITY) renderActivity(state, items)
    }

    private fun addProgressLine(text: String) = addProgressLineTo(llProgressDetails, text)

    private fun renderActivity(state: com.tunnel.turbo.coordinator.AppUiState, items: List<AgentProgressItem> = emptyList()) {
        val current = state.conversation.lastOrNull { it.role == MessageRole.USER }
        findViewById<TextView>(R.id.tvActivityCurrent).text = when {
            state.isBusy -> current?.text ?: "Tarea en curso"
            current != null -> if (state.statusMessage.contains("Atención", true)) "Requiere atención" else "Última tarea"
            else -> "No hay tareas en curso"
        }
        findViewById<TextView>(R.id.tvActivityCurrentDetail).text = if (state.isBusy) "${state.statusMessage}\n${items.lastOrNull()?.label.orEmpty()}" else state.statusMessage
        llActivityProgress.removeAllViews()
        items.forEach { item -> addProgressLineTo(llActivityProgress, "${item.label} · ${item.detail}") }
        llActivityHistory.removeAllViews()
        state.conversation.filter { it.role == MessageRole.ASSISTANT && (it.route != null || it.turnStatus != null) }.takeLast(8).reversed().forEach { msg ->
            val result = TextView(this).apply {
                text = buildString {
                    append(msg.text.take(180))
                    val route = msg.route?.let { when (it) { com.tunnel.turbo.coordinator.Route.LOCAL_CHAT -> "Chat local"; com.tunnel.turbo.coordinator.Route.CLOUD_API -> "Gemini"; com.tunnel.turbo.coordinator.Route.ANDROID_AGENT -> "Agente"; com.tunnel.turbo.coordinator.Route.ANDROID_DIRECT -> "Android"; com.tunnel.turbo.coordinator.Route.RESEARCH -> "Investigación"; com.tunnel.turbo.coordinator.Route.WORK -> "Trabajo"; else -> "" } }
                    if (!route.isNullOrBlank()) append("\n$route")
                    msg.turnStatus?.let { append(" · ${it.name.lowercase().replace('_', ' ')}") }
                }
                textSize = 14f
                setTextColor(Color.parseColor("#D4D4D4"))
                setPadding(dp(12), dp(12), dp(12), dp(12))
                setOnClickListener { coordinator.selectNavigationTab(com.tunnel.turbo.coordinator.NavigationTab.CONVERSATION) }
            }
            llActivityHistory.addView(result)
        }
    }

    private fun addProgressLineTo(parent: LinearLayout, text: String) {
        TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.parseColor("#B8B8B8"))
            setPadding(0, dp(6), 0, dp(6))
            parent.addView(this)
        }
    }

    private var renderedConversation: List<ConversationMessage>? = null

    private fun renderUiState(state: com.tunnel.turbo.coordinator.AppUiState) {
        if (state.isBusy) {
            if (busyStartedAtMs == null) busyStartedAtMs = System.currentTimeMillis()
        } else {
            busyStartedAtMs = null
        }
        val tab = state.activeTab
        if (tab != lastRenderedTab) {
            layoutAppMode.visibility = if (tab == com.tunnel.turbo.coordinator.NavigationTab.CONVERSATION) View.VISIBLE else View.GONE
            layoutDeviceMode.visibility = if (tab == com.tunnel.turbo.coordinator.NavigationTab.DEVICE) View.VISIBLE else View.GONE
            layoutDebugMode.visibility = if (tab == com.tunnel.turbo.coordinator.NavigationTab.SETTINGS_LAB) View.VISIBLE else View.GONE
            findViewById<View>(R.id.layoutActivity).visibility = if (tab == com.tunnel.turbo.coordinator.NavigationTab.ACTIVITY) View.VISIBLE else View.GONE
            findViewById<View>(R.id.layoutSettingsHome).visibility = if (tab == com.tunnel.turbo.coordinator.NavigationTab.SETTINGS) View.VISIBLE else View.GONE
            findViewById<View>(R.id.layoutModelCenter).visibility = if (tab == com.tunnel.turbo.coordinator.NavigationTab.MODEL_CENTER) View.VISIBLE else View.GONE
            findViewById<View>(R.id.layoutConnections).visibility = if (tab == com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS) View.VISIBLE else View.GONE
            btnToggleMode.text = "☰"
            btnToggleMode.contentDescription = "Abrir navegación"
            findViewById<View>(R.id.bottomNavigation).visibility = View.GONE
            lastRenderedTab = tab
        }
        tvHeaderStatus.visibility = if (state.isBusy) View.GONE else View.VISIBLE
        tvHeaderStatus.text = when {
            state.statusMessage.contains("Atención", true) -> "Necesita atención"
            state.statusMessage.contains("error", true) || state.statusMessage.contains("falló", true) -> "No se completó"
            else -> "Listo"
        }
        updateComposerModelLabel()
        btnAppSend.isEnabled = !state.isBusy && !isRegenerating
        tvHeaderStatus.setTextColor(if (state.isBusy) Color.parseColor("#D4D4D4") else Color.parseColor("#A3A3A3"))
        renderProgress(state)
        when (com.tunnel.turbo.coordinator.ConversationRenderPolicy.decide(renderedConversation, state.conversation)) {
            com.tunnel.turbo.coordinator.ConversationRenderUpdate.REBUILD -> {
                renderConversation(state.conversation)
                renderedConversation = state.conversation.toList()
            }
            com.tunnel.turbo.coordinator.ConversationRenderUpdate.STREAMING_TEXT -> {
                state.conversation.lastOrNull()?.let(::updateStreamingMessageText)
                renderedConversation = state.conversation.toList()
            }
            com.tunnel.turbo.coordinator.ConversationRenderUpdate.NONE -> Unit
        }

        // Hidden diagnostic panels do not need per-fragment updates while chat streams.
        if (tab == com.tunnel.turbo.coordinator.NavigationTab.DEVICE ||
            tab == com.tunnel.turbo.coordinator.NavigationTab.SETTINGS_LAB
        ) {
        tvShizukuStatus.text = state.debugState.shizukuStatusText
        tvAccessibilityStatus.text = state.debugState.accessibilityStatusText
        tvProviderStatus.text = state.debugState.providerStatusText
        tvCoreStatus.text = "Core: ${state.debugState.coreBackend} | Rev: ${state.debugState.stateEngineRevision} | Eventos: ${state.debugState.journalEventCount}"
        tvExecutionStatus.text = "ESTADO: ${if (state.isBusy) "EJECUTANDO..." else state.debugState.lastVerification}"
        tvExecutionStatus.setTextColor(
            if (state.isBusy) Color.parseColor("#00B0FF")
            else if (state.debugState.lastVerification == "SUCCESS") Color.parseColor("#00E676")
            else Color.parseColor("#FF5252")
        )

        findViewById<TextView>(R.id.tvDeviceShizukuStatus).text = state.debugState.shizukuStatusText
        findViewById<TextView>(R.id.tvDeviceAccessibilityStatus).text = state.debugState.accessibilityStatusText
        findViewById<TextView>(R.id.tvDeviceModelStatus).text = "Modelo local · ${state.debugState.localEngine.displayName ?: "sin seleccionar"} · ${state.debugState.localEngine.status}"
        findViewById<TextView>(R.id.tvDeviceCloudStatus).text = "API cloud · ${state.debugState.cloudProvider.displayName} · ${state.debugState.cloudProvider.status}"

        // Section 43: Agent, World, Skills, Budget Rendering
        val agentRuntime = coordinator.providerRuntime.coreAdapter.nativeCore.agentRuntime
        val lastRes = agentRuntime.runtimeState.value.lastResult
        val skills = agentRuntime.skillMemory.getAllSkills()
        val proposed = skills.count { it.state == com.tunnel.turbo.agent.SkillState.PROPOSED }
        val validating = skills.count { it.state == com.tunnel.turbo.agent.SkillState.VALIDATING }
        val active = skills.count { it.state == com.tunnel.turbo.agent.SkillState.ACTIVE }
        val deprecated = skills.count { it.state == com.tunnel.turbo.agent.SkillState.DEPRECATED }

        val budget = lastRes?.budget ?: com.tunnel.turbo.agent.AgentBudget()
        val stepsUsed = budget.stepsUsed
        val aiRounds = budget.aiRoundsUsed
        val obsUsed = budget.observationsSent

        val lastTrace = com.tunnel.turbo.agent.ProviderCallRepository.getLastTrace()
        val lastVer = com.tunnel.turbo.agent.GoalVerifier.lastVerification

        tvAgentGoal?.text = "REASONING: provider=${lastTrace?.provider ?: "no configurado"} | callId=${lastTrace?.providerCallId ?: "NONE"} | AI rounds REAL=$aiRounds | injected=${lastTrace?.promptInjected ?: false} | resp=${lastTrace?.responseDetected ?: false} | proofMatch=${lastTrace?.error == null && lastTrace?.responseDetected == true} | src=${lastRes?.decisionSource?.name ?: "LOCAL_HEURISTIC"}"
        tvAgentWorld?.text = "GOAL VERIFICATION: desired=${lastRes?.goal?.desiredState ?: "NONE"} | outcome=${lastRes?.outcome?.name ?: "NONE"} | satisfied=${lastVer?.satisfied ?: false} | conf=${String.format("%.2f", lastVer?.confidence ?: 0.0)} | music=${lastRes?.goalEvidence?.isMusicActive ?: false} | bt=${lastRes?.goalEvidence?.isBluetoothEnabled ?: "N/A"}"
        tvAgentSkills?.text = "SKILLS: proposed=$proposed | validating=$validating | active=$active | deprecated=$deprecated"
        tvAgentBudget?.text = "BUDGET: steps=$stepsUsed/${budget.maxSteps} | aiRounds=$aiRounds/${budget.maxAiRounds} | obs=$obsUsed/${budget.maxObservationsSentToAi} | elapsed=${String.format("%.0f", lastRes?.totalElapsedMs ?: 0.0)}ms"

        tvDebugLogOutput.text = state.debugState.logOutput
        }
    }

    private fun renderConversation(messages: List<ConversationMessage>) {
        llChatMessages.removeAllViews()
        streamingStatusViews.clear()
        messageTextViews.clear()
        val state = coordinator.uiState.value
        val hasStreamingAssistant = messages.lastOrNull { it.role == MessageRole.ASSISTANT }?.turnStatus ==
            com.tunnel.turbo.coordinator.TurnStatus.GENERATING
        val activeUserId = if (state.isBusy && !hasStreamingAssistant) {
            messages.lastOrNull { it.role == MessageRole.USER }?.id
        } else null
        for (msg in messages) {
            val isUser = msg.role == MessageRole.USER
            val messageGroup = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(0, dp(8), 0, dp(8))
                }
            }
            val bubble = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val lp = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = if (isUser) Gravity.END else Gravity.START
                }
                layoutParams = lp
                setBackgroundResource(if (isUser) R.drawable.bg_user_bubble else R.drawable.bg_assistant_bubble)
                setPadding(dp(14), dp(10), dp(14), dp(10))
            }
            messageGroup.addView(bubble)

            if (!isUser && msg.turnStatus == com.tunnel.turbo.coordinator.TurnStatus.GENERATING) {
                addStreamingStatus(bubble, msg.id)
                bubble.addView(View(this).apply {
                    setBackgroundColor(Color.parseColor("#303036"))
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                    bottomMargin = dp(8)
                })
            }

            val tvText = TextView(this).apply {
                text = if (isUser || msg.turnStatus == com.tunnel.turbo.coordinator.TurnStatus.GENERATING) {
                    msg.text
                } else {
                    com.tunnel.turbo.chat.ChatMarkdown.render(msg.text)
                }
                textSize = 14f
                setLineSpacing(dp(2).toFloat(), 1f)
                breakStrategy = android.text.Layout.BREAK_STRATEGY_HIGH_QUALITY
                hyphenationFrequency = android.text.Layout.HYPHENATION_FREQUENCY_NORMAL
                val windowWidthPx = (resources.configuration.screenWidthDp * resources.displayMetrics.density).toInt()
                maxWidth = (windowWidthPx - dp(16)).coerceAtMost(dp(760)).coerceAtLeast(dp(220))
                setTextColor(getColor(R.color.chat_primary_text))
                setTextIsSelectable(true)
            }
            bubble.addView(tvText)
            messageTextViews[msg.id] = tvText
            if (!isUser && msg.turnStatus != null && msg.turnStatus != com.tunnel.turbo.coordinator.TurnStatus.GENERATING) {
                msg.latencyMs?.let { latency ->
                    val timing = TextView(this).apply {
                        text = "Respondió en ${formatResponseDuration(latency)}"
                        textSize = 11f
                        setTextColor(getColor(R.color.chat_secondary_text))
                        setPadding(0, dp(5), 0, dp(2))
                    }
                    bubble.addView(timing)
                }
            }
            if (!isUser && msg.turnStatus != null && msg.turnStatus != com.tunnel.turbo.coordinator.TurnStatus.GENERATING) {
                addAssistantActions(messageGroup, msg)
            }
            if (isUser) {
                val actions = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.END or Gravity.CENTER_VERTICAL
                    setPadding(0, dp(2), 0, 0)
                }
                actions.addView(messageIconButton(R.drawable.ic_content_copy_rounded, "Copiar mensaje") {
                    copyMessage(msg.text, "Mensaje del usuario", "Mensaje copiado")
                })
                actions.addView(messageIconButton(R.drawable.ic_edit_rounded, "Editar y reenviar este mensaje", enabled = !coordinator.uiState.value.isBusy) {
                    showEditPromptDialog(msg)
                })
                messageGroup.addView(actions)
            }
            if (msg.id == activeUserId) addStreamingStatus(messageGroup, "user-${msg.id}", withDivider = true)
            bubble.setOnLongClickListener {
                if (isUser) showUserMessageMenu(bubble, msg) else showMessageOverflow(bubble, msg)
                true
            }
            llChatMessages.addView(messageGroup)
        }

        scrollChat.post {
            scrollChat.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun updateStreamingMessageText(message: ConversationMessage) {
        val textView = messageTextViews[message.id] ?: return
        val content = scrollChat.getChildAt(0)
        val wasAtBottom = content == null ||
            scrollChat.scrollY + scrollChat.height >= content.height - dp(48)
        textView.text = message.text
        if (wasAtBottom && coordinator.uiState.value.activeTab == com.tunnel.turbo.coordinator.NavigationTab.CONVERSATION) {
            scrollChat.post { scrollChat.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun addStreamingStatus(parent: LinearLayout, key: String, withDivider: Boolean = false) {
        val elapsedSeconds = busyStartedAtMs?.let { ((System.currentTimeMillis() - it).coerceAtLeast(0) / 1000L) } ?: 0L
        val statusWord = com.tunnel.turbo.coordinator.ProgressStatusPresenter.present(true, coordinator.uiState.value.statusMessage)
        val status = TextView(this).apply {
            text = "$statusWord desde hace ${elapsedSeconds}s"
            textSize = 12f
            setTextColor(getColor(R.color.chat_secondary_text))
            setPadding(0, dp(2), 0, dp(8))
        }
        streamingStatusViews[key] = status
        parent.addView(status)
        if (withDivider) {
            parent.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#303036"))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                bottomMargin = dp(8)
            })
        }
    }

    private fun formatResponseDuration(milliseconds: Double): String = when {
        milliseconds < 1000 -> "${milliseconds.toLong()} ms"
        milliseconds < 60_000 -> String.format(java.util.Locale.getDefault(), "%.1f s", milliseconds / 1000.0)
        else -> String.format(java.util.Locale.getDefault(), "%d min %02d s", (milliseconds / 60_000).toInt(), ((milliseconds % 60_000) / 1000).toInt())
    }

    private fun addAssistantActions(parent: LinearLayout, message: ConversationMessage) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, 0)
        }
        fun action(description: String, iconRes: Int, selected: Boolean = false, onClick: () -> Unit) {
            row.addView(messageIconButton(iconRes, description, selected, onClick = onClick))
        }
        action("Copiar respuesta", R.drawable.ic_content_copy_rounded) { copyMessage(message.text) }
        action("Respuesta útil", R.drawable.ic_thumb_up_rounded, message.feedback == com.tunnel.turbo.coordinator.MessageFeedback.POSITIVE) {
            coordinator.setMessageFeedback(message.id, com.tunnel.turbo.coordinator.MessageFeedback.POSITIVE)
        }
        action("Respuesta no útil", R.drawable.ic_thumb_down_rounded, message.feedback == com.tunnel.turbo.coordinator.MessageFeedback.NEGATIVE) {
            coordinator.setMessageFeedback(message.id, com.tunnel.turbo.coordinator.MessageFeedback.NEGATIVE)
        }
        action("Escuchar respuesta", R.drawable.ic_volume_up_rounded) {
            speakMessage(message)
        }
        action("Más opciones", R.drawable.ic_more_vert_rounded) { showMessageOverflow(itOrParent = row, message = message) }
        parent.addView(row)
    }

    private fun messageIconButton(
        iconRes: Int,
        description: String,
        selected: Boolean = false,
        enabled: Boolean = true,
        onClick: () -> Unit
    ): android.widget.ImageButton = android.widget.ImageButton(this).apply {
        setImageResource(iconRes)
        imageTintList = android.content.res.ColorStateList.valueOf(getColor(if (selected) R.color.chat_accent else R.color.chat_secondary_text))
        background = getDrawable(android.R.drawable.list_selector_background)
        scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
        setPadding(0, 0, 0, 0)
        contentDescription = description
        minimumWidth = dp(48)
        minimumHeight = dp(48)
        isEnabled = enabled
        setOnClickListener { onClick() }
    }

    private fun copyMessage(
        text: String,
        clipLabel: String = "Respuesta de Tunnel Turbo",
        confirmation: String = "Respuesta copiada"
    ) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(clipLabel, text))
        Toast.makeText(this, confirmation, Toast.LENGTH_SHORT).show()
    }

    private fun updateProviderTitle() {
        val title = findViewById<TextView>(R.id.tvAppTitle)
        title.text = "Tunnel Turbo"
        title.contentDescription = "Tunnel Turbo"
    }

    private fun isGeminiReady(): Boolean =
        geminiKeyVault.hasKey() &&
            coordinator.uiState.value.debugState.cloudProvider.status == com.tunnel.turbo.coordinator.CloudProviderStatus.READY_CHECKED

    private fun updateComposerModelLabel() {
        if (!::btnComposerModel.isInitialized) return
        val geminiSelected = findViewById<CheckBox>(R.id.cbUseGemini).isChecked
        val labelKey = "$geminiSelected|${coordinator.selectedLocalModelId}|${coordinator.uiState.value.debugState.cloudProvider.status}"
        if (labelKey == lastComposerModelLabelKey) return
        lastComposerModelLabelKey = labelKey
        val label = if (geminiSelected) {
            if (isGeminiReady()) "Gemini API · listo ▾" else "Gemini · revisar conexión ▾"
        } else {
            val spec = com.tunnel.turbo.chat.LocalModelCatalog.availableForChat(this)
                .firstOrNull { it.id == coordinator.selectedLocalModelId }
            val shortName = spec?.displayName?.substringBefore(" (")?.substringBefore(" ·")
            if (shortName == null) "Configurar modelo local ▾" else "$shortName · local ▾"
        }
        btnComposerModel.text = label
        btnComposerModel.contentDescription = if (geminiSelected) {
            "Modelo seleccionado: $label. Toca para ver modelos listos."
        } else {
            "Modelo seleccionado: $label. Toca para ver modelos instalados y utilizables."
        }
    }

    private fun showAvailableModelSelector(anchor: View) {
        val geminiMode = findViewById<CheckBox>(R.id.cbUseGemini)
        val geminiSearch = findViewById<CheckBox>(R.id.cbUseGeminiSearch)
        val menu = androidx.appcompat.widget.PopupMenu(this, anchor)
        menu.menu.setGroupCheckable(0, true, true)
        val availableLocalModels = com.tunnel.turbo.chat.LocalModelCatalog.availableForChat(this)
        val currentModelId = coordinator.selectedLocalModelId
        availableLocalModels.forEachIndexed { index, spec ->
            menu.menu.add(0, 1000 + index, index, "${spec.displayName} · local").apply {
                isCheckable = true
                isChecked = !geminiMode.isChecked && spec.id == currentModelId
            }
        }
        val geminiReady = isGeminiReady()
        if (geminiReady) {
            menu.menu.add(0, 2000, availableLocalModels.size, "Gemini API · ${com.tunnel.turbo.chat.GeminiFreeApiClient.DEFAULT_FREE_TEST_MODEL}").apply {
                isCheckable = true
                isChecked = geminiMode.isChecked
            }
        }
        if (availableLocalModels.isEmpty() && !geminiReady) {
            menu.menu.add(0, 3000, 0, "No hay modelos listos para usar").isEnabled = false
            menu.menu.add(0, 3001, 1, "Configurar modelos o conexiones…")
        }
        if (geminiReady && geminiMode.isChecked) {
            menu.menu.add(2, 2001, availableLocalModels.size + 1, "Buscar en la web").apply {
                isCheckable = true
                isChecked = geminiSearch.isChecked
            }
        }
        menu.setOnMenuItemClickListener { item ->
            when {
                item.itemId in 1000 until (1000 + availableLocalModels.size) -> {
                    val spec = availableLocalModels[item.itemId - 1000]
                    geminiMode.isChecked = false
                    geminiSearch.isChecked = false
                    btnComposerModel.isEnabled = false
                    lifecycleScope.launch {
                        val loaded = coordinator.selectLocalModel(spec.id, coordinator.preferredBackend)
                        btnComposerModel.isEnabled = true
                        if (loaded) {
                            updateComposerModelLabel()
                            Toast.makeText(this@MainActivity, "${spec.displayName} listo", Toast.LENGTH_SHORT).show()
                        } else {
                            updateComposerModelLabel()
                            Toast.makeText(this@MainActivity, "No se pudo iniciar ese modelo; se conservó el modelo anterior", Toast.LENGTH_LONG).show()
                        }
                    }
                    true
                }
                item.itemId == 2000 -> {
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Usar Gemini API")
                        .setMessage("El mensaje y parte del contexto reciente se enviarán a Google y pueden consumir cuota.")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Continuar") { _, _ -> geminiMode.isChecked = true; updateComposerModelLabel() }
                        .show()
                    true
                }
                item.itemId == 2001 -> {
                    geminiSearch.isChecked = !geminiSearch.isChecked
                    true
                }
                item.itemId == 3001 -> {
                    coordinator.selectNavigationTab(if (geminiKeyVault.hasKey()) com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS else com.tunnel.turbo.coordinator.NavigationTab.MODEL_CENTER)
                    true
                }
                else -> false
            }
        }
        menu.show()
    }

    private fun speakMessage(message: ConversationMessage) {
        val tts = textToSpeech
        if (tts == null) {
            Toast.makeText(this, "La voz del dispositivo no está lista", Toast.LENGTH_SHORT).show()
            return
        }
        val plainText = com.tunnel.turbo.chat.ChatMarkdown.render(message.text).toString().trim()
        val maxLength = (android.speech.tts.TextToSpeech.getMaxSpeechInputLength() - 16).coerceAtLeast(128)
        val chunks = mutableListOf<String>()
        var remaining = plainText
        while (remaining.length > maxLength) {
            var cut = remaining.lastIndexOf(' ', maxLength)
            if (cut < maxLength / 2) cut = maxLength
            chunks += remaining.substring(0, cut).trim()
            remaining = remaining.substring(cut).trimStart()
        }
        if (remaining.isNotBlank()) chunks += remaining
        val failed = chunks.isEmpty() || chunks.withIndex().any { (index, chunk) ->
            tts.speak(
                chunk,
                if (index == 0) android.speech.tts.TextToSpeech.QUEUE_FLUSH else android.speech.tts.TextToSpeech.QUEUE_ADD,
                android.os.Bundle(),
                "tt-${message.id}-$index"
            ) == android.speech.tts.TextToSpeech.ERROR
        }
        if (failed) Toast.makeText(this, "No pude iniciar la voz del dispositivo", Toast.LENGTH_SHORT).show()
    }

    private fun showMessageOverflow(itOrParent: View, message: ConversationMessage) {
        val menu = androidx.appcompat.widget.PopupMenu(this, itOrParent)
        menu.menu.add("Compartir respuesta")
        val chatResponse = message.turnStatus == com.tunnel.turbo.coordinator.TurnStatus.GENERATED &&
            (message.route == com.tunnel.turbo.coordinator.Route.LOCAL_CHAT ||
                message.route == com.tunnel.turbo.coordinator.Route.CLOUD_API ||
                message.route == com.tunnel.turbo.coordinator.Route.RESEARCH)
        if (chatResponse && com.tunnel.turbo.coordinator.ConversationEditReducer.userMessageForResponse(
                coordinator.uiState.value.conversation, message.id
            ) != null
        ) {
            menu.menu.add("Regenerar con otro motor")
        }
        val hasRouteInfo = message.route != null || message.turnStatus != null ||
            !message.provenance.isNullOrBlank() || !message.actionSummary.isNullOrBlank() ||
            !message.verificationExplanation.isNullOrBlank()
        if (hasRouteInfo) menu.menu.add("Ruta y verificación")
        menu.setOnMenuItemClickListener { item ->
            when (item.title.toString()) {
                "Compartir respuesta" -> {
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, message.text)
                    }
                    startActivity(android.content.Intent.createChooser(send, "Compartir respuesta"))
                }
                "Ruta y verificación" -> showResponseRouteInfo(message)
                "Regenerar con otro motor" -> showRegenerateEngineMenu(itOrParent, message)
            }
            true
        }
        menu.show()
    }

    private fun showRegenerateEngineMenu(anchor: View, response: ConversationMessage) {
        val conversation = coordinator.uiState.value.conversation
        val userMessage = com.tunnel.turbo.coordinator.ConversationEditReducer.userMessageForResponse(conversation, response.id)
            ?: return
        val availableLocalModels = com.tunnel.turbo.chat.LocalModelCatalog.availableForChat(this)
            .filter { it.id != coordinator.selectedLocalModelId }
        val currentIsGemini = response.route == com.tunnel.turbo.coordinator.Route.CLOUD_API ||
            response.route == com.tunnel.turbo.coordinator.Route.RESEARCH
        val geminiReady = isGeminiReady() && !currentIsGemini
        val menu = androidx.appcompat.widget.PopupMenu(this, anchor)
        availableLocalModels.forEachIndexed { index, spec ->
            menu.menu.add(0, 10_000 + index, index, "${spec.displayName} · local")
        }
        if (geminiReady) {
            menu.menu.add(0, 20_000, availableLocalModels.size, "Gemini API")
        }
        if (availableLocalModels.isEmpty() && !geminiReady) {
            menu.menu.add("No hay otro motor listo").isEnabled = false
        }
        menu.setOnMenuItemClickListener { item ->
            when {
                item.itemId in 10_000 until 10_000 + availableLocalModels.size -> {
                    regenerateWithLocalModel(userMessage, response, availableLocalModels[item.itemId - 10_000])
                    true
                }
                item.itemId == 20_000 -> {
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Regenerar con Gemini API")
                        .setMessage("El mensaje y parte del contexto anterior se enviarán a Google y pueden consumir cuota. La respuesta actual se reemplazará.")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Regenerar") { _, _ ->
                            regenerateWithGemini(userMessage, response)
                        }
                        .show()
                    true
                }
                else -> false
            }
        }
        menu.show()
    }

    private fun canRegenerate(userMessage: ConversationMessage, response: ConversationMessage): Boolean {
        if (coordinator.uiState.value.isBusy) {
            Toast.makeText(this, "Espera a que termine la tarea actual", Toast.LENGTH_SHORT).show()
            return false
        }
        val current = coordinator.uiState.value.conversation
        return com.tunnel.turbo.coordinator.ConversationEditReducer.userMessageForResponse(current, response.id)?.id == userMessage.id
    }

    private fun regenerateWithLocalModel(
        userMessage: ConversationMessage,
        response: ConversationMessage,
        model: com.tunnel.turbo.chat.LocalModelSpec
    ) {
        if (!canRegenerate(userMessage, response)) return
        isRegenerating = true
        btnComposerModel.isEnabled = false
        btnAppSend.isEnabled = false
        etAppInput.isEnabled = false
        lifecycleScope.launch {
            val loaded = runCatching { coordinator.selectLocalModel(model.id, coordinator.preferredBackend) }.getOrDefault(false)
            isRegenerating = false
            btnComposerModel.isEnabled = true
            etAppInput.isEnabled = true
            btnAppSend.isEnabled = !coordinator.uiState.value.isBusy
            if (!loaded) {
                updateComposerModelLabel()
                Toast.makeText(this@MainActivity, "No se pudo cargar ${model.displayName}; no se reemplazó la respuesta", Toast.LENGTH_LONG).show()
                return@launch
            }
            val retained = coordinator.prepareEditedPrompt(userMessage.id)
            if (!retained) {
                updateComposerModelLabel()
                Toast.makeText(this@MainActivity, "No se pudo iniciar la regeneración", Toast.LENGTH_SHORT).show()
                return@launch
            }
            findViewById<CheckBox>(R.id.cbUseGemini).isChecked = false
            findViewById<CheckBox>(R.id.cbUseGeminiSearch).isChecked = false
            updateComposerModelLabel()
            coordinator.submitIntent(userMessage.text, source = "REGENERATE_WITH_LOCAL_MODEL")
        }
    }

    private fun regenerateWithGemini(userMessage: ConversationMessage, response: ConversationMessage) {
        if (!canRegenerate(userMessage, response)) return
        if (!isGeminiReady()) {
            Toast.makeText(this, "Gemini no está listo; revisa Ajustes · Conexiones", Toast.LENGTH_LONG).show()
            coordinator.selectNavigationTab(com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS)
            return
        }
        if (!coordinator.prepareEditedPrompt(userMessage.id)) {
            Toast.makeText(this, "No se pudo iniciar la regeneración", Toast.LENGTH_SHORT).show()
            return
        }
        findViewById<CheckBox>(R.id.cbUseGemini).isChecked = true
        findViewById<CheckBox>(R.id.cbUseGeminiSearch).isChecked = response.route == com.tunnel.turbo.coordinator.Route.RESEARCH
        etAppInput.setText(userMessage.text)
        updateComposerModelLabel()
        btnAppSend.performClick()
    }

    private fun showResponseRouteInfo(message: ConversationMessage) {
        val routeLabel = when (message.route) {
            com.tunnel.turbo.coordinator.Route.LOCAL_CHAT -> "Chat local"
            com.tunnel.turbo.coordinator.Route.CLOUD_API -> "API cloud"
            com.tunnel.turbo.coordinator.Route.ANDROID_DIRECT -> "Android directo"
            com.tunnel.turbo.coordinator.Route.ANDROID_AGENT -> "Agente Android"
            com.tunnel.turbo.coordinator.Route.RESEARCH -> "Investigación"
            com.tunnel.turbo.coordinator.Route.WORK -> "Trabajo"
            com.tunnel.turbo.coordinator.Route.CLARIFY -> "Aclaración"
            com.tunnel.turbo.coordinator.Route.UNSUPPORTED -> "Sin ruta disponible"
            null -> null
        }
        val statusLabel = when (message.turnStatus) {
            com.tunnel.turbo.coordinator.TurnStatus.GENERATED -> "Respuesta generada"
            com.tunnel.turbo.coordinator.TurnStatus.COMPLETED_VERIFIED -> "Resultado verificado"
            com.tunnel.turbo.coordinator.TurnStatus.COMPLETED_UNVERIFIED -> "Resultado sin verificar"
            com.tunnel.turbo.coordinator.TurnStatus.NEEDS_CLARIFICATION -> "Necesita aclaración"
            com.tunnel.turbo.coordinator.TurnStatus.UNSUPPORTED -> "No disponible"
            com.tunnel.turbo.coordinator.TurnStatus.FAILED -> "No completado"
            else -> null
        }
        val details = buildList {
            routeLabel?.let { add("Ruta: $it") }
            statusLabel?.let { add("Estado: $it") }
            message.provenance?.takeIf(String::isNotBlank)?.let { add("Modelo: $it") }
            message.latencyMs?.let { add("Duración: ${formatResponseDuration(it)}") }
            message.actionSummary?.takeIf(String::isNotBlank)?.let { add("Acción: $it") }
            message.verificationExplanation?.takeIf(String::isNotBlank)?.let { add("Verificación: $it") }
        }.joinToString("\n\n").ifBlank { "No hay información adicional para esta respuesta." }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Información de respuesta")
            .setMessage(details)
            .setPositiveButton("Cerrar", null)
            .show()
    }

    private fun showUserMessageMenu(anchor: View, message: ConversationMessage) {
        val menu = androidx.appcompat.widget.PopupMenu(this, anchor)
        menu.menu.add("Editar y reenviar")
        menu.setOnMenuItemClickListener { item ->
            if (item.title == "Editar y reenviar") showEditPromptDialog(message)
            true
        }
        menu.show()
    }

    private fun showEditPromptDialog(message: ConversationMessage) {
        val input = EditText(this).apply {
            setText(message.text)
            setSelection(text.length)
            minLines = 3
            maxLines = 8
            gravity = Gravity.TOP or Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(TextView(this@MainActivity).apply {
                text = "Se volverá a ejecutar. La respuesta y los mensajes posteriores se quitarán desde este punto."
                textSize = 12f
                setTextColor(Color.parseColor("#B8BAC8"))
                setPadding(0, dp(10), 0, 0)
            })
        }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Reformular mensaje")
            .setView(content)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Reenviar", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val revised = input.text.toString().trim()
                if (revised.isEmpty()) {
                    input.error = "Escribe el mensaje"
                    return@setOnClickListener
                }
                val conversation = coordinator.uiState.value.conversation
                val editedIndex = conversation.indexOfFirst { it.id == message.id }
                val followingAssistant = conversation.drop((editedIndex + 1).coerceAtLeast(0))
                    .firstOrNull { it.role == MessageRole.ASSISTANT }
                val wasGeminiTurn = followingAssistant?.provenance?.startsWith("Gemini API") == true
                if (wasGeminiTurn && !geminiKeyVault.hasKey()) {
                    dialog.dismiss()
                    Toast.makeText(this, "Configura Gemini en Ajustes · Conexiones antes de reenviar", Toast.LENGTH_LONG).show()
                    coordinator.selectNavigationTab(com.tunnel.turbo.coordinator.NavigationTab.CONNECTIONS)
                    return@setOnClickListener
                }
                dialog.dismiss()
                if (wasGeminiTurn) {
                    if (!coordinator.prepareEditedPrompt(message.id)) {
                        Toast.makeText(this, "No se pudo editar mientras hay una tarea en curso", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    findViewById<CheckBox>(R.id.cbUseGemini).isChecked = true
                    findViewById<CheckBox>(R.id.cbUseGeminiSearch).isChecked = followingAssistant?.route == com.tunnel.turbo.coordinator.Route.RESEARCH
                    etAppInput.setText(revised)
                    btnAppSend.performClick()
                } else if (coordinator.submitEditedPrompt(message.id, revised) == null) {
                    Toast.makeText(this, "No se pudo editar mientras hay una tarea en curso", Toast.LENGTH_SHORT).show()
                }
            }
        }
        dialog.show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun getViewerOcrScanner(): com.tunnel.turbo.perception.LocalOcrScanner {
        return viewerOcrScanner ?: com.tunnel.turbo.perception.LocalOcrScanner().also { viewerOcrScanner = it }
    }

    private fun importScreenCapture(uri: android.net.Uri) {
        tvSnapshotMeta?.text = "Abriendo captura del teléfono…"
        lifecycleScope.launch(Dispatchers.IO) {
            val bitmap = runCatching {
                contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
            }.getOrNull()
            val recognized = if (bitmap != null) {
                runCatching { getViewerOcrScanner().scanBitmap(bitmap, targetWidth = 1200) }.getOrDefault(emptyList())
            } else emptyList()

            withContext(Dispatchers.Main) {
                if (bitmap == null) {
                    tvSnapshotMeta?.text = "No se pudo abrir la imagen. Elige una captura PNG o JPG."
                    return@withContext
                }
                val oldFrame = viewerScreenBitmap
                viewerScreenBitmap = bitmap
                if (oldFrame != null && oldFrame !== bitmap && !oldFrame.isRecycled) oldFrame.recycle()
                val importedSnapshot = com.tunnel.turbo.accessibility.AccessibilitySnapshot(
                    nodes = emptyList(),
                    foregroundPackage = "captura importada",
                    displayWidth = bitmap.width,
                    displayHeight = bitmap.height,
                    serviceStatus = "NOT_APPLICABLE"
                )
                mapViewSemantic?.screenBitmap = bitmap
                mapViewSemantic?.ocrElements = recognized
                mapViewSemantic?.snapshot = importedSnapshot
                selectedUiNode = null
                btnActOnSelectedNode?.isEnabled = false
                tvActionOutcome?.text = "Captura importada: acciones desactivadas; no hay nodos vivos asociados."
                btnModeAccessibility?.isEnabled = false
                btnModeCombined?.isEnabled = false
                tvSnapshotMeta?.text = "Captura importada · ${bitmap.width}x${bitmap.height} · OCR ${recognized.size} líneas"
                tvViewerModeHint?.text = "Captura importada: no se combina con Accessibility para evitar mezclar pantallas distintas."
                tvViewerOcrText?.text = if (recognized.isEmpty()) {
                    "OCR: no se encontró texto en esta captura."
                } else {
                    "OCR (${recognized.size} líneas):\n" + recognized.joinToString("\n") { "• ${it.text}" }.take(2200)
                }
                btnModePixels?.performClick()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::coordinator.isInitialized) {
            coordinator.refreshBridgesStatus()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewerOcrScanner?.close()
        viewerOcrScanner = null
        viewerScreenBitmap?.let { if (!it.isRecycled) it.recycle() }
        viewerScreenBitmap = null
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        if (::coordinator.isInitialized) {
            coordinator.devToolsBridge.stop()
        }
        if (::shizukuBridge.isInitialized) {
            shizukuBridge.destroy()
        }
    }
}
