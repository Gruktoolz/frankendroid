package com.tunnel.turbo.accessibility

/**
 * Selection rules for an action that can affect only one accessibility node.
 * Collection modes are deliberately not allowed to degrade to an arbitrary first match.
 */
internal object SemanticMatchPolicy {
    fun shouldStopSearch(mode: String, matchCount: Int): Boolean = when (mode) {
        "first" -> matchCount >= 1
        "single" -> matchCount >= 2
        "all" -> true
        else -> true
    }

    fun <T> selectOne(mode: String, matches: List<T>): T? = when (mode) {
        "first" -> matches.firstOrNull()
        "single" -> matches.singleOrNull()
        "all" -> null
        else -> null
    }
}
