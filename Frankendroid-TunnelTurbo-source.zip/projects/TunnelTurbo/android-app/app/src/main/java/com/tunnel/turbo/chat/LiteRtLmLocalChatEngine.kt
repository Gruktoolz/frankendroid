package com.tunnel.turbo.chat

import android.util.Log
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * Concrete production adapter wrapping Google LiteRT-LM.
 * Strictly configured with ZERO tools registered to guarantee no Android side effects.
 */
class LiteRtLmLocalChatEngine : LocalChatEngine {

    companion object {
        private const val TAG = "LiteRtLmLocalChatEngine"
    }

    private var engine: Engine? = null
    override var isModelLoaded: Boolean = false
        private set
    override var loadedModelPath: String? = null
        private set
    override var backend: ChatBackend = ChatBackend.CPU
        private set
    override var lifecycleState: ModelLifecycleState = ModelLifecycleState.UNLOADED
        private set

    override suspend fun loadModel(modelPath: String, backend: ChatBackend): Boolean = withContext(Dispatchers.IO) {
        val file = File(modelPath)
        if (!file.exists() || !file.canRead()) {
            Log.e(TAG, "Model file not accessible at: $modelPath")
            lifecycleState = ModelLifecycleState.ERROR
            return@withContext false
        }

        try {
            lifecycleState = ModelLifecycleState.LOADING
            close() // release any previous engine

            val litertBackend = when (backend) {
                ChatBackend.GPU -> Backend.GPU()
                ChatBackend.NPU -> Backend.NPU()
                ChatBackend.CPU -> Backend.CPU()
            }

            val config = EngineConfig(
                modelPath = modelPath,
                backend = litertBackend
            )

            val newEngine = Engine(config)
            newEngine.initialize()

            engine = newEngine
            isModelLoaded = true
            loadedModelPath = modelPath
            this@LiteRtLmLocalChatEngine.backend = backend
            lifecycleState = ModelLifecycleState.READY
            Log.i(TAG, "LiteRT-LM Engine successfully initialized with model: $modelPath (backend: $backend)")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize LiteRT-LM Engine with model $modelPath", e)
            close()
            lifecycleState = ModelLifecycleState.ERROR
            false
        }
    }

    override suspend fun startSession(profile: LocalChatProfile, systemPrompt: String?): LocalChatSession = withContext(Dispatchers.IO) {
        val currentEngine = engine ?: error("Engine is not loaded. Call loadModel() first.")

        val sampler = if (profile.topK != null || profile.topP != null || profile.temperature != null) {
            SamplerConfig(
                topK = profile.topK ?: 40,
                topP = profile.topP ?: 0.95,
                temperature = profile.temperature ?: 0.7,
                seed = profile.seed ?: 0
            )
        } else {
            null
        }

        val convConfig = ConversationConfig(
            systemInstruction = if (!systemPrompt.isNullOrBlank()) com.google.ai.edge.litertlm.Contents.of(systemPrompt) else null,
            samplerConfig = sampler,
            maxOutputToken = profile.maxOutputTokens
        )

        // Section 9: Explicitly ensure zero tools are passed
        val conversation = currentEngine.createConversation(convConfig)
        LiteRtLmLocalChatSession(conversation)
    }

    override fun close() {
        lifecycleState = ModelLifecycleState.CLOSING
        try {
            engine?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing LiteRT-LM engine", e)
        } finally {
            engine = null
            isModelLoaded = false
            loadedModelPath = null
            lifecycleState = ModelLifecycleState.UNLOADED
        }
    }

    private class LiteRtLmLocalChatSession(
        private val conversation: Conversation,
        override val sessionId: String = UUID.randomUUID().toString()
    ) : LocalChatSession {

        override fun sendMessage(text: String): Flow<String> = flow {
            conversation.sendMessageAsync(text).collect { message ->
                val chunkText = extractText(message)
                Log.i(TAG, "sendMessageAsync chunk: '$chunkText'")
                if (chunkText.isNotEmpty()) {
                    emit(chunkText)
                }
            }
        }.flowOn(Dispatchers.IO)

        override suspend fun sendSingleMessage(text: String): String = withContext(Dispatchers.IO) {
            val sb = StringBuilder()
            conversation.sendMessageAsync(text).collect { message ->
                val chunkText = extractText(message)
                sb.append(chunkText)
            }
            sb.toString()
        }

        @OptIn(com.google.ai.edge.litertlm.ExperimentalApi::class)
        override fun getBenchmarkInfo(): SessionBenchmark? {
            return try {
                val b = conversation.getBenchmarkInfo()
                SessionBenchmark(
                    initTimeInSecond = b.initTimeInSecond,
                    timeToFirstTokenInSecond = b.timeToFirstTokenInSecond,
                    lastPrefillTokenCount = b.lastPrefillTokenCount,
                    lastDecodeTokenCount = b.lastDecodeTokenCount,
                    lastPrefillTokensPerSecond = b.lastPrefillTokensPerSecond,
                    lastDecodeTokensPerSecond = b.lastDecodeTokensPerSecond
                )
            } catch (e: Exception) {
                Log.d(TAG, "Native benchmark info not available", e)
                null
            }
        }

        private fun extractText(message: com.google.ai.edge.litertlm.Message): String {
            val contentsText = runCatching {
                message.contents.contents.filterIsInstance<com.google.ai.edge.litertlm.Content.Text>()
                    .joinToString("") { it.text }
            }.getOrNull()
            if (!contentsText.isNullOrEmpty()) {
                return contentsText
            }
            val channels = runCatching { message.channels }.getOrNull()
            if (!channels.isNullOrEmpty()) {
                return channels.values.joinToString("")
            }
            return ""
        }

        override fun close() {
            try {
                conversation.close()
            } catch (e: Exception) {
                Log.w(TAG, "Error closing LiteRT-LM conversation", e)
            }
        }
    }
}
