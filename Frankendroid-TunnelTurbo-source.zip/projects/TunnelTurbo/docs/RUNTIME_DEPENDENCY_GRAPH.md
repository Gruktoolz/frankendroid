# RUNTIME DEPENDENCY GRAPH — TUNNEL TURBO CONTROLLER
**Fecha:** 17 de octubre de 2026  
**Auditoría de Arquitectura & Fronteras de Dependencia (Fase 9.5)**

Este documento formaliza el gráfico de dependencias deseado para Tunnel Turbo, estableciendo fronteras estrictas y eliminando acoplamientos laterales indebidos.

---

## 1. Gráfico de Dependencias Deseado

```mermaid
graph TD
    subgraph Presentation_Layer [Capa de Presentación / UI]
        UI[MainActivity / App UI & Debug UI]
        State[AppUiState / StateFlow]
    end

    subgraph Coordination_Layer [Capa de Coordinación de Negocio]
        Coordinator[IntentCoordinator]
    end

    subgraph Decision_and_Planning [Capa de Decisión y Planificación]
        Router[LocalIntentRouter]
        Runtime[ProviderRuntime]
        Provider[AndroidAiAppProvider]
        Validator[PlanValidator]
    end

    subgraph Core_Execution [Capa de Ejecución Nativa]
        Adapter[TunnelCoreAdapter]
        NativeCore[NativeTunnelCore]
        SeqExec[NativeSequenceExecutor]
        ActionEngine[NativeActionEngine]
        Policy[DisplayTargetPolicy]
        Verifier[NativeVerifier]
        StateEngine[NativeStateEngine]
        Journal[NativeEventJournal]
    end

    subgraph Infrastructure_Adapters [Adaptadores de Infraestructura]
        A11yBridge[AccessibilityBridge]
        A11yService[TunnelTurboAccessibilityService]
        Shizuku[ShizukuBridge]
        DisplayMgr[WorkerDisplayManager]
        WorkerBridge[AiWorkerBridge]
    end

    %% Flujo unidireccional
    UI -->|Envía UserIntent| Coordinator
    State -->|Observado por| UI
    Coordinator -->|Actualiza| State
    Coordinator -->|Consulta ruta| Router
    Coordinator -->|Orquesta ejecución / IA| Runtime
    Runtime -->|Consulta inferencia| Provider
    Provider -->|Usa puente| WorkerBridge
    Runtime -->|Valida planes| Validator
    Coordinator -->|Despacha plan validado| Adapter
    Adapter -->|Ejecuta nativamente| NativeCore
    NativeCore --> SeqExec
    NativeCore --> ActionEngine
    SeqExec --> ActionEngine
    ActionEngine --> Policy
    ActionEngine --> Verifier
    ActionEngine --> Journal
    Verifier --> StateEngine
    StateEngine --> Journal

    %% Infraestructura conecta a Core y Provider
    ActionEngine -.->|Usa Intent / APIs| Infrastructure_Adapters
    ActionEngine -.->|Usa Accessibility| A11yService
    WorkerBridge -.->|Usa Display| DisplayMgr
    WorkerBridge -.->|Usa Nodos| A11yBridge
    A11yBridge -.-> A11yService
    StateEngine <-.-|Eventos TYPE_WINDOW| A11yService
```

---

## 2. Reglas de Frontera y Prohibición de Dependencias Laterales

Para prevenir la degradación a código espagueti, se establecen las siguientes reglas arquitectónicas inviolables:

| Origen | Destino Prohibido | Motivo Arquitectónico | Frontera Correcta |
|---|---|---|---|
| **MainActivity / UI** | `NativeActionEngine` | La UI no debe conocer la implementación de bajo nivel de las acciones. | La UI solo invoca `IntentCoordinator.submitIntent(userText)`. |
| **MainActivity / UI** | `Shizuku internals` | La UI no gestiona binders ni IPC de Shizuku directamente. | La UI consulta el estado a través de `AppUiState.shizukuState`. |
| **MainActivity / UI** | `ProviderRuntime internals` | La UI no debe interactuar con mutex, colas o tokens de proveedores. | La UI interactúa con el `IntentCoordinator`. |
| **Provider (AI Worker)** | `NativeActionEngine` | El proveedor de IA razona y emite texto estructurado JSON; no ejecuta código Android. | El proveedor retorna texto; `PlanValidator` valida y `NativeTunnelCore` ejecuta. |
| **AccessibilityService** | `ProviderRuntime` / `AI` | El servicio del sistema informa eventos de accesibilidad; no inicia lógica de IA. | El servicio alimenta `NativeStateEngine` pasivamente. |
| **Router** | Modificaciones directas de UI | El ruteador es puramente una función pura `(String) -> RouteResult`. | Retorna `RouteResult` al coordinador. |
| **WorkerBridge** | Estado visual directo de UI | El worker de display virtual es infraestructura desacoplada. | El resultado se propaga a través de `IntentCoordinator` hacia `AppUiState`. |

---

## 3. Naturaleza de los Servicios de Infraestructura

Los siguientes componentes son **Adaptadores de Infraestructura**, NO coordinadores de negocio:
1. `ShizukuBridge`: Encapsula la comunicación Binder con el servidor Shizuku y la verificación de permisos UID 2000.
2. `AccessibilityBridge` / `TunnelTurboAccessibilityService`: Encapsula la interacción con la API de accesibilidad de Android para inspeccionar nodos y ejecutar gestos/global actions.
3. `WorkerDisplayManager`: Encapsula la creación del `VirtualDisplay` y el lanzamiento de actividades en displays secundarios.
4. `AiWorkerBridge`: Encapsula la inyección de texto y lectura semántica del proveedor de IA en el display virtual.

Ninguno de estos adaptadores decide qué hacer; únicamente ejecutan operaciones ordenadas por el motor de negocio.
