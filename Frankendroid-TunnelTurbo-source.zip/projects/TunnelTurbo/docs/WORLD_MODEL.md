# World Model & Observation Reducer

## Overview

The **World Model** (`WorldModel`) maintains the runtime's awareness of the Android environment without creating permanent, monolithic memory snapshots. It divides environment perception into three distinct tiers:

### 1. Static World Model
Discovered on demand:
- **Installed Applications**: Labels and package names discovered via `AppManager.listInstalledApps()`. (Currently 71 apps on the Xiaomi POCO Pad).
- **Capability Registry**: Available primitive system and UI capabilities (exactly 20 capabilities registered).
- **Display Configurations**: Screen resolutions, orientation, and interactive status.

### 2. Dynamic World Model
Refreshed at every step:
- **Foreground Context**: Current `foregroundPackage` and `foregroundActivity`.
- **Display Nodes**: Hierarchical accessibility UI tree on target display.
- **Visible Text**: Human-readable textual elements on screen.
- **Provider Health**: Active AI reasoning provider state and cooldown status.

### 3. Learned World Model
Persisted across goals:
- **Known Skills**: Registered dynamic skills (PROPOSED, VALIDATING, ACTIVE).
- **Candidate App Affinities**: Historical app success counts by task category.
- **Failure Signatures**: Known UI interaction failure points.

---

## On-Demand World Snapshot (`WorldSnapshot`)
Constructed specifically for a target goal. Instead of passing all 71 installed applications to the AI reasoning engine, `WorldModel.createSnapshot(goal)` discovers and scores **Candidate Apps**:

```json
{
  "packageName": "com.spotify.music",
  "label": "Spotify",
  "relevance": 0.95,
  "knownSuccess": 2,
  "currentAvailability": true,
  "reason": "Reproductor de streaming de música principal"
}
```

---

## Observation Reducer (`ObservationReducer`)
Raw Android accessibility dumps contain excessive structural containers, layout wrappers, and empty bounding boxes that waste context windows and latency.

The `ObservationReducer` filters out:
1. Empty non-interactive layout containers without text or descriptions.
2. Redundant non-informative frames.
3. Repetitive layout insets.

### Measured Reduction Metrics
In production benchmarks on Xiaomi HyperOS:
- **Nodes Before**: 97 nodes
- **Nodes After**: 35 semantic nodes
- **Bytes Before**: 28,575 bytes
- **Bytes After**: 10,379 bytes
- **Reduction**: **63.68%**
