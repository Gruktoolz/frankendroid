# Event Journal — Tunnel Turbo Controller

El **Event Journal** es un búfer circular en memoria RAM (ring buffer) de capacidad acotada (default 1,000 eventos) que registra de forma continua y monótona todos los cambios de estado, transiciones de pantalla y ciclo de vida de las acciones en Tunnel Turbo Controller.

---

## 1. Propósito

Permite a agentes y modelos de lenguaje consultar qué ocurrió en el dispositivo Android mientras estaban procesando o razonando, sin tener que solicitar capturas de pantalla ni jerarquías de layout completas.

### Comparativa Conceptual:
- **Antes (Inspección tradicional)**: Ejecutar `android layout` (~1,350 ms) o capturar screenshot (~1,070 ms + multimodal).
- **Ahora (Event Journal)**: Llamar a `tunnel_get_changes(since_revision, limit=100)` (<0.16 ms en RAM).

---

## 2. Estructura de Evento y Esquema de Paginación

Cada evento registrado en el journal implementa el siguiente esquema estructurado:

```json
{
  "revision": 53,
  "timestamp_ns": 1729182390123456789,
  "type": "activity_changed",
  "before": "com.android.settings.MiuiSettings",
  "after": "com.android.settings.Settings$WifiSettingsActivity",
  "source": "persistent_observer",
  "details": {}
}
```

### Respuesta Paginada (Cero Truncado Silencioso)

La herramienta `tunnel_get_changes(since_revision, limit=100)` garantiza que ningún modelo reciba respuestas truncadas sin metadata explícita:

```json
{
  "events_available": 250,
  "events_returned": 100,
  "returned": 100,
  "remaining": 150,
  "truncated": true,
  "oldest_revision": 1,
  "newest_revision": 100,
  "next_revision": 100,
  "events": [ ... ]
}
```

---

## 3. Catálogo de Eventos Soportados

| Tipo de Evento | Origen | Descripción |
| :--- | :--- | :--- |
| `device_connected` | `StateEngine` / `DeviceTracker` | Dispositivo detectado y conectado vía `adb track-devices`. |
| `device_disconnected` | `DeviceTracker` | Dispositivo desconectado de la conexión ADB. |
| `package_changed` | `PersistentObserver` / `StateEngine` | La aplicación en primer plano cambió de paquete. |
| `activity_changed` | `PersistentObserver` / `StateEngine` | La actividad (pantalla) en primer plano cambió. |
| `orientation_changed` | `PersistentObserver` | La orientación física de la pantalla cambió. |
| `ui_invalidated` | `StateEngine` | La caché de UI fue marcada como `stale` o `dirty`. |
| `ui_refreshed` | `StateEngine` | Se capturó y parseó un nuevo árbol de UI. |
| `action_started` | `ActionEngine` | Se inició una acción individual. |
| `action_completed` | `ActionEngine` | Una acción finalizó con verificación exitosa. |
| `verification_failed` | `ActionEngine` | Una acción finalizó sin poder verificar su efecto esperado. |
| `sequence_started` | `SequenceExecutor` | Se inició una secuencia de múltiples pasos. |
| `step_started` | `SequenceExecutor` | Se inició la ejecución del paso $N$ de una secuencia. |
| `step_completed` | `SequenceExecutor` | El paso $N$ completó su verificación. |
| `step_failed` | `SequenceExecutor` | El paso $N$ falló su verificación. |
| `sequence_completed` | `SequenceExecutor` | La secuencia finalizó (éxito o parada por fallo). |

---

## 4. Auditoría de Escalabilidad y Causa de la Anomalía Fase 5

### Explicación de la Anomalía (10 vs 100 eventos en Fase 5)
En el benchmark original de Fase 5, solo se generaron ~12 revisiones de estado en total durante el setup. Al solicitar `since_revision=10` se devolvieron 2 eventos (~9.9 KB por la inclusión de un diff de UI de prueba) y al solicitar `since_revision=0` se devolvieron los 12 eventos (~10.1 KB). La similitud de tamaño fue un **artefacto del benchmark sintético que carecía de suficientes eventos en el buffer**, no una truncación del motor.

### Medición Determinista Real (Fase 6)

Medición sobre eventos sintéticos controlados escalando de 0 a 1,000 eventos:

| Eventos Disponibles | Eventos Devueltos | Bytes Serializados | Tiempo Serialización | Paginado (`limit=100`) | Truncado |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **0** | 0 | 177 B | 0.02 ms | 177 B | `False` |
| **1** | 1 | 445 B | 0.01 ms | 445 B | `False` |
| **10** | 10 | 2,926 B | 0.03 ms | 2,926 B | `False` |
| **25** | 25 | 7,069 B | 0.04 ms | 7,069 B | `False` |
| **50** | 50 | 13,986 B | 0.07 ms | 13,986 B | `False` |
| **100** | 100 | 27,817 B | 0.16 ms | 27,817 B | `False` |
| **250** | 100 (paginado) | 69,592 B | 0.35 ms | 27,817 B | `True` (`next_rev=100`) |
| **1,000** | 100 (paginado) | 278,473 B | 1.71 ms | 27,818 B | `True` (`next_rev=100`) |

- Cada evento ocupa en promedio **~275 bytes**.
- Serialización de 100 eventos en JSON toma solo **0.16 ms**.
- 1,000 eventos completos ocupan en memoria física RAM únicamente **~340 KB**.
