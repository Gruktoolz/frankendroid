# Tunnel Turbo — AI Worker Android Requirements & Feasibility Analysis

## Executive Summary

Phase 7.5 evaluates executing an installed Android AI application (e.g., ChatGPT, Gemini) on a secondary virtual display as a remote reasoning worker for Tunnel Turbo, completely isolated from the user's primary interactive display (`Display #0`).

This document details what will be required to manage, host, and interact with the AI Worker from a future standalone Android APK, evaluating both unprivileged capabilities and elevated privilege requirements (Shizuku / ADB shell).

---

## 1. Virtual Display Creation & Hosting

### Unprivileged Android App (Standard APK)
* In the standard Android SDK (`android.hardware.display.DisplayManager`), an app can create a virtual display via:
  ```java
  DisplayManager dm = getSystemService(DisplayManager.class);
  VirtualDisplay vd = dm.createVirtualDisplay(
      "AI_Worker",
      1080, 1920, 420,
      surface,
      DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION
  );
  ```
* **Critical Limitation for Standard APKs**:
  1. **Flag Restrictions**: Only system apps or apps holding the signature permission `android.permission.CAPTURE_VIDEO_OUTPUT` or `android.permission.INTERNAL_SYSTEM_WINDOW` can create displays with flags like `FLAG_TRUSTED`, `FLAG_OWN_FOCUS`, or `FLAG_OWN_DISPLAY_GROUP`.
  2. **Activity Launch Restrictions**: A regular third-party app cannot arbitrarily launch *other packages* into its own virtual display. Android checks `ActivityRecord` permissions; launching an external app (like `com.openai.chatgpt`) onto a secondary display without `INTERNAL_SYSTEM_WINDOW` or privileged intent flags causes a `SecurityException`.
  3. **Multi-Resume Isolation**: On Android 10+ (and confirmed on Android 16), secondary displays support multi-resume, but apps may declare `android:resizeableActivity="false"`, forcing them to only launch on the default display. ChatGPT (`com.openai.chatgpt`) handles secondary display presentation when launched via ADB shell / `am start --display <id>`, but refuses unprivileged third-party redirects.

### Privileged / Shizuku / ADB Shell Approach
* `scrcpy` succeeds because it executes as `com.android.shell` (UID 2000), which holds:
  - `android.permission.INTERNAL_SYSTEM_WINDOW`
  - `android.permission.MANAGE_ACTIVITY_TASKS`
  - `android.permission.CREATE_VIRTUAL_DISPLAYS` with `FLAG_TRUSTED` and `FLAG_OWN_FOCUS`.
* **Shizuku Integration**:
  A future Tunnel Turbo APK integrating Shizuku can bind directly to the `IActivityTaskManager` and `IDisplayManager` system binders under UID 2000, creating virtual displays with identical privileges to `scrcpy` and dispatching `am start --display <id>`.

---

## 2. Interaction & Input Routing

### Isolated Touch & Key Events
* In Android 14–16, `input` supports display targeting:
  ```bash
  input -d <display_id> tap <x> <y>
  input -d <display_id> text "<string>"
  input -d <display_id> keyevent <keycode>
  ```
* **Unprivileged APK**:
  Standard apps cannot inject `MotionEvent` or `KeyEvent` into windows owned by other processes (enforced by `android.permission.INJECT_EVENTS`, a signature-or-system permission).
* **Requirements for Future APK**:
  - **Option A (Accessibility Service)**: Tunnel Turbo can register as an `AccessibilityService`. With `canPerformGestures="true"`, it can dispatch gestures on targeted displays.
  - **Option B (Shizuku / InputManager IPC)**: Tunnel Turbo calls `IInputManager.injectInputEvent` via Shizuku with displayId specified in the event metadata.

---

## 3. Perception & Semantic Extraction

### Priority Hierarchy:
1. **AccessibilityNodeInfo Hierarchy**:
   - As proven in Phase 7.5, the assistant's response in ChatGPT is exposed directly as an accessible `android.widget.TextView` with full text and action descriptors (`desc="Copiar"`, `desc="Chat nuevo"`).
   - An `AccessibilityService` in the future APK can query `AccessibilityWindowInfo` filtering by `window.getDisplayId() == workerDisplayId` and read the text directly in microsecond time, without any `screencap` or OCR overhead.
2. **Clipboard Interception**:
   - ChatGPT copies output to the primary clipboard when the "Copiar" button is clicked.
   - However, Android 13+ restricts background clipboard reading unless the app is currently focused or an input method editor (IME).
   - Therefore, direct `AccessibilityNodeInfo.getText()` is vastly superior and more reliable than clipboard polling.

---

## 4. Matrix of Requirements for Future APK

| Capability | Standard Unprivileged APK | With AccessibilityService | With Shizuku (UID 2000) | Root (UID 0) |
|---|---|---|---|---|
| Create VirtualDisplay | Partial (Presentation only) | Partial | Full (`FLAG_TRUSTED`) | Full |
| Launch ChatGPT on Display ID | ❌ SecurityException | ❌ Blocked | ✅ Full (`am start --display`) | ✅ Full |
| Read ChatGPT Text Semantically | ❌ Blocked | ✅ Full (displayId aware) | ✅ Full (Accessibility/UI dump)| ✅ Full |
| Inject Input to ChatGPT | ❌ Blocked | ✅ Gestures (display-aware) | ✅ Full (`injectInputEvent`) | ✅ Full |
| Zero Impact on Display 0 | ❌ Cannot isolate | ✅ Yes | ✅ Yes | ✅ Yes |

---

## 5. Architectural Recommendation & Phase 7.6 Hardening Conclusions

1. **Phase 7.5 & 7.6 Validation (PC Controller Endurecido)**:
   - Utiliza `scrcpy --new-display` (UID 2000) con `--display-ime-policy=hide` (0 apariciones de teclado en Display #0).
   - Inyección de texto directa y keyboardless mediante `AccessibilityNodeInfo.ACTION_SET_TEXT` (0 uso de portapapeles en ruta principal).
   - Envío semántico nativo mediante `AccessibilityNodeInfo.ACTION_CLICK` (0 coordenadas fijas).
   - Sesión persistente `WorkerSession` que reutiliza el mismo hilo para 20 peticiones consecutivas con 100% de precisión y 0 spam de conversaciones.
   - Percepción estructurada display-scoped filtrando estrictamente por `displayId`.
   - Inferencia remota pesada en la nube del proveedor; consumo de RAM en PC reducido a 25.2 MB (vs 3.1 GB con Qwen local).

2. **Criterio de Go / No-Go para la APK Nativa**:
   - Múltiples chats resueltos: **SÍ** (1 conversación / 20 peticiones).
   - Teclado en Display #0: **SÍ** (0 apariciones).
   - Inyección sin portapapeles global: **SÍ** (`ACCESSIBILITY_SET_TEXT`).
   - Envío semántico sin coordenadas fijas: **SÍ** (`ACTION_CLICK`).
   - Asociaciones erróneas de request: **SÍ** (0).
   - Ejecuciones no seguras en Android: **SÍ** (0.0%).
   - Cero screenshots y cero OCR: **SÍ**.
   - **Veredicto:** `ready_for_apk_architecture = YES`.
   - **Siguiente Fase:** **FASE 8 — TUNNEL TURBO APK SKELETON (Completada)**.

---

## 6. Realización en Fase 8 (APK Nativa + Provider Runtime)

La APK nativa implementa la arquitectura recomendada en hardware real (Xiaomi POCO Pad):
1. **ShizukuBridge integrado oficialmente**:
   - Conexión con binder (`moe.shizuku.privileged.api`).
   - Acceso confirmado con `pingBinder=true` y `hasPermission=true` bajo UID 2000.
2. **AccessibilityBridge con filtrado por `displayId`**:
   - Servicio `TunnelTurboAccessibilityService` registrado e integrado.
   - Búsqueda de nodos y ejecución de acciones (`ACTION_SET_TEXT`, `ACTION_CLICK`) restringidas al display del worker.
3. **Provider Runtime con tolerancia a fallos**:
   - Manejo semántico de `"Too many requests"`, pasando a estado `RATE_LIMITED` con política conservadora de cooldown y backoff.
   - Eliminación de tormentas de reintento (máximo 1 reintento automático).
   - Core y comandos locales directos (`open_wifi_settings`, `press_back`) continúan operando con 100% de disponibilidad incluso si el proveedor de IA está saturado o fuera de línea.
