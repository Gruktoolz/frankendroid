# MULTI-MODAL PERCEPTION ARCHITECTURE SPECIFICATION (V2)

**Date:** October 17, 2026  
**System:** Tunnel Turbo Controller — Phase 12 Architecture Design  
**Scope:** Specification for multi-tier sensory observation, semantic coverage detection, atomic world snapshots, unified element references, and visual fallback policies.

---

## 1. Perception Tiering Model (S0 to S3)

Tunnel Turbo V2 replaces ad-hoc UI scraping with a formal 4-layer sensory architecture managed by `PerceptionRouter`:

```
                       ┌─────────────────────────┐
                       │    PerceptionRouter     │
                       └────────────┬────────────┘
                                    │
           ┌────────────────────────┼────────────────────────┐
           ▼                        ▼                        ▼
    ┌─────────────┐          ┌─────────────┐          ┌─────────────┐
    │  S0 SYSTEM  │          │S1 SEMANTIC  │          │  S3 VISUAL  │
    │    PROBE    │          │    PROBE    │          │    PROBE    │
    └──────┬──────┘          └──────┬──────┘          └──────┬──────┘
           │                        │ (if ambiguous)         │ (if coverage
           │                        ▼                        │  insufficient)
           │                 ┌─────────────┐                 │
           │                 │S2 STRUCTURAL│                 │
           │                 │    PROBE    │                 │
           │                 └──────┬──────┘                 │
           │                        └────────────────────────┤
           ▼                                                 ▼
    ┌──────────────────────────────────────────────────────────────┐
    │                        WorldSnapshot                         │
    │         (Atomic, Immutable, Timestamped, Single Revision)    │
    └──────────────────────────────────────────────────────────────┘
```

### 1.1 S0: System Probe (Direct OS & Hardware State)
- **Role:** Queries Android framework system services directly via IPC/Binder without touching or rendering UI.
- **Data Sources:**
  - `BluetoothManager` / `BluetoothAdapter`: Is enabled, connected devices, pairing state.
  - `WifiManager` / `ConnectivityManager`: Active network, SSID, Wi-Fi enabled.
  - `MediaSessionManager`: Active playback sessions, playback state (`STATE_PLAYING`, `STATE_PAUSED`), track metadata (title, artist, duration).
  - `AudioManager`: Stream volumes (media, ring, alarm), ringer mode, mute state.
  - `PackageManager`: Installed packages, launcher activities, app versions.
  - `ActivityTaskManager` / `UsageStats`: True foreground package & activity per display.
  - `PowerManager` / `BatteryManager`: Screen state, battery percentage, charging status.
- **Rule:** If a goal can be verified or observed via S0, S1/S2/S3 are completely bypassed. S0 provides 0ms latency, zero token cost, and 100% determinism.

### 1.2 S1: Accessibility Probe (Primary Semantic UI Sensor)
- **Role:** Inspects the logical view hierarchy of Android applications via `TunnelTurboAccessibilityService`.
- **Capabilities & Scope:**
  - Queries `getWindowsOnAllDisplays()` to maintain independent multi-display awareness (Display 0 vs. Worker Display 28).
  - Traverses `AccessibilityWindowInfo` and `AccessibilityNodeInfo` with `FLAG_RETRIEVE_INTERACTIVE_WINDOWS`.
  - Captures: `className`, `text`, `contentDescription`, `stateDescription`, `isClickable`, `isCheckable`, `isChecked`, `isEditable`, `boundsInScreen`, and parent/child hierarchies.
  - Formats tree into token-efficient serialized summaries via `ObservationReducer`.

### 1.3 S2: Structural Probe (Privileged Diagnostic Hierarchy)
- **Role:** Secondary structured hierarchy inspection via `UiAutomation` / `UiDevice.dumpWindowHierarchy()`.
- **Trigger Conditions:** Activated only if `AccessibilityService` connection is suspected to be dropped, frozen, or under system diagnostic profiling.
- **Architectural Reality:** As proven in Phase 12 empirical testing, S2 queries the same underlying OS Accessibility Node Provider as S1. S2 **does not** magically reveal `SurfaceView`, OpenGL canvas, or unmerged Compose elements. It is kept solely as a diagnostic failover.

### 1.4 S3: Visual Probe (Multi-Modal Screenshot & Grounding)
- **Role:** Captures high-fidelity visual frames of the target display and applies visual grounding (bounding box localization / Set-of-Marks) to generate interactive elements.
- **Trigger Conditions:** Activated ONLY when `SemanticCoverageDetector` returns `INSUFFICIENT` or `PARTIAL`, or when S1/S2 fail to detect expected target controls.
- **Implementation Mechanism:**
  - Primary: `AccessibilityService.takeScreenshot(displayId)` (configured with `android:canTakeScreenshot="true"` in Android 16).
  - Privileged Fallback: Shizuku / ADB `screencap -d <displayId> -p` pipe.
- **Optimization:** Raw screenshots are scaled/compressed to WebP (median size ~38KB on worker display, ~140KB on 2.5K physical display).

---

## 2. Semantic Coverage Detector

The `SemanticCoverageDetector` is the intelligent gatekeeper that prevents blind agent action. It evaluates the S1 Accessibility Tree against expected interaction invariants:

```kotlin
enum class CoverageStatus {
    COMPLETE,      // Tree exposes all controls needed for the current goal
    PARTIAL,       // Controls exist but are incomplete or ambiguously labeled
    INSUFFICIENT,   // Target region is empty, unmerged, or Canvas-rendered
    UNKNOWN        // Screen transitioning or loading
}
```

### Coverage Evaluation Rules:
1. **Goal Expectation Rule:** If the goal is "search music" and foreground is `com.spotify.music`, but the tree contains 0 `EditText` nodes and 0 search-related nodes, coverage is **`INSUFFICIENT`** (Triggers immediate S3 escalation).
2. **Interactive Node Ratio Rule:** If a window bounds occupy $[0, 0, W, H]$ but the total interactive child nodes cover less than 15% of the interactive viewport area (e.g., Google Maps SurfaceView), coverage is **`INSUFFICIENT`**.
3. **Empty Text with Rich Visuals:** If interactive nodes have empty `text` and empty `contentDescription` (blank icons), coverage is **`PARTIAL`**.
4. **Action-Stagnation Rule:** If a previous action (e.g. `click_node`) reported success but the semantic tree hash remained 100% identical on subsequent turns, coverage is flagged **`PARTIAL`** for re-inspection.

---

## 3. Unified Element References (`ElementRef`)

The Reasoning Provider must never receive raw screen coordinates. Raw coordinates cause hallucinations, token inflation, and coordinate drift across screen resolutions.

Instead, Tunnel Turbo V2 introduces a unified, opaque identifier: **`ElementRef`**.

### 3.1 Ref Format
- **Semantic Element:** `s:<displayId>:<revisionId>:<nodeIndex>` (e.g., `s:0:184:e17`)
- **Visual Element:** `v:<displayId>:<revisionId>:<visualMarkIndex>` (e.g., `v:0:184:v04`)

### 3.2 Internal Data Structure (Encapsulated in ActionDriver)
```kotlin
data class ElementRef(
    val id: String,                    // e.g. "s:0:184:e17"
    val displayId: Int,                // 0 or 28
    val revisionId: Long,              // 184
    val source: ElementSource,          // ACCESSIBILITY, VISION, SYSTEM
    val bounds: Rect,                  // Rect(48, 120, 1172, 220)
    val centerPoint: Point,            // Point(610, 170)
    val semanticLabel: String,         // "¿Qué quieres escuchar?"
    val className: String?,            // "android.widget.EditText"
    val isClickable: Boolean,
    val confidence: Float              // 1.0 for S1, 0.85-0.99 for S3
)
```

### 3.3 Presentation to Reasoning Model
The LLM prompt sees only clean, readable symbolic labels:
```text
Available UI Elements on Display 0 [Revision 184]:
[e01] Button: "Inicio" (Selected)
[e02] Button: "Buscar"
[e03] Button: "Tu biblioteca"
[v01] SearchBar: "¿Qué quieres escuchar?" (Visual Grounding 98%)
[v02] CategoryCard: "Música" (Visual Grounding 95%)
```
The model decides:
```json
{
  "action": "click",
  "target": "v01"
}
```
The `ActionDriver` resolves `v01` -> internal coordinates `Point(610, 170)` on Display 0 and dispatches the tap.

---

## 4. Ref Invalidation & Temporal Staleness

To eliminate race conditions and ghost taps:
1. Every `ElementRef` is tied strictly to `(displayId, revisionId)`.
2. As soon as an action is executed or an accessibility window event fires, the runtime increments `stateRevision`.
3. All previous `ElementRef` instances become **`STALE`**.
4. If an agent attempts to execute `click("s:0:183:e02")` when the current revision is `184`, `ActionDriver` **immediately rejects** the command with `STALE_ELEMENT_REF` and forces a fresh observation.

---

## 5. Visual Fallback Policy & Rate Limiting

Visual observation is powerful but carries compute and latency overhead. The escalation policy is strictly deterministic:

```
[Start Observation]
         │
         ▼
[Step 1: Check S0 System State] ────────(State conclusive?)────────► [Complete Observation]
         │ No
         ▼
[Step 2: Capture S1 Accessibility Tree]
         │
         ▼
[Step 3: Run SemanticCoverageDetector]
         │
         ├─── Coverage == COMPLETE ────────────────────────────────► [Return WorldSnapshot]
         │
         ├─── Coverage == PARTIAL ──► [Focused S1 Retry (1x)] ──────► [If still partial, escalate]
         │                                                                   │
         └─── Coverage == INSUFFICIENT ──────────────────────────────────────┘
                                                                             │
                                                                             ▼
                                                                  [Step 4: Capture S3 Visual]
                                                                             │
                                                                             ▼
                                                                  [Merge Visual Marks & S1]
                                                                             │
                                                                             ▼
                                                                  [Return WorldSnapshot]
```

### Constraints:
- Maximum 1 semantic retry before visual escalation.
- Never loop infinitely in S1 when coverage is `INSUFFICIENT`.
- Max visual fallbacks per task bounded by session budget (default: 5 visual queries per task).

---

## 6. Atomic World Snapshot Specification

To eliminate the observed bug where `foregroundPackage` showed ChatGPT while visible text showed Spotify, all sensory data must be unified in an atomic, immutable snapshot:

```kotlin
data class WorldSnapshot(
    val snapshotId: String,            // UUID
    val revision: Long,                // Monotonic revision counter
    val capturedAtMs: Long,            // SystemClock.uptimeMillis()
    val displayId: Int,                // Target display (0 or 28)
    val foregroundPackage: String,     // Verified active package on this display
    val foregroundActivity: String,    // Verified top activity
    val windows: List<WindowSummary>,  // Active interactive windows
    val elements: List<ElementRef>,    // Validated interactive elements (S1 + S3)
    val systemState: SystemSnapshot,   // Bluetooth, Wi-Fi, Audio, MediaSession
    val coverage: CoverageStatus,      // Coverage evaluation
    val isValid: Boolean               // Invariant consistency flag
)
```

### Snapshot Consistency Invariants:
1. $\text{snapshot.capturedAtMs} - \text{windowState.capturedAtMs} < 250\text{ ms}$.
2. The `foregroundPackage` must match the owning package of the active focused window.
3. If window hierarchy diverges from the verified foreground activity, `isValid` is set to `false`, and the loop pauses for a 150ms stabilization cycle.

---

## 7. Security, Privacy & `FLAG_SECURE`

1. **`FLAG_SECURE` Windows:** Banking apps, password managers, and DRM content (Netflix, payment gateways) declare `FLAG_SECURE`.
   - Android disables screenshots on secure windows (returns pure black frames or `SecurityException`).
   - S1 Accessibility is also blocked or redacted by the OS.
2. **Behavior on Secure Windows:**
   - `PerceptionRouter` detects `FLAG_SECURE` on the focused window.
   - Sets state to **`VISUAL_UNAVAILABLE`**.
   - The runtime **NEVER guesses or blindly clicks coordinates**.
   - The agent immediately transitions to **`WAITING_USER`** or halts with `TASK_BLOCKED: SECURE_SURFACE_INTERACTION_REQUIRED`.
3. **Privacy Protections:**
   - Raw screenshots are held strictly in ephemeral RAM and never persisted to flash storage by default.
   - Debug logging of raw bitmap data is disabled in production builds.
   - Virtual worker display (Display 28) isolates agent background tasks from user private notifications on Display 0.
