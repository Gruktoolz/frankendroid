# Dynamic Skills & Memory System

## Declarative Data Model (`DynamicSkill.kt`)

Skills in Tunnel Turbo are **strictly declarative data structures**, never executable scripts, eval strings, or arbitrary shell commands.

```json
{
  "skillId": "skill_play_artist",
  "name": "play_artist",
  "description": "Reproduce música de un artista específico en Spotify",
  "goalPattern": "reproducir música de {artist}",
  "parameters": [
    {
      "name": "artist",
      "type": "string",
      "description": "Nombre del artista a reproducir"
    }
  ],
  "preconditions": [
    "app_installed"
  ],
  "steps": [
    {
      "tool": "open_app",
      "arguments": { "package": "com.spotify.music" }
    },
    {
      "tool": "wait_for",
      "arguments": { "condition": "foreground_package", "value": "com.spotify.music", "timeoutMs": 5000 }
    },
    {
      "tool": "click_node",
      "arguments": { "selector": "{text=Buscar}" }
    },
    {
      "tool": "wait_for",
      "arguments": { "condition": "text_exists", "value": "Buscar", "timeoutMs": 5000 }
    }
  ],
  "successConditions": [ "music_playing" ],
  "failureConditions": [ "artist_not_found" ],
  "confidence": 0.90,
  "successCount": 2,
  "state": "VALIDATING",
  "version": 1
}
```

---

## Skill Lifecycle & Promotion Rules

Skills are not activated immediately after a single success:

1. **PROPOSED**:
   - Synthesized after a single successful multi-step sequence.
   - Requires parameterization (e.g. `Michael Jackson` -> `{artist}`).
   - Registered in `SkillCandidate` and `SkillMemory`.

2. **VALIDATING**:
   - Reused successfully on a distinct parameter variation (e.g. `Prince` vs `Michael Jackson`).
   - `examplesSeen >= 2` and `parameterVariations >= 2`.

3. **ACTIVE**:
   - Promoted after 3+ verified successes across distinct parameter variations with 0 critical failures.
   - Becomes a default execution route for matching natural language goals.

4. **DEPRECATED**:
   - Transitioned if UI changes cause consecutive execution failures and `SkillRepairCandidate` fails.

---

## Skill Memory Persistence (`SkillMemory.kt`)

Stored in `skills_memory.json` in internal storage:
- Thread-safe ConcurrentHashMap collections.
- Full inspection, deletion, and debugging via DevTools endpoints:
  - `/debug_get_skills`
  - `/debug_get_skill?skillId=...`
  - `/debug_get_skill_candidates`
