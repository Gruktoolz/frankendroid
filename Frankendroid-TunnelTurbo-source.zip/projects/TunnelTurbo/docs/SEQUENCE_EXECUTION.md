# Sequence Execution Engine — Tunnel Turbo Controller

El **Sequence Executor** permite a modelos de lenguaje (como Antigravity) enviar planes de acción estructurados y deterministas en **una sola llamada de herramienta MCP** (`tunnel_execute_sequence`), reduciendo los viajes redondos (round-trips) entre el modelo y el dispositivo Android.

---

## 1. Motivación y Arquitectura

En tareas multi-paso comunes (ej. *"Abre Wi-Fi, vuelve atrás y abre Bluetooth"*), el flujo tradicional requiere:
```
Modelo -> Tool 1 -> Espera resultado -> Modelo -> Tool 2 -> Espera resultado -> Modelo -> Tool 3
```
Esto genera una penalización severa de latencia debido a los múltiples turnos de inferencia del LLM y consumo de tokens de red.

Con Sequence Executor, el flujo se colapsa a:
```
Modelo -> tunnel_execute_sequence(steps=[...])
           |
           +--> Step 1 -> Local ActionEngine -> Persistent Observer -> Local Verifier
           |
           +--> Step 2 -> Local ActionEngine -> Persistent Observer -> Local Verifier
           |
           +--> Step 3 -> Local ActionEngine -> Persistent Observer -> Local Verifier
           |
           +--> Devuelve resumen estructurado al Modelo (1 solo round-trip)
```

---

## 2. Acciones Soportadas

El motor V1 es intencionalmente simple y estricto. No admite lenguajes de scripting dinámicos, bucles ni código ejecutable. Soporta exclusivamente las acciones nativas registradas:

| Acción | Alias Aceptados | Argumentos Requeridos | Descripción |
| :--- | :--- | :--- | :--- |
| `open_settings` | `settings` | Ninguno | Abre la pantalla principal de Ajustes Android. |
| `open_wifi_settings` | `open_wifi`, `wifi` | Ninguno | Abre directamente los ajustes de Wi-Fi. |
| `open_bluetooth_settings` | `open_bluetooth`, `bluetooth` | Ninguno | Abre directamente los ajustes de Bluetooth. |
| `open_app` | — | `package` (string) | Lanza una aplicación por su package name. |
| `press_key` | `key` | `key` (`"BACK"`, `"HOME"`, `"ENTER"`) | Simula pulsación de tecla física o navegación. |
| `press_back` | `back` | Ninguno | Simula tecla Atrás. |
| `press_home` | `home` | Ninguno | Simula tecla Inicio. |
| `semantic_tap` | `tap` | `selector` (string), `match` (`"single"`, `"first"`) | Pulsa un elemento semántico en pantalla. |

---

## 3. Validación Fail-Fast

Antes de ejecutar el primer paso, `SequenceExecutor.validate()` comprueba todos los pasos de la lista:
- Si una acción no existe en `ALLOWED_ACTIONS` -> **Rechazo inmediato**.
- Si faltan argumentos obligatorios (como `package`, `key` o `selector`) -> **Rechazo inmediato**.
- Si un argumento tiene un valor no permitido -> **Rechazo inmediato**.

Ningún comando parcial o erróneo es despachado al dispositivo Android si la secuencia contiene errores de validación.

---

## 4. Política de Parada en Fallo (`stop_on_failure`)

Por defecto, `stop_on_failure=True`. Si el paso $N$ no logra verificarse o falla su ejecución:
- Los pasos restantes ($N+1 \dots M$) **no se ejecutan**.
- El estado reporta:
  ```json
  {
    "success": false,
    "completed_steps": 1,
    "failed_step": 2,
    "remaining_steps": 1,
    "error": "Step 2 (open_app) failed verification."
  }
  ```

---

## 5. Resultados del Benchmark Star Test

| Métrica | Fase 4 (Llamadas Individuales) | Fase 5 (Sequence Executor) | Mejora |
| :--- | :--- | :--- | :--- |
| **Model Tool Calls** | 3 llamadas | **1 llamada** | **3x reducción de round-trips** |
| **Core Latency** | ~630 ms | **613.77 ms** | Equivalente (~204 ms/paso) |
| **MCP Overhead** | 0.019 ms | **0.005 ms** | Cero overhead |
| **Payload Size** | ~3 KB acumulados | **935 Bytes** | **68% reducción de bytes** |
| **Screenshots / Layouts** | 0 / 0 | **0 / 0** | **Cero percepción costosa** |
