# Arquitectura del Sistema — Túnel Turbo Controller

## Visión General
Túnel Turbo Controller actúa como mediador de alta velocidad entre Antigravity y dispositivos Android, exponiendo una interfaz de herramientas estructuradas (MCP) sobre `stdio`.

```
                    ┌────────────────────────┐
                    │    Antigravity IDE     │
                    └───────────┬────────────┘
                                │ (MCP stdio - JSON-RPC)
                    ┌───────────▼────────────────────────────────────────┐
                    │               Túnel Turbo Controller               │
                    │                                                    │
                    │  ┌────────────────────────┬─────────────────────┐  │
                    │  │   MCP Server Tools     │  Sequence Executor  │  │
                    │  └───────────┬────────────┴──────────┬──────────┘  │
                    │              │                       │             │
                    │  ┌───────────▼───────────────────────▼──────────┐  │
                    │  │                 Action Engine                │  │
                    │  │         (Semantic Resolver, Direct)          │  │
                    │  └───────────┬───────────────────────┬──────────┘  │
                    │              │                       │             │
                    │  ┌───────────▼────────────┐ ┌────────▼──────────┐  │
                    │  │      State Engine      │ │   Event Journal   │  │
                    │  │ (RAM Cache, Revisions) │ │   (Ring Buffer)   │  │
                    │  └───────────┬────────────┘ └────────▲──────────┘  │
                    │              │                       │             │
                    │  ┌───────────▼───────────────────────┴──────────┐  │
                    │  │             Persistent Observer              │  │
                    │  │       (Adaptive IDLE / ACTIVE Polling)       │  │
                    │  └───────────┬───────────────────────┬──────────┘  │
                    │              │                       │             │
                    │        ┌─────┴──────┐          ┌─────┴──────┐      │
                    │        │            │          │            │      │
                    │    ┌───▼────┐   ┌───▼───┐  ┌───▼────┐   ┌───▼───┐  │
                    │    │Android │   │  ADB  │  │Android │   │  ADB  │  │
                    │    │  CLI   │   │Client │  │  CLI   │   │Client │  │
                    │    └───┬────┘   └───┬───┘  └───┬────┘   └───┬───┘  │
                    └────────┼────────────┼──────────┼────────────┼──────┘
                             │            │          │            │
                    ┌────────▼────────────▼──────────▼────────────▼──────┐
                    │                Dispositivo Android                 │
                    └────────────────────────────────────────────────────┘
```

## Componentes Principales

1. **ADB Client (`controller/adb/client.py`)**:
   - Detección y ciclo de vida de dispositivos conectados.
   - Consulta de propiedades del sistema (`getprop`).
   - Identificación de ventana y Activity en primer plano (`dumpsys window` / `dumpsys activity`).
   - Dimensiones de pantalla (`wm size`).
   - Allowlist estricta de comandos; sin exposición de shell arbitrario.

2. **Android CLI Client (`controller/android_cli/client.py`)**:
   - Extracción de jerarquía UI estructurada viva mediante `android layout --flat --no-idle`.
   - Limpieza y parseo de respuestas JSON evitando caídas por mensajes de inicialización.
   - Fallback secundario de interacción táctil.

3. **State Engine & Diff (`controller/state/`)**:
   - Mantenimiento del último estado lógico del dispositivo (`DeviceState`) en memoria RAM.
   - Sistema de revisiones monotónicas (`revision 1 -> 2 -> ...`).
   - Gestión estricta de estado de caché (`stale` y `dirty`).

4. **Event Journal (`controller/state/events.py`)**:
   - Búfer circular en RAM (capacidad de 1,000 eventos).
   - Registro con timestamp y revisión de cambios de ventana, apps, orientaciones y ciclo de vida de acciones.
   - Paginación determinista sin truncado silencioso mediante `tunnel_get_changes(since_revision, limit=100)`.
   - Incluye cursores `next_revision`, `events_available`, `events_returned`, `remaining` y `truncated`.

5. **Persistent Observer & Adaptive Backoff (`controller/observer/persistent.py`)**:
   - Tarea asíncrona continua que mantiene actualizado el Fast State.
   - Backoff adaptativo: `ACTIVE` (~20–30 ms), `SETTLE` (250 ms), `RECENT_ACTIVE` (500 ms), `STEADY` (1000 ms), `EXTENDED_IDLE` (2000 ms).
   - Separación estricta de señales: `STATIC` (cacheado en init, nunca en polling), `DISPLAY` (ocasional >60s), `FOREGROUND` (señal principal ~79 ms).
   - Reducción del uso del bus ADB en reposo de 12.4% a 3.95%–8.91% y tráfico a ~11.5 KB/min.
   - Cero llamadas a layout en segundo plano y cero capturas de pantalla.

6. **Device Tracker (`controller/observer/device_tracker.py`)**:
   - Conexión persistente mediante el servicio oficial `adb track-devices`.
   - Notificaciones push en tiempo real ante eventos de conexión (`device_connected`, `device_disconnected`, `device_offline`).
   - Elimina al 100% el sondeo periódico de conectividad.

7. **Action Engine & Semantic Resolver (`controller/actions/`)**:
   - `act_and_observe`: Toma instantánea, ejecuta acción semántica o directa, detecta primer cambio relevante, verifica y devuelve diff + métricas de latencia.
   - Resolución semántica local en RAM en ~100 µs despachando taps directamente vía ADB.
   - Detiene inmediatamente el modo `ACTIVE` del observer al confirmar la verificación.

8. **Sequence Executor (`controller/actions/sequence.py`)**:
   - Ejecución local por lotes de acciones deterministas pre-validadas (Fail-Fast).
   - Elimina la necesidad de múltiples turnos de inferencia con el modelo (1 tool call para N acciones).
   - Parada automática en caso de fallo (`stop_on_failure`).

9. **Servidor MCP (`controller/mcp_server/server.py`)**:
   - Implementado mediante el SDK oficial de Python `mcp` (v2.3.0).
   - Transporte estricto por `stdio` con stdout reservado para JSON-RPC.
   - Herramienta `tunnel_get_state(mode="cached")` enriquecida con `age_ms`, `foreground_age_ms`, `observer_mode`, `device_tracker`.
   - Herramienta `tunnel_get_changes(since_revision, limit=100)` con paginación explícita.
   - 12 herramientas públicas expuestas con docstrings orientados a LLM.

10. **Traductor de Intención y Validador Determinista (`controller/model/`)**:
   - **`IntentModel` (`controller/model/base.py`)**: Interfaz abstracta agnóstica de proveedor.
   - **`OllamaIntentModel` (`controller/model/ollama_provider.py`)**: Conexión hacia modelos locales (`qwen3:4b`, `qwen3:direct`) mediante JSON Schema estricto.
   - **`FunctionGemmaIntentModel` (`controller/model/functiongemma_provider.py`)**: Conexión hacia `functiongemma:270m`.
   - **`PlanValidator` (`controller/model/validator.py`)**: Validador determinista de 21 µs que protege al Core de alucinaciones, scripts shell, inyecciones y coordenadas arbitrarias.
   - El modelo es considerado NO CONFIABLE; jamás ejecuta directamente sobre Android.

11. **AI App Worker & Aislamiento de Display (`controller/model/app_worker/`)**:
   - **`AndroidAiAppIntentModel` (`controller/model/ai_app_provider.py`)**: Inferencia remota delegada a aplicaciones de razonamiento instaladas (ChatGPT Mobile) en un Virtual Display secundario.
   - **`VirtualDisplayManager` (`controller/model/app_worker/display.py`)**: Despliegue de display virtual scrcpy aislado con política `--display-ime-policy=hide` (0 apariciones de teclado en Display #0).
   - **`WorkerSession` (`controller/model/app_worker/session.py`)**: Hilo de conversación persistente y control de rotación (20 solicitudes consecutivas en 1 sola conversación, 0 fugas de contexto mediante nonces `TT_XXXXXX` autocontenidos).
   - **`WorkerPromptBuffer` (`controller/model/app_worker/buffer.py`)**: Almacenamiento en memoria privada del Controller (0 uso de portapapeles en ruta principal).
   - **`TunnelWorkerBridge` (`controller/model/app_worker/worker_bridge.dex`)**:
     - Inyección rápida keyboardless mediante `AccessibilityNodeInfo.ACTION_SET_TEXT`.
     - Envío semántico nativo mediante `AccessibilityNodeInfo.ACTION_CLICK` (0 coordenadas fijas).
     - Percepción estructurada directa de nodos accesibles (0 capturas de pantalla, 0 OCR).
     - Fallback aislado `CLIPBOARD_PASTE_RESTORE` documentado con restricciones de seguridad de Android.

12. **Tunnel Turbo APK Skeleton & Provider Runtime (`android-app/`)**:
   - **`LocalIntentRouter`**: Enrutador determinista local de baja latencia (~0.15 ms) que resuelve intenciones conocidas ("Abre Wi-Fi", "Regresa", "Inicio") sin consultar modelos de IA (0 llamadas de red, 0 tokens consumidos).
   - **`ProviderRuntime` & `RateLimitPolicy`**: Máquina de estados que administra la disponibilidad del proveedor remoto (`READY`, `BUSY`, `RATE_LIMITED`, `OFFLINE`). Convierte respuestas *"Too many requests"* en estados estructurados con backoff exponencial estricto (máximo 1 reintento automático; 0 bucles infinitos de reintento).
   - **`IntentRequestQueue`**: Cola FIFO de intenciones con concurrencia de IA = 1.
   - **`ShizukuBridge`**: Enlace con Shizuku IPC (`moe.shizuku.privileged.api`) con UID 2000 verificado en hardware.
   - **`AccessibilityBridge` & `TunnelTurboAccessibilityService`**: Servicio de accesibilidad registrado nativo en el dispositivo con filtrado por `displayId`.
   - **`TunnelCoreAdapter`**: Fachada que desacopla la UI de la ubicación física del Core durante la transición PC -> teléfono.

## Próxima Fase: Fase 9 — Migración del Core a Android Nativo
> [!NOTE]
> Con la APK Skeleton, Shizuku, Accessibility, el Provider Runtime y el Router Local validados al 100% en el dispositivo (Fase 8), la siguiente fase se enfoca en mover gradualmente el StateEngine, EventJournal, ActionEngine y Verifier desde la PC hacia Android Nativo.

