# TUNNEL TURBO AGENT ARCHITECTURE V2 SPECIFICATION

**Date:** October 17, 2026  
**System:** Tunnel Turbo Controller — Phase 12 Architecture Design  
**Scope:** Specification for the unified, single-authority agent runtime, canonical tool-use loop, progress/stuck detectors, durable goal lifecycle, and budgeting.

---

## 1. System Architecture Diagram

```text
                                USER
                                  │
                                  ▼
                         LanguageFrontend
                                  │
                                  ▼
                           AgentSession ◄─────────────────────────┐
                      (Single Task Authority)                     │
                                  │                               │
                 ┌────────────────┴───────────────┐               │
                 ▼                                ▼               │
          PerceptionRouter                 ProviderRouter         │
                 │                                │               │
                 ▼                                ▼               │
           WorldSnapshot ───────────────►  ReasoningProvider      │
                 ▲                                │               │
                 │ (State Delta)                  ▼               │
                 └───────────────────────── ActionDriver          │
                                                  │               │
                                                  ▼               │
                                               Android            │
                                                  │               │
                                                  ▼               │
                                             GoalVerifier         │
                                                  │               │
                                                  ▼               │
                                           ProgressDetector       │
                                                  │               │
                                                  ▼               │
                                            StuckDetector         │
                                                  │               │
                                                  └───────────────┘

                      Supporting Services (Non-competing):
              • SkillMemory (Experience Cache & Trace Traversal)
              • InteractionPolicy (User Approvals & Confirmations)
              • DevToolsBridge V2 (Inspection & Diagnostic Probes)
```

---

## 2. The Single Task Authority: `AgentSession`

In Architecture V2, **`AgentSession`** is the sole authority managing task execution. Competing loops and heuristic coordinators (`IntentCoordinator`, `AdaptivePlanner`) are permanently eliminated.

### 2.1 Responsibilities of `AgentSession`:
1. Holds and updates the **Durable Goal** state machine.
2. Enforces **Budget Limits** (actions, tokens, wall-clock time, visual queries).
3. Maintains the **Current Atomic WorldSnapshot**.
4. Records the append-only **Session Journal** (actions, traces, provider calls).
5. Orchestrates the canonical **Step Loop**.
6. Handles external interruptions, cancellations, and user clarification requests.

### 2.2 Components as Services, Not Brains:
No sub-component is permitted to launch its own independent agent loop or declare task victory:
- **`PerceptionRouter`:** Measures state (S0-S3). It does not decide what actions to take.
- **`ProviderRouter`:** Selects the active LLM backend (Worker ChatGPT, Claude, Gemini, API).
- **`ReasoningProvider`:** Proposes the *next logical action* based on the current `WorldSnapshot`. It is an advisor, not a judge.
- **`ActionDriver`:** Executes tools safely against Android.
- **`GoalVerifier`:** Evaluates completion evidence against objective criteria.
- **`ProgressDetector` & `StuckDetector`:** Detect momentum and stagnation to guard the loop.
- **`SkillMemory`:** Supplies historical successful paths to accelerate execution.

---

## 3. The Canonical Tool-Use Loop

The execution loop follows the proven, battle-tested computer-use paradigm:

```kotlin
fun executeLoop(goal: Goal): SessionResult {
    while (goal.status == GoalStatus.ACTIVE) {
        // 1. Check Budgets
        if (budget.isExhausted()) {
            goal.transitionTo(GoalStatus.BUDGET_LIMITED)
            break
        }

        // 2. Multi-Tier Perception
        val snapshot = perceptionRouter.captureSnapshot(displayId = goal.targetDisplay)
        session.currentSnapshot = snapshot

        // 3. Independent Goal Verification
        val verification = goalVerifier.evaluate(goal, snapshot, session.history)
        if (verification.isComplete) {
            goal.transitionTo(GoalStatus.COMPLETE_VERIFIED, verification.evidence)
            break
        }

        // 4. Progress & Stuck Detection
        val progress = progressDetector.evaluate(session.previousSnapshot, snapshot, goal)
        val stuckState = stuckDetector.check(session.history, snapshot, progress)
        if (stuckState.isStuck) {
            val recoveryAction = handleStuck(stuckState)
            if (!recoveryAction.canRecover) {
                goal.transitionTo(GoalStatus.BLOCKED, stuckState.reason)
                break
            }
        }

        // 5. Reasoning Provider Turn
        val decision = reasoningProvider.decideNextStep(
            goal = goal,
            snapshot = snapshot,
            history = session.recentActions,
            availableCapabilities = capabilityRegistry.getAdvertisedSchemas()
        )

        // 6. Handle Special Decision Types
        if (decision.isAskUser) {
            goal.transitionTo(GoalStatus.WAITING_USER, decision.question)
            break
        }
        if (decision.isDeclareDone) {
            // Model thinks it is done; verify immediately with GoalVerifier
            val finalCheck = goalVerifier.evaluate(goal, snapshot, session.history)
            if (finalCheck.isComplete) {
                goal.transitionTo(GoalStatus.COMPLETE_VERIFIED, finalCheck.evidence)
            } else {
                goal.transitionTo(GoalStatus.COMPLETE_UNVERIFIED, "Model claimed done but evidence was missing")
            }
            break
        }

        // 7. Execute Action via Driver
        val stepResult = actionDriver.execute(decision.action, snapshot.revision)
        session.recordStep(decision, stepResult)

        // 8. Handle Batched Local Actions (if applicable)
        if (decision.hasSubsequentSafeLocalAction) {
            actionDriver.execute(decision.subsequentSafeAction, snapshot.revision)
        }

        // 9. Tick Budget
        budget.consumeAction()
    }

    return session.finalize()
}
```

---

## 4. Progress and Stuck Detectors

### 4.1 `ProgressDetector`
Evaluates the sensory delta between snapshot $N-1$ and snapshot $N$.
- **`PROGRESS`:**
  - Desired target application came to foreground.
  - Expected UI element (e.g. search input field) became visible.
  - System state changed closer to target (e.g., Bluetooth turning on, Media playback started).
  - Target text or query confirmation appeared in node tree or visual marks.
- **`NO_PROGRESS`:**
  - No change in foreground, window hierarchy, or system state after action.
- **`REGRESSION`:**
  - App crashed, was minimized, or returned to home screen unexpectedly.
- **`UNKNOWN`:**
  - Transient spinner or loading state.

### 4.2 `StuckDetector`
Maintains an observation ring buffer to catch loops before budgets are wasted.
- **Stuck Conditions:**
  1. **Hash Repetition:** Identical `WorldSnapshot` tree hash across 3 consecutive action attempts.
  2. **Action Oscillation:** Alternating sequence `A -> B -> A -> B` (e.g., clicking open/close toggle repeatedly).
  3. **Continuous No-Progress:** 4 consecutive actions yielding `NO_PROGRESS`.
  4. **Provider Hallucination Loop:** Model proposing the same invalid `ElementRef` multiple times.
- **Remediation Strategy:**
  1. *Level 1:* Escalate perception tier (e.g., if S1 failed repeatedly, trigger S3 Visual Probe).
  2. *Level 2:* Invalidate view cache, press Back to clear stuck modal, and re-observe.
  3. *Level 3:* Halt immediately with `GoalStatus.BLOCKED` and prompt user for manual assistance.

---

## 5. Budget Management & Profiles

Every goal execution is constrained by an immutable budget profile:

| Profile | Max Steps | Max Provider Calls | Max Visual Fallbacks | Max Wall-Clock Time | Use Case |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`FAST`** | 6 actions | 6 calls | 1 screenshot | 30 seconds | Quick settings toggles, launching apps, simple volume adjustments. |
| **`NORMAL_AGENT`** | 15 actions | 12 calls | 4 screenshots | 90 seconds | In-app searches (Spotify song, Maps location), form filling, navigation. |
| **`LONG_TASK`** | 35 actions | 30 calls | 10 screenshots | 300 seconds | Complex multi-app workflows, research, file management, multi-step tasks. |

If a budget limit is reached, execution terminates with `BUDGET_LIMITED`. Under no circumstances is the agent allowed to run for 30 minutes in an uncontrolled loop.

---

## 6. Durable Goal Lifecycle

Tunnel Turbo V2 adopts formal durable goal states inspired by mature runtimes:

```text
                  ┌───────────────┐
                  │    CREATED    │
                  └───────┬───────┘
                          │
                          ▼
                  ┌───────────────┐
      ┌──────────►│    ACTIVE     │◄──────────┐
      │           └───────┬───────┘           │
      │                   │                   │
(User Responds)           ├───────────────────┼───────────────────┐
      │                   ▼                   ▼                   ▼
┌─────┴────────┐  ┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ WAITING_USER │  │    BLOCKED    │   │BUDGET_LIMITED │   │PROVIDER_LIMIT │
└──────────────┘  └───────────────┘   └───────────────┘   └───────────────┘
                          │
                          ▼
           ┌──────────────────────────────┐
           │        TERMINAL STATES       │
           ├──────────────────────────────┤
           │ • COMPLETE_VERIFIED          │
           │ • COMPLETE_UNVERIFIED        │
           │ • FAILED                     │
           │ • CANCELLED                  │
           └──────────────────────────────┘
```

**Crucial Invariant:**  
`BLOCKED != COMPLETE`  
`BUDGET_LIMITED != COMPLETE`  
`PROVIDER_LIMITED != COMPLETE`  
Never report user success unless `GoalVerifier` establishes empirical verification.

---

## 7. Future Capability Foundations

### 7.1 DynamicSkills: Experience Caching
A Skill is not a hardcoded Java/Kotlin class. A Skill is a recorded **Trajectory**:
$$\text{Trajectory} = [(\text{Snapshot}_1, \text{Action}_1), (\text{Snapshot}_2, \text{Action}_2), \dots]$$
When an agent successfully completes a goal (e.g. "Play Bohemian Rhapsody on Spotify"), `SkillMemory` persists the sequence of anchor elements and actions. Next time, `SkillMemory` offers a fast replay path. If any anchor fails or UI drifts, it immediately falls back to the general `AgentSession` loop.

### 7.2 Human Demonstration Ingestion
Inspired by AppAgent: A future recording service allows a user to perform an action manually on Display 0. Tunnel Turbo records `(WorldSnapshot, UserTouch, TargetRef)` and compiles it into an executable `SkillCandidate`.

### 7.3 Multi-Provider Independence
`AgentSession`, `PerceptionRouter`, `ActionDriver`, and `GoalVerifier` have zero provider-specific code. The `ReasoningProvider` interface can be swapped between:
- Background ChatGPT Mobile Worker (Display 28)
- Anthropic Claude Tool-Use API
- OpenAI Computer-Use API
- Local on-device LLM (DeepSeek / Gemini Nano / Qwen via Shizuku/NPU)

---

## 8. DevTools V2 Diagnostic Endpoints

To support inspection, debugging, and automated contract testing, `DevToolsBridge` will expose the following REST/WebSocket endpoints in Phase 13:

1. `GET /api/v2/perception/sources` — Returns status and latency of S0, S1, S2, and S3 probes.
2. `GET /api/v2/snapshot/consistency` — Validates synchronization between foreground, windows, and node trees.
3. `GET /api/v2/semantic/coverage` — Returns current `CoverageStatus` and ratio metrics for active screen.
4. `GET /api/v2/elements/refs` — Returns all active `ElementRef` tokens for the current revision.
5. `GET /api/v2/progress/state` — Inspects recent `ProgressDetector` classifications.
6. `GET /api/v2/stuck/diagnostics` — Inspects repetition hashes and stuck detector buffers.
7. `GET /api/v2/capabilities/contract` — Runs automated schema validation and executor dispatch check (`ADVERTISED == EXECUTABLE`).
