# CURRENT RUNTIME FLOW — TUNNEL TURBO CONTROLLER
**Fecha:** 17 de octubre de 2026  
**Auditoría de Arquitectura Real (Fase 9.5)**

Este documento traza con precisión de código el flujo real de ejecución de Tunnel Turbo tal como está implementado hoy, documentando cada clase, archivo, método y parámetro sin especulaciones.

---

## 1. Flujo de Ejecución DIRECT: "Abre Wi-Fi"

### Paso 1: Entrada de Usuario en UI
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/ui/MainActivity.kt`
- **Componente / Trigger:**
  - Opción A: Botón `btnQuickWifi` -> `onClick` invoca `executeIntent("Abre Wi-Fi", source = "BUTTON_WIFI")`.
  - Opción B: Campo `etCommandInput` con texto "Abre Wi-Fi" y tap en `btnSend` -> invoca `executeIntent("Abre Wi-Fi", source = "TEXT_SEND")`.
- **Método:** `MainActivity.executeIntent(userText: String, source: String)`
  - Incrementa contador de solicitud `uiRequestCounter` -> `TT_UI_0001`.
  - Normaliza texto para vista previa: `providerRuntime.router.normalize(userText)`.
  - Actualiza estado visual transitorio a `ESTADO: PLANNING...`.
  - Lanza corrutina en background: `lifecycleScope.launch(Dispatchers.Default)`.

### Paso 2: Despacho a ProviderRuntime
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/provider/ProviderRuntime.kt`
- **Método:** `suspend fun processUserIntent(userText: String, inputSource: InputSource = InputSource.TEXT): ProcessResult`
  - Genera ID de solicitud interna: `nextRequestId()` -> `"TT_000001"`.
  - Inicia temporizador `t0 = System.nanoTime()`.

### Paso 3: Ruteo Local Determinista
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/router/LocalIntentRouter.kt`
- **Método:** `fun route(rawText: String): RouteResult`
  - Normalización en `normalize(rawText)`:
    * Convierte a minúsculas (`lowercase()`).
    * Elimina acentos/diacríticos (`normalizeNfdAccents`).
    * Elimina puntuación (`.,;:!¡?¿"'()`).
    * Colapsa espacios en blanco repetidos.
    * Resultado: `"abre wifi"`.
  - Evaluación en bloque `when (cleaned)`:
    * Coincidencia exacta con `"abre wifi"` o `"wifi"`.
  - Retorna `RouteResult`:
    * `decision = RouteDecision.DIRECT`
    * `directPlan = ActionPlan(action = "open_wifi_settings")`
    * `confidence = 1.0`
    * `reason = "Deterministic direct match: open_wifi_settings"`
    * `routingElapsedMs = ~0.28 ms`

### Paso 4: Ejecución a través del Adaptador Core
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/adapter/TunnelCoreAdapter.kt`
- **Método:** `fun executePlan(plan: StructuredPlan): ExecutionResult`
  - Evalúa `backendMode` (`CoreBackendMode.NATIVE_ANDROID`).
  - Llama a `runBlocking { nativeCore.executePlan(plan) }`.

### Paso 5: Fachada NativeTunnelCore
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/core/NativeTunnelCore.kt`
- **Método:** `suspend fun executePlan(plan: StructuredPlan): ExecutionResult`
  - Reconoce tipo de plan: `is ActionPlan`.
  - Llama a `actionEngine.executeAction(plan, verify = true)`.

### Paso 6: Motor Nativo de Acciones y Seguridad
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/core/NativeActionEngine.kt`
- **Método:** `suspend fun executeAction(actionPlan: ActionPlan, isWorkerOperation: Boolean = false, verify: Boolean = true): ActionResult`
  - Captura estado inicial: `initialRev`, `initialPkg`, `initialActivity` desde `stateEngine.currentState`.
  - Registra evento en `NativeEventJournal`: `action_started` con acción `"open_wifi_settings"`.
  - Verifica aislamiento de pantalla con `DisplayTargetPolicy.isTargetAllowed(targetDisplay, isWorkerOperation)`:
    * `targetDisplay = 0`, `isWorkerOperation = false` -> Permitido.
  - Ejecuta despacho Android nativo:
    ```kotlin
    val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)
    ```
  - Si `verify == true` y `context != null`:
    * Invoca `verifier.verifyAction("open_wifi_settings", args, initialRev, initialPkg, initialActivity)`.

### Paso 7: Verificación Event-Driven
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/core/NativeVerifier.kt`
- **Método:** `suspend fun verifyAction(actionName: String, ...): VerificationOutcome`
  - Evalúa condición de éxito:
    ```kotlin
    val state = stateEngine.currentState
    state.foregroundPackage == "com.android.settings" &&
      (state.foregroundActivity.contains("Wifi", ignoreCase = true) ||
       state.foregroundActivity.contains("Settings", ignoreCase = true))
    ```
  - Espera confirmación reactiva del estado del sistema.
  - Retorna `VerificationOutcome(verified = true, details = "Acción open_wifi_settings verificada exitosamente", elapsedMs = ~100-300ms)`.

### Paso 8: Registro en Journal y Retorno de Resultado
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/core/NativeEventJournal.kt`
  - Registra `action_completed` con `success = true`.
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/provider/ProviderRuntime.kt`
  - Empaqueta `ProcessResult(success = true, routeDecision = DIRECT, requestId = "TT_000001", ...)`.

### Paso 9: Notificación y Renderizado en UI
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/ui/MainActivity.kt`
  - Recibe `res` en corrutina background y emite bloque de diagnóstico estructurado a Logcat tag `TT_UI`.
  - Salta al hilo principal: `withContext(Dispatchers.Main)`.
  - Invoca `updateStatuses()` para refrescar Shizuku, Accessibility y Provider.
  - Actualiza `tvExecutionStatus`: `ESTADO: DONE` en color `#00E676`.
  - Inserta en `tvLogOutput`:
    `-> ÉXITO | Ruta: DIRECT | Acción: open_wifi_settings | Total: 435.8ms`.

---

## 2. Flujo de Ejecución AI_REQUIRED: "Abre Wi-Fi y después vuelve atrás"

### Paso 1: Entrada de Usuario
- **Archivo:** `MainActivity.kt`
- **Método:** `executeIntent("Abre Wi-Fi y después vuelve atrás", source = "TEXT_SEND")`
- Genera etiqueta de solicitud `TT_UI_0002` y envía a `providerRuntime.processUserIntent(...)`.

### Paso 2: Ruteo Local con Decisión AI_REQUIRED
- **Archivo:** `LocalIntentRouter.kt`
- **Método:** `route(rawText)`
  - Texto limpio: `"abre wifi y despues vuelve atras"`.
  - No coincide con diccionario directo atómico ni directo compuesto estricto.
  - Retorna `RouteResult(decision = RouteDecision.AI_REQUIRED, confidence = 0.9, reason = "Complex or multi-step command requires AI app planner")`.

### Paso 3: Coordinación de Inferencia en ProviderRuntime
- **Archivo:** `ProviderRuntime.kt`
- **Método:** `processUserIntent(...)` -> Rama `RouteDecision.AI_REQUIRED`
  - Verifica políticas de Rate Limit: `if (health.rateLimited && System.currentTimeMillis() < health.cooldownUntil)`.
  - Adquiere bloqueo de concurrencia: `aiMutex.withLock`.
  - Actualiza estado: `health.state = ProviderState.BUSY`.
  - Invoca `activeProvider.processIntent(userText, reqId)`.

### Paso 4: Provider Android AI App
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/provider/AndroidAiAppProvider.kt`
- **Método:** `suspend fun processIntent(userText: String, requestId: String): ProviderResponse`
  - Inicia sesión de conversación: `workerSession.createSession(requestId)`.
  - Verifica que el display virtual del worker esté listo: `workerBridge.ensureWorkerReady()`.
  - Envía prompt formateado con el esquema del sistema: `workerBridge.sendPrompt(userText, requestId)`.

### Paso 5: Puente con la App de IA en Virtual Display
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/worker/AiWorkerBridge.kt`
- **Método:** `suspend fun sendPrompt(prompt: String, requestId: String): Boolean`
  - Localiza el nodo de entrada en el display virtual del AI Worker mediante `accessibilityBridge.findNode(workerDisplayId) { isEditable }`.
  - Inyecta texto: `accessibilityBridge.performSetText(inputNode, prompt)`.
  - Busca el botón de envío y ejecuta click: `accessibilityBridge.performClick(sendBtnNode)`.
- **Método:** `suspend fun readResponse(requestId: String, timeoutMs: Long): String?`
  - Observa el árbol de accesibilidad en `workerDisplayId` esperando la respuesta generada por la app externa (ChatGPT Mobile / proveedor).
  - Extrae el texto semántico estructurado JSON:
    `{"type":"sequence","steps":[{"action":"open_wifi_settings"},{"action":"press_back"}]}`.
  - Retorna `rawResponse`.

### Paso 6: Validación Determinista del Plan (Fail-Closed)
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/model/PlanValidator.kt`
- **Método:** `fun validatePlan(planJson: String): StructuredPlan`
  - Parsea JSON con `JSONObject`.
  - Inspecciona claves permitidas: `type`, `steps`, `action`, `arguments`.
  - Si contiene inyección de shell, coordenadas numéricas o acciones fuera de la allowlist:
    * Lanza `PlanValidationError`.
    * ProviderRuntime atrapa la excepción y retorna `ProcessResult(success = false, error = "Plan rejected by PlanValidator")`.
  - Si es válido:
    * Retorna `SequencePlan(steps = [ActionPlan("open_wifi_settings"), ActionPlan("press_back")])`.

### Paso 7: Despacho a NativeTunnelCore y SequenceExecutor
- **Archivo:** `TunnelCoreAdapter.kt` -> `NativeTunnelCore.kt`
- **Método:** `nativeCore.executePlan(sequencePlan)`
  - Invoca `sequenceExecutor.executeSequence(sequencePlan, stopOnFailure = true)`.
- **Archivo:** `android-app/app/src/main/java/com/tunnel/turbo/core/NativeSequenceExecutor.kt`
- **Método:** `suspend fun executeSequence(...)`
  - Registra en journal: `sequence_started`.
  - Itera sobre cada paso:
    * Paso 0: `actionEngine.executeAction(open_wifi_settings)` -> `NativeVerifier` -> Éxito.
    * Rendimiento de transición: `delay(50)`.
    * Paso 1: `actionEngine.executeAction(press_back)` -> `NativeVerifier` -> Éxito.
  - Registra en journal: `sequence_completed`.
  - Retorna `SequenceExecutionResult(success = true, executedSteps = 2, totalSteps = 2)`.

### Paso 8: Retorno y Renderizado en UI
- **Archivo:** `ProviderRuntime.kt`
  - Libera mutex y actualiza `health.state = ProviderState.READY`.
  - Retorna `ProcessResult(success = true, routeDecision = AI_REQUIRED, plan = sequencePlan, ...)`.
- **Archivo:** `MainActivity.kt`
  - En `withContext(Dispatchers.Main)`:
  - Actualiza indicadores y añade log estructurado a `tvLogOutput`.

---

## 3. Puntos Críticos y Hallazgos de la Auditoría

1. **Aislamiento Actual:**
   - La frontera de seguridad en `PlanValidator` y `DisplayTargetPolicy` está funcionando correctamente y previene inyecciones.
2. **Mezcla en MainActivity:**
   - `MainActivity.kt` posee actualmente instancias directas de `ShizukuBridge`, `AccessibilityBridge`, `TunnelCoreAdapter`, `AndroidAiAppProvider`, `ProviderRuntime` y maneja tanto la lógica de prueba (simuladores de rate-limit y offline) como los botones de quick-actions y los campos de entrada de usuario.
3. **Solución Requerida:**
   - Extraer un `IntentCoordinator` unificado que orqueste la interacción entre la UI y el runtime.
   - Dividir la interfaz visual en un `AppUiState` limpio consumido por la vista productiva (Chat-first) y la vista de laboratorio/diagnóstico (Debug Mode).
