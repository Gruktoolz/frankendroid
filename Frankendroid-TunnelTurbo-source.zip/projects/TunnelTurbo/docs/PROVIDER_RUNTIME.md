# Provider Runtime — Especificación y Diseño

## 1. Motivación y Principio de Realidad
Los modelos y aplicaciones de IA (como ChatGPT Mobile, Gemini o endpoints remotos) no representan recursos computacionales infinitos ni garantizan disponibilidad continua. Durante uso intensivo, ráfagas o degradación de red, los proveedores remotos pueden devolver respuestas como:
- *"Too many requests"*
- *"Rate limit exceeded"*
- *"Try again later"*
- *"You've reached a limit"*

Tratar este comportamiento como una excepción genérica o error fatal del sistema causaba bloqueos y bucles de reintento inútiles.
**Principio Fundamental de Fase 8**: El Core de Tunnel Turbo nunca cae porque un proveedor externo esté saturado o desconectado.

## 2. Máquina de Estados del Proveedor

```mermaid
stateDiagram-v2
    [*] --> DISCONNECTED
    DISCONNECTED --> STARTING: initialize()
    STARTING --> READY: worker ready
    READY --> BUSY: request en proceso
    BUSY --> READY: respuesta exitosa
    BUSY --> RATE_LIMITED: clasificado RATE_LIMITED
    BUSY --> ERROR: fallo irrecuperable
    BUSY --> OFFLINE: desconexión de red
    RATE_LIMITED --> COOLDOWN: esperando backoff
    COOLDOWN --> READY: tiempo de cooldown expirado
    OFFLINE --> READY: conectividad restaurada
```

| Estado | Significado | Comportamiento del Core |
|---|---|---|
| `DISCONNECTED` | El servicio o display del proveedor no ha sido iniciado. | Core activo, comandos locales funcionan. |
| `STARTING` | Display virtual inicializándose y cargando la app. | Cola de intenciones en espera (`ROUTING`). |
| `READY` | Proveedor disponible para razonar y planificar intenciones. | Procesamiento normal de solicitudes. |
| `BUSY` | Proveedor ocupado procesando un prompt activo. | Concurrencia de IA bloqueada (=1), comandos directos locales continúan ejecutándose de inmediato. |
| `RATE_LIMITED` | Proveedor rechazó la solicitud por límites de cuota/frecuencia. | Entra en cooldown con backoff exponencial. Se prohíben reintentos continuos en bucle. |
| `COOLDOWN` | Ventana temporal durante la cual no se envían nuevos prompts al proveedor. | Permite que las órdenes directas locales sigan operando. |
| `OFFLINE` | Sin conectividad o proveedor deliberadamente deshabilitado. | Comandos que requieren IA devuelven `AI_PROVIDER_UNAVAILABLE` sin crash. |
| `ERROR` | Error irrecuperable de la app del proveedor o corrupción del estado. | Registro del incidente en auditoría, aislamiento de la sesión. |

## 3. Concurrencia y Cola de Solicitudes
- Concurrencia de AI Provider = 1.
- No se envían prompts simultáneos a ChatGPT o al display virtual, previniendo condiciones de carrera en el campo de texto y en la extracción de respuestas.
- Implementado mediante `IntentRequestQueue` en memoria con orden FIFO y protección de exclusión mutua `Mutex` en Kotlin.
