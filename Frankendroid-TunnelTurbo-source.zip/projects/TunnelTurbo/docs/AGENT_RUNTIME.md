# Tunnel Turbo Agent Runtime

## Overview

The **General Agent Runtime** (`GeneralAgentRuntime`) transforms Tunnel Turbo from a command router into an autonomous agent runtime on Android. Instead of hardcoding specialized intents for every specific app and action, the agent runtime operates through a generalized perception-reasoning-action-verification-learning cycle:

```
User Goal
  ├──> Goal Interpretation (GoalInterpreter)
  ├──> World Snapshot (WorldModel + ObservationReducer)
  ├──> Adaptive Planning (AdaptivePlanner + ReasoningProvider)
  ├──> Local Execution & Continuation (NativeTaskExecutor)
  ├──> Observation & Dynamic Replanning (only when necessary)
  ├──> Success Verification (NativeVerifier)
  └──> Declarative Skill Learning (SkillMemory)
```

## Core Components

### 1. Goal Representation (`Goal.kt`)
The runtime avoids closed intent taxonomies (e.g. `PLAY_MUSIC`, `TAKE_NOTES`). Goals are open data structures:
- `goalId`: Unique identifier (e.g. `goal_5cff9360`).
- `originalText`: Unmodified raw user utterance.
- `objective`: High-level goal objective.
- `entities`: Extracted entities (type, value).
- `constraints`: Execution restrictions.
- `desiredState`: Target world state for verification.
- `risk`: Risk tier (`READ_ONLY`, `LOW_RISK`, `REVERSIBLE`, `EXTERNAL_EFFECT`, `DESTRUCTIVE`).
- `categoryHint`: Optional heuristic hint (never a rigid constraint).

### 2. General Agent Runtime Coordinator (`GeneralAgentRuntime.kt`)
Coordinates the end-to-end execution flow:
- Maintains real-time `AgentRuntimeState` (isBusy, currentGoal, lastResult, activeSkill, lastAiRounds).
- Bypasses local intent shortcuts during agent tasks to ensure true generalization.
- Enforces strict execution safety boundaries (no external communications, no destructive mutations).

### 3. Agent Budget (`AgentBudget`)
Limits the computational, financial, and network footprint of any agent execution:
- `maxSteps`: 15 steps.
- `maxAiRounds`: 3 reasoning calls.
- `maxObservationsSentToAi`: 5 snapshots.
- `maxTaskDurationMs`: 60,000 ms.
- `maxProviderWaitMs`: 15,000 ms.
Ideal execution is completed in **1 AI round** or **0 AI rounds** (when reusing dynamic skills).

### 4. Telemetry and Steps (`AgentStep`)
Every capability invocation records:
- `stepId`, `goalId`, `stepIndex`.
- `decisionSource`: `LOCAL`, `AI`, or `SKILL`.
- `capability` and `arguments`.
- `observationBefore` and `observationAfter`.
- `executionResult` and `verification`.
- `durationMs`.
