# Tunnel Turbo

Aplicación Android y controlador local que exploran una experiencia de agente operativo: conversación, investigación, ejecución en Android y trabajo verificable.

## Recorrido

La app integra un chat, proveedores de razonamiento, un runtime de tareas, observación por Accessibility, OCR local, acciones Android y verificación. Un controlador Python/MCP permite experimentar desde el escritorio con ADB y herramientas estructuradas. Las rutas de modelo incluyen inferencia LiteRT-LM local y conexión Gemini; las capacidades disponibles dependen de configuración, dispositivo y permisos concedidos.

La carpeta `android-app/` contiene la app nativa; `controller/` implementa el controlador Python; `tests/` y `fixtures/` conservan comprobaciones y casos; `docs/` explica runtime, percepción, providers y modelo de estado. `STATUS.md` acompaña el código con evidencia de implementación y recorrido observado.

Consulta `docs/ARCHITECTURE.md` para el mapa general y `ROADMAP.md` para la intención evolutiva.
