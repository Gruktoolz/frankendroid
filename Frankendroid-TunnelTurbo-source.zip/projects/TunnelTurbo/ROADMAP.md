# Dirección y siguientes pasos

## North Star

Tunnel Turbo busca un flujo integrado de **Chat + Research + Agent + Work/Cowork + multi-provider orchestration**, capaz de aprovechar motores locales cuando son suficientes y escalar a proveedores conectados sólo cuando hace falta.

## Fases propuestas

1. **Reproducibilidad**: compilar desde checkout limpio, ejecutar pruebas existentes y registrar dispositivo/SDK/dependencias; corregir fallos con TDD.
2. **Contratos del worker**: consolidar AgentSession y GoalVerifier como autoridad; cada acción debe tener precondición, ejecución, evidencia y resultado verificable.
3. **Chat y continuidad**: probar historial/memoria/instrucción maestra, edición/reintento, streaming, cancelación y límites de contexto en sesiones reales.
4. **Enrutamiento económico**: decisión local primero; consultar web/proveedor sólo ante intención que lo requiera o falta de capacidad; explicar la escalada y dejar el proveedor elegido por el usuario.
5. **Seguridad Android**: permisos mínimos, límites de acciones, protección frente a instrucciones maliciosas en pantalla y auditoría de Accesibilidad/Shizuku.
6. **UX de Worker**: estado breve y progresivo, actividad desplegable, resultados y aprobaciones; dejar herramientas de diagnóstico en Developer Lab.
7. **Multi-provider**: interfaces intercambiables, salud observable, timeouts, reintentos acotados, fallback explícito y pruebas de fallos sin falsos éxitos.
8. **Publicación**: CI, política de privacidad, licencias/dependencias, firma/release y matriz de dispositivos.

## Reglas de ingeniería

- Research First antes de cambios importantes; investigar fuente oficial, sistemas comparables, fallos y evidencia contraria.
- TDD y Clean Code pragmático, evitando reescrituras totales y hardcode innecesario.
- No marcar verde si no se ejecutó y verificó.
- AgentSession/GoalVerifier conservan la autoridad sobre la ejecución y la evidencia.
- Cada entrega versionada debe incluir un reporte con alcance, decisiones, riesgos, fuentes y lista exacta de archivos modificados.
