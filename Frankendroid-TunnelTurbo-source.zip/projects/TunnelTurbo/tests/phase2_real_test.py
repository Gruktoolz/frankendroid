"""Real on-device integration test for Phase 2: Fast State, Invalidation, Diff, and Re-use."""

import asyncio
import sys
import time
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from controller.adb.client import AdbClient
from controller.android_cli.client import AndroidCliClient
from controller.state.engine import StateEngine
from controller.observer.observer import AdaptiveObserver


async def run_phase2_real_test():
    print("=" * 60)
    print("TUNNEL TURBO CONTROLLER — PRUEBA REAL FASE 2")
    print("=" * 60)

    adb = AdbClient()
    cli = AndroidCliClient()
    devices = await adb.list_devices()
    if not devices:
        print("❌ Error: No se encontró dispositivo conectado.")
        sys.exit(1)

    serial = devices[0].serial
    print(f"Dispositivo activo: {serial}")

    # 1. Poner dispositivo en Ajustes principales
    print("\n[Paso 1] Abriendo Ajustes principales...")
    await adb.execute_raw(["shell", "am", "start", "-a", "android.settings.SETTINGS"], serial=serial)
    await asyncio.sleep(0.8)

    engine = StateEngine(serial=serial, adb_client=adb, cli_client=cli)
    observer = AdaptiveObserver(engine)

    # 2. Inicializar estado y capturar UI inicial
    print("\n[Paso 2] Inicializando StateEngine y capturando layout inicial de Ajustes...")
    t0 = time.monotonic_ns()
    initial_state = await engine.get_state(mode="ui")
    t1 = time.monotonic_ns()
    initial_ui_duration_ms = (t1 - t0) / 1_000_000

    initial_rev = initial_state.revision
    initial_ui_invocations = engine.ui_invocations
    initial_act = initial_state.fast.activity

    print(f"  ✓ Estado inicial listo:")
    print(f"    * Revision: {initial_rev}")
    print(f"    * Activity: {initial_act}")
    print(f"    * Nodos UI: {initial_state.ui.nodes_count}")
    print(f"    * Invocaciones UI acumuladas: {initial_ui_invocations}")

    # 3. Navegar a otra sección mediante acción segura (Ajustes de Pantalla)
    print("\n[Paso 3] Ejecutando navegación segura a DisplaySettings...")
    await adb.execute_raw(["shell", "am", "start", "-a", "android.settings.DISPLAY_SETTINGS"], serial=serial)

    # 4. Monitorear con Observer en modo ACTIVE (Fast State)
    print("\n[Paso 4] Monitoreando cambio con Fast State (sin ejecutar layout)...")
    t_obs_start = time.monotonic_ns()
    detected = await observer.observe_after_action(timeout_s=3.0, check_interval_s=0.04)
    t_obs_end = time.monotonic_ns()
    detection_duration_ms = (t_obs_end - t_obs_start) / 1_000_000

    if not detected:
        print("❌ Error: Fast State no detectó el cambio de pantalla.")
        sys.exit(1)

    # Medir lectura de cache en modo fast
    t_fast_start = time.monotonic_ns()
    fast_state = await engine.get_state(mode="fast")
    t_fast_end = time.monotonic_ns()
    fast_cache_duration_ms = (t_fast_end - t_fast_start) / 1_000_000

    print(f"  ✓ Cambio de pantalla detectado con Fast State!")
    print(f"    * Duración de detección: {detection_duration_ms:.2f} ms")
    print(f"    * Duración lectura cache fast: {fast_cache_duration_ms * 1000:.2f} µs ({fast_cache_duration_ms:.4f} ms)")
    print(f"    * Nueva revision: {fast_state.revision} (anterior: {initial_rev})")
    print(f"    * Nueva Activity: {fast_state.fast.activity}")
    print(f"    * UI stale flag: {fast_state.ui.stale}")
    print(f"    * Invocaciones layout durante observación: {engine.ui_invocations - initial_ui_invocations} (¡CERO!)")

    assert fast_state.revision > initial_rev, "Revision debió incrementarse"
    assert fast_state.ui.stale is True, "UI debió quedar marcada como stale"
    assert engine.ui_invocations == initial_ui_invocations, "No debió invocarse layout"

    # 5. Solicitar get_state(mode="ui"): aquí sí debe ejecutarse layout y refrescarse
    print("\n[Paso 5] Solicitando get_state(mode='ui') tras cambio...")
    t_fresh_start = time.monotonic_ns()
    refreshed_state = await engine.get_state(mode="ui")
    t_fresh_end = time.monotonic_ns()
    refresh_layout_ms = (t_fresh_end - t_fresh_start) / 1_000_000

    print(f"  ✓ Layout actualizado:")
    print(f"    * Duración de refresco UI: {refresh_layout_ms:.2f} ms")
    print(f"    * Nueva UI revision: {refreshed_state.ui.revision}")
    print(f"    * UI stale flag: {refreshed_state.ui.stale} (debe ser False)")
    print(f"    * Invocaciones UI acumuladas: {engine.ui_invocations}")

    assert refreshed_state.ui.stale is False, "UI stale debió ser False tras refresh"
    assert engine.ui_invocations == initial_ui_invocations + 1, "Debió haber exactamente 1 invocación a layout"

    # Calcular diff
    diff = engine.get_changes(since_revision=initial_rev)
    print(f"  ✓ Diff calculado desde revisión {initial_rev}:")
    print(f"    * Cambios detectados: {len(diff.changes)}")
    for ch in diff.changes[:5]:
        print(f"      - [{ch.type}] {ch.target}: {ch.from_val} -> {ch.to_val}")
    if len(diff.changes) > 5:
        print(f"      - ... y {len(diff.changes) - 5} cambios más.")

    # 6. Solicitar get_state(mode="ui") OTRA VEZ sin modificar la pantalla
    print("\n[Paso 6] Solicitando get_state(mode='ui') nuevamente SIN cambiar pantalla...")
    t_cached_start = time.monotonic_ns()
    cached_ui_state = await engine.get_state(mode="ui")
    t_cached_end = time.monotonic_ns()
    cached_ui_duration_ms = (t_cached_end - t_cached_start) / 1_000_000

    print(f"  ✓ Reutilización de layout en memoria exitosa:")
    print(f"    * Duración: {cached_ui_duration_ms * 1000:.2f} µs ({cached_ui_duration_ms:.4f} ms)")
    print(f"    * Invocaciones UI acumuladas: {engine.ui_invocations} (¡NO aumentó!)")

    assert engine.ui_invocations == initial_ui_invocations + 1, "Layout debió ser reutilizado sin invocar Android CLI"

    # 7. Restaurar pantalla inicial (BACK a Ajustes)
    print("\n[Paso 7] Restaurando pantalla de Ajustes con tecla BACK...")
    await adb.execute_raw(["shell", "input", "keyevent", "BACK"], serial=serial)
    await asyncio.sleep(0.5)

    print("\n" + "=" * 60)
    print("RESUMEN DE MÉTRICAS OBTENIDAS:")
    print("=" * 60)
    print(f"A. Detección de cambio de Activity con Fast State ADB: {detection_duration_ms:.2f} ms")
    print(f"B. Lectura get_state(mode='fast') desde cache RAM:      {fast_cache_duration_ms:.4f} ms")
    print(f"C. Lectura get_state(mode='ui') con layout cacheado:    {cached_ui_duration_ms:.4f} ms")
    print(f"D. Refresco de layout cuando stale=True:                 {refresh_layout_ms:.2f} ms")
    print(f"E. Invocaciones reales a android layout:                 {engine.ui_invocations}")
    print(f"F. Screenshots utilizados:                               0")
    print("=" * 60)
    print("✓ PRUEBA REAL FASE 2 SUPERADA CON ÉXITO")


if __name__ == "__main__":
    asyncio.run(run_phase2_real_test())
