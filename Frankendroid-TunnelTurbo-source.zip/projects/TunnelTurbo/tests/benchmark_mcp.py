"""Comprehensive MCP Benchmark for Phase 4.

Runs 30 iterations for:
A) tunnel_get_state (cache)
B) tunnel_get_state (fast)
C) tunnel_open_wifi_settings (direct action)
D) tunnel_semantic_tap with valid cache (semantic tap)
"""

import asyncio
import json
import os
import sys
import time
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
VENV_PYTHON = os.path.join(PROJECT_ROOT, ".venv", "bin", "python3")
SERVER_SCRIPT = os.path.join(PROJECT_ROOT, "controller", "mcp_server", "server.py")


def compute_stats(arr):
    if not arr:
        return {"min": 0, "median": 0, "p95": 0, "max": 0}
    s = sorted(arr)
    n = len(s)
    min_v = s[0]
    max_v = s[-1]
    # Median
    if n % 2 == 1:
        med_v = s[n // 2]
    else:
        med_v = (s[n // 2 - 1] + s[n // 2]) / 2.0
    # p95 (nearest rank)
    p95_idx = int(round(0.95 * (n - 1)))
    p95_v = s[p95_idx]
    return {
        "min": round(float(min_v), 3),
        "median": round(float(med_v), 3),
        "p95": round(float(p95_v), 3),
        "max": round(float(max_v), 3),
    }


async def run_benchmark():
    print("=" * 70)
    print("TUNNEL TURBO MCP SERVER — FASE 4 BENCHMARK")
    print(f"Server script: {SERVER_SCRIPT}")
    print("=" * 70)

    server_params = StdioServerParameters(
        command=VENV_PYTHON,
        args=[SERVER_SCRIPT],
        env=os.environ.copy(),
    )

    async with stdio_client(server_params) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            print("\n[Init] Handshaking MCP session over stdio...")
            t_init0 = time.monotonic_ns()
            init_res = await session.initialize()
            t_init1 = time.monotonic_ns()
            startup_ms = (t_init1 - t_init0) / 1_000_000
            print(f" -> MCP handshake complete in {startup_ms:.2f} ms")

            # Warmup: list devices and trigger lazy init
            print("\n[Warmup] Lazy initialization...")
            await session.call_tool("tunnel_list_devices", arguments={})
            await session.call_tool("tunnel_get_state", arguments={"mode": "cache"})
            # Ensure Settings is open for subsequent tests
            await session.call_tool("tunnel_open_settings", arguments={})
            print(" -> Warmup complete.")

            results = {}

            # =========================================================================
            # Suite A: tunnel_get_state cache (30 iterations)
            # =========================================================================
            print("\n" + "-" * 70)
            print("Suite A: tunnel_get_state (cache) — 30 iterations")
            print("-" * 70)
            overhead_a = []
            core_a = []
            server_a = []
            client_a = []

            for i in range(30):
                t_c0 = time.monotonic_ns()
                res = await session.call_tool("tunnel_get_state", arguments={"mode": "cache"})
                t_c1 = time.monotonic_ns()
                data = json.loads(res.content[0].text)
                assert data.get("success") is True, f"Failed at {i}: {data}"

                m = data["metrics"]
                overhead_a.append(m["mcp_overhead_ms"])
                core_a.append(m["core_ms"])
                server_a.append(m["total_server_ms"])
                client_a.append((t_c1 - t_c0) / 1_000_000)

            stats_a = {
                "overhead": compute_stats(overhead_a),
                "core": compute_stats(core_a),
                "server": compute_stats(server_a),
                "client": compute_stats(client_a),
            }
            results["suite_a"] = stats_a
            print(f" -> MCP Overhead: median = {stats_a['overhead']['median']} ms, p95 = {stats_a['overhead']['p95']} ms")
            print(f" -> Core:         median = {stats_a['core']['median']} ms, p95 = {stats_a['core']['p95']} ms")
            print(f" -> Total Server: median = {stats_a['server']['median']} ms, p95 = {stats_a['server']['p95']} ms")
            print(f" -> Client E2E:   median = {stats_a['client']['median']} ms, p95 = {stats_a['client']['p95']} ms")

            # =========================================================================
            # Suite B: tunnel_get_state fast (30 iterations)
            # =========================================================================
            print("\n" + "-" * 70)
            print("Suite B: tunnel_get_state (fast) — 30 iterations")
            print("-" * 70)
            overhead_b = []
            core_b = []
            server_b = []
            client_b = []

            for i in range(30):
                t_c0 = time.monotonic_ns()
                res = await session.call_tool("tunnel_get_state", arguments={"mode": "fast"})
                t_c1 = time.monotonic_ns()
                data = json.loads(res.content[0].text)
                assert data.get("success") is True, f"Failed at {i}: {data}"

                m = data["metrics"]
                overhead_b.append(m["mcp_overhead_ms"])
                core_b.append(m["core_ms"])
                server_b.append(m["total_server_ms"])
                client_b.append((t_c1 - t_c0) / 1_000_000)

            stats_b = {
                "overhead": compute_stats(overhead_b),
                "core": compute_stats(core_b),
                "server": compute_stats(server_b),
                "client": compute_stats(client_b),
            }
            results["suite_b"] = stats_b
            print(f" -> MCP Overhead: median = {stats_b['overhead']['median']} ms, p95 = {stats_b['overhead']['p95']} ms")
            print(f" -> Core:         median = {stats_b['core']['median']} ms, p95 = {stats_b['core']['p95']} ms")
            print(f" -> Total Server: median = {stats_b['server']['median']} ms, p95 = {stats_b['server']['p95']} ms")
            print(f" -> Client E2E:   median = {stats_b['client']['median']} ms, p95 = {stats_b['client']['p95']} ms")

            # =========================================================================
            # Suite C: tunnel_open_wifi_settings (30 iterations)
            # =========================================================================
            print("\n" + "-" * 70)
            print("Suite C: tunnel_open_wifi_settings — 30 iterations")
            print("-" * 70)
            overhead_c = []
            core_c = []
            server_c = []
            client_c = []

            for i in range(30):
                # Alternate slightly to create real Activity transition periodically
                if i % 2 == 0:
                    await session.call_tool("tunnel_open_settings", arguments={})
                    await asyncio.sleep(0.05)

                t_c0 = time.monotonic_ns()
                res = await session.call_tool("tunnel_open_wifi_settings", arguments={})
                t_c1 = time.monotonic_ns()
                data = json.loads(res.content[0].text)
                assert data.get("success") is True, f"Failed at {i}: {data}"

                m = data["metrics"]
                overhead_c.append(m["mcp_overhead_ms"])
                core_c.append(m["core_ms"])
                server_c.append(m["total_server_ms"])
                client_c.append((t_c1 - t_c0) / 1_000_000)

            stats_c = {
                "overhead": compute_stats(overhead_c),
                "core": compute_stats(core_c),
                "server": compute_stats(server_c),
                "client": compute_stats(client_c),
            }
            results["suite_c"] = stats_c
            print(f" -> MCP Overhead: median = {stats_c['overhead']['median']} ms, p95 = {stats_c['overhead']['p95']} ms")
            print(f" -> Core:         median = {stats_c['core']['median']} ms, p95 = {stats_c['core']['p95']} ms")
            print(f" -> Total Server: median = {stats_c['server']['median']} ms, p95 = {stats_c['server']['p95']} ms")
            print(f" -> Client E2E:   median = {stats_c['client']['median']} ms, p95 = {stats_c['client']['p95']} ms")

            # =========================================================================
            # Suite D: tunnel_semantic_tap with valid cache (30 iterations)
            # =========================================================================
            print("\n" + "-" * 70)
            print("Suite D: tunnel_semantic_tap (valid cache) — 30 iterations")
            print("-" * 70)
            overhead_d = []
            core_d = []
            server_d = []
            client_d = []

            # Setup: Ensure Settings is active and UI cache is populated and valid
            await session.call_tool("tunnel_open_settings", arguments={})
            await session.call_tool("tunnel_get_layout", arguments={"freshness": "fresh"})

            for i in range(30):
                # Ensure cache is valid for each measured tap
                st_res = await session.call_tool("tunnel_get_state", arguments={"mode": "cache"})
                st_data = json.loads(st_res.content[0].text)
                if st_data.get("data", {}).get("ui", {}).get("stale", True):
                    # Refresh layout if stale to ensure valid cache
                    await session.call_tool("tunnel_get_layout", arguments={"freshness": "fresh"})

                # Tap a known stable element in Settings: e.g. "Bluetooth" or "Wi-Fi"
                # To maintain UI stability without deeply navigating away, we can tap Bluetooth then press back,
                # or tap an item that stays on screen.
                t_c0 = time.monotonic_ns()
                res = await session.call_tool(
                    "tunnel_semantic_tap",
                    arguments={"selector": "text=Bluetooth", "match": "first"},
                )
                t_c1 = time.monotonic_ns()
                data = json.loads(res.content[0].text)
                assert data.get("success") is True, f"Failed at {i}: {data}"
                assert data.get("execution", {}).get("resolver") == "CACHE", f"Not resolved from cache: {data}"

                m = data["metrics"]
                overhead_d.append(m["mcp_overhead_ms"])
                core_d.append(m["core_ms"])
                server_d.append(m["total_server_ms"])
                client_d.append((t_c1 - t_c0) / 1_000_000)

                # Return to Settings if activity changed
                if data.get("verified"):
                    await session.call_tool("tunnel_press_key", arguments={"key": "BACK"})
                    await asyncio.sleep(0.05)

            stats_d = {
                "overhead": compute_stats(overhead_d),
                "core": compute_stats(core_d),
                "server": compute_stats(server_d),
                "client": compute_stats(client_d),
            }
            results["suite_d"] = stats_d
            print(f" -> MCP Overhead: median = {stats_d['overhead']['median']} ms, p95 = {stats_d['overhead']['p95']} ms")
            print(f" -> Core:         median = {stats_d['core']['median']} ms, p95 = {stats_d['core']['p95']} ms")
            print(f" -> Total Server: median = {stats_d['server']['median']} ms, p95 = {stats_d['server']['p95']} ms")
            print(f" -> Client E2E:   median = {stats_d['client']['median']} ms, p95 = {stats_d['client']['p95']} ms")

            print("\n" + "=" * 70)
            print("BENCHMARK SUMMARY JSON:")
            print(json.dumps(results, indent=2))
            print("=" * 70)

            # Save benchmark results to file
            out_path = os.path.join(PROJECT_ROOT, "reports", "mcp_benchmark_results.json")
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2)
            print(f"Results saved to {out_path}")


if __name__ == "__main__":
    asyncio.run(run_benchmark())
