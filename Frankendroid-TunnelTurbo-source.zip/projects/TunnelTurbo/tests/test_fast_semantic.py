"""Unit tests for semantic selector parser and resolver."""

import unittest
from controller.actions.selector import parse_selector, ParsedSelector
from controller.actions.resolver import SemanticResolver, MatchStatus
from controller.state.models import UiState, UiNode


class TestSemanticSelectorAndResolver(unittest.TestCase):
    def test_parse_selector(self):
        s1 = parse_selector("text=Bluetooth,clickable=true")
        self.assertEqual(s1.text, "Bluetooth")
        self.assertEqual(s1.booleans.get("clickable"), True)

        # Aliases
        s2 = parse_selector("txt=Wi-Fi,res=android:id/title,clz=android.widget.TextView")
        self.assertEqual(s2.text, "Wi-Fi")
        self.assertEqual(s2.resource_id, "android:id/title")
        self.assertEqual(s2.class_name, "android.widget.TextView")

        # Plain string
        s3 = parse_selector("Pantalla")
        self.assertEqual(s3.text, "Pantalla")

    def test_resolver_stale(self):
        ui = UiState(stale=True, nodes=[UiNode(key="1", text="Test")])
        res = SemanticResolver.resolve(ui, "text=Test", 1080, 2400)
        self.assertEqual(res.status, MatchStatus.UI_STALE)
        self.assertFalse(res.ok)

    def test_resolver_unique_and_coords(self):
        node = UiNode(
            key="res:android:id/title",
            resource_id="android:id/title",
            text="Bluetooth",
            bounds="[100,200][300,400]",
            center="[200,300]",
            interactions=["CLICKABLE"],
        )
        ui = UiState(stale=False, nodes=[node])
        res = SemanticResolver.resolve(ui, "text=blue", 1080, 2400)
        self.assertEqual(res.status, MatchStatus.MATCH_UNIQUE)
        self.assertTrue(res.ok)
        self.assertEqual(res.coordinates, (200, 300))

    def test_resolver_multiple_matches(self):
        n1 = UiNode(key="1", text="Ajustes", center="[10,10]")
        n2 = UiNode(key="2", text="Ajustes avanzados", center="[20,20]")
        ui = UiState(stale=False, nodes=[n1, n2])

        # match="single" should reject
        res_single = SemanticResolver.resolve(ui, "text=Ajustes", 1080, 2400, match="single")
        self.assertEqual(res_single.status, MatchStatus.MATCH_MULTIPLE)
        self.assertEqual(res_single.candidates_count, 2)
        self.assertFalse(res_single.ok)

        # match="first" should accept first
        res_first = SemanticResolver.resolve(ui, "text=Ajustes", 1080, 2400, match="first")
        self.assertEqual(res_first.status, MatchStatus.MATCH_UNIQUE)
        self.assertTrue(res_first.ok)
        self.assertEqual(res_first.coordinates, (10, 10))


if __name__ == "__main__":
    unittest.main()
