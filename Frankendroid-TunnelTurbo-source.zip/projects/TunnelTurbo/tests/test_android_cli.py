"""Tests for Android CLI client and JSON layout extraction."""

import json
from pathlib import Path
import unittest
from controller.android_cli.client import AndroidCliClient


class TestAndroidCli(unittest.TestCase):
    def test_android_cli_json_extraction(self):
        client = AndroidCliClient()
        sample_path = Path(__file__).parent.parent / "docs" / "examples" / "layout_sample.json"
        with open(sample_path, "r", encoding="utf-8") as f:
            sample_json_text = f.read()

        noisy_output = f"Installing layout instrumentation server...\nWarning: test banner\n{sample_json_text}"
        extracted = client._extract_json(noisy_output)
        self.assertIsInstance(extracted, list)
        self.assertEqual(len(extracted), 3)


if __name__ == "__main__":
    unittest.main()
