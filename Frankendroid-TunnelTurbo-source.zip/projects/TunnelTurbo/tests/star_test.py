"""Star Test: Demonstrating open_wifi_settings() and press_back() with zero layouts and zero screenshots."""

import asyncio
import json
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from controller.adb.client import AdbClient
from controller.state.engine import StateEngine
from controller.actions.engine import ActionEngine


async def run_star_test():
    print("=" * 65)
    print("TUNNEL TURBO CONTROLLER — PRUEBA ESTRELLA (FASE 3)")
    print("=" * 65)

    adb = AdbClient()
    devs = await adb.list_devices()
    if not devs:
        print("❌ Error: No se encontró dispositivo conectado.")
        sys.exit(1)

    serial = devs[0].serial
    print(f"Dispositivo activo: {serial}")

    # Set up initial state at main Settings
    await adb.execute_raw(["shell", "am", "start", "-a", "android.settings.SETTINGS"], serial=serial)
    await asyncio.sleep(0.5)

    state = StateEngine(serial=serial, adb_client=adb)
    await state.initialize()
    engine = ActionEngine(serial=serial, state_engine=state, adb_client=adb)

    print("\n--- [1] EJECUTANDO open_wifi_settings() ---")
    res1 = await engine.open_wifi_settings()
    d1 = res1.to_dict()
    print(json.dumps(d1, indent=2))

    assert res1.execution_ok is True
    assert res1.verified is True
    assert res1.verification == "SUCCESS_VERIFIED_FAST"
    assert res1.layout_invocations == 0
    assert res1.screenshots_used == 0

    await asyncio.sleep(0.5)

    print("\n--- [2] EJECUTANDO press_back() ---")
    res2 = await engine.press_back()
    d2 = res2.to_dict()
    print(json.dumps(d2, indent=2))

    assert res2.execution_ok is True
    assert res2.verified is True
    assert res2.verification == "SUCCESS_VERIFIED_FAST"
    assert res2.layout_invocations == 0
    assert res2.screenshots_used == 0

    print("\n" + "=" * 65)
    print("✓ PRUEBA ESTRELLA SUPERADA EXITOSAMENTE:")
    print(f"  * open_wifi_settings: {res1.metrics.total_ms:.2f} ms | layout_calls: 0 | screenshots: 0")
    print(f"  * press_back:        {res2.metrics.total_ms:.2f} ms | layout_calls: 0 | screenshots: 0")
    print("=" * 65)


if __name__ == "__main__":
    asyncio.run(run_star_test())
