"""Unit tests for AI App Worker and AndroidAiAppIntentModel."""

import unittest
from unittest.mock import MagicMock, patch

from controller.model.app_worker.state import WorkerState, WorkerMetrics
from controller.model.app_worker.display import VirtualDisplayManager
from controller.model.app_worker.chatgpt_worker import ChatGptWorker
from controller.model.ai_app_provider import AndroidAiAppIntentModel
from controller.model.schemas import StructuredPlan, PlanStep


class TestAiAppWorker(unittest.TestCase):

    def test_worker_state_transitions(self):
        worker = ChatGptWorker(serial="TEST_SERIAL")
        self.assertEqual(worker.state, WorkerState.STOPPED)

    @patch("subprocess.run")
    def test_virtual_display_discovery(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="""DisplayDeviceInfo{"scrcpy": uniqueId="virtual:com.android.shell,2000,scrcpy,6", 1080 x 1920}
mDisplayId=8
mPrimaryDisplayDevice=scrcpy(virtual:com.android.shell,2000,scrcpy,6)""",
        )
        mgr = VirtualDisplayManager(serial="TEST_SERIAL")
        disp_id = mgr.discover_existing_display()
        self.assertEqual(disp_id, 8)
        self.assertEqual(mgr.surface_flinger_id, "virtual:com.android.shell,2000,scrcpy,6")

    @patch.object(ChatGptWorker, "start")
    @patch.object(ChatGptWorker, "send_prompt")
    @patch.object(ChatGptWorker, "wait_for_response")
    def test_ai_app_intent_model_plan_success(self, mock_wait, mock_send, mock_start):
        mock_wait.return_value = '{"type": "action", "action": "open_wifi_settings", "arguments": {}}'
        worker = ChatGptWorker(serial="TEST_SERIAL")
        worker.state = WorkerState.READY
        worker._display_id = 8

        model = AndroidAiAppIntentModel(worker=worker)
        import asyncio
        result = asyncio.run(model.plan("Abre los ajustes de Wi-Fi"))

        self.assertTrue(result.success)
        self.assertIsNotNone(result.plan)
        self.assertEqual(result.plan.type, "action")
        self.assertEqual(result.plan.action, "open_wifi_settings")
        mock_send.assert_called_once()
        mock_wait.assert_called_once()

    @patch.object(ChatGptWorker, "start")
    @patch.object(ChatGptWorker, "send_prompt")
    @patch.object(ChatGptWorker, "wait_for_response")
    def test_ai_app_intent_model_plan_markdown_fence_strip(self, mock_wait, mock_send, mock_start):
        mock_wait.return_value = '```json\n{"type": "sequence", "steps": [{"action": "open_wifi_settings", "arguments": {}}, {"action": "press_back", "arguments": {}}, {"action": "open_bluetooth_settings", "arguments": {}}]}\n```'
        worker = ChatGptWorker(serial="TEST_SERIAL")
        worker.state = WorkerState.READY
        worker._display_id = 8

        model = AndroidAiAppIntentModel(worker=worker)
        import asyncio
        result = asyncio.run(model.plan("Abre Wi-Fi, vuelve atrás y abre Bluetooth"))

        self.assertTrue(result.success)
        self.assertEqual(result.plan.type, "sequence")
        self.assertEqual(len(result.plan.steps), 3)


if __name__ == "__main__":
    unittest.main()
