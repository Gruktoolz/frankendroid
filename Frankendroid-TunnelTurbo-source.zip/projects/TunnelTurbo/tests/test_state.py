"""Unit tests for State models, DiffEngine, and caching."""

import unittest
from controller.state.models import (
    DeviceState,
    StaticDeviceState,
    FastDeviceState,
    UiState,
    UiNode,
)
from controller.state.diff import DiffEngine


class TestStateAndDiff(unittest.TestCase):
    def setUp(self):
        self.static = StaticDeviceState(
            serial="TEST_SERIAL",
            manufacturer="Xiaomi",
            model="2412DPC0AG",
            android_version="16",
            api_level=36,
            display_width=1220,
            display_height=2712,
        )

    def test_diff_fast_activity_changed(self):
        s1 = DeviceState(
            revision=1,
            updated_at=1000,
            static=self.static,
            fast=FastDeviceState(package="com.android.settings", activity="MainActivity"),
            ui=UiState(revision=1, stale=False),
        )
        s2 = DeviceState(
            revision=2,
            updated_at=2000,
            static=self.static,
            fast=FastDeviceState(package="com.android.settings", activity="DisplayActivity"),
            ui=UiState(revision=1, stale=True),
        )

        diff = DiffEngine.compute(s1, s2)
        self.assertTrue(diff.has_changes)
        self.assertEqual(len(diff.changes), 1)
        self.assertEqual(diff.changes[0].type, "activity_changed")
        self.assertEqual(diff.changes[0].from_val, "MainActivity")
        self.assertEqual(diff.changes[0].to_val, "DisplayActivity")

    def test_diff_ui_node_changes(self):
        n1 = UiNode(
            key="res:com.test:id/btn",
            resource_id="com.test:id/btn",
            text="Guardar",
            state=["FOCUSED"],
        )
        n2 = UiNode(
            key="res:com.test:id/btn",
            resource_id="com.test:id/btn",
            text="Guardado",
            state=["CHECKED"],
        )

        changes = DiffEngine.diff_ui([n1], [n2])
        change_types = [c.type for c in changes]
        self.assertIn("text_changed", change_types)
        self.assertIn("focused_changed", change_types)
        self.assertIn("checked_changed", change_types)


if __name__ == "__main__":
    unittest.main()
