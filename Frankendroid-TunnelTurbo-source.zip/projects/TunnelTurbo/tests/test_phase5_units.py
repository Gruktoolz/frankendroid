"""Unit tests for Phase 5 modules: EventJournal, SequenceExecutor, and PersistentObserver."""

import asyncio
import unittest
from unittest.mock import AsyncMock, MagicMock
from controller.state.events import EventJournal, JournalEvent
from controller.actions.sequence import SequenceExecutor, SequenceValidationError, SequenceResult
from controller.actions.models import ActionResult, VerificationLevel


class TestEventJournal(unittest.TestCase):
    def setUp(self):
        self.journal = EventJournal(capacity=5)

    def test_record_and_query(self):
        ev1 = self.journal.record("activity_changed", 10, before="A", after="B")
        ev2 = self.journal.record("package_changed", 11, before="P1", after="P2")

        self.assertEqual(len(self.journal), 2)
        events_since_9 = self.journal.get_events(since_revision=9)
        self.assertEqual(len(events_since_9), 2)

        events_since_10 = self.journal.get_events(since_revision=10)
        self.assertEqual(len(events_since_10), 1)
        self.assertEqual(events_since_10[0].type, "package_changed")

    def test_ring_buffer_capacity(self):
        for i in range(10):
            self.journal.record("step", i)
        self.assertEqual(len(self.journal), 5)
        self.assertEqual(self.journal.total_recorded, 10)
        # Oldest in buffer should be revision 5
        self.assertEqual(self.journal.get_events(since_revision=0)[0].revision, 5)


class TestSequenceExecutor(unittest.TestCase):
    def setUp(self):
        self.mock_action_engine = MagicMock()
        self.mock_state_engine = MagicMock()
        self.mock_state_engine.get_state = AsyncMock(return_value=MagicMock(revision=1))
        self.mock_state_engine.journal = EventJournal()
        self.mock_action_engine.state = self.mock_state_engine
        self.executor = SequenceExecutor(self.mock_action_engine)

    def test_validation_errors(self):
        # Empty steps
        with self.assertRaises(SequenceValidationError):
            self.executor.validate([])

        # Not a list
        with self.assertRaises(SequenceValidationError):
            self.executor.validate("invalid")

        # Unknown action
        with self.assertRaises(SequenceValidationError):
            self.executor.validate([{"action": "hack_device"}])

        # Missing required parameter for open_app
        with self.assertRaises(SequenceValidationError):
            self.executor.validate([{"action": "open_app"}])

        # Missing required parameter for press_key
        with self.assertRaises(SequenceValidationError):
            self.executor.validate([{"action": "press_key", "key": "INVALID_KEY"}])

        # Missing selector for tap
        with self.assertRaises(SequenceValidationError):
            self.executor.validate([{"action": "semantic_tap"}])

    def test_valid_steps(self):
        valid = [
            {"action": "open_settings"},
            {"action": "open_wifi_settings"},
            {"action": "press_key", "key": "BACK"},
            {"action": "semantic_tap", "selector": "text=Bluetooth"},
            {"action": "open_app", "package": "com.android.settings"},
        ]
        # Should not raise
        self.executor.validate(valid)


if __name__ == "__main__":
    unittest.main()
