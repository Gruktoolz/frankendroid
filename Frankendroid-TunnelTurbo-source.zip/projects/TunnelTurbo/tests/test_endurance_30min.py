"""Endurance & Resource Audit Suite for Phase 6 (30 Minutes).

Protocol:
- Segment 1 (10 min): Pure IDLE (no touches, device stable)
- Segment 2 (10 min): Light state queries & background awareness
- Segment 3 (10 min): Alternating Tunnel Turbo actions (open_wifi -> back -> open_bluetooth -> back)

Tracks per segment:
- CPU %
- VmRSS / PSS (MB)
- ADB Busy %
- Polls count & polls/min
- Bytes transferred
- Events generated
- False changes
- Missed changes
- Layouts count
- Screenshots count
- Subprocess & thread count
"""

import asyncio
import os
import statistics
import time
from typing import Dict, Any

from controller.adb.client import AdbClient
from controller.state.engine import StateEngine
from controller.observer.persistent import PersistentObserver
from controller.observer.device_tracker import DeviceTracker
from controller.actions.engine import ActionEngine
from controller.actions.sequence import SequenceExecutor

SERIAL = "TEST_DEVICE_SERIAL"


def get_mem_details() -> Dict[str, float]:
    vm_rss = 0.0
    pss = 0.0
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    vm_rss = float(line.split()[1]) / 1024.0
                    break
    except Exception:
        pass

    try:
        with open("/proc/self/smaps_rollup", "r") as f:
            for line in f:
                if line.startswith("Pss:"):
                    pss = float(line.split()[1]) / 1024.0
                    break
    except Exception:
        pss = vm_rss

    return {"rss_mb": round(vm_rss, 2), "pss_mb": round(pss, 2)}


def count_threads() -> int:
    try:
        return len(os.listdir("/proc/self/task"))
    except Exception:
        return 1


def count_open_fds() -> int:
    try:
        return len(os.listdir("/proc/self/fd"))
    except Exception:
        return 0


def count_subprocesses() -> int:
    try:
        my_pid = os.getpid()
        count = 0
        for entry in os.listdir("/proc"):
            if entry.isdigit():
                try:
                    with open(f"/proc/{entry}/stat", "r") as f:
                        fields = f.read().split()
                        # field 4 is ppid
                        if len(fields) > 4 and int(fields[3]) == my_pid:
                            count += 1
                except Exception:
                    pass
        return count
    except Exception:
        return 0


async def run_endurance():
    print("=" * 70)
    print("STARTING 30-MINUTE TUNNEL TURBO OBSERVER ENDURANCE TEST")
    print("=" * 70)

    adb = AdbClient()
    state_engine = StateEngine(serial=SERIAL, adb_client=adb)
    await state_engine.initialize()

    tracker = DeviceTracker(target_serial=SERIAL)
    tracker.start()

    observer = PersistentObserver(state_engine, device_tracker=tracker)
    observer.start()

    action_engine = ActionEngine(serial=SERIAL, state_engine=state_engine, adb_client=adb)
    seq_executor = SequenceExecutor(action_engine)

    # Initial snapshot
    init_mem = get_mem_details()
    print(f"Initial State: RSS={init_mem['rss_mb']} MB, PSS={init_mem['pss_mb']} MB, Subprocesses={count_subprocesses()}")

    segments_data = {}

    # -------------------------------------------------------------
    # SEGMENT 1: 10 MINUTES PURE IDLE
    # -------------------------------------------------------------
    print("\n>>> SEGMENT 1: 10 Minutes Pure IDLE (No actions, extended backoff)...")
    t0 = time.monotonic()
    t_seg1_start = t0
    # Run 600s
    await asyncio.sleep(600)
    t_seg1_end = time.monotonic()
    seg1_dur = t_seg1_end - t_seg1_start
    tel1 = observer.get_telemetry()
    mem1 = get_mem_details()
    subp1 = count_subprocesses()

    seg1_polls = tel1["polls_idle_count"]
    seg1_polls_min = (seg1_polls / seg1_dur) * 60.0
    seg1_busy = tel1["adb_busy_percent"]
    seg1_bytes = tel1["bytes_per_min"]

    segments_data["segment_1_idle"] = {
        "duration_s": seg1_dur,
        "polls": seg1_polls,
        "polls_per_min": round(seg1_polls_min, 1),
        "adb_busy_pct": seg1_busy,
        "bytes_per_min": seg1_bytes,
        "rss_mb": mem1["rss_mb"],
        "pss_mb": mem1["pss_mb"],
        "subprocesses": subp1,
        "false_changes": tel1["false_changes"],
        "layouts": state_engine.ui_invocations,
        "screenshots": 0,
    }
    print(f"Segment 1 Complete: {seg1_polls} polls (~{seg1_polls_min:.1f}/min), ADB Busy={seg1_busy:.2f}%, RSS={mem1['rss_mb']} MB")

    # -------------------------------------------------------------
    # SEGMENT 2: 10 MINUTES LIGHT USAGE & CACHED MCP QUERIES
    # -------------------------------------------------------------
    print("\n>>> SEGMENT 2: 10 Minutes Light Usage & Fast State Queries...")
    t_seg2_start = time.monotonic()
    polls_before_seg2 = observer.polls_idle_count + observer.polls_active_count
    adb_busy_before_seg2 = observer.adb_busy_time_ns

    # Periodic light checks every 60s
    for i in range(10):
        await asyncio.sleep(60)
        # Periodic query cached state
        st = await state_engine.get_state(mode="fast")
        # Periodic query changes
        ch = state_engine.get_changes(since_revision=0, limit=50)

    t_seg2_end = time.monotonic()
    seg2_dur = t_seg2_end - t_seg2_start
    tel2 = observer.get_telemetry()
    mem2 = get_mem_details()
    subp2 = count_subprocesses()

    seg2_polls = (tel2["polls_idle_count"] + tel2["polls_active_count"]) - polls_before_seg2
    seg2_polls_min = (seg2_polls / seg2_dur) * 60.0
    seg2_busy_ms = (observer.adb_busy_time_ns - adb_busy_before_seg2) / 1_000_000
    seg2_busy_pct = round((seg2_busy_ms / (seg2_dur * 1000)) * 100, 2)

    segments_data["segment_2_light"] = {
        "duration_s": seg2_dur,
        "polls": seg2_polls,
        "polls_per_min": round(seg2_polls_min, 1),
        "adb_busy_pct": seg2_busy_pct,
        "rss_mb": mem2["rss_mb"],
        "pss_mb": mem2["pss_mb"],
        "subprocesses": subp2,
        "false_changes": tel2["false_changes"],
        "layouts": state_engine.ui_invocations,
        "screenshots": 0,
    }
    print(f"Segment 2 Complete: {seg2_polls} polls (~{seg2_polls_min:.1f}/min), ADB Busy={seg2_busy_pct:.2f}%, RSS={mem2['rss_mb']} MB")

    # -------------------------------------------------------------
    # SEGMENT 3: 10 MINUTES ALTERNATING ACTIONS
    # -------------------------------------------------------------
    print("\n>>> SEGMENT 3: 10 Minutes Alternating Tunnel Turbo Actions...")
    t_seg3_start = time.monotonic()
    polls_before_seg3 = observer.polls_idle_count + observer.polls_active_count
    adb_busy_before_seg3 = observer.adb_busy_time_ns

    action_count = 0
    # Every 60s perform an action cycle
    for i in range(10):
        # Open Wi-Fi
        observer.trigger_active_mode(duration_s=2.0)
        res_w = await action_engine.open_wifi_settings()
        observer.stop_active_mode()
        action_count += 1
        await asyncio.sleep(25)

        # Back
        observer.trigger_active_mode(duration_s=2.0)
        await action_engine.press_back()
        observer.stop_active_mode()
        action_count += 1
        await asyncio.sleep(25)

        # Open Bluetooth
        observer.trigger_active_mode(duration_s=2.0)
        res_b = await action_engine.open_bluetooth_settings()
        observer.stop_active_mode()
        action_count += 1
        await asyncio.sleep(10)

    t_seg3_end = time.monotonic()
    seg3_dur = t_seg3_end - t_seg3_start
    tel3 = observer.get_telemetry()
    mem3 = get_mem_details()
    subp3 = count_subprocesses()

    seg3_polls = (tel3["polls_idle_count"] + tel3["polls_active_count"]) - polls_before_seg3
    seg3_polls_min = (seg3_polls / seg3_dur) * 60.0
    seg3_busy_ms = (observer.adb_busy_time_ns - adb_busy_before_seg3) / 1_000_000
    seg3_busy_pct = round((seg3_busy_ms / (seg3_dur * 1000)) * 100, 2)

    segments_data["segment_3_actions"] = {
        "duration_s": seg3_dur,
        "actions_executed": action_count,
        "polls": seg3_polls,
        "polls_per_min": round(seg3_polls_min, 1),
        "adb_busy_pct": seg3_busy_pct,
        "rss_mb": mem3["rss_mb"],
        "pss_mb": mem3["pss_mb"],
        "subprocesses": subp3,
        "events_total": state_engine.journal.total_recorded,
        "false_changes": tel3["false_changes"],
        "layouts": state_engine.ui_invocations,
        "screenshots": 0,
    }
    print(f"Segment 3 Complete: {action_count} actions executed, RSS={mem3['rss_mb']} MB")

    await observer.stop()
    await tracker.stop()

    import json
    with open("reports/phase6_endurance_30min.json", "w") as f:
        json.dump(segments_data, f, indent=2)
    print("\n30-Minute Endurance Test Finished Successfully. Data saved to reports/phase6_endurance_30min.json.")


if __name__ == "__main__":
    asyncio.run(run_endurance())
