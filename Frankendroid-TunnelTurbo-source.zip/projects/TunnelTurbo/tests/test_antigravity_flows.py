"""Tests executing the 4 required Antigravity interaction flows over MCP stdio."""

import asyncio
import json
import os
import sys
import time
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
VENV_PYTHON = os.path.join(PROJECT_ROOT, ".venv", "bin", "python3")
SERVER_SCRIPT = os.path.join(PROJECT_ROOT, "controller", "mcp_server", "server.py")


async def run_antigravity_flows():
    print("=" * 70)
    print("ANTIGRAVITY INTERACTION FLOWS VIA MCP STDIO")
    print("=" * 70)

    server_params = StdioServerParameters(
        command=VENV_PYTHON,
        args=[SERVER_SCRIPT],
        env=os.environ.copy(),
    )

    async with stdio_client(server_params) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            print("Session initialized over stdio.")

            # -------------------------------------------------------------
            # PRUEBA 1: "Obtén el estado de mi dispositivo Android conectado."
            # Expected tool: tunnel_get_state(mode="fast")
            # -------------------------------------------------------------
            print("\n" + "-" * 70)
            print("PRUEBA 1: 'Obtén el estado de mi dispositivo Android conectado.'")
            print("-" * 70)
            t0 = time.monotonic_ns()
            res1 = await session.call_tool("tunnel_get_state", arguments={"mode": "fast"})
            t1 = time.monotonic_ns()
            p1_json = json.loads(res1.content[0].text)
            p1_total_ms = (t1 - t0) / 1_000_000

            print(f"Tool called: tunnel_get_state(mode='fast')")
            print(f"Success: {p1_json.get('success')}")
            print(f"Foreground: {p1_json.get('data', {}).get('fast', {}).get('package')}/{p1_json.get('data', {}).get('fast', {}).get('activity')}")
            print(f"Revision: {p1_json.get('data', {}).get('revision')}")
            print(f"Screenshots used: {p1_json.get('screenshots_used', 0)}")
            print(f"Core latency: {p1_json.get('metrics', {}).get('core_ms')} ms")
            print(f"MCP overhead: {p1_json.get('metrics', {}).get('mcp_overhead_ms')} ms")
            print(f"Total roundtrip: {p1_total_ms:.2f} ms")

            # -------------------------------------------------------------
            # PRUEBA 2: "Abre los ajustes de Wi-Fi de mi dispositivo."
            # Expected tool: tunnel_open_wifi_settings
            # -------------------------------------------------------------
            print("\n" + "-" * 70)
            print("PRUEBA 2: 'Abre los ajustes de Wi-Fi de mi dispositivo.'")
            print("-" * 70)
            t0 = time.monotonic_ns()
            res2 = await session.call_tool("tunnel_open_wifi_settings", arguments={})
            t1 = time.monotonic_ns()
            p2_json = json.loads(res2.content[0].text)
            p2_total_ms = (t1 - t0) / 1_000_000

            print(f"Tool called: tunnel_open_wifi_settings()")
            print(f"Success: {p2_json.get('success')}")
            print(f"Verified: {p2_json.get('verified')} ({p2_json.get('verification')})")
            print(f"Backend: {p2_json.get('execution', {}).get('backend')}")
            print(f"Layout invocations: {p2_json.get('layout_invocations', 0)}")
            print(f"Screenshots used: {p2_json.get('screenshots_used', 0)}")
            print(f"Core latency: {p2_json.get('metrics', {}).get('core_ms')} ms")
            print(f"MCP overhead: {p2_json.get('metrics', {}).get('mcp_overhead_ms')} ms")
            print(f"Total roundtrip: {p2_total_ms:.2f} ms")

            # -------------------------------------------------------------
            # PRUEBA 3: Preparar layout cache válido. Solicitar "Pulsa Bluetooth."
            # Expected tool: tunnel_semantic_tap(selector="text=Bluetooth")
            # -------------------------------------------------------------
            print("\n" + "-" * 70)
            print("PRUEBA 3: Preparar layout cache válido -> 'Pulsa Bluetooth.'")
            print("-" * 70)
            # Step A: Return to Settings and capture layout to populate cache
            await session.call_tool("tunnel_open_settings", arguments={})
            res_layout = await session.call_tool("tunnel_get_layout", arguments={"freshness": "fresh"})
            layout_data = json.loads(res_layout.content[0].text)
            print(f"Layout cache prepared: {layout_data.get('data', {}).get('nodes_count')} nodes stored in RAM.")

            # Step B: Model executes semantic tap
            t0 = time.monotonic_ns()
            res3 = await session.call_tool(
                "tunnel_semantic_tap",
                arguments={"selector": "text=Bluetooth", "match": "first"},
            )
            t1 = time.monotonic_ns()
            p3_json = json.loads(res3.content[0].text)
            p3_total_ms = (t1 - t0) / 1_000_000

            print(f"Tool called: tunnel_semantic_tap(selector='text=Bluetooth')")
            print(f"Success: {p3_json.get('success')}")
            print(f"Verified: {p3_json.get('verified')} ({p3_json.get('verification')})")
            print(f"Resolver: {p3_json.get('execution', {}).get('resolver')}")
            print(f"Backend: {p3_json.get('execution', {}).get('backend')}")
            print(f"New layout calls: {p3_json.get('layout_invocations', 0)}")
            print(f"Screenshots used: {p3_json.get('screenshots_used', 0)}")
            print(f"Core latency: {p3_json.get('metrics', {}).get('core_ms')} ms")
            print(f"MCP overhead: {p3_json.get('metrics', {}).get('mcp_overhead_ms')} ms")
            print(f"Total roundtrip: {p3_total_ms:.2f} ms")

            # -------------------------------------------------------------
            # PRUEBA MULTI-STEP: "Abre Wi-Fi, vuelve atrás y abre Bluetooth."
            # High-level actions sequence
            # -------------------------------------------------------------
            print("\n" + "-" * 70)
            print("PRUEBA MULTI-STEP: 'Abre Wi-Fi, vuelve atrás y abre Bluetooth.'")
            print("-" * 70)
            # Step 1: Open Wi-Fi
            t_ms0 = time.monotonic_ns()
            step1_res = await session.call_tool("tunnel_open_wifi_settings", arguments={})
            s1 = json.loads(step1_res.content[0].text)

            # Step 2: Back
            step2_res = await session.call_tool("tunnel_press_key", arguments={"key": "BACK"})
            s2 = json.loads(step2_res.content[0].text)

            # Step 3: Open Bluetooth
            step3_res = await session.call_tool("tunnel_open_bluetooth_settings", arguments={})
            s3 = json.loads(step3_res.content[0].text)
            t_ms1 = time.monotonic_ns()

            total_multi_ms = (t_ms1 - t_ms0) / 1_000_000
            total_core_ms = (
                s1.get("metrics", {}).get("core_ms", 0)
                + s2.get("metrics", {}).get("core_ms", 0)
                + s3.get("metrics", {}).get("core_ms", 0)
            )
            total_mcp_overhead_ms = (
                s1.get("metrics", {}).get("mcp_overhead_ms", 0)
                + s2.get("metrics", {}).get("mcp_overhead_ms", 0)
                + s3.get("metrics", {}).get("mcp_overhead_ms", 0)
            )
            total_layouts = (
                s1.get("layout_invocations", 0)
                + s2.get("layout_invocations", 0)
                + s3.get("layout_invocations", 0)
            )
            total_screenshots = (
                s1.get("screenshots_used", 0)
                + s2.get("screenshots_used", 0)
                + s3.get("screenshots_used", 0)
            )

            print(f"Sequence executed: tunnel_open_wifi_settings -> tunnel_press_key('BACK') -> tunnel_open_bluetooth_settings")
            print(f"Model tool calls: 3")
            print(f"Step 1 verified: {s1.get('verified')} ({s1.get('metrics', {}).get('core_ms')} ms)")
            print(f"Step 2 verified: {s2.get('verified')} ({s2.get('metrics', {}).get('core_ms')} ms)")
            print(f"Step 3 verified: {s3.get('verified')} ({s3.get('metrics', {}).get('core_ms')} ms)")
            print(f"Total Core latency: {total_core_ms:.2f} ms")
            print(f"Total MCP overhead: {total_mcp_overhead_ms:.3f} ms")
            print(f"Total multi-step time: {total_multi_ms:.2f} ms")
            print(f"Total layout calls: {total_layouts}")
            print(f"Total screenshots: {total_screenshots}")
            print(f"Errors: 0")

            # Save detailed report dictionary
            report_data = {
                "prueba_1": {
                    "tool": "tunnel_get_state",
                    "mode": "fast",
                    "tool_calls": 1,
                    "core_ms": p1_json.get("metrics", {}).get("core_ms"),
                    "mcp_overhead_ms": p1_json.get("metrics", {}).get("mcp_overhead_ms"),
                    "total_ms": round(p1_total_ms, 2),
                    "screenshots": 0,
                    "adb_manual": 0,
                },
                "prueba_2": {
                    "tool": "tunnel_open_wifi_settings",
                    "tool_calls": 1,
                    "verified": p2_json.get("verified"),
                    "verification": p2_json.get("verification"),
                    "core_ms": p2_json.get("metrics", {}).get("core_ms"),
                    "mcp_overhead_ms": p2_json.get("metrics", {}).get("mcp_overhead_ms"),
                    "total_ms": round(p2_total_ms, 2),
                    "layout_calls": p2_json.get("layout_invocations", 0),
                    "screenshots": 0,
                },
                "prueba_3": {
                    "tool": "tunnel_semantic_tap",
                    "selector": "text=Bluetooth",
                    "tool_calls": 1,
                    "resolver": p3_json.get("execution", {}).get("resolver"),
                    "backend": p3_json.get("execution", {}).get("backend"),
                    "verified": p3_json.get("verified"),
                    "core_ms": p3_json.get("metrics", {}).get("core_ms"),
                    "mcp_overhead_ms": p3_json.get("metrics", {}).get("mcp_overhead_ms"),
                    "total_ms": round(p3_total_ms, 2),
                    "new_layout_calls": p3_json.get("layout_invocations", 0),
                    "screenshots": 0,
                },
                "multi_step": {
                    "prompt": "Abre Wi-Fi, vuelve atrás y abre Bluetooth.",
                    "tools_selected": [
                        "tunnel_open_wifi_settings",
                        "tunnel_press_key(BACK)",
                        "tunnel_open_bluetooth_settings",
                    ],
                    "tool_calls": 3,
                    "total_core_ms": round(total_core_ms, 2),
                    "total_mcp_overhead_ms": round(total_mcp_overhead_ms, 3),
                    "total_ms": round(total_multi_ms, 2),
                    "layouts": total_layouts,
                    "screenshots": total_screenshots,
                    "errors": 0,
                },
            }

            out_flows = os.path.join(PROJECT_ROOT, "reports", "antigravity_flows_result.json")
            with open(out_flows, "w", encoding="utf-8") as f:
                json.dump(report_data, f, indent=2)
            print(f"\nFlows result saved to {out_flows}")


if __name__ == "__main__":
    asyncio.run(run_antigravity_flows())
