"""Tests for ADB client and parsers."""

import unittest
from controller.adb.parsers import parse_adb_devices, parse_foreground_window
from controller.adb.client import AdbClient


SAMPLE_ADB_DEVICES_OUTPUT = """
List of devices attached
TEST_DEVICE_SERIAL       device usb:3-4 product:rodin_global model:2412DPC0AG device:rodin transport_id:1
EMULATOR_5554          offline transport_id:2
"""

SAMPLE_DUMPSYS_OUTPUT = """
  mCurrentFocus=Window{ae327ab u0 com.mi.android.globallauncher/com.miui.home.launcher.Launcher}
  mFocusedApp=ActivityRecord{235442560 u0 com.mi.android.globallauncher/com.miui.home.launcher.Launcher t1612}
"""


class TestAdb(unittest.TestCase):
    def test_parse_adb_devices(self):
        devices = parse_adb_devices(SAMPLE_ADB_DEVICES_OUTPUT)
        self.assertEqual(len(devices), 2)

        d1 = devices[0]
        self.assertEqual(d1.serial, "TEST_DEVICE_SERIAL")
        self.assertEqual(d1.state, "device")
        self.assertEqual(d1.usb, "3-4")
        self.assertEqual(d1.product, "rodin_global")
        self.assertEqual(d1.model, "2412DPC0AG")
        self.assertEqual(d1.transport_id, "1")

        d2 = devices[1]
        self.assertEqual(d2.serial, "EMULATOR_5554")
        self.assertEqual(d2.state, "offline")

    def test_parse_foreground_window(self):
        fg = parse_foreground_window(SAMPLE_DUMPSYS_OUTPUT)
        self.assertEqual(fg.package, "com.mi.android.globallauncher")
        self.assertEqual(fg.activity, "com.miui.home.launcher.Launcher")


if __name__ == "__main__":
    unittest.main()
