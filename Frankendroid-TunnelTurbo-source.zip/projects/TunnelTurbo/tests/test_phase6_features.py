"""Unit tests for Phase 6 Event Journal pagination and Device Tracker."""

import unittest
from controller.state.events import EventJournal, JournalEvent
from controller.observer.device_tracker import DeviceTracker


class TestEventJournalPagination(unittest.TestCase):
    def test_query_changes_empty(self):
        journal = EventJournal(capacity=100)
        res = journal.query_changes(since_revision=0, limit=50)
        self.assertEqual(res["events_available"], 0)
        self.assertEqual(res["events_returned"], 0)
        self.assertFalse(res["truncated"])
        self.assertEqual(res["oldest_revision"], 0)
        self.assertEqual(res["newest_revision"], 0)
        self.assertIsNone(res["next_revision"])
        self.assertEqual(len(res["events"]), 0)

    def test_query_changes_pagination(self):
        journal = EventJournal(capacity=500)
        for i in range(1, 151):
            journal.record(
                event_type="test_event",
                revision=i,
                details={"idx": i},
            )

        # Query first page: limit=50
        page1 = journal.query_changes(since_revision=0, limit=50)
        self.assertEqual(page1["events_available"], 150)
        self.assertEqual(page1["events_returned"], 50)
        self.assertEqual(page1["remaining"], 100)
        self.assertTrue(page1["truncated"])
        self.assertEqual(page1["oldest_revision"], 1)
        self.assertEqual(page1["newest_revision"], 50)
        self.assertEqual(page1["next_revision"], 50)

        # Query second page: since_revision=50, limit=50
        page2 = journal.query_changes(since_revision=50, limit=50)
        self.assertEqual(page2["events_available"], 100)
        self.assertEqual(page2["events_returned"], 50)
        self.assertEqual(page2["remaining"], 50)
        self.assertTrue(page2["truncated"])
        self.assertEqual(page2["oldest_revision"], 51)
        self.assertEqual(page2["newest_revision"], 100)
        self.assertEqual(page2["next_revision"], 100)

        # Query third page: since_revision=100, limit=50
        page3 = journal.query_changes(since_revision=100, limit=50)
        self.assertEqual(page3["events_available"], 50)
        self.assertEqual(page3["events_returned"], 50)
        self.assertEqual(page3["remaining"], 0)
        self.assertFalse(page3["truncated"])
        self.assertEqual(page3["oldest_revision"], 101)
        self.assertEqual(page3["newest_revision"], 150)
        self.assertIsNone(page3["next_revision"])


class TestDeviceTrackerParsing(unittest.TestCase):
    def test_parse_track_devices_payload(self):
        tracker = DeviceTracker(target_serial="SERIAL123")
        payload = "0018SERIAL123\tdevice\nSERIAL456\toffline\n"
        parsed = tracker._parse_payload(payload)
        self.assertEqual(parsed.get("SERIAL123"), "device")
        self.assertEqual(parsed.get("SERIAL456"), "offline")


if __name__ == "__main__":
    unittest.main()
