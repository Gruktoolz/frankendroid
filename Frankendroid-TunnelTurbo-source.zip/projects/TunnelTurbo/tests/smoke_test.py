"""Phase 1 Smoke Test: End-to-end verification of ADB and Android CLI clients."""

import asyncio
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from controller.adb.client import AdbClient
from controller.android_cli.client import AndroidCliClient


async def run_smoke_test():
    print("=== TÚNEL TURBO CONTROLLER — SMOKE TEST FASE 1 ===")

    # 1. Test ADB Client
    print("\n[1/3] Verificando cliente ADB...")
    adb = AdbClient()
    if not adb.is_available():
        print("❌ Error: ADB binario no encontrado.")
        sys.exit(1)
    print("  ✓ ADB disponible")

    devices = await adb.list_devices()
    print(f"  ✓ Dispositivos detectados: {len(devices)}")
    for d in devices:
        print(f"    - Serial: {d.serial} (Estado: {d.state}, Modelo: {d.model})")

    if not devices:
        print("❌ Error: No se encontró ningún dispositivo conectado.")
        sys.exit(1)

    target_serial = devices[0].serial
    props = await adb.get_device_props(target_serial)
    print(f"  ✓ Propiedades del dispositivo:")
    print(f"    * Fabricante: {props.manufacturer}")
    print(f"    * Modelo: {props.model}")
    print(f"    * Android: {props.android_version} (API {props.api_level})")

    fg = await adb.get_foreground_app(target_serial)
    print(f"  ✓ Foreground actual: {fg.package} / {fg.activity}")

    # 2. Test Android CLI Client
    print("\n[2/3] Verificando cliente Android CLI...")
    cli = AndroidCliClient()
    if not cli.is_available():
        print("❌ Error: Android CLI binario no encontrado.")
        sys.exit(1)
    print("  ✓ Android CLI disponible")

    print("\n[3/3] Obteniendo layout estructurado con android layout --flat --no-idle...")
    layout_res = await cli.get_layout(serial=target_serial, flat=True, no_idle=True)

    if not layout_res.ok:
        print(f"❌ Error al obtener layout: {layout_res.error}")
        sys.exit(1)

    print(f"  ✓ Layout obtenido exitosamente!")
    print(f"    * Duración: {layout_res.duration_ms:.2f} ms")
    print(f"    * Tamaño recibido: {layout_res.bytes_count} bytes")
    print(f"    * Ventanas analizadas: {layout_res.windows_count}")
    print(f"    * Nodos totales encontrados: {layout_res.nodes_count}")

    print("\n=== SMOKE TEST COMPLETADO CON ÉXITO ===")


if __name__ == "__main__":
    asyncio.run(run_smoke_test())
