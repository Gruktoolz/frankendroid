"""Unit tests for Phase 7 Intent Model Schemas and Validator."""

import unittest
from controller.model.schemas import StructuredPlan, PlanStep
from controller.model.validator import PlanValidator, PlanValidationError


class TestPlanValidator(unittest.TestCase):
    def test_valid_action_plan(self):
        raw = '{"type": "action", "action": "open_wifi_settings", "arguments": {}}'
        plan = PlanValidator.validate(raw)
        self.assertEqual(plan.type, "action")
        self.assertEqual(plan.action, "open_wifi_settings")
        self.assertEqual(plan.arguments, {})

    def test_valid_sequence_plan(self):
        raw = {
            "type": "sequence",
            "steps": [
                {"action": "open_wifi_settings", "arguments": {}},
                {"action": "press_key", "arguments": {"key": "BACK"}},
                {"action": "open_bluetooth_settings", "arguments": {}},
            ]
        }
        plan = PlanValidator.validate(raw)
        self.assertEqual(plan.type, "sequence")
        self.assertEqual(len(plan.steps), 3)
        self.assertEqual(plan.steps[1].arguments["key"], "BACK")

    def test_valid_needs_observation(self):
        raw = '{"type": "needs_observation", "reason": "Cannot see app list"}'
        plan = PlanValidator.validate(raw)
        self.assertEqual(plan.type, "needs_observation")
        self.assertEqual(plan.reason, "Cannot see app list")

    def test_valid_unsupported(self):
        raw = '{"type": "unsupported", "reason": "Cannot run shell"}'
        plan = PlanValidator.validate(raw)
        self.assertEqual(plan.type, "unsupported")

    def test_reject_unauthorized_action(self):
        raw = '{"type": "action", "action": "reboot_device", "arguments": {}}'
        with self.assertRaises(PlanValidationError) as ctx:
            PlanValidator.validate(raw)
        self.assertEqual(ctx.exception.code, "UNAUTHORIZED_ACTION")

    def test_reject_extra_arguments(self):
        raw = '{"type": "action", "action": "open_wifi_settings", "arguments": {"unknown_flag": true}}'
        with self.assertRaises(PlanValidationError) as ctx:
            PlanValidator.validate(raw)
        self.assertEqual(ctx.exception.code, "EXTRA_ARGUMENT")

    def test_reject_coordinates(self):
        raw = '{"type": "action", "action": "semantic_tap", "arguments": {"selector": "x=500 y=300"}}'
        with self.assertRaises(PlanValidationError) as ctx:
            PlanValidator.validate(raw)
        self.assertEqual(ctx.exception.code, "COORDINATES_FORBIDDEN")

    def test_reject_shell_injection(self):
        raw = '{"type": "action", "action": "semantic_tap", "arguments": {"selector": "text=Click; rm -rf /"}}'
        with self.assertRaises(PlanValidationError) as ctx:
            PlanValidator.validate(raw)
        self.assertEqual(ctx.exception.code, "SHELL_INJECTION_DETECTED")

    def test_reject_oversized_sequence(self):
        raw = {
            "type": "sequence",
            "steps": [{"action": "open_wifi_settings", "arguments": {}} for _ in range(9)]
        }
        with self.assertRaises(PlanValidationError) as ctx:
            PlanValidator.validate(raw)
        self.assertEqual(ctx.exception.code, "PLAN_TOO_LARGE")

    def test_reject_malformed_json(self):
        raw = "{type: action, action: open_wifi_settings"
        with self.assertRaises(PlanValidationError) as ctx:
            PlanValidator.validate(raw)
        self.assertEqual(ctx.exception.code, "MALFORMED_JSON")

    def test_shared_json_fixtures(self):
        import os
        import json
        fixture_path = os.path.join(os.path.dirname(__file__), "..", "fixtures", "shared_plan_fixtures.json")
        with open(fixture_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        for item in data["valid_fixtures"]:
            plan = PlanValidator.validate(item["raw"])
            self.assertEqual(plan.type, item["expected_type"])
            if "expected_action" in item:
                self.assertEqual(plan.action, item["expected_action"])
            if "expected_steps_count" in item:
                self.assertEqual(len(plan.steps), item["expected_steps_count"])

        for item in data["invalid_fixtures"]:
            with self.assertRaises(PlanValidationError) as ctx:
                PlanValidator.validate(item["raw"])
            self.assertEqual(ctx.exception.code, item["expected_error"])


if __name__ == "__main__":
    unittest.main()
