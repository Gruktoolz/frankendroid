"""Experiment: Isolated comparison between one-shot adb subprocess vs persistent adb shell session.

Evaluates:
- Round-trip latency across 30 warm iterations
- Framing robustness (delimiters, exit codes, multiline outputs)
- Disconnection / pipe crash recovery
- Engineering complexity vs actual performance gain
"""

import asyncio
import os
import sys
import time
import statistics
from typing import List, Tuple

SERIAL = "TEST_DEVICE_SERIAL"
CMD = "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'"
DELIMITER = "__TT_CMD_DONE__"


async def bench_subprocess(iterations: int = 30) -> List[float]:
    latencies = []
    # Warmup
    for _ in range(3):
        proc = await asyncio.create_subprocess_exec(
            "adb", "-s", SERIAL, "shell", CMD,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await proc.communicate()

    for _ in range(iterations):
        t0 = time.monotonic_ns()
        proc = await asyncio.create_subprocess_exec(
            "adb", "-s", SERIAL, "shell", CMD,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        t1 = time.monotonic_ns()
        latencies.append((t1 - t0) / 1_000_000)
    return latencies


class PersistentShell:
    def __init__(self, serial: str):
        self.serial = serial
        self.proc = None

    async def start(self):
        # We start an adb shell with raw stdin/stdout pipes
        self.proc = await asyncio.create_subprocess_exec(
            "adb", "-s", self.serial, "shell",
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

    async def execute(self, cmd: str) -> Tuple[str, int]:
        # Send command with echo of delimiter and exit status
        token = f"{DELIMITER}_{time.monotonic_ns()}"
        full_cmd = f"{cmd}\necho {token}_$?_\n"
        self.proc.stdin.write(full_cmd.encode())
        await self.proc.stdin.drain()

        # Read line by line until token is encountered
        lines = []
        exit_code = 0
        while True:
            line_bytes = await self.proc.stdout.readline()
            if not line_bytes:
                # EOF / connection broken
                raise ConnectionResetError("Persistent adb shell terminated unexpectedly.")
            line = line_bytes.decode(errors="replace").rstrip("\r\n")
            if token in line:
                # Format: __TT_CMD_DONE_<ns>_<exit_code>_
                parts = line.split(token)
                if len(parts) > 1 and parts[1].startswith("_"):
                    try:
                        code_str = parts[1].split("_")[1]
                        exit_code = int(code_str)
                    except Exception:
                        exit_code = 0
                break
            lines.append(line)
        return "\n".join(lines), exit_code

    async def close(self):
        if self.proc:
            try:
                self.proc.stdin.write(b"exit\n")
                await self.proc.stdin.drain()
            except Exception:
                pass
            try:
                await asyncio.wait_for(self.proc.wait(), timeout=1.0)
            except Exception:
                self.proc.kill()


async def bench_persistent(iterations: int = 30) -> Tuple[List[float], bool]:
    latencies = []
    shell = PersistentShell(SERIAL)
    await shell.start()

    framing_clean = True
    try:
        # Warmup
        for _ in range(3):
            await shell.execute(CMD)

        for _ in range(iterations):
            t0 = time.monotonic_ns()
            out, code = await shell.execute(CMD)
            t1 = time.monotonic_ns()
            if code != 0 and code != 1:  # grep might return 1 if no match, 0 if match
                framing_clean = False
            latencies.append((t1 - t0) / 1_000_000)
    finally:
        await shell.close()

    return latencies, framing_clean


async def main():
    print(f"=== PERSISTENT ADB EXPERIMENT (Target: {SERIAL}) ===")
    print(f"Command: {CMD}")
    print("Testing one-shot subprocess...")
    subp_times = await bench_subprocess(30)
    print(f"Subprocess (30 runs): min={min(subp_times):.2f}ms, median={statistics.median(subp_times):.2f}ms, p95={statistics.quantiles(subp_times, n=20)[18]:.2f}ms")

    print("\nTesting persistent interactive shell...")
    pers_times, framing_ok = await bench_persistent(30)
    print(f"Persistent (30 runs): min={min(pers_times):.2f}ms, median={statistics.median(pers_times):.2f}ms, p95={statistics.quantiles(pers_times, n=20)[18]:.2f}ms")
    print(f"Framing status: {'STABLE' if framing_ok else 'UNSTABLE'}")

    diff = statistics.median(subp_times) - statistics.median(pers_times)
    pct = (diff / statistics.median(subp_times)) * 100
    print(f"\nDelta: {diff:+.2f} ms ({pct:+.1f}%)")


if __name__ == "__main__":
    asyncio.run(main())
