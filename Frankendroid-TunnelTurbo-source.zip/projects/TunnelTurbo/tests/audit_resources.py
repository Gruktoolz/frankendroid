"""Resource Audit script for Tunnel Turbo Controller Phase 6.

Measures memory (VmRSS, PSS), threads, open file descriptors, child processes,
asyncio tasks, and journal entries across stages A to H:
A. Python mínimo sin MCP
B. Tunnel Turbo Core cargado
C. MCP server cargado sin observer
D. MCP + Persistent Observer
E. MCP + Observer después de 5 min
F. MCP + Observer después de 30 min (referenced from endurance run)
G. Después de ejecutar 100 acciones
H. Después de llenar Event Journal (1,000 eventos)
"""

import asyncio
import gc
import json
import os
import sys
import time
from typing import Dict, Any

SERIAL = "TEST_DEVICE_SERIAL"


def get_mem() -> Dict[str, float]:
    vm_rss = 0.0
    pss = 0.0
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    vm_rss = float(line.split()[1]) / 1024.0
                    break
    except Exception:
        pass

    try:
        with open("/proc/self/smaps_rollup", "r") as f:
            for line in f:
                if line.startswith("Pss:"):
                    pss = float(line.split()[1]) / 1024.0
                    break
    except Exception:
        pss = vm_rss
    return {"rss_mb": round(vm_rss, 2), "pss_mb": round(pss, 2)}


def count_threads() -> int:
    try:
        return len(os.listdir("/proc/self/task"))
    except Exception:
        return 1


def count_open_fds() -> int:
    try:
        return len(os.listdir("/proc/self/fd"))
    except Exception:
        return 0


def count_child_procs() -> int:
    try:
        my_pid = os.getpid()
        count = 0
        for entry in os.listdir("/proc"):
            if entry.isdigit():
                try:
                    with open(f"/proc/{entry}/stat", "r") as f:
                        fields = f.read().split()
                        if len(fields) > 4 and int(fields[3]) == my_pid:
                            count += 1
                except Exception:
                    pass
        return count
    except Exception:
        return 0


def record_stage(name: str, journal_entries: int = 0) -> Dict[str, Any]:
    mem = get_mem()
    threads = count_threads()
    fds = count_open_fds()
    children = count_child_procs()
    try:
        tasks = len([t for t in asyncio.all_tasks() if not t.done()])
    except RuntimeError:
        tasks = 0

    data = {
        "stage": name,
        "rss_mb": mem["rss_mb"],
        "pss_mb": mem["pss_mb"],
        "threads": threads,
        "open_fds": fds,
        "child_procs": children,
        "asyncio_tasks": tasks,
        "journal_entries": journal_entries,
    }
    print(f"[{name}] RSS: {data['rss_mb']} MB | PSS: {data['pss_mb']} MB | Threads: {threads} | FDs: {fds} | Children: {children} | Tasks: {tasks} | Journal: {journal_entries}")
    return data


async def main():
    print("=" * 70)
    print("STARTING RESOURCE AUDIT (STAGES A -> H)")
    print("=" * 70)
    results = {}

    # Stage A: Python mínimo
    results["A_bare_python"] = record_stage("A. Python mínimo")

    # Stage B: Tunnel Turbo Core cargado
    from controller.adb.client import AdbClient
    from controller.state.engine import StateEngine
    from controller.actions.engine import ActionEngine
    adb = AdbClient()
    state_engine = StateEngine(serial=SERIAL, adb_client=adb)
    await state_engine.initialize()
    action_engine = ActionEngine(serial=SERIAL, state_engine=state_engine, adb_client=adb)
    results["B_core_loaded"] = record_stage("B. Core cargado", journal_entries=state_engine.journal.total_recorded)

    # Stage C: MCP server cargado sin observer
    from controller.mcp_server.server import TunnelTurboMCPServer
    # We load server module and classes
    mcp_server = TunnelTurboMCPServer(serial=SERIAL)
    # Don't start observer yet
    results["C_mcp_no_observer"] = record_stage("C. MCP sin observer", journal_entries=state_engine.journal.total_recorded)

    # Stage D: MCP + Persistent Observer + DeviceTracker
    from controller.observer.persistent import PersistentObserver
    from controller.observer.device_tracker import DeviceTracker
    tracker = DeviceTracker(target_serial=SERIAL)
    tracker.start()
    observer = PersistentObserver(state_engine, device_tracker=tracker)
    observer.start()
    results["D_mcp_with_observer"] = record_stage("D. MCP + Observer", journal_entries=state_engine.journal.total_recorded)

    # Stage E: MCP + Observer después de 5 min (or 300s)
    print("\nRunning 5-minute soak for Stage E...")
    await asyncio.sleep(300)
    results["E_mcp_observer_5min"] = record_stage("E. MCP + Observer tras 5 min", journal_entries=state_engine.journal.total_recorded)

    # Stage G: Después de ejecutar 100 acciones (alternating direct back / settings)
    print("\nExecuting 100 actions for Stage G...")
    for i in range(50):
        await adb.execute_raw(["shell", "input", "keyevent", "4"], serial=SERIAL)  # BACK
        await state_engine.refresh_fast_state()
    results["G_after_100_actions"] = record_stage("G. Tras 100 acciones", journal_entries=state_engine.journal.total_recorded)

    # Stage H: Después de llenar Event Journal (1,000 eventos)
    print("\nFilling Event Journal to 1,000 events for Stage H...")
    for i in range(1000):
        state_engine.journal.record(
            event_type="test_event",
            revision=state_engine._current_state.revision + i + 1,
            details={"iter": i, "payload": "synthetic_audit_payload"},
        )
    gc.collect()
    results["H_journal_full_1000"] = record_stage("H. Event Journal lleno (1000)", journal_entries=state_engine.journal.total_recorded)

    await observer.stop()
    await tracker.stop()

    with open("reports/phase6_resource_audit.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\nResource audit completed. Saved to reports/phase6_resource_audit.json.")


if __name__ == "__main__":
    asyncio.run(main())
