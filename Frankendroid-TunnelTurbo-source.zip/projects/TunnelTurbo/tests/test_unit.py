"""Unit tests using standard library unittest for zero-dependency execution."""

import asyncio
import json
from pathlib import Path
import unittest

from controller.adb.parsers import parse_adb_devices, parse_foreground_window
from controller.android_cli.client import AndroidCliClient


SAMPLE_ADB_DEVICES_OUTPUT = """
List of devices attached
TEST_DEVICE_SERIAL       device usb:3-4 product:rodin_global model:2412DPC0AG device:rodin transport_id:1
EMULATOR_5554          offline transport_id:2
"""

SAMPLE_DUMPSYS_OUTPUT = """
  mCurrentFocus=Window{ae327ab u0 com.mi.android.globallauncher/com.miui.home.launcher.Launcher}
  mFocusedApp=ActivityRecord{235442560 u0 com.mi.android.globallauncher/com.miui.home.launcher.Launcher t1612}
"""


class TestTunnelTurboUnit(unittest.TestCase):
    def test_parse_adb_devices(self):
        devices = parse_adb_devices(SAMPLE_ADB_DEVICES_OUTPUT)
        self.assertEqual(len(devices), 2)
        d1 = devices[0]
        self.assertEqual(d1.serial, "TEST_DEVICE_SERIAL")
        self.assertEqual(d1.state, "device")
        self.assertEqual(d1.model, "2412DPC0AG")
        self.assertEqual(d1.usb, "3-4")

    def test_parse_foreground_window(self):
        fg = parse_foreground_window(SAMPLE_DUMPSYS_OUTPUT)
        self.assertEqual(fg.package, "com.mi.android.globallauncher")
        self.assertEqual(fg.activity, "com.miui.home.launcher.Launcher")

    def test_android_cli_json_extraction(self):
        client = AndroidCliClient()
        sample_path = Path(__file__).parent.parent / "docs" / "examples" / "layout_sample.json"
        with open(sample_path, "r", encoding="utf-8") as f:
            sample_json_text = f.read()

        noisy_output = f"Installing layout instrumentation server...\nWarning banner\n{sample_json_text}"
        extracted = client._extract_json(noisy_output)
        self.assertIsInstance(extracted, list)
        self.assertEqual(len(extracted), 3)


if __name__ == "__main__":
    unittest.main()
