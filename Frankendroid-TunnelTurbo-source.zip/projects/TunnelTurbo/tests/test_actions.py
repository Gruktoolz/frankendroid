"""Unit tests for Action models, conditions, and results."""

import unittest
from controller.actions.models import (
    ActionResult,
    ActionMetrics,
    VerificationLevel,
    ExpectedActivity,
    ExpectedPackage,
    ActivityChanged,
    PackageChanged,
    StateChanged,
    ExpectedUiNode,
)
from controller.state.models import FastDeviceState, UiState, UiNode


class TestActionModels(unittest.TestCase):
    def test_expected_activity(self):
        f1 = FastDeviceState(package="com.android.settings", activity="SettingsActivity")
        f2 = FastDeviceState(package="com.android.settings", activity="WifiSettingsActivity")

        cond = ExpectedActivity("WifiSettings")
        self.assertFalse(cond.is_satisfied_fast(f1, f1))
        self.assertTrue(cond.is_satisfied_fast(f1, f2))
        self.assertFalse(cond.requires_ui())

    def test_expected_package(self):
        f1 = FastDeviceState(package="com.android.settings")
        f2 = FastDeviceState(package="com.google.android.youtube")

        cond = ExpectedPackage("com.google.android.youtube")
        self.assertFalse(cond.is_satisfied_fast(f1, f1))
        self.assertTrue(cond.is_satisfied_fast(f1, f2))

    def test_activity_changed(self):
        f1 = FastDeviceState(activity="Act1")
        f2 = FastDeviceState(activity="Act2")

        cond = ActivityChanged()
        self.assertFalse(cond.is_satisfied_fast(f1, f1))
        self.assertTrue(cond.is_satisfied_fast(f1, f2))

    def test_expected_ui_node(self):
        cond = ExpectedUiNode(selector="btn_submit", expected_text="Submit")
        self.assertTrue(cond.requires_ui())

        node = UiNode(key="k1", resource_id="com.test:id/btn_submit", text="Submit")
        ui_state = UiState(nodes=[node])
        self.assertTrue(cond.is_satisfied_ui(ui_state))

    def test_action_result_to_dict(self):
        res = ActionResult(
            action="open_wifi_settings",
            execution_ok=True,
            verified=True,
            verification=VerificationLevel.SUCCESS_VERIFIED_FAST.value,
            before_revision=1,
            after_revision=2,
            before_activity="MainActivity",
            after_activity="WifiActivity",
            metrics=ActionMetrics(dispatch_ms=50.0, detection_ms=30.0, total_ms=80.0),
        )
        d = res.to_dict()
        self.assertEqual(d["action"], "open_wifi_settings")
        self.assertEqual(d["verification"], "SUCCESS_VERIFIED_FAST")
        self.assertEqual(d["metrics"]["total_ms"], 80.0)
        self.assertEqual(d["screenshots_used"], 0)


if __name__ == "__main__":
    unittest.main()
