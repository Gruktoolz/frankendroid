"""Synthetic scaling benchmark for Event Journal.

Measures:
- events_available
- events_returned
- serialized_bytes (JSON encoded)
- serialization_ms
For event counts: 0, 1, 10, 25, 50, 100, 250, 1000.
Also tests pagination (limit=100) and ensures non-silent truncation.
"""

import json
import time
from typing import Dict, Any
from controller.state.events import EventJournal, JournalEvent


def run_benchmark():
    event_counts = [0, 1, 10, 25, 50, 100, 250, 1000]
    results = {}

    for count in event_counts:
        journal = EventJournal(capacity=2000)
        # Populate with synthetic events
        for i in range(1, count + 1):
            journal.record(
                event_type="activity_changed" if i % 2 == 0 else "resumed",
                revision=i,
                before="com.android.settings/.SubSettings_prev",
                after="com.android.settings/.SubSettings_curr",
                source="observer",
                details={
                    "package": "com.android.settings",
                    "activity": f".SubSettings_{i}",
                },
            )

        # Query all (limit=1500) to measure unpaginated scaling
        t0 = time.monotonic_ns()
        query_res = journal.query_changes(since_revision=0, limit=1500)
        json_bytes = json.dumps(query_res).encode("utf-8")
        t1 = time.monotonic_ns()

        ser_ms = round((t1 - t0) / 1_000_000, 3)
        bytes_len = len(json_bytes)

        # Query with default limit=100 to check pagination
        paginated_res = journal.query_changes(since_revision=0, limit=100)
        pag_bytes = len(json.dumps(paginated_res).encode("utf-8"))

        results[count] = {
            "events_available": query_res["events_available"],
            "events_returned_all": query_res["events_returned"],
            "serialized_bytes_all": bytes_len,
            "serialization_ms": ser_ms,
            "paginated_returned": paginated_res["events_returned"],
            "paginated_bytes": pag_bytes,
            "truncated": paginated_res["truncated"],
            "next_revision": paginated_res["next_revision"],
        }

        print(
            f"Events: {count:4d} | All Bytes: {bytes_len:6d} B ({ser_ms:.2f} ms) | "
            f"Limit 100: {paginated_res['events_returned']:3d} ret, {pag_bytes:5d} B, "
            f"truncated={paginated_res['truncated']}, next_rev={paginated_res['next_revision']}"
        )

    return results


if __name__ == "__main__":
    run_benchmark()
