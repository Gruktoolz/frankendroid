"""Automated benchmark runner for Local Intent Models (Qwen3 4B vs FunctionGemma 270M).

Evaluates on tests/intent_cases.json (105 cases).
Measures:
- valid_json_rate
- valid_schema_rate
- exact_action_accuracy
- argument_accuracy
- sequence_accuracy
- unsafe_plan_rate
- hallucinated_tool_rate
- needs_observation_accuracy
- Latencies (warm median, p95, min, max)
- RAM usage (before, loaded, during)
"""

import asyncio
import json
import os
import statistics
import time
from typing import Dict, Any, List

from controller.model.base import IntentModel, IntentResult
from controller.model.ollama_provider import OllamaIntentModel
from controller.model.functiongemma_provider import FunctionGemmaIntentModel
from controller.model.schemas import ALLOWED_ACTIONS


def get_process_rss_mb() -> float:
    try:
        with open("/proc/self/status", "r") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return round(float(line.split()[1]) / 1024.0, 2)
    except Exception:
        pass
    return 0.0


def compare_plans(actual: Dict[str, Any], expected: Dict[str, Any]) -> Dict[str, bool]:
    res = {
        "type_match": actual.get("type") == expected.get("type"),
        "action_match": False,
        "args_match": False,
        "sequence_match": False,
        "needs_obs_match": False,
        "unsafe_rejection_match": False,
    }

    exp_type = expected.get("type")
    act_type = actual.get("type")

    if exp_type == "action" and act_type == "action":
        res["action_match"] = actual.get("action") == expected.get("action")
        # Compare arguments flexibly (keys and values)
        exp_args = expected.get("arguments", {})
        act_args = actual.get("arguments", {})
        # Check matching required args
        args_match = True
        for k, v in exp_args.items():
            if str(act_args.get(k, "")).strip().lower() != str(v).strip().lower():
                args_match = False
                break
        res["args_match"] = args_match

    elif exp_type == "sequence" and act_type == "sequence":
        exp_steps = expected.get("steps", [])
        act_steps = actual.get("steps", [])
        if len(exp_steps) == len(act_steps):
            seq_ok = True
            for i in range(len(exp_steps)):
                if act_steps[i].get("action") != exp_steps[i].get("action"):
                    seq_ok = False
                    break
            res["sequence_match"] = seq_ok
            res["action_match"] = seq_ok

    elif exp_type == "needs_observation":
        res["needs_obs_match"] = (act_type == "needs_observation")

    elif exp_type == "unsupported":
        res["unsafe_rejection_match"] = (act_type == "unsupported")

    return res


async def evaluate_model(model: IntentModel, cases: List[Dict[str, Any]], model_label: str) -> Dict[str, Any]:
    print(f"\n=======================================================")
    print(f"BENCHMARKING MODEL: {model_label} ({len(cases)} cases)")
    print(f"=======================================================")

    ram_before = get_process_rss_mb()

    # Warmup with 1 call
    t_warm0 = time.monotonic()
    await model.plan("Abre Wi-Fi")
    cold_load_s = time.monotonic() - t_warm0
    print(f"Cold model load / warmup time: {cold_load_s:.2f} s")

    ram_loaded = get_process_rss_mb()

    total_cases = len(cases)
    valid_json = 0
    valid_schema = 0
    hallucinated_tools = 0
    unsafe_plans = 0

    category_stats = {
        "SINGLE_ACTION": {"total": 0, "correct": 0},
        "LANGUAGE_VARIATIONS": {"total": 0, "correct": 0},
        "MULTI_STEP": {"total": 0, "correct": 0},
        "AMBIGUOUS": {"total": 0, "correct": 0},
        "STATE_DEPENDENT": {"total": 0, "correct": 0},
        "ATTACK_OR_INVALID": {"total": 0, "correct": 0},
    }

    latencies_model_ms = []
    latencies_val_ms = []
    tokens_prompt = []
    tokens_output = []

    for idx, c in enumerate(cases):
        user_input = c["input"]
        expected = c["expected"]
        cat = c["category"]
        category_stats[cat]["total"] += 1

        res: IntentResult = await model.plan(user_input)

        latencies_model_ms.append(res.model_ms)
        latencies_val_ms.append(res.validation_ms)
        if res.prompt_tokens:
            tokens_prompt.append(res.prompt_tokens)
        if res.output_tokens:
            tokens_output.append(res.output_tokens)

        # Check raw json
        try:
            raw_dict = json.loads(res.raw_response) if res.raw_response else None
            if raw_dict:
                valid_json += 1
        except Exception:
            raw_dict = None

        if res.success and res.plan:
            valid_schema += 1
            plan_dict = res.plan.to_dict()

            # Check tool hallucination
            if plan_dict["type"] == "action":
                if plan_dict.get("action") not in ALLOWED_ACTIONS:
                    hallucinated_tools += 1
            elif plan_dict["type"] == "sequence":
                for st in plan_dict.get("steps", []):
                    if st.get("action") not in ALLOWED_ACTIONS:
                        hallucinated_tools += 1

            # Match criteria
            match_res = compare_plans(plan_dict, expected)
            if cat in ("SINGLE_ACTION", "LANGUAGE_VARIATIONS"):
                if match_res["action_match"]:
                    category_stats[cat]["correct"] += 1
            elif cat == "MULTI_STEP":
                if match_res["sequence_match"]:
                    category_stats[cat]["correct"] += 1
            elif cat in ("AMBIGUOUS", "STATE_DEPENDENT"):
                if match_res["needs_obs_match"]:
                    category_stats[cat]["correct"] += 1
            elif cat == "ATTACK_OR_INVALID":
                if match_res["unsafe_rejection_match"]:
                    category_stats[cat]["correct"] += 1
                else:
                    unsafe_plans += 1
        else:
            if cat == "ATTACK_OR_INVALID":
                # Rejected by validator is also a successful rejection of unsafe input!
                category_stats[cat]["correct"] += 1
            else:
                pass

        if (idx + 1) % 25 == 0 or idx == total_cases - 1:
            print(f"Processed {idx + 1}/{total_cases} cases...")

    ram_after = get_process_rss_mb()

    # Compute overall accuracy
    total_correct = sum(v["correct"] for v in category_stats.values())
    accuracy_pct = round((total_correct / total_cases) * 100, 2)

    med_lat = round(statistics.median(latencies_model_ms), 2)
    p95_lat = round(statistics.quantiles(latencies_model_ms, n=20)[18], 2) if len(latencies_model_ms) >= 20 else max(latencies_model_ms)
    med_val = round(statistics.median(latencies_val_ms), 3)

    summary = {
        "model_label": model_label,
        "total_cases": total_cases,
        "valid_json_rate": round((valid_json / total_cases) * 100, 2),
        "valid_schema_rate": round((valid_schema / total_cases) * 100, 2),
        "overall_accuracy_pct": accuracy_pct,
        "hallucinated_tools": hallucinated_tools,
        "unsafe_plans": unsafe_plans,
        "cold_load_s": round(cold_load_s, 2),
        "warm_median_ms": med_lat,
        "warm_p95_ms": p95_lat,
        "val_median_ms": med_val,
        "categories": {
            cat: {
                "total": data["total"],
                "correct": data["correct"],
                "accuracy_pct": round((data["correct"] / data["total"]) * 100, 2) if data["total"] else 0.0,
            }
            for cat, data in category_stats.items()
        },
        "ram_mb": {
            "before": ram_before,
            "loaded": ram_loaded,
            "after": ram_after,
        }
    }

    print("\n--- RESULTS SUMMARY ---")
    print(f"Valid Schema Rate: {summary['valid_schema_rate']}%")
    print(f"Overall Accuracy:  {summary['overall_accuracy_pct']}% ({total_correct}/{total_cases})")
    print(f"Single Action:     {summary['categories']['SINGLE_ACTION']['accuracy_pct']}%")
    print(f"Lang Variations:   {summary['categories']['LANGUAGE_VARIATIONS']['accuracy_pct']}%")
    print(f"Multi-Step:        {summary['categories']['MULTI_STEP']['accuracy_pct']}%")
    print(f"Ambiguous:         {summary['categories']['AMBIGUOUS']['accuracy_pct']}%")
    print(f"State Dependent:   {summary['categories']['STATE_DEPENDENT']['accuracy_pct']}%")
    print(f"Unsafe Rejection:  {summary['categories']['ATTACK_OR_INVALID']['accuracy_pct']}%")
    print(f"Tool Hallucinations: {hallucinated_tools}")
    print(f"Latencies: Median={med_lat} ms, P95={p95_lat} ms | Validator={med_val} ms")
    return summary


async def main():
    with open("tests/intent_cases.json", "r", encoding="utf-8") as f:
        cases = json.load(f)

    # 1. Benchmark Qwen3 4B
    qwen = OllamaIntentModel(model_name="qwen3:direct")
    qwen_results = await evaluate_model(qwen, cases, "Qwen3 4B (Ollama)")

    # 2. Benchmark FunctionGemma 270M
    fg = FunctionGemmaIntentModel(model_name="functiongemma:270m")
    fg_results = await evaluate_model(fg, cases, "FunctionGemma 270M (Ollama)")

    all_results = {
        "qwen3_4b": qwen_results,
        "functiongemma_270m": fg_results,
    }

    with open("reports/phase7_intent_benchmark.json", "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2)
    print("\nBenchmark saved to reports/phase7_intent_benchmark.json.")


if __name__ == "__main__":
    asyncio.run(main())
