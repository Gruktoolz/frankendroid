"""Real E2E Pipeline Evaluation: User Text -> Model -> Plan -> Validation -> Tunnel Turbo -> Android -> Verifier.

Tests on connected Xiaomi device with 10 safe real-world orders.
"""

import asyncio
import json
import time
from typing import Dict, Any, List

from controller.adb.client import AdbClient
from controller.state.engine import StateEngine
from controller.actions.engine import ActionEngine
from controller.actions.sequence import SequenceExecutor
from controller.model.ollama_provider import OllamaIntentModel
from controller.model.schemas import StructuredPlan

SERIAL = "TEST_DEVICE_SERIAL"


async def execute_e2e_command(
    user_text: str,
    model: OllamaIntentModel,
    action_engine: ActionEngine,
    seq_executor: SequenceExecutor,
    state_engine: StateEngine,
) -> Dict[str, Any]:
    print(f"\n--- Processing E2E: \"{user_text}\" ---")
    t_pipeline_start = time.monotonic_ns()

    # 1. State Summary context (lightweight)
    fast_st = await state_engine.get_state(mode="fast")
    summary = {
        "foreground_package": fast_st.fast.package,
        "foreground_activity": fast_st.fast.activity,
        "device_connected": fast_st.fast.connected,
    }

    # 2. Model Translation
    intent_res = await model.plan(user_text, state_summary=summary)

    model_ms = intent_res.model_ms
    val_ms = intent_res.validation_ms
    plan: StructuredPlan = intent_res.plan

    core_ms = 0.0
    execution_result = None
    screenshots = 0
    layouts = 0
    init_ui_invocations = state_engine.ui_invocations

    # 3. Execution via Tunnel Turbo Core
    t_core0 = time.monotonic_ns()
    if not intent_res.success or not plan:
        status = "FAILED_VALIDATION"
        reason = intent_res.error
    elif plan.type == "action":
        action_name = plan.action
        args = plan.arguments or {}
        if action_name == "open_settings":
            execution_result = await action_engine.open_settings()
        elif action_name == "open_wifi_settings":
            execution_result = await action_engine.open_wifi_settings()
        elif action_name == "open_bluetooth_settings":
            execution_result = await action_engine.open_bluetooth_settings()
        elif action_name == "open_app":
            execution_result = await action_engine.open_app(args.get("package", ""))
        elif action_name == "press_key":
            key = args.get("key", "").upper()
            if key == "BACK":
                execution_result = await action_engine.press_back()
            elif key == "HOME":
                execution_result = await action_engine.press_home()
            else:
                execution_result = await action_engine.act_and_observe("press_enter", lambda: action_engine.adb.execute_raw(["shell", "input", "keyevent", "66"], serial=SERIAL))
        elif action_name == "press_back":
            execution_result = await action_engine.press_back()
        elif action_name == "press_home":
            execution_result = await action_engine.press_home()
        elif action_name == "semantic_tap":
            execution_result = await action_engine.semantic_tap(args.get("selector", ""), match=args.get("match", "single"))
        status = "EXECUTED_ACTION"
        reason = f"Verified: {execution_result.verified if execution_result else False}"

    elif plan.type == "sequence":
        steps = [s.to_dict() for s in (plan.steps or [])]
        execution_result = await seq_executor.execute_sequence(steps=steps)
        status = "EXECUTED_SEQUENCE"
        reason = f"Success: {execution_result.success}, Steps: {execution_result.completed_steps}/{execution_result.total_steps}"

    elif plan.type == "needs_observation":
        status = "NEEDS_OBSERVATION"
        reason = plan.reason
    elif plan.type == "unsupported":
        status = "REJECTED_UNSUPPORTED"
        reason = plan.reason
    else:
        status = "UNKNOWN_PLAN"
        reason = "Unrecognized plan type"

    t_core1 = time.monotonic_ns()
    core_ms = (t_core1 - t_core0) / 1_000_000
    t_pipeline_end = time.monotonic_ns()
    total_ms = (t_pipeline_end - t_pipeline_start) / 1_000_000
    layouts = state_engine.ui_invocations - init_ui_invocations

    print(f"Status: {status} | Plan: {plan.to_dict() if plan else 'None'}")
    print(f"Timings: Model={model_ms:.2f}ms | Val={val_ms:.3f}ms | Core={core_ms:.2f}ms | Total={total_ms:.2f}ms | Screenshots={screenshots} | Layouts={layouts}")

    return {
        "input": user_text,
        "status": status,
        "plan": plan.to_dict() if plan else None,
        "reason": reason,
        "model_ms": round(model_ms, 2),
        "val_ms": round(val_ms, 3),
        "core_ms": round(core_ms, 2),
        "total_ms": round(total_ms, 2),
        "screenshots": screenshots,
        "layouts": layouts,
    }


async def main():
    adb = AdbClient()
    state_engine = StateEngine(serial=SERIAL, adb_client=adb)
    await state_engine.initialize()
    action_engine = ActionEngine(serial=SERIAL, state_engine=state_engine, adb_client=adb)
    seq_executor = SequenceExecutor(action_engine)

    model = OllamaIntentModel(model_name="qwen3:direct")

    orders = [
        "Abre los ajustes de Wi-Fi.",
        "Regresa.",
        "Abre Bluetooth.",
        "Ve al inicio.",
        "Abre Ajustes.",
        "Vuelve atrás.",
        "Abre Wi-Fi, vuelve atrás y abre Bluetooth.",
        "Ve al inicio y entra a Ajustes.",
        "Abre batería y restringe la aplicación que esté consumiendo más.",
        "Abre eso.",
    ]

    results = []
    for order in orders:
        res = await execute_e2e_command(order, model, action_engine, seq_executor, state_engine)
        results.append(res)
        await asyncio.sleep(0.5)

    with open("reports/phase7_e2e_real_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print("\nE2E evaluation complete. Saved to reports/phase7_e2e_real_results.json.")


if __name__ == "__main__":
    asyncio.run(main())
