"""Focused verification of Star Test and Simple Text Test."""

import asyncio
import json
import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from controller.adb.client import AdbClient
from controller.state.engine import StateEngine
from controller.actions.engine import ActionEngine
from controller.actions.sequence import SequenceExecutor
from controller.model.ai_app_provider import AndroidAiAppIntentModel
from controller.model.app_worker.chatgpt_worker import ChatGptWorker
from controller.model.app_worker.display import VirtualDisplayManager

SERIAL = "TEST_DEVICE_SERIAL"


async def run_star_test():
    adb = AdbClient()
    state_engine = StateEngine(serial=SERIAL, adb_client=adb)
    action_engine = ActionEngine(serial=SERIAL, state_engine=state_engine, adb_client=adb)
    seq_executor = SequenceExecutor(action_engine=action_engine)

    disp_mgr = VirtualDisplayManager(serial=SERIAL, package="com.openai.chatgpt")
    worker = ChatGptWorker(serial=SERIAL, package="com.openai.chatgpt", display_manager=disp_mgr)
    model = AndroidAiAppIntentModel(worker=worker, serial=SERIAL)

    worker.start()
    disp_id = worker.display_id
    print(f"Worker running on Display #{disp_id}")

    # Ensure clean state on home screen
    await action_engine.press_home()
    await asyncio.sleep(0.5)

    print("\n--- Running Star Test: \"Abre Wi-Fi, vuelve atrás y abre Bluetooth.\" ---")
    worker.new_chat()
    t0 = time.monotonic()

    intent_res = await model.plan("Abre Wi-Fi, vuelve atrás y abre Bluetooth.")
    t_model_end = time.monotonic()
    print(f"Model Success: {intent_res.success}")
    print(f"Raw Response: {intent_res.raw_response}")
    print(f"Plan: {intent_res.plan.to_dict() if intent_res.plan else None}")
    print(f"Model Latency: {intent_res.model_ms:.1f}ms | Val Latency: {intent_res.validation_ms:.3f}ms")

    # Core execution via SequenceExecutor
    t_core0 = time.monotonic()
    exec_res = None
    if intent_res.plan and intent_res.plan.type == "sequence":
        steps = [s.to_dict() for s in (intent_res.plan.steps or [])]
        exec_res = await seq_executor.execute_sequence(steps=steps)
    t_core1 = time.monotonic()
    core_ms = (t_core1 - t_core0) * 1000
    total_ms = (time.monotonic() - t0) * 1000

    print(f"\nSequence Result: Success={exec_res.success if exec_res else False}")
    if exec_res:
        print(f"Completed Steps: {exec_res.completed_steps}/{exec_res.total_steps}")
        for s in exec_res.steps:
            print(f"  Step {s.index}: {s.action} -> verified={s.verified} ({s.verification}) in {s.total_ms:.1f}ms")

    print(f"Timings: AI={intent_res.model_ms:.1f}ms | Core={core_ms:.1f}ms | Total={total_ms:.1f}ms")
    print(f"Screenshots Used: 0 | UI Dumps: {worker.last_metrics.ui_dumps_used}")


if __name__ == "__main__":
    asyncio.run(run_star_test())
