"""Standalone MCP Client test for Tunnel Turbo MCP Server over stdio."""

import asyncio
import os
import sys
import json
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
VENV_PYTHON = os.path.join(PROJECT_ROOT, ".venv", "bin", "python3")
SERVER_SCRIPT = os.path.join(PROJECT_ROOT, "controller", "mcp_server", "server.py")


async def run_standalone_test():
    print(f"Testing MCP server via stdio using: {VENV_PYTHON} {SERVER_SCRIPT}")

    server_params = StdioServerParameters(
        command=VENV_PYTHON,
        args=[SERVER_SCRIPT],
        env=os.environ.copy(),
    )

    async with stdio_client(server_params) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            # 1. Initialize session
            print("\n[1] Initializing MCP session...")
            init_result = await session.initialize()
            print(f" -> Session initialized! Server capabilities: {init_result.capabilities}")

            # 2. List tools (Discovery)
            print("\n[2] Discovering tools...")
            tools_result = await session.list_tools()
            tool_names = [t.name for t in tools_result.tools]
            print(f" -> Discovered {len(tool_names)} tools: {tool_names}")

            expected_tools = [
                "tunnel_list_devices",
                "tunnel_get_state",
                "tunnel_get_changes",
                "tunnel_get_layout",
                "tunnel_open_settings",
                "tunnel_open_wifi_settings",
                "tunnel_open_bluetooth_settings",
                "tunnel_open_app",
                "tunnel_semantic_tap",
                "tunnel_press_key",
                "tunnel_act_and_observe",
                "tunnel_execute_sequence",
            ]
            for exp in expected_tools:
                assert exp in tool_names, f"Expected tool '{exp}' not discovered!"
            print(f" -> All {len(expected_tools)} expected tools found with schemas!")

            # 3. Call tunnel_list_devices
            print("\n[3] Calling tunnel_list_devices()...")
            res_devices = await session.call_tool("tunnel_list_devices", arguments={})
            dev_json = json.loads(res_devices.content[0].text)
            assert dev_json.get("success") is True, f"Failed: {dev_json}"
            assert dev_json["data"]["count"] >= 1, "No devices found!"

            # 4. Call tunnel_get_state(mode='fast')
            print("\n[4] Calling tunnel_get_state(mode='fast')...")
            res_state = await session.call_tool("tunnel_get_state", arguments={"mode": "fast"})
            state_json = json.loads(res_state.content[0].text)
            print(f" -> Result success: {state_json.get('success')}")
            print(f" -> Foreground: {state_json.get('data', {}).get('fast', {}).get('package')}/{state_json.get('data', {}).get('fast', {}).get('activity')}")
            print(f" -> Revision: {state_json.get('data', {}).get('revision')}")
            print(f" -> Observer: {state_json.get('data', {}).get('observer')}")
            assert state_json.get("success") is True
            assert state_json.get("data", {}).get("observer", {}).get("observer_active") is True

            # 5. Call tunnel_get_changes(since_revision=0)
            print("\n[5] Calling tunnel_get_changes(since_revision=0)...")
            res_changes = await session.call_tool("tunnel_get_changes", arguments={"since_revision": 0})
            changes_json = json.loads(res_changes.content[0].text)
            print(f" -> Events count: {changes_json.get('data', {}).get('events_count')}")
            assert changes_json.get("success") is True

            # 6. Test sequence validation error
            print("\n[6] Testing sequence validation error handling...")
            res_val_err = await session.call_tool("tunnel_execute_sequence", arguments={"steps": [{"action": "invalid_action"}]})
            val_json = json.loads(res_val_err.content[0].text)
            print(f" -> Validation error response: {val_json}")
            assert val_json.get("success") is False
            assert val_json.get("error", {}).get("code") == "VALIDATION_ERROR"

            # 7. Test sequence execution (open_settings)
            print("\n[7] Testing valid sequence execution...")
            res_seq = await session.call_tool("tunnel_execute_sequence", arguments={"steps": [{"action": "open_settings"}]})
            seq_json = json.loads(res_seq.content[0].text)
            print(f" -> Sequence execution success: {seq_json.get('success')}, completed: {seq_json.get('completed_steps')}")
            assert seq_json.get("success") is True
            assert seq_json.get("completed_steps") == 1

            # 5. Call with invalid key to test error handling
            print("\n[5] Calling tunnel_press_key with invalid key 'FOOBAR' (testing error handling)...")
            res_err = await session.call_tool("tunnel_press_key", arguments={"key": "FOOBAR"})
            err_json = json.loads(res_err.content[0].text)
            print(f" -> Error response: {err_json}")
            assert err_json.get("success") is False
            assert err_json.get("error", {}).get("code") == "INVALID_ARGUMENT"

            print("\n[SUCCESS] Standalone MCP Server verification passed cleanly!")


if __name__ == "__main__":
    asyncio.run(run_standalone_test())
