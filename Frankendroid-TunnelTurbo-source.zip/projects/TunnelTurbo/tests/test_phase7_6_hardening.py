"""Unit tests for Phase 7.6 AI App Worker hardening components."""

import unittest
from controller.model.app_worker.session import WorkerSession, WorkerSessionState, CompletionResult
from controller.model.app_worker.buffer import WorkerPromptBuffer
from controller.model.app_worker.state import WorkerMetrics, WorkerState


class TestPhase76Hardening(unittest.TestCase):

    def test_worker_session_monotonic_ids(self):
        session = WorkerSession(max_turns_per_worker=20)
        id1 = session.next_request_id()
        id2 = session.next_request_id()
        id3 = session.next_request_id()

        self.assertEqual(id1, "TT_000001")
        self.assertEqual(id2, "TT_000002")
        self.assertEqual(id3, "TT_000003")
        self.assertEqual(session.request_counter, 3)
        self.assertEqual(session.turns_used, 3)
        self.assertEqual(session.conversation_generation, 1)

    def test_worker_session_rotation(self):
        session = WorkerSession(max_turns_per_worker=5)
        for _ in range(5):
            session.next_request_id()
        
        self.assertTrue(session.needs_rotation())
        session.rotate_conversation()
        self.assertEqual(session.conversation_generation, 2)
        self.assertEqual(session.turns_used, 0)
        self.assertFalse(session.needs_rotation())

    def test_worker_prompt_buffer_isolation(self):
        buf = WorkerPromptBuffer()
        self.assertIsNone(buf.get_prompt())
        self.assertIsNone(buf.get_request_id())

        buf.set_prompt("TT_000042", "Open Wi-Fi settings")
        meta = buf.get_metadata()
        self.assertTrue(meta["has_prompt"])
        self.assertEqual(meta["request_id"], "TT_000042")
        self.assertEqual(meta["length_chars"], len("Open Wi-Fi settings"))

        buf.clear()
        self.assertIsNone(buf.get_prompt())
        self.assertIsNone(buf.get_request_id())
        self.assertFalse(buf.get_metadata()["has_prompt"])

    def test_completion_result(self):
        res = CompletionResult(
            complete=True,
            confidence=1.0,
            signals=["Copiar", "Buena respuesta"],
            last_text='{"type": "action", "action": "open_wifi_settings", "arguments": {}}',
            is_generating=False,
            candidate_count=1,
            elapsed_ms=45.0
        )
        self.assertTrue(res.complete)
        self.assertEqual(res.last_text, '{"type": "action", "action": "open_wifi_settings", "arguments": {}}')
        self.assertIn("Copiar", res.signals)


if __name__ == "__main__":
    unittest.main()
