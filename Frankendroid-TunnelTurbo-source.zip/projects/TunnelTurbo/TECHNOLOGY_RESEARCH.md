# Investigación técnica y comparativa

**Consultado:** 18 de octubre de 2026.  
**Propósito:** orientar el North Star (Chat + Research + Agent + Work/Cowork + multi-provider orchestration) sin confundir tendencias externas con evidencia de que Tunnel Turbo ya funcione.

## Comparación de patrones de AI Worker

| Producto / patrón documentado | Qué aporta al diseño | Qué NO demuestra para Tunnel Turbo |
|---|---|---|
| ChatGPT Work: tareas largas, progreso revisable, redirección del trabajo y aprobación de acciones importantes | La interfaz debe acompañar el ciclo de trabajo y dejar al usuario corregir dirección, no limitarse al cuadro de chat. Mantener estados visibles, preguntas/aprobaciones y resultados revisables. | No acredita que el agente de Tunnel Turbo planifique bien, respete permisos ni termine una tarea. |
| Codex app: tareas en hilos/proyectos, contexto de trabajo, revisión de cambios y worktrees aislados | Separar conversaciones/tareas y mostrar evidencia revisable facilita trabajo paralelo y recuperación de contexto. Para Android, tomar el patrón de sesiones aisladas y revisión, no copiar la arquitectura cloud/escritorio. | No demuestra que el control de Android por accesibilidad sea equivalente a los entornos aislados de Codex. |
| ChatGPT Projects: instrucciones y material persistentes dentro de un proyecto | Apoya conservar instrucciones y contexto con ámbito claro, editables y visibles. Tunnel Turbo ya tiene memoria local/instrucciones por conversación en el código. | No prueba recuperación semántica ni memoria ilimitada en Tunnel Turbo; tampoco implica sincronización entre dispositivos. |

**Inferencia de diseño:** mantener el chat como ventana principal, con progreso de una palabra, pasos desplegables, evidencia de cada acción, pausas para aprobación y una memoria editable con ámbito por conversación. Cuando una tarea requiere una capacidad no disponible localmente, explicar por qué y usar un proveedor sólo si el usuario configuró y habilitó esa ruta.

## IA local en Android: situación actual y límites

- Android presenta Gemini Nano mediante AICore y ML Kit GenAI para tareas concretas, y separa eso de runtimes para modelos propios. La selección depende de soporte/dispositivo y de la tarea. Es evidencia de que el camino on-device existe; no de que cualquier teléfono pueda ejecutar cualquier modelo ni de que sirva como worker general.
- Google mantiene LiteRT-LM con APIs Kotlin/Android y soporte para modelos en dispositivo. El repositorio es activo; la documentación de CMake llama a esa ruta preliminar. No asumir paridad de capacidades entre runtimes ni compatibilidad universal de modelo, GPU/NPU y OEM.
- Contraevidencia: el issue tracker oficial registra reportes de fallos de decodificación GPU, crashes multivuelta/multimodal, respuestas de herramientas mal serializadas y callbacks que no cierran. Son reportes de usuarios, no resultados reproducidos por esta investigación; bastan para exigir validación por versión/dispositivo y fallback observable antes de afirmar confiabilidad.
- Alternativa más simple para funciones de sistema delimitadas: APIs de ML Kit GenAI/AICore cuando estén disponibles; usar un LLM local general sólo cuando se necesite flexibilidad de instrucciones/herramientas. Esto reduce descarga e integración en algunos casos, pero cede control de modelo y soporte de dispositivo.

**Aplicación al código:** `LiteRtLmLocalChatEngine.kt`, `LocalModelCatalog.kt`, `AgentSession.kt` y los proveedores locales son adaptadores de fuente del proyecto. El checkout no contiene sus pesos. La selección debe comprobar artefacto legible, carga real, compatibilidad y salida válida; catálogo o benchmark estático no equivale a “listo”.

## Android y control del dispositivo

- La guía oficial define Accessibility Service como servicio de accesibilidad para ayudar a usuarios con discapacidad o necesidad de interacción alternativa y advierte que debe usarse con ese propósito. Tunnel Turbo incluye control por accesibilidad como parte del worker; antes de distribuirlo hay que revisar propósito, disclosure, consentimiento y política de Play. La existencia técnica del permiso no da legitimidad automática para automatizar cualquier app.
- Android 16 elimina para apps target 36 la opción de evitar edge-to-edge y habilita por defecto cambios de predictive back en ciertos casos. El proyecto target SDK 35 al corte; subir target requiere trabajo de insets/back y verificación, no sólo cambiar un número.

## Riesgos y dirección recomendada

1. **Falso éxito:** una acción ejecutada no significa que se alcanzó la meta. Mantener `AgentSession`/`GoalVerifier` como autoridad, registrar evidencia por paso y distinguir completado, parcial, fallido y no verificado.
2. **Inyección de instrucciones en pantalla:** tratar texto de apps/web como entrada no confiable; separar el objetivo del usuario de las instrucciones observadas; limitar acciones sensibles y pedir confirmación.
3. **Runtimes/modelos heterogéneos:** capar modelos por artefacto real y prueba de arranque/generación; backend/versión/dispositivo; timeout y recuperación recreando sesión; no dar “verde” por una métrica de benchmark aislada.
4. **API/costos y privacidad:** mantener claves fuera del repo; solicitar sólo contexto necesario; búsqueda puede enviar el mensaje actual a un proveedor. Informar la ruta antes de habilitarla y probar con una clave de desarrollo propia, nunca con secretos reales en CI.
5. **Dependencia de accesibilidad:** reforzar selector semántico con jerarquía y OCR como opciones/fallback; si no existe evidencia inequívoca, pausar en lugar de tocar coordenadas a ciegas.
6. **Autonomía de largo horizonte:** el trabajo largo da más oportunidad de acciones no deseadas. Introducir límites, presupuesto/tiempo, aprobaciones y stop/rollback antes de aumentar autonomía.

## Referencias materiales

Cada enlace se consultó el **18 de octubre de 2026**. El “no demuestra” de cada fuente evita usarla como prueba del código propio.

1. **“ChatGPT Work and Codex”** — OpenAI Help Center — https://help.openai.com/en/articles/20001275-chatgpt-work-and-codex  
   Respalda: distinción Chat vs Work/Codex, tareas largas, proyectos/contexto, revisión/progreso y aprobaciones según producto actual.  
   No demuestra: calidad, seguridad o equivalencia del worker Tunnel Turbo.
2. **“Introducing the Codex app”** — OpenAI — https://openai.com/index/introducing-the-codex-app/  
   Respalda: tareas en hilos/proyectos, revisión de cambios, worktrees y control de múltiples agentes.  
   No demuestra: que Tunnel Turbo tenga worktrees, infraestructura cloud o ese nivel de aislamiento.
3. **“Projects in ChatGPT”** — OpenAI Help Center — https://help.openai.com/en/articles/10169521-projects-in-chatgpt  
   Respalda: contexto e instrucciones persistentes con ámbito de proyecto y controles de memoria.  
   No demuestra: memoria duradera o recuperación semántica en Tunnel Turbo.
4. **“Gemini Nano”** — Android Developers — https://developer.android.com/ai/gemini-nano  
   Respalda: AICore/Gemini Nano en dispositivo y acceso mediante ML Kit GenAI/AI Edge.  
   No demuestra: disponibilidad en todo Android, capacidad agentiva general ni ejecución del código del proyecto.
5. **“Find the right AI/ML solution for your app”** — Android Developers — https://developer.android.com/ai/overview  
   Respalda: opciones Android de GenAI on-device y cuándo usar servicios de alto nivel o modelo propio.  
   No demuestra: que una ruta concreta sea la mejor en todos los equipos o que Tunnel Turbo ya integre ML Kit GenAI.
6. **“LiteRT-LM”** — Google AI Edge, repositorio oficial — https://github.com/google-ai-edge/LiteRT-LM  
   Respalda: estado y alcance del runtime de inferencia local y ejemplos de Kotlin/plataformas.  
   No demuestra: compatibilidad de cada modelo/OEM ni seguridad del agente construido encima.
7. **“LiteRT-LM Documentation”** — Google AI Edge — https://github.com/google-ai-edge/LiteRT-LM/blob/main/docs/README.md  
   Respalda: APIs y estado relativo de las rutas de build; CMake se señala como preliminar en la documentación consultada.  
   No demuestra: calidad de producción en Android ni el rendimiento en este dispositivo.
8. **LiteRT-LM issue tracker, reportes abiertos** — Google AI Edge — https://github.com/google-ai-edge/LiteRT-LM/issues  
   Respalda: contraevidencia concreta de fallos de runtimes/versiones reportados por la comunidad (por ejemplo issues #3266, #3771, #3927).  
   No demuestra: tasa general de fallo, estado de resolución de todos los issues ni reproducción independiente.
9. **“Create your own accessibility service (Views)”** — Android Developers — https://developer.android.com/guide/topics/ui/accessibility/views/service  
   Respalda: propósito, declaración del servicio y protección del servicio Android.  
   No demuestra: aprobación de Play ni que toda automatización de apps por accesibilidad sea aceptable.
10. **“Behavior changes: Apps targeting Android 16 or higher”** — Android Developers — https://developer.android.com/about/versions/16/behavior-changes-16  
    Respalda: edge-to-edge obligatorio para target 36 y cambios de back.  
    No demuestra: que Tunnel Turbo ya sea compatible con target 36.
11. **“Safety and alignment in an era of long-horizon models”** — OpenAI — https://openai.com/index/safety-alignment-long-horizon-models/  
    Respalda: riesgos nuevos observados en tareas autónomas prolongadas y necesidad de monitoreo, mitigación y rollback.  
    No demuestra: que los mismos incidentes ocurran en Tunnel Turbo; motiva límites y validación independiente.

## Evidencia local revisada

Sólo se usó para describir alcance del repositorio: `AgentSession.kt`, `GoalVerifier.kt`, `IntentCoordinator.kt`, `LocalModelCatalog.kt`, `LiteRtLmLocalChatEngine.kt`, `ConversationMemory.kt`, `GeminiFreeApiClient.kt`, `ApiKeyVault.kt`, `AccessibilityBridge.kt`, `SemanticDisplayMapView.kt`, `controller/`, `tests/` y la configuración Gradle/manifest.

La consulta externa no es una prueba de compilación, ejecución, latencia ni corrección de Tunnel Turbo. No se ejecutaron pruebas ni se instaló la app en esta publicación.
