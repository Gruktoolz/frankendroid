import os
import sys
import json
import hashlib
from collections import defaultdict
import jsonschema

MANIFEST_PATH = "datasets/tiny-cognitive-v2-manifest.json"
DATASET_PATH = "datasets/tiny-cognitive-v2.jsonl"
SCHEMA_PATH = "schemas/local-cognitive-assessment-v1.schema.json"

# Section 35: Generator must fail if dataset is already frozen!
if os.path.exists(MANIFEST_PATH):
    try:
        with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
            manifest_data = json.load(f)
            if manifest_data.get("frozen", False):
                print(f"FATAL: {MANIFEST_PATH} is marked FROZEN! Section 35 forbids overwriting a frozen dataset.", file=sys.stderr)
                sys.exit(1)
    except Exception as e:
        print(f"Error reading manifest: {e}", file=sys.stderr)
        sys.exit(1)

# Load schema
with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
    schema = json.load(f)
schema_validator = jsonschema.Draft202012Validator(schema)

def validate_invariants(assessment):
    violations = []
    conf = assessment.get("confidence", 0.0)
    if conf < 0.0 or conf > 1.0:
        violations.append(f"confidence must be between 0.0 and 1.0, got {conf}")
    ver = assessment.get("schemaVersion")
    if ver != "1.0.0":
        violations.append(f"unsupported schemaVersion: '{ver}', expected '1.0.0'")
    mode = assessment.get("interactionMode")
    clar_req = assessment.get("clarificationRequired", False)
    if mode == "CLARIFY" and not clar_req:
        violations.append("interactionMode == CLARIFY requires clarificationRequired == true")
    unres = assessment.get("unresolvedReferences", [])
    risk = assessment.get("riskHint")
    if clar_req and not unres and not risk:
        violations.append("clarificationRequired == true requires unresolvedReferences or explicit riskHint")
    needs_info = assessment.get("needsCurrentInformation", False)
    caps = assessment.get("requiredCapabilityClasses", [])
    routes = assessment.get("candidateRouteClasses", [])
    roles = assessment.get("providerRoleHints", [])
    if needs_info:
        has_research = ("CURRENT_WEB_INFORMATION" in caps) or any(r in ["WEB", "BROWSER", "PROVIDER_NATIVE"] for r in routes) or ("CURRENT_INFO_RESEARCH" in roles)
        if not has_research:
            violations.append("needsCurrentInformation == true requires appropriate research/web capability, route, or role hint")
    durable = assessment.get("needsDurableWork", False)
    if durable and mode != "WORK":
        violations.append("needsDurableWork == true requires interactionMode == WORK")
    strat_req = assessment.get("strategyRequired", False)
    if strat_req and not caps:
        violations.append("strategyRequired == true requires at least one RequiredCapabilityClass")
    if mode in ["ACTION", "WORK"]:
        has_any = assessment.get("needsDeviceInteraction", False) or assessment.get("needsBrowser", False) or assessment.get("needsFiles", False) or assessment.get("needsCode", False) or assessment.get("needsMediaGeneration", False) or durable or len(caps) > 0 or len(routes) > 0
        if not has_any:
            violations.append("ACTION or WORK mode must not have empty capability, route, and requirement flags")
    return violations

groups = {}

def create_group(group_id, template_family, scenario_family, mode, domain):
    groups[group_id] = {
        "group_id": group_id,
        "template_family": template_family,
        "scenario_family": scenario_family,
        "mode": mode,
        "domain": domain,
        "items": []
    }

def add_item(
    group_id,
    language,
    difficulty,
    user_message,
    local_sufficiency="LOCAL_ONLY",
    needs_current_info=False,
    needs_device_interaction=False,
    needs_browser=False,
    needs_files=False,
    needs_code=False,
    needs_media_gen=False,
    needs_durable_work=False,
    strategy_required=False,
    parallelizable=False,
    clarification_required=False,
    required_caps=None,
    candidate_routes=None,
    provider_roles=None,
    entities=None,
    constraints=None,
    unresolved_refs=None,
    risk_hint=None,
    confidence=0.95,
    conv_context=None,
    active_goal=None,
    active_work=None,
    fg_package=None,
    avail_caps=None,
    recent_progress=None
):
    grp = groups[group_id]
    if required_caps is None: required_caps = []
    if candidate_routes is None: candidate_routes = []
    if provider_roles is None: provider_roles = []
    if entities is None: entities = []
    if constraints is None: constraints = []
    if unresolved_refs is None: unresolved_refs = []
    if avail_caps is None: avail_caps = []

    locale = "es-ES" if language in ["es", "mixed"] else "en-US"

    item = {
        "paraphraseGroup": group_id,
        "templateFamily": grp["template_family"],
        "scenarioFamily": grp["scenario_family"],
        "language": language,
        "difficulty": difficulty,
        "input": {
            "userMessage": user_message,
            "conversationContextSummary": conv_context,
            "activeGoalSummary": active_goal,
            "activeWorkSummary": active_work,
            "currentForegroundPackage": fg_package,
            "availableCapabilityClasses": avail_caps,
            "recentProgressState": recent_progress,
            "unresolvedReferences": unresolved_refs,
            "locale": locale
        },
        "expectedAssessment": {
            "schemaVersion": "1.0.0",
            "interactionMode": grp["mode"],
            "taskDomain": grp["domain"],
            "entities": entities,
            "constraints": constraints,
            "unresolvedReferences": unresolved_refs,
            "needsCurrentInformation": needs_current_info,
            "needsDeviceInteraction": needs_device_interaction,
            "needsBrowser": needs_browser,
            "needsFiles": needs_files,
            "needsCode": needs_code,
            "needsMediaGeneration": needs_media_gen,
            "needsDurableWork": needs_durable_work,
            "localSufficiency": local_sufficiency,
            "requiredCapabilityClasses": required_caps,
            "candidateRouteClasses": candidate_routes,
            "providerRoleHints": provider_roles,
            "strategyRequired": strategy_required,
            "parallelizablePotential": parallelizable,
            "clarificationRequired": clarification_required,
            "riskHint": risk_hint,
            "confidence": confidence,
            "telemetry": {
                "tinyEngineAvailable": True,
                "tinyModelId": "dataset-v2-ground-truth",
                "tinyBackend": "SPECIFICATION",
                "tinyInferenceMs": 0,
                "tinyColdStartMs": 0,
                "tinyInputTokens": len(user_message.split()),
                "tinyOutputTokens": 20,
                "potentialCloudRoundsAvoided": 1 if local_sufficiency in ["LOCAL_ONLY", "LOCAL_PREFERRED"] else 0,
                "estimatedLocalizableDecisions": 1 if local_sufficiency in ["LOCAL_ONLY", "LOCAL_PREFERRED"] else 0
            }
        }
    }
    grp["items"].append(item)

def add_group(gid, template, scenario, mode, domain, es_variants, en_variant, mix_variant=None, **kwargs):
    create_group(gid, template, scenario, mode, domain)
    for es in es_variants:
        diff = "easy" if len(es.split()) < 6 else ("medium" if len(es.split()) < 12 else "hard")
        add_item(gid, "es", diff, es, **kwargs)
    diff_en = "easy" if len(en_variant.split()) < 6 else "medium"
    add_item(gid, "en", diff_en, en_variant, **kwargs)
    if mix_variant:
        add_item(gid, "mixed", "medium", mix_variant, **kwargs)

print("Building Spanish-dominant structured groups...")

# =====================================================================
# 1. CHAT GROUPS (~65 examples)
# =====================================================================
add_group("chat_shizuku", "concept_explanation", "os_architecture", "CHAT", "GENERAL_KNOWLEDGE",
          ["qué es Shizuku?", "para qué sirve Shizuku en Android?", "cómo funciona el servicio Shizuku?", "explícame qué permisos otorga Shizuku"],
          "what is Shizuku on Android?", "qué es Shizuku on Android?",
          local_sufficiency="LOCAL_PREFERRED", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_coroutines", "concept_explanation", "software_development", "CHAT", "GENERAL_KNOWLEDGE",
          ["explícame las corrutinas en Kotlin", "cómo evitan bloquear hilos las corrutinas?", "qué diferencia hay entre corrutina y thread?", "cómo funciona suspend fun en Kotlin?"],
          "explain how Kotlin coroutines work conceptually", "cómo funcionan coroutines en Kotlin?",
          local_sufficiency="LOCAL_PREFERRED", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_docker", "concept_explanation", "cloud_infrastructure", "CHAT", "GENERAL_KNOWLEDGE",
          ["qué diferencia hay entre Docker y una máquina virtual?", "cómo aísla procesos Docker?", "por qué los contenedores son más ligeros que las VMs?", "explícame las capas de una imagen Docker"],
          "what is the difference between Docker and a VM?", "cuál es la diferencia between Docker and VMs?",
          local_sufficiency="LOCAL_PREFERRED", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_binder", "concept_explanation", "os_internals", "CHAT", "GENERAL_KNOWLEDGE",
          ["cómo funciona IPC Binder en Android?", "por qué Android usa Binder en lugar de sockets?", "qué papel tiene el ServiceManager con Binder?", "explícame el driver de Binder en el kernel de Linux"],
          "how does Android Binder IPC work in the kernel?", "explícame cómo funciona Binder IPC in Android",
          local_sufficiency="LOCAL_PREFERRED", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_oauth", "concept_explanation", "cybersecurity", "CHAT", "GENERAL_KNOWLEDGE",
          ["cuál es la diferencia entre OAuth 2.0 y OpenID Connect?", "cómo funciona el flujo de autorización OAuth2?", "para qué sirve el refresh token?", "qué protege el protocolo OpenID Connect?"],
          "what is the difference between OAuth 2 and OIDC?", "explícame la diferencia between OAuth2 and OIDC",
          local_sufficiency="LOCAL_PREFERRED", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_writing_apology", "writing_assistance", "communication", "CHAT", "COMMUNICATION",
          ["ayúdame a redactar un correo formal disculpándome por un retraso", "cómo puedo disculparme educadamente por entregar tarde un informe?", "redacta una nota formal de disculpa por demora", "ayúdame a disculparme con un cliente por una entrega retrasada"],
          "help me draft a polite email apologizing for a delay", "redacta a polite email disculpándome por la demora",
          local_sufficiency="LOCAL_PREFERRED", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_writing_declining", "writing_assistance", "communication", "CHAT", "COMMUNICATION",
          ["cómo rechazar una oferta de trabajo de manera profesional?", "redacta un mensaje amable declinando una propuesta laboral", "consejos para decir que no a una oferta sin cerrar puertas", "redacta un correo declinando cortésmente un puesto"],
          "how can I politely decline a job offer?", "cómo puedo decline a job offer cordialmente?",
          local_sufficiency="LOCAL_PREFERRED", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_pleasantries_greetings", "pleasantry", "social", "CHAT", "CONVERSATIONAL",
          ["hola, buenos días", "hola, qué tal estás?", "buenas tardes, cómo te va?", "hola qué tal"],
          "hello, how are you today?", "hola, how is it going?",
          local_sufficiency="LOCAL_ONLY", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC"], provider_roles=["GENERAL_REASONING"])

add_group("chat_pleasantries_thanks", "pleasantry", "social", "CHAT", "CONVERSATIONAL",
          ["muchas gracias por tu ayuda", "te lo agradezco mucho", "perfecto, muchas gracias", "mil gracias por todo"],
          "thank you so much for your help", "muchas gracias, that was great",
          local_sufficiency="LOCAL_ONLY", required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC"], provider_roles=["GENERAL_REASONING"])

add_group("chat_ctx_code_example", "contextual_followup", "programming", "CHAT", "CONVERSATIONAL",
          ["dame un ejemplo práctico en código de lo que acabas de explicar", "puedes mostrarme cómo se implementa eso en kotlin?", "escribe un snippet corto ilustrando ese concepto", "cómo se vería eso en código real?"],
          "can you show me a practical code snippet for that?", "dame a practical code snippet de eso",
          local_sufficiency="LOCAL_PREFERRED", conv_context="explicación conceptual previa sobre el patrón Repository en Kotlin",
          required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

add_group("chat_ctx_simplify_analogy", "contextual_followup", "pedagogy", "CHAT", "CONVERSATIONAL",
          ["explícaselo a un niño de 10 años", "puedes simplificar la explicación anterior?", "resume lo anterior con una analogía cotidiana", "dímelo de forma más sencilla sin tecnicismos"],
          "explain that as if I were ten years old", "explícalo simpler para alguien no técnico",
          local_sufficiency="LOCAL_PREFERRED", conv_context="discusión técnica sobre criptografía asimétrica",
          required_caps=["GENERAL_CHAT"], candidate_routes=["LOCAL_DETERMINISTIC", "PROVIDER_NATIVE"], provider_roles=["GENERAL_REASONING"])

# =====================================================================
# 2. RESEARCH GROUPS (~50 examples)
# =====================================================================
add_group("res_news_android", "news_search", "technology_news", "RESEARCH", "RESEARCH",
          ["busca qué cambió hoy con Android 16", "qué novedades salieron hoy sobre Android 16?", "busca noticias recientes del lanzamiento de Android 16", "investiga qué anunció Google hoy sobre Android 16"],
          "search what changed today regarding Android 16", "busca what changed today with Android 16",
          local_sufficiency="CLOUD_PREFERRED", needs_current_info=True, strategy_required=True,
          required_caps=["CURRENT_WEB_INFORMATION"], candidate_routes=["PROVIDER_NATIVE", "WEB", "BROWSER"], provider_roles=["CURRENT_INFO_RESEARCH", "GENERAL_REASONING"],
          entities=[{"type": "topic", "value": "Android 16"}])

add_group("res_stocks_market", "financial_lookup", "market_data", "RESEARCH", "RESEARCH",
          ["a cuánto cotiza Tesla hoy?", "cuál es el precio de las acciones de Apple en este momento?", "busca la cotización actual del índice S&P 500", "cuánto vale la acción de Google hoy?"],
          "what is the current stock price of Tesla today?", "cuánto vale Tesla stock right now?",
          local_sufficiency="CLOUD_PREFERRED", needs_current_info=True, strategy_required=True,
          required_caps=["CURRENT_WEB_INFORMATION"], candidate_routes=["PROVIDER_NATIVE", "WEB", "BROWSER"], provider_roles=["CURRENT_INFO_RESEARCH", "GENERAL_REASONING"],
          entities=[{"type": "topic", "value": "Tesla"}])

add_group("res_weather_forecast", "weather_lookup", "meteorology", "RESEARCH", "RESEARCH",
          ["qué tiempo hace hoy en Madrid?", "va a llover hoy en Barcelona?", "cuál es la temperatura actual en Sevilla?", "pronóstico del tiempo para hoy en Valencia"],
          "what is the weather like today in Madrid?", "qué tiempo hace today in Madrid?",
          local_sufficiency="CLOUD_PREFERRED", needs_current_info=True, strategy_required=True,
          required_caps=["CURRENT_WEB_INFORMATION"], candidate_routes=["PROVIDER_NATIVE", "WEB", "BROWSER"], provider_roles=["CURRENT_INFO_RESEARCH", "GENERAL_REASONING"],
          entities=[{"type": "topic", "value": "Madrid"}])

add_group("res_flight_prices", "price_comparison", "travel", "RESEARCH", "RESEARCH",
          ["cuánto cuestan actualmente los vuelos a Tokio para diciembre?", "busca precios de vuelos baratos a Roma para el próximo puente", "cuánto vale viajar en avión a París la próxima semana?", "busca ofertas actuales de vuelos a Nueva York"],
          "how much are flights to Tokyo for December currently?", "cuánto cuestan flights to Tokyo currently?",
          local_sufficiency="CLOUD_PREFERRED", needs_current_info=True, strategy_required=True,
          required_caps=["CURRENT_WEB_INFORMATION"], candidate_routes=["PROVIDER_NATIVE", "WEB", "BROWSER"], provider_roles=["CURRENT_INFO_RESEARCH", "GENERAL_REASONING"],
          entities=[{"type": "topic", "value": "Tokio"}])

# Contextual research continuations (Section 10 specific examples!)
add_group("res_ctx_routers_wifi7", "contextual_filter", "product_specs", "RESEARCH", "RESEARCH",
          ["compara sólo los que cuesten menos de 150 euros", "filtra la lista dejando sólo los modelos de menos de 150€", "descarta los que superen los 150 euros y compara el resto", "de esos routers cuáles valen menos de 150 euros?"],
          "compare only those costing under 150 euros", "filtra and compare only models under 150 euros",
          local_sufficiency="CLOUD_PREFERRED", needs_current_info=True, strategy_required=True,
          conv_context="investigación previa sobre routers WiFi 7 disponibles en España",
          required_caps=["CURRENT_WEB_INFORMATION"], candidate_routes=["PROVIDER_NATIVE", "WEB", "BROWSER"], provider_roles=["CURRENT_INFO_RESEARCH", "GENERAL_REASONING"],
          constraints=[{"text": "menos de 150 euros", "isNegative": False, "category": "scope"}])

add_group("res_ctx_smartphone_battery", "contextual_filter", "product_specs", "RESEARCH", "RESEARCH",
          ["de esos móviles, cuáles tienen más de 5000 mAh de batería?", "filtra sólo los terminales con más de 5000 mAh", "de la lista anterior muéstrame los que tengan al menos 5000 mAh", "cuáles de esos teléfonos superan los 5000 mAh?"],
          "out of those phones, which ones have more than 5000 mAh battery?", "de esos smartphones, which ones have over 5000 mAh?",
          local_sufficiency="CLOUD_PREFERRED", needs_current_info=True, strategy_required=True,
          conv_context="comparativa de smartphones de gama media en 2026",
          required_caps=["CURRENT_WEB_INFORMATION"], candidate_routes=["PROVIDER_NATIVE", "WEB", "BROWSER"], provider_roles=["CURRENT_INFO_RESEARCH", "GENERAL_REASONING"],
          constraints=[{"text": "más de 5000 mAh", "isNegative": False, "category": "scope"}])

add_group("res_ctx_hotels_cancellation", "contextual_filter", "travel_booking", "RESEARCH", "RESEARCH",
          ["muestra únicamente los hoteles con cancelación gratuita", "filtra sólo opciones con política de cancelación sin coste", "descarta los que no tengan cancelación gratuita", "de esos alojamientos cuáles se pueden cancelar gratis?"],
          "show only hotels with free cancellation", "muestra sólo hotels with free cancellation",
          local_sufficiency="CLOUD_PREFERRED", needs_current_info=True, strategy_required=True,
          conv_context="búsqueda de hoteles en Barcelona para este fin de semana",
          required_caps=["CURRENT_WEB_INFORMATION"], candidate_routes=["PROVIDER_NATIVE", "WEB", "BROWSER"], provider_roles=["CURRENT_INFO_RESEARCH", "GENERAL_REASONING"],
          constraints=[{"text": "cancelación gratuita", "isNegative": False, "category": "filter"}])

# =====================================================================
# 3. ACTION GROUPS (~135 examples)
# =====================================================================

# 3A. Bounded System Settings & OS Controls (LOCAL_ONLY, strategyRequired=false)
add_group("act_sys_bluetooth", "os_setting_toggle", "hardware_control", "ACTION", "SYSTEM_SETTINGS",
          ["abre bluetooth", "entra a los ajustes de bluetooth", "enciende bluetooth en el dispositivo", "ve a la configuración de bluetooth"],
          "open bluetooth settings", "abre bluetooth settings",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=False,
          required_caps=["SYSTEM_SETTINGS", "SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE", "ANDROID_UI"],
          entities=[{"type": "device_setting", "value": "Bluetooth"}])

add_group("act_sys_wifi", "os_setting_toggle", "hardware_control", "ACTION", "SYSTEM_SETTINGS",
          ["apaga el wifi", "desconecta la red wifi", "apaga la conexión wifi", "desactiva el wifi del dispositivo"],
          "turn off wifi", "apaga el wifi right now",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=False,
          required_caps=["SYSTEM_SETTINGS", "SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE", "ANDROID_UI"],
          entities=[{"type": "device_setting", "value": "WiFi"}])

add_group("act_sys_settings_hub", "os_setting_toggle", "hardware_control", "ACTION", "SYSTEM_SETTINGS",
          ["abre ajustes", "abre la configuración del sistema", "entra a los ajustes de android", "ve a configuración general"],
          "open device settings", "abre system settings",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=False,
          required_caps=["SYSTEM_SETTINGS", "SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE", "ANDROID_UI"],
          entities=[{"type": "device_setting", "value": "Settings"}])

add_group("act_sys_flashlight", "os_device_toggle", "hardware_control", "ACTION", "DEVICE_CONTROL",
          ["enciende la linterna", "activa la linterna del móvil", "prende la luz de la linterna", "enciende el flash como linterna"],
          "turn on the flashlight", "enciende the flashlight",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=False,
          required_caps=["SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE"],
          entities=[{"type": "device_setting", "value": "Linterna"}])

add_group("act_sys_rotation", "os_device_toggle", "hardware_control", "ACTION", "DEVICE_CONTROL",
          ["bloquea la rotación de pantalla", "desactiva el giro automático", "bloquea el giro de la pantalla", "fija la orientación en vertical"],
          "lock screen rotation", "bloquea screen rotation",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=False,
          required_caps=["SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE"],
          entities=[{"type": "device_setting", "value": "Rotación"}])

add_group("act_sys_volume", "os_device_toggle", "hardware_control", "ACTION", "DEVICE_CONTROL",
          ["silencia el volumen multimedia", "baja el volumen a cero", "pon el móvil en silencio", "desactiva el sonido multimedia"],
          "mute media volume", "silencia media volume",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=False,
          required_caps=["SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE"],
          entities=[{"type": "device_setting", "value": "Volumen"}])

add_group("act_sys_alarm", "os_device_toggle", "alarm_management", "ACTION", "DEVICE_CONTROL",
          ["pon una alarma a las 7:30 de la mañana", "despiértame a las 7:30 am", "configura una alarma para las siete y media", "crea una alarma mañana a las 7:30"],
          "set an alarm for 7:30 am", "pon an alarm at 7:30 am",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=False,
          required_caps=["SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE"],
          entities=[{"type": "device_setting", "value": "Alarma"}])

# 3B. Generic Media Playback Strategy Family (Section 12 Spotify/Queen Strategy Regression Family)
add_group("act_media_queen_spotify", "media_playback_strategy", "media_playback", "ACTION", "MEDIA_PLAYBACK",
          ["pon Queen en Spotify", "reproduce Queen en Spotify", "quiero escuchar Queen en la app de Spotify", "pon música de Queen en Spotify"],
          "play Queen on Spotify", "pon Queen on Spotify right now",
          local_sufficiency="LOCAL_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["MEDIA_PLAYBACK"], candidate_routes=["SYSTEM_API", "PROVIDER_NATIVE", "ANDROID_NATIVE", "ANDROID_UI"], provider_roles=["GENERAL_REASONING"],
          entities=[{"type": "artist", "value": "Queen"}, {"type": "app", "value": "Spotify"}])

add_group("act_media_jazz_generic", "media_playback_strategy", "media_playback", "ACTION", "MEDIA_PLAYBACK",
          ["reproduce jazz en mi app de música", "pon música jazz en mi reproductor", "escuchar algo de jazz en mi servicio de música", "pon canciones de jazz en la app de música"],
          "play jazz on my music service", "reproduce jazz on my music service",
          local_sufficiency="LOCAL_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["MEDIA_PLAYBACK"], candidate_routes=["SYSTEM_API", "PROVIDER_NATIVE", "ANDROID_NATIVE", "ANDROID_UI"], provider_roles=["GENERAL_REASONING"],
          entities=[{"type": "genre", "value": "jazz"}])

add_group("act_media_podcast_default", "media_playback_strategy", "media_playback", "ACTION", "MEDIA_PLAYBACK",
          ["pon este podcast en la app que uso normalmente", "reproduce el podcast en mi aplicación habitual", "escuchar este episodio en mi app de podcast", "reproduce este podcast en mi reproductor favorito"],
          "play this podcast on my default audio app", "pon este podcast on my default player",
          local_sufficiency="LOCAL_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["MEDIA_PLAYBACK"], candidate_routes=["SYSTEM_API", "PROVIDER_NATIVE", "ANDROID_NATIVE", "ANDROID_UI"], provider_roles=["GENERAL_REASONING"],
          entities=[{"type": "podcast", "value": "este podcast"}])

add_group("act_media_car_audio", "media_playback_strategy", "media_playback", "ACTION", "MEDIA_PLAYBACK",
          ["reproduce música en el coche", "pon mi música en el coche", "activa la música para el coche", "reproduce mi lista favorita en el coche"],
          "play music in the car", "reproduce music in the car",
          local_sufficiency="LOCAL_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["MEDIA_PLAYBACK"], candidate_routes=["SYSTEM_API", "PROVIDER_NATIVE", "ANDROID_NATIVE", "ANDROID_UI"], provider_roles=["GENERAL_REASONING"],
          entities=[{"type": "genre", "value": "música"}])

add_group("act_media_bohemian_rhapsody", "media_playback_strategy", "media_playback", "ACTION", "MEDIA_PLAYBACK",
          ["reproduce Bohemian Rhapsody en Spotify", "pon Bohemian Rhapsody en mi lista", "escuchar Bohemian Rhapsody en Spotify", "pon la canción Bohemian Rhapsody en Spotify"],
          "play Bohemian Rhapsody on Spotify", "pon Bohemian Rhapsody on Spotify",
          local_sufficiency="LOCAL_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["MEDIA_PLAYBACK"], candidate_routes=["SYSTEM_API", "PROVIDER_NATIVE", "ANDROID_NATIVE", "ANDROID_UI"], provider_roles=["GENERAL_REASONING"],
          entities=[{"type": "song", "value": "Bohemian Rhapsody"}, {"type": "app", "value": "Spotify"}])

add_group("act_media_huberman_lab", "media_playback_strategy", "media_playback", "ACTION", "MEDIA_PLAYBACK",
          ["reproduce el último episodio de Huberman Lab", "pon Huberman Lab en mi app", "escuchar Huberman Lab podcast", "pon el nuevo episodio de Huberman Lab"],
          "play the latest episode of Huberman Lab", "pon the latest episode of Huberman Lab",
          local_sufficiency="LOCAL_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["MEDIA_PLAYBACK"], candidate_routes=["SYSTEM_API", "PROVIDER_NATIVE", "ANDROID_NATIVE", "ANDROID_UI"], provider_roles=["GENERAL_REASONING"],
          entities=[{"type": "podcast", "value": "Huberman Lab"}])

# 3C. Negative Constraints & Safety Restrictions (Section 17 Critical Error Triggers)
add_group("act_neg_claude_no_write", "safety_prohibition", "app_interaction", "ACTION", "PRODUCTIVITY",
          ["abre Claude pero no escribas ni envíes nada", "entra a Claude en modo sólo lectura sin escribir", "abre la app de Claude sin escribir ningún prompt", "abre Claude sólo para mirar sin redactar nada"],
          "open Claude but do not write or send anything", "abre Claude but don't write or send anything",
          local_sufficiency="CLOUD_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["ANDROID_NAVIGATION", "APP_INTERACTION"], candidate_routes=["ANDROID_UI", "ANDROID_NATIVE"], provider_roles=["COMPUTER_USE", "GENERAL_REASONING"],
          entities=[{"type": "app", "value": "Claude"}],
          constraints=[{"text": "sin escribir", "isNegative": True, "category": "interaction"}, {"text": "sin enviar", "isNegative": True, "category": "side_effect"}])

add_group("act_neg_files_no_delete", "safety_prohibition", "file_operations", "ACTION", "FILE_MANAGEMENT",
          ["abre Files y revisa las descargas pero no borres nada", "entra en la carpeta de descargas de Files sin eliminar ningún archivo", "revisa los archivos descargados sin borrar nada", "abre Files en Descargas sin borrar ningún documento"],
          "open Files and inspect downloads but do not delete anything", "abre Files and check downloads but don't delete anything",
          local_sufficiency="CLOUD_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["ANDROID_NAVIGATION", "APP_INTERACTION", "FILE_READ"], candidate_routes=["ANDROID_UI", "ANDROID_NATIVE", "FILES"], provider_roles=["COMPUTER_USE", "GENERAL_REASONING"],
          entities=[{"type": "app", "value": "Files"}, {"type": "folder", "value": "Descargas"}],
          constraints=[{"text": "no borrar", "isNegative": True, "category": "safety"}])

add_group("act_neg_whatsapp_read_only", "safety_prohibition", "communication", "ACTION", "COMMUNICATION",
          ["abre WhatsApp y sólo lee los mensajes sin contestar", "entra en WhatsApp únicamente para revisar chats sin responder", "abre WhatsApp en modo lectura sin enviar respuestas", "revisa WhatsApp pero no envíes ningún mensaje"],
          "open WhatsApp and only read messages without replying", "abre WhatsApp and only read messages without replying",
          local_sufficiency="CLOUD_PREFERRED", needs_device_interaction=True, strategy_required=True,
          required_caps=["ANDROID_NAVIGATION", "APP_INTERACTION"], candidate_routes=["ANDROID_UI", "ANDROID_NATIVE"], provider_roles=["COMPUTER_USE", "GENERAL_REASONING"],
          entities=[{"type": "app", "value": "WhatsApp"}],
          constraints=[{"text": "sin enviar", "isNegative": True, "category": "side_effect"}, {"text": "sólo lectura / inspección", "isNegative": True, "category": "scope"}])

add_group("act_neg_settings_no_modify", "safety_prohibition", "system_settings", "ACTION", "SYSTEM_SETTINGS",
          ["entra en ajustes de pantalla pero no cambies configuración", "revisa la configuración de display sin modificar ningún ajuste", "abre ajustes de pantalla en modo inspección", "mira los ajustes de pantalla sin tocar la configuración"],
          "open display settings but do not change any settings", "entra a display settings but don't change configuration",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=True,
          required_caps=["SYSTEM_SETTINGS", "ANDROID_NAVIGATION"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE", "ANDROID_UI"],
          entities=[{"type": "app", "value": "Settings"}],
          constraints=[{"text": "no cambiar configuración", "isNegative": True, "category": "safety"}])

# 3D. Creative Media Generation (Speed vs Quality Preferences)
add_group("act_gen_video_speed", "generative_preference", "multimodal_media", "ACTION", "CREATIVE_MEDIA",
          ["hazme un video rápido de un atardecer en la playa", "genera un video corto y rápido de una puesta de sol", "crea un video rápido de olas del mar", "renderiza un video rápido de un atardecer"],
          "generate a fast video of a beach sunset", "hazme a fast video de un atardecer",
          local_sufficiency="CLOUD_REQUIRED", needs_media_gen=True, strategy_required=True,
          required_caps=["VIDEO_GENERATION"], candidate_routes=["MEDIA_GENERATION", "PROVIDER_NATIVE"], provider_roles=["VIDEO_GENERATION", "MULTIMODAL_ANALYSIS"],
          constraints=[{"text": "priorizar velocidad", "isNegative": False, "category": "speed_preference"}])

add_group("act_gen_image_quality", "generative_preference", "multimodal_media", "ACTION", "CREATIVE_MEDIA",
          ["genera una imagen con máxima calidad de un astronauta en Marte aunque tarde", "dibuja un astronauta en Marte en alta resolución máxima calidad", "haz una imagen de un astronauta con máxima calidad", "renderiza un astronauta en Marte con máxima calidad aunque demore"],
          "generate a maximum quality image of an astronaut on Mars even if it takes longer", "genera an image con máxima calidad de un astronauta",
          local_sufficiency="CLOUD_REQUIRED", needs_media_gen=True, strategy_required=True,
          required_caps=["IMAGE_GENERATION"], candidate_routes=["MEDIA_GENERATION", "PROVIDER_NATIVE"], provider_roles=["IMAGE_GENERATION"],
          constraints=[{"text": "priorizar máxima calidad", "isNegative": False, "category": "quality_preference"}])

# 3E. Contextual App Actions (Foreground package context, active goal continuations)
add_group("act_ctx_fg_settings", "contextual_app_action", "foreground_context", "ACTION", "SYSTEM_SETTINGS",
          ["apaga el bluetooth ahora", "desconéctalo de inmediato", "apágalo", "desactívalo ya"],
          "turn off bluetooth now", "turn off bluetooth right now",
          local_sufficiency="LOCAL_ONLY", needs_device_interaction=True, strategy_required=True,
          fg_package="com.android.settings", active_goal="usuario navegando en ajustes de Bluetooth",
          required_caps=["SYSTEM_SETTINGS", "SYSTEM_CONTROL"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE", "ANDROID_UI"],
          entities=[{"type": "device_setting", "value": "Bluetooth"}])

add_group("act_ctx_fg_chrome", "contextual_app_action", "foreground_context", "ACTION", "PRODUCTIVITY",
          ["abre una nueva pestaña y navega a Wikipedia", "abre otra pestaña en Wikipedia", "nueva pestaña con la web de Wikipedia", "crea una pestaña y entra en Wikipedia"],
          "open a new tab and navigate to Wikipedia", "abre a new tab in Wikipedia",
          local_sufficiency="LOCAL_PREFERRED", needs_device_interaction=True, strategy_required=True,
          fg_package="com.android.chrome", active_goal="navegando en Chrome",
          required_caps=["ANDROID_NAVIGATION", "APP_INTERACTION"], candidate_routes=["SYSTEM_API", "ANDROID_NATIVE", "ANDROID_UI"],
          entities=[{"type": "app", "value": "Chrome"}, {"type": "topic", "value": "Wikipedia"}])

# =====================================================================
# 4. WORK GROUPS (~40 examples)
# =====================================================================
add_group("work_batch_spreadsheet", "batch_work_graph", "productivity_cowork", "WORK", "PRODUCTIVITY",
          ["analiza estos 400 chats, identifica ventas y crea un Sheet editable", "revisa los 400 mensajes de clientes, extrae ventas y genera una hoja de cálculo", "procesa estos cientos de chats y prepara un Sheet con métricas de ventas", "lee los chats de clientes y extrae ventas a un Sheet editable"],
          "analyze these 400 chats, identify sales and create an editable Sheet", "analiza these 400 chats and create an editable Sheet with sales",
          local_sufficiency="CLOUD_REQUIRED", needs_files=True, needs_durable_work=True, strategy_required=True, parallelizable=True,
          required_caps=["DATA_EXTRACTION", "SPREADSHEET_CREATION", "FILE_READ"], candidate_routes=["WORK_GRAPH", "FILES", "PROVIDER_NATIVE"], provider_roles=["LONG_DOCUMENT_ANALYSIS", "PRODUCTIVITY", "GENERAL_REASONING"],
          constraints=[{"text": "formato editable requerido", "isNegative": False, "category": "format_requirement"}])

add_group("work_contracts_summary", "batch_work_graph", "legal_document_analysis", "WORK", "PRODUCTIVITY",
          ["lee estos 5 contratos pdf, extrae las cláusulas de rescisión y prepara un documento comparativo", "analiza estos cinco pdfs legales y genera un informe comparativo de cláusulas", "revisa los contratos pdf y redacta un documento con las penalizaciones", "extrae cláusulas de estos contratos pdf a un documento comparativo"],
          "read these 5 pdf contracts, extract termination clauses and prepare a comparative document", "lee these 5 pdf contracts and prepare a comparative summary document",
          local_sufficiency="CLOUD_REQUIRED", needs_files=True, needs_durable_work=True, strategy_required=True, parallelizable=True,
          required_caps=["DATA_EXTRACTION", "DOCUMENT_CREATION", "FILE_READ"], candidate_routes=["WORK_GRAPH", "FILES", "PROVIDER_NATIVE"], provider_roles=["LONG_DOCUMENT_ANALYSIS", "PRODUCTIVITY", "GENERAL_REASONING"],
          constraints=[{"text": "documento comparativo", "isNegative": False, "category": "format_requirement"}])

add_group("work_ctx_scope_exclusion", "contextual_work_modification", "cowork_continuation", "WORK", "PRODUCTIVITY",
          ["no incluyas los datos de septiembre en el informe", "excluye las cifras del mes de septiembre del reporte", "elimina septiembre del análisis consolidado", "descarta el mes de septiembre del informe"],
          "do not include september data in the report", "no incluyas september data in the report",
          local_sufficiency="CLOUD_REQUIRED", needs_files=True, needs_durable_work=True, strategy_required=True, parallelizable=True,
          active_work="analizando chats de soporte y ventas de Q3 para generar informe consolidado",
          required_caps=["DATA_EXTRACTION", "SPREADSHEET_CREATION", "FILE_WRITE"], candidate_routes=["WORK_GRAPH", "FILES", "PROVIDER_NATIVE"], provider_roles=["LONG_DOCUMENT_ANALYSIS", "PRODUCTIVITY", "GENERAL_REASONING"],
          constraints=[{"text": "no incluir septiembre", "isNegative": True, "category": "scope"}])

add_group("work_codebase_refactor", "code_cowork_pipeline", "software_engineering", "WORK", "CODE_DEVELOPMENT",
          ["revisa todo el repositorio, detecta fugas de memoria y genera un parche con tests unitarios", "audita el código del proyecto, busca memory leaks y escribe los tests correspondientes", "analiza el código completo para corregir fugas de memoria con tests", "encuentra memory leaks en el repo y genera tests unitarios"],
          "review the entire repository, detect memory leaks and generate a patch with unit tests", "revisa the entire repo for memory leaks and generate unit tests",
          local_sufficiency="CLOUD_REQUIRED", needs_files=True, needs_code=True, needs_durable_work=True, strategy_required=True, parallelizable=True,
          required_caps=["CODE_EDITING", "CODE_EXECUTION", "FILE_READ", "FILE_WRITE"], candidate_routes=["WORK_GRAPH", "FILES", "CODE_RUNTIME", "PROVIDER_NATIVE"], provider_roles=["CODE", "GENERAL_REASONING"],
          constraints=[{"text": "incluir tests unitarios", "isNegative": False, "category": "scope"}])

# =====================================================================
# 5. CLARIFY GROUPS (~30 examples)
# =====================================================================
add_group("clarify_unresolved_pronoun", "unresolved_coreference", "ambiguous_pronoun", "CLARIFY", "COMMUNICATION",
          ["haz lo mismo que antes", "repite lo de antes", "hazlo de nuevo", "ejecuta lo mismo de antes"],
          "do the same as before", "haz lo mismo que before",
          local_sufficiency="LOCAL_ONLY", clarification_required=True, strategy_required=False,
          unresolved_refs=["referencia previa no disponible en contexto"])

add_group("clarify_bare_send_action", "missing_arguments", "ambiguous_action", "CLARIFY", "COMMUNICATION",
          ["envía", "manda el mensaje", "envíalo ahora mismo", "dale a enviar"],
          "send the message now", "envía it now",
          local_sufficiency="LOCAL_ONLY", clarification_required=True, strategy_required=False,
          unresolved_refs=["destinatario y contenido faltantes"])

add_group("clarify_bare_compose", "missing_arguments", "ambiguous_action", "CLARIFY", "COMMUNICATION",
          ["escribe", "redacta un texto", "escribe un mensaje", "comienza a escribir"],
          "write a message", "escribe a message",
          local_sufficiency="LOCAL_ONLY", clarification_required=True, strategy_required=False,
          unresolved_refs=["destinatario y contenido no especificados"])

add_group("clarify_destructive_delete_all", "destructive_ambiguity", "safety_risk", "CLARIFY", "FILE_MANAGEMENT",
          ["borra todo", "elimínalo todo inmediatamente", "borra los archivos", "elimina todo el contenido"],
          "delete everything now", "borra everything right now",
          local_sufficiency="LOCAL_ONLY", clarification_required=True, strategy_required=False,
          unresolved_refs=["alcance destructivo no definido"], risk_hint="destructive_action_missing_scope")

# =====================================================================
# DETERMINISTIC GROUPED SPLITTING (Section 8 & Section 9)
# =====================================================================
calib_groups = set()
holdout_groups = set()
calib_examples = []
holdout_examples = []

SPLIT_SEED = "TUNNEL_TURBO_V2_SPLIT_20261018"

for gid, grp in sorted(groups.items()):
    h = hashlib.sha256(f"{SPLIT_SEED}:{gid}".encode("utf-8")).hexdigest()
    # ~20% of groups go to holdout
    is_holdout = (int(h[:8], 16) % 5 == 0)
    if is_holdout:
        holdout_groups.add(gid)
        for it in grp["items"]:
            it["split"] = "holdout"
            holdout_examples.append(it)
    else:
        calib_groups.add(gid)
        for it in grp["items"]:
            it["split"] = "calibration"
            calib_examples.append(it)

# Invariant: Leakage check
leakage = calib_groups.intersection(holdout_groups)
if leakage:
    raise AssertionError(f"FATAL: Group leakage detected: {leakage}")

# Assign sequential IDs
all_examples = []
idx = 1
for ex in calib_examples + holdout_examples:
    ex["id"] = f"tt_v2_{idx:04d}"
    ex["expectedAssessment"]["assessmentId"] = f"cog_v2_{idx:04d}"
    idx += 1
    all_examples.append(ex)

print(f"Total Groups: {len(groups)}")
print(f"Total Examples: {len(all_examples)}")
print(f"Calibration: {len(calib_examples)} (Groups: {len(calib_groups)})")
print(f"Holdout: {len(holdout_examples)} (Groups: {len(holdout_groups)})")

# Validate all against Draft 2020-12 schema & invariants
schema_errs = 0
inv_errs = 0
for ex in all_examples:
    payload = ex["expectedAssessment"]
    if not schema_validator.is_valid(payload):
        schema_errs += 1
        for err in schema_validator.iter_errors(payload):
            print(f"Schema error in {ex['id']}: {err.message}", file=sys.stderr)
    inv = validate_invariants(payload)
    if inv:
        inv_errs += 1
        print(f"Invariant error in {ex['id']}: {inv}", file=sys.stderr)

if schema_errs > 0 or inv_errs > 0:
    raise AssertionError(f"Validation failed: {schema_errs} schema errors, {inv_errs} invariant errors")

def calc_lang_stats(ex_list):
    c = defaultdict(int)
    for e in ex_list:
        c[e["language"]] += 1
    tot = len(ex_list)
    return {k: f"{v} ({v/tot*100:.1f}%)" for k, v in sorted(c.items())}

def calc_mode_stats(ex_list):
    c = defaultdict(int)
    for e in ex_list:
        c[e["expectedAssessment"]["interactionMode"]] += 1
    return dict(sorted(c.items()))

print("Language distribution - Calibration:", calc_lang_stats(calib_examples))
print("Language distribution - Holdout:", calc_lang_stats(holdout_examples))
print("Language distribution - Overall:", calc_lang_stats(all_examples))
print("Mode distribution:", calc_mode_stats(all_examples))

# Write frozen datasets/tiny-cognitive-v2.jsonl
with open(DATASET_PATH, "w", encoding="utf-8") as f:
    for ex in all_examples:
        f.write(json.dumps(ex, ensure_ascii=False) + "\n")

# Compute SHA-256
hasher = hashlib.sha256()
with open(DATASET_PATH, "rb") as f:
    hasher.update(f.read())
dataset_sha256 = hasher.hexdigest()
print(f"Frozen Dataset V2 SHA-256: {dataset_sha256}")

manifest = {
    "datasetName": "tiny-cognitive-v2",
    "schemaVersion": "1.0.0",
    "datasetFile": "tiny-cognitive-v2.jsonl",
    "sha256": dataset_sha256,
    "totalExamples": len(all_examples),
    "calibrationCount": len(calib_examples),
    "holdoutCount": len(holdout_examples),
    "calibrationGroupsCount": len(calib_groups),
    "holdoutGroupsCount": len(holdout_groups),
    "modeDistribution": calc_mode_stats(all_examples),
    "languageDistribution": {
        "calibration": calc_lang_stats(calib_examples),
        "holdout": calc_lang_stats(holdout_examples),
        "overall": calc_lang_stats(all_examples)
    },
    "groupLeakageCount": 0,
    "frozen": True,
    "frozenDate": "2026-10-18"
}

with open(MANIFEST_PATH, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2, ensure_ascii=False)

print(f"SUCCESS: Frozen dataset written to {DATASET_PATH}")
print(f"SUCCESS: Frozen manifest written to {MANIFEST_PATH}")
