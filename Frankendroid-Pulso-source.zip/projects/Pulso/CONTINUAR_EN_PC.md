# Continuar Pulso en la PC

Este paquete contiene el proyecto Android y el APK compilado. Extrae la carpeta `pulso-android` en tu PC y ábrela como carpeta de trabajo en una sesión con ejecución local.

El ZIP por sí mismo no cambia el modo de una conversación ni conecta el USB a una sesión de nube. La sesión local debe poder ejecutar comandos en el ordenador al que está conectado el teléfono.

## Instrucción para continuar

Puedes pegar lo siguiente en la sesión local:

> Continúa este proyecto Pulso desde esta carpeta, usando ejecución local en esta PC. El usuario quiere probar el asistente en su POCO X7 Pro con Android 16 conectado por USB y afirma haber habilitado la depuración USB. Comprueba primero que los comandos se ejecutan en esta PC y detecta el teléfono con ADB. Localiza ADB en PATH o en el SDK local; si falta, instala Android Platform Tools oficiales de Google para este sistema. Si hay varios dispositivos, identifica el POCO antes de actuar. Comprueba modelo y versión Android, instala `dist/pulso-alpha.apk` y abre `dev.pulso.assistant/.MainActivity`. Si el teléfono pide autorización USB o habilitar accesibilidad, indica el paso exacto que necesita intervención en el móvil y continúa después. Revisa errores del proceso de Pulso. Con accesibilidad habilitada y una API key configurada por el usuario dentro de la app, prueba consultar la versión Android en Ajustes sin cambiar configuraciones y comprueba Pausar, Continuar y Detener. No leas ni exportes la API key. Corrige los fallos que encuentres y documenta lo que hayas probado realmente. Lee README.md y VALIDACION.md antes de empezar.

## Estado del proyecto

- App nativa Java, paquete `dev.pulso.assistant`, versión 0.1.0.
- Android mínimo API 30; compilación y objetivo API 36 (Android 16).
- APK disponible en `dist/pulso-alpha.apk`; SHA-256 en el archivo adjunto del mismo nombre.
- 46 comprobaciones de host superadas; recursos, código y DEX compilan; firma v3 e integridad del APK verificadas.
- Las pruebas en teléfono real y una solicitud real a Gemini siguen pendientes. No se ha detectado ni controlado el POCO desde la sesión de nube.
- No se ha recibido ni configurado una API key del usuario en este proyecto.
- El APK está firmado con un certificado de desarrollo. Este paquete no incluye la clave privada de firma. Si compilas con otra firma, no desinstales una app existente con datos para resolver un conflicto de firmas sin revisar primero la situación.

## Prueba inicial por ADB

Ejecutar estos comandos en la PC local, con Platform Tools disponible. Si hay varios dispositivos, usar `adb -s SERIAL` en cada comando que afecte al teléfono.

```sh
adb devices -l
adb shell getprop ro.product.model
adb shell getprop ro.build.version.release
adb shell getprop ro.build.version.sdk
adb shell pm path dev.pulso.assistant
adb install -r dist/pulso-alpha.apk
adb shell am start -W -n dev.pulso.assistant/.MainActivity
```

Antes de instalar, confirmar que el dispositivo seleccionado es el POCO del usuario. El estado `unauthorized` requiere aceptar la huella de depuración en el teléfono. Algunos dispositivos Xiaomi/POCO pueden pedir permisos adicionales para instalar por USB; comprobar el error concreto antes de proponer cambios.

La primera tarea dentro de Pulso es:

> Abre Ajustes, busca la información del teléfono y dime qué versión de Android tengo. No cambies ninguna configuración.

Mantener revisión de cada interacción activada en esa primera prueba. `Probar conexión` consulta el listado de modelos: la cuota y una solicitud con captura se verifican al ejecutar la tarea real.

## Archivos principales

- `README.md`: instalación, funciones, límites, datos y compilación.
- `VALIDACION.md`: comprobaciones realizadas y pendientes.
- `app/`: proyecto nativo Android.
- `tools/build.py`: compilación portable para Linux con Python y runtime Java.
- `tests/CoreTests.java`: contratos de acciones y reglas de confirmación.
- `dist/pulso-alpha.apk`: binario listo para instalar.

Para desarrollar en otros sistemas puede importarse el proyecto en Android Studio con SDK 36, JDK 17+ y Gradle 8.11.1. Para comenzar las pruebas no es necesario recompilar: utiliza el APK incluido.
