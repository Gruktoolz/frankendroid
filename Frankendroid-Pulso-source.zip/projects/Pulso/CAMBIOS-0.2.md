# Decisiones de la alfa 0.2

Trabajo iniciado el 18 de octubre de 2026. Objetivo autorizado: integrar el panel principal de Tunnel Turbo y reducir el tiempo y coste de las tareas de Pulso, con lotes de acciones mecánicas y recuperación automática.

## Decisiones frente al código revisado

Se adaptaron los recursos del panel; Pulso conserva su paquete, cifrado de claves y ejecución Java. Copiar la actividad de 1.723 líneas de Tunnel habría incorporado laboratorio, proveedores y runtimes ajenos al panel.

Se conservó el patrón de snapshot compartido, no las consultas repetidas de `AgentSession.executeSingleCapability()`. La ruta principal de Pulso usa un recorrido por observación. Los eventos y la comprobación puntual de raíz/nodo invalidan acciones sin repetir todo el recorrido. Esto no convierte la observación en una transacción atómica de Android.

Los lotes son estructuras JSON acotadas. Para esta alfa evitan incorporar un intérprete de scripts. Una observación nueva puede usarse para comprobar el paso anterior y resolver el siguiente selector sin solicitar otra decisión al modelo. Los índices de una observación no se ejecutan en otra; los índices futuros sobrantes se descartan si hay selector, y se trunca el lote cuando faltan referencias válidas. Un resultado terminal anticipado se difiere hasta observar el resultado.

Se corrigió una fuente de confirmaciones innecesarias: el código anterior comprobaba “sin etiqueta” antes de distinguir `open_app`, Inicio, Atrás o desplazamientos. Esas acciones globales no tienen etiqueta de nodo. También se separa activar el foco de una búsqueda de activar una configuración del teléfono.

De las nuevas rutas de Tunnel se tomó el criterio de preferir clic semántico, un contenedor comparable y un gesto en el centro del elemento; también scroll semántico con gesto interno como alternativa. No se trasladaron los `CountDownLatch.await()` al hilo de interfaz. Tampoco se copió la rama de `NativeActionEngine` que devuelve éxito de validación sin servicio: Pulso debe tener un servicio real para actuar.

Se examinó `WorkerDisplayManager.createWorkerDisplay()`: crear un display no prueba que exista una ruta de inyección táctil, observación y verificación para ese display. No se incorpora a la alfa. El `ShizukuBridge` actual incluye estado/permisos y captura, pero no una implementación de tap/swipe; no aporta una mejora demostrada a la ruta principal de gestos de Accesibilidad.

Los presupuestos y las pausas ante cambio de app se conservan. No hay evidencia para prometer completar cualquier tarea o para eliminar verificaciones internas. Una interfaz estable no demuestra que una tarea haya terminado; una respuesta JSON válida tampoco demuestra que la acción elegida sea correcta.

## Referencias materiales

Consultadas el 18 de octubre de 2026. Investigación previa y ampliación para interacción/pruebas. Ninguna de estas fuentes demuestra que Pulso funcione: esa evidencia procede de las comprobaciones de host y dispositivo registradas en `VALIDACION.md`.

| Título exacto / fuente y URL directa | Qué respalda | Qué no demuestra |
| --- | --- | --- |
| **Structured outputs** — Google AI for Developers. https://ai.google.dev/gemini-api/docs/structured-output | Contrato estructurado con arrays/objetos y validación propia. | Corrección semántica o éxito de un plan generado. |
| **Gemini Developer API pricing** — Google AI for Developers. https://ai.google.dev/gemini-api/docs/pricing | Orientación económica hacia modelos Lite y coste de entrada/salida. | Coste exacto de esta cuenta, cuota disponible o calidad suficiente en cada app. |
| **Gemini thinking** — Google AI for Developers. https://ai.google.dev/gemini-api/docs/thinking | Relación entre razonamiento, latencia y tokens; configuración compatible por familia. | Que desactivar pensamiento sea óptimo para todas las tareas. |
| **android-agent** — Fox-Islam, GitHub del proyecto. https://github.com/Fox-Islam/android-agent | Comparación con ejecución local de lotes/scripts y selectores entre consultas. | Fiabilidad del proyecto externo o del código de Pulso. No se ejecutó ese repositorio. |
| **AccessibilityService** — Android Developers. https://developer.android.com/reference/android/accessibilityservice/AccessibilityService | Gestos, eventos, capturas y callbacks públicos. | Que todas las apps acepten acciones ni que su aceptación confirme un resultado. |
| **AccessibilityNodeInfo.AccessibilityAction** — Android Developers. https://developer.android.com/reference/android/view/accessibility/AccessibilityNodeInfo.AccessibilityAction | Acciones semánticas de clic, escritura y desplazamiento. | Que cualquier control las implemente correctamente. |
| **AccessibilityNodeInfo** — Android Developers. https://developer.android.com/reference/android/view/accessibility/AccessibilityNodeInfo | Actualización y caducidad de referencias a controles. | Atomicidad del árbol o ausencia de carreras con la UI. |
| **UiAutomation** — Android Developers. https://developer.android.com/reference/android/app/UiAutomation | Las pruebas suprimen servicios de accesibilidad por defecto y existe `FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES`. | Que una prueba instrumentada dentro del proceso del agente conserve su servicio enlazado. |
| **Write automated tests with UI Automator** — Android Developers. https://developer.android.com/training/testing/other-components/ui-automator | Esperas acotadas y límites de la estabilidad de UI. | Que esperar quietud confirme el objetivo ni que debamos incorporar el framework de pruebas al runtime. |

La revisión inicial detallada y sus referencias siguen en `../pulso-reutilizacion-tunnel/REVISION.md`. Su extracción candidata fue el punto de partida; este documento y el README describen la integración posterior.


## Refuerzo posterior — 19 de octubre de 2026

El cierre anterior marcaba `finished` sin una contabilidad explícita de operaciones pendientes. Ahora una tarea conserva su exclusión hasta cerrar HTTP, vaciar el lote y drenar callbacks de operaciones del servicio. La UI distingue el resultado de la tarea del estado interno `IDLE`/`DRAINING`. Cancelar un Future o desconectar HTTP no se utiliza por sí solo como prueba de drenaje. Una respuesta tardía conserva el dueño y la revisión de su tarea; no puede ejecutar pasos de la siguiente. Si el sistema no devuelve un callback, se mantiene el bloqueo para iniciar otra tarea; no se finge un contador cero. Los mensajes de refresco visual no ejecutan acciones sobre otras apps.

Se registran solicitudes iniciadas/completadas/fallidas/canceladas/en curso, streams HTTP abiertos, trabajo activo, callbacks operativos y cola de acciones. El transporte es síncrono y no encola solicitudes ni abre streaming de generación. El contador global también incluye las comprobaciones de conexión iniciadas desde Configuración. `requests_completed` significa respuesta HTTP/JSON recibida; no equivale a tarea conseguida.

`BatchGuard` conserva un paso tras cambiar la firma únicamente con paquete esperado y un marcador contextual único, distinto del destino, más un destino único. Si no se cumplen las precondiciones, se cancela el resto y se replantea. La continuación de escritura/Intro en el campo enfocado sólo se admite con el contexto local del buscador que se acaba de abrir. Una pausa invalida ese contexto. Esto reduce la posibilidad de recetas antiguas, pero un marcador textual no constituye una identidad criptográfica de la pantalla.

El gesto derivado de un nodo exige ventana/paquete vigentes, selector único, límites visibles válidos, centro dentro de la pantalla y ausencia de otra ventana detectada que tape ese centro. No se admite un destino enorme para pulsación física. Android puede tener superposiciones que Accesibilidad no exponga: no se promete detectar toda oclusión. La observación siguiente se comparte entre la comprobación del paso anterior y el siguiente. La aceptación del gesto se registra como envío; si no se comprueba la postcondición, se descarta el lote y se replantea. Un cambio de firma indica cambio observado, no éxito de la tarea.

La comparación con Tunnel confirmó que `clickNode()` puede devolver el resultado de enviar el gesto sin verificar su efecto, y que `executeSingleCapability()` vuelve a consultar texto, paquete y actividad en la espera. No se copiaron esos contratos. Los 20 archivos inventariados del origen conservaron sus hashes al comprobarlos en esta sesión.

Se añadieron rutas locales exactas para abrir Ajustes, Wi-Fi, Bluetooth e información del teléfono mediante intents públicos. Las variantes con «y vuelve atrás» terminan en Inicio para usar una superficie conocida. No se ignoran otras órdenes añadidas a la petición para simular éxito. Estas rutas no sustituyen la ronda de inferencia real.

### Proveedores elegibles

A petición del usuario se añadió un selector de Gemini, Groq, OpenRouter, DeepSeek y OpenAI. El usuario eligió Groq para continuar. Comparten `ModelClient`, contrato de lotes, límites, cancelación y verificación nativa. Cada proveedor tiene un origen HTTPS fijo y un almacén cifrado distinto. Cambiar de proveedor no reenvía una clave existente ni prueba automáticamente otro servicio. No hay fallback entre proveedores ni selección automática de un modelo de precio desconocido.

Los adaptadores compatibles usan Chat Completions con JSON Object, validación nativa y generación sin streaming. Esa coincidencia de protocolo no prueba compatibilidad de todos los modelos. En esta alfa esas conexiones usan semántica textual; sólo Gemini admite la ampliación visual. Groq propone `openai/gpt-oss-20b` al seleccionarlo por primera vez y aplica razonamiento bajo a GPT-OSS 20B/120B. Se puede elegir otro identificador. Las pruebas simuladas validan transporte y contratos, no la calidad de los planes ni una clave real.

La prueba real detectó HTTP 404 para `gemini-2.5-flash-lite`; el descubrimiento repetía ese mismo modelo. Se eliminó su preferencia y la recuperación excluye el identificador recién rechazado. La documentación actual contradice atribuir automáticamente ese error a retirada global: Google indica acceso limitado a proyectos activos y no anuncia cierre de 2.5 Flash-Lite. Tras pasar a otro modelo, el servicio devolvió HTTP 400 con «API key not valid». No se leyó la clave ni se intentó corregirla fuera de la app.

### Investigación material adicional

Todas consultadas el **19 de octubre de 2026**. Las fuentes externas no prueban el funcionamiento de Pulso.

| Título exacto / fuente / URL directa | Qué respalda | Qué NO demuestra |
| --- | --- | --- |
| **Future (Java SE 17 & JDK 17)** — Oracle — https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/concurrent/Future.html | Cancelar solicita interrupción; no reemplaza esperar el cierre real. | Que nuestras operaciones estén drenadas. |
| **AccessibilityService** — Android Developers — https://developer.android.com/reference/android/accessibilityservice/AccessibilityService | Callbacks de gestos/capturas, eventos y sus contratos. | Que un gesto completado haya logrado el objetivo. |
| **AccessibilityNodeInfo** — Android Developers — https://developer.android.com/reference/android/view/accessibility/AccessibilityNodeInfo | Referencias actualizadas y su invalidez si desaparecen. | Atomicidad o ausencia de todas las superposiciones. |
| **Settings** — Android Developers — https://developer.android.com/reference/android/provider/Settings | Intents públicos de páginas Wi-Fi/Bluetooth/información. | Que cada fabricante conserve la misma UI o navegación Atrás. |
| **commands.md** — Callstack, agent-device — https://github.com/callstack/agent-device/blob/main/website/docs/docs/commands.md | Comparación: estabilidad, lotes y efectos parciales/resultado desconocido tras envío. | Que sus garantías se hereden al copiar una idea. No se ejecutó ese motor. |
| **AndroidWorld is an environment and benchmark for autonomous agents** — Google Research, repositorio AndroidWorld — https://github.com/google-research/android_world | Tareas variadas y verificación independiente del resultado. | Equivalencia entre nuestra batería en Ajustes y ese benchmark. |
| **Exception Mapping** — LiteLLM — https://docs.litellm.ai/docs/exception_mapping | Alternativa de adaptadores compartidos y errores por parámetros incompatibles. | Que todos los proveedores acepten los mismos parámetros. No se incorporó el proxy/SDK Python. |
| **Create chat completion** — OpenAI API Reference — https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create | Protocolo de mensajes, respuesta JSON y límites de generación. | Compatibilidad de cada modelo con cada modo. |
| **Create a chat completion** — OpenRouter — https://openrouter.ai/docs/api/api-reference/chat/create-a-chat-completion | Endpoint compatible y extracción de choices/message. | Que un modelo cualquiera acepte imágenes o genere planes correctos. |
| **Provider Routing - Smart Multi-Provider Request Management** — OpenRouter — https://openrouter.ai/docs/guides/routing/provider-selection | `require_parameters` para exigir soporte del formato pedido. | Adherencia semántica a la tarea de Pulso. |
| **API Reference** — GroqDocs — https://console.groq.com/docs/api-reference | Autenticación, Chat Completions, modelos y uso de tokens. | Acceso/cuota real de la cuenta del usuario. |
| **Structured Outputs** — GroqDocs — https://console.groq.com/docs/structured-outputs | JSON Object disponible; diferencias frente a JSON Schema estricto. | Que JSON válido constituya una acción apropiada. |
| **Reasoning** — GroqDocs — https://console.groq.com/docs/reasoning | Esfuerzo bajo compatible con GPT-OSS. | Que reduzca la latencia total o conserve precisión en esta app. |
| **Supported Models** — GroqDocs — https://console.groq.com/docs/models | Modelos publicados, tarifa y velocidad anunciadas para GPT-OSS 20B. | Disponibilidad particular, coste facturado o velocidad medida en el POCO. |
| **JSON Output** — DeepSeek API Docs — https://api-docs.deepseek.com/guides/json_mode/ | Formato JSON Object y necesidad de instruir JSON. | Adherencia automática al esquema ni soporte de imágenes. |
| **Gemini deprecations** — Google AI for Developers — https://ai.google.dev/gemini-api/docs/deprecations/ | Restricciones de acceso a 2.5 y diferencia entre disponibilidad y retirada. | Causa completa de un HTTP 404 o validez de la clave guardada. |
