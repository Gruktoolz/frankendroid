package dev.pulso.assistant;

import org.json.JSONObject;

/** Host-side contract tests: no emulator, API key or Android stubs at runtime. */
public final class CoreTests {
    private static int checks;
    private static void check(boolean condition,String message){checks++;if(!condition)throw new AssertionError(message);}
    private static String json(String extra){return "{\"action\":\"tap\",\"reason\":\"Abrir pantalla solicitada\",\"node_id\":3"+extra+"}";}
    private static void invalid(String value)throws Exception{
        boolean failed=false;try{Action.parse(value);}catch(Exception expected){failed=true;}
        check(failed,"Accepted invalid model output: "+value);
    }
    private static void invalidBatch(String raw)throws Exception{
        boolean failed=false;try{ActionBatch.parse(raw);}catch(Exception expected){failed=true;}
        check(failed,"Accepted an unsafe batch: "+raw);
    }
    public static void main(String[]args)throws Exception{
        Action a=Action.parse(json(""));
        check(!SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,false),"Routine grounded navigation should run automatically");
        invalid(json(",\"x\":1001"));
        invalid(json(",\"x\":-2"));
        invalid(json(",\"x\":1.5"));
        invalid(json(",\"x\":\"23\""));
        invalid("{\"action\":\"shell\",\"reason\":\"x\"}");
        invalid("{\"action\":\"tap\",\"reason\":\"x\"}");
        invalid(json("")+" {}");
        invalid("[]");invalid("null");invalid("```json\n"+json("")+"\n```");
        check(Action.parse("{\"action\":\"type_text\",\"reason\":\"x\",\"text\":\"hola\"}").nodeId==-1,"Focused-field typing defers grounding to the fresh native observation");
        check(Action.parse("{\"action\":\"enter\",\"reason\":\"x\"}").nodeId==-1,"Focused Enter must be resolved before execution");
        invalid("{\"action\":\"open_app\",\"reason\":\"x\",\"package\":\"com.x;rm -rf /\"}");
        invalid("{\"action\":\"swipe\",\"reason\":\"x\",\"x\":0,\"y\":0,\"x2\":1000,\"y2\":1000,\"duration_ms\":5000}");
        invalid("{\"action\":\"wait\",\"reason\":\"x\",\"duration_ms\":5001}");
        a=Action.parse(json(""));
        check(!SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,false),"Search navigation runs automatically");
        check(SafetyPolicy.needsApproval(true,a,"Buscar",a.reason,false),"Supervised mode reviews every action");
        for(String label:new String[]{"Enviar","Pagar","Eliminar","Comprar","Confirmar","Developer options","Permitir","Contraseña","sin etiqueta"})
            check(SafetyPolicy.needsApproval(false,a,label,"Pulsar control",false),"Sensitive or unknown control must be reviewed: "+label);
        check(SafetyPolicy.needsApproval(false,a,"Acerca del teléfono","Abrir información solicitada",false)==false,
            "Read-only About phone navigation should run automatically");
        check(SafetyPolicy.needsApproval(false,a,"Información del sistema","Activar las opciones de desarrollador",false),
            "Out-of-scope developer settings action must be reviewed");
        a=Action.parse("{\"action\":\"tap\",\"reason\":\"Activar las opciones de desarrollador\",\"node_id\":3}");
        check(SafetyPolicy.outsideReadOnlyGoal("Dime la versión de Android. No cambies ninguna configuración.",a,"Información del sistema"),
            "Mutating detour is discarded automatically for a read-only goal");
        check(!SafetyPolicy.outsideReadOnlyGoal("Dime la versión de Android.",a,"Información del sistema"),
            "No read-only boundary is inferred when user did not set one");
        a=Action.parse("{\"action\":\"tap\",\"reason\":\"x\",\"x\":1000,\"y\":0}");
        check(SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,false),"Coordinates always need review");
        a=Action.parse("{\"action\":\"type_text\",\"reason\":\"Buscar la versión solicitada\",\"node_id\":2,\"text\":\"Android 16\"}");
        check(!SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,true),"Ordinary task text in an editable field may run automatically");
        check(SafetyPolicy.needsApproval(false,a,"sin etiqueta",a.reason,false),"Typing into unidentified fields must be reviewed");
        a=Action.parse("{\"action\":\"type_text\",\"reason\":\"Buscar\",\"node_id\":2,\"text\":\"áéí 中文\"}");
        check(a.text.equals("áéí 中文"),"Unicode must survive parsing");
        a=Action.parse("{\"action\":\"type_text\",\"reason\":\"Buscar\",\"node_id\":2,\"text\":\"" + "A" + "I" + "Z" + "a" + "X".repeat(32) + "\"}");
        check(SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,true),"Secret-like text is gated");
        a=Action.parse("{\"action\":\"enter\",\"reason\":\"Buscar versión Android\",\"node_id\":2}");
        check(!SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,true),"Search submission may run automatically");
        check(SafetyPolicy.needsApproval(false,a,"Mensaje",a.reason,true),"Enter in a message field requires review");
        for(String action:new String[]{"home","back","open_app","swipe"}){
            JSONObject j=new JSONObject().put("action",action).put("reason","Volver dentro de la tarea");
            if(action.equals("open_app"))j.put("package","com.android.settings");
            if(action.equals("swipe"))j.put("x",500).put("y",800).put("x2",500).put("y2",200).put("duration_ms",450);
            a=Action.parse(j.toString());
            check(!SafetyPolicy.needsApproval(false,a,"Ajustes",a.reason,false),"Basic navigation allowed: "+action);
            check(SafetyPolicy.needsApproval(true,a,"Ajustes",a.reason,false),"Supervised navigation reviewed: "+action);
        }
        for(String action:new String[]{"done","ask_user","wait"}){
            a=Action.parse(new JSONObject().put("action",action).put("reason","x").toString());
            check(!SafetyPolicy.needsApproval(true,a,"",a.reason,false),"Non-executing outcomes don't require action approval");
        }
        check(!Action.schema().getJSONObject("properties").has("requires_confirmation"),"Model does not control the approval policy");
        a=Action.parse("{\"action\":\"open_app\",\"reason\":\"Abrir Ajustes\",\"package\":\"com.android.settings\"}");
        check(!SafetyPolicy.needsApproval(false,a,"sin etiqueta",a.reason,false),"Actual runtime: app launch has no node label and must not prompt");
        for(String kind:new String[]{"home","back"}){
            a=Action.parse(new JSONObject().put("action",kind).put("reason","Navegar").toString());
            check(!SafetyPolicy.needsApproval(false,a,"sin etiqueta",a.reason,false),"Actual runtime: global navigation has no node label");
        }
        String first="{\"action\":\"open_app\",\"reason\":\"Abrir\",\"package\":\"com.android.settings\"}";
        String second="{\"action\":\"tap\",\"reason\":\"Buscar\",\"target\":\"Buscar\",\"expected_package\":\"com.android.settings\"}";
        ActionBatch batch=ActionBatch.parse("{\"summary\":\"Buscar en Ajustes\",\"actions\":["+first+","+second+"]}");
        check(batch.actions.size()==2 && batch.actions.get(1).target.equals("Buscar"),"Known navigation can run as a two-action local batch");
        invalidBatch("{\"summary\":\"x\",\"actions\":[]}");
        check(ActionBatch.parse("{\"summary\":\"x\",\"actions\":["+first+","+json("")+"]}").actions.size()==1,"Execute grounded prefix; never a future index");
        check(ActionBatch.parse("{\"summary\":\"x\",\"actions\":["+first+",{\"action\":\"done\",\"reason\":\"success\"}]}").actions.size()==1,"Premature done is deferred until fresh evidence");
        check(ActionBatch.parse("{\"summary\":\"x\",\"actions\":["+first+",{\"action\":\"ask_user\",\"reason\":\"x\"}]}").actions.size()==1,"Do grounded prefix before re-evaluating missing data");
        invalidBatch("{\"summary\":\"x\",\"actions\":["+first+","+second+"]} {}");
        check(ActionBatch.parse(json("")).actions.size()==1,"Single-action fallback remains supported");
        check(LocalRoutes.androidVersionGoal("Abre Ajustes y dime qué versión de Android tengo. No cambies ninguna configuración."),"Read-only Android version task has a deterministic route");
        check(!LocalRoutes.androidVersionGoal("Dime mi versión Android y envía el resultado por correo"),"Compound messaging task must not be silently completed by the local recipe");
        check(!LocalRoutes.androidVersionGoal("Qué versión de Android me recomiendas instalar"),"Advice must not be confused with querying this device");
        org.json.JSONArray nodes=new org.json.JSONArray().put(new JSONObject().put("text","Versión de Android")).put(new JSONObject().put("text","16"));
        check(LocalRoutes.visibleAndroidVersion(nodes).equals("16"),"Read version from an Android label and value");
        check(LocalRoutes.visibleAndroidVersion(new org.json.JSONArray().put(new JSONObject().put("text","Android 16"))).equals("16"),"Read inline Android version");
        check(LocalRoutes.visibleAndroidVersion(new org.json.JSONArray().put(new JSONObject().put("text","16"))).isEmpty(),"Unrelated numbers cannot prove an Android version");
        check(LocalRoutes.visibleAndroidVersion(new org.json.JSONArray().put(new JSONObject().put("text","Android 16").put("password",true))).isEmpty(),"Protected node cannot supply evidence");
        check(!LocalRoutes.matches(new JSONObject().put("text","Enviar mensaje"),"Enviar"),"Partial label must not silently select a different action");
        check(!LocalRoutes.matches(new JSONObject().put("text","Buscar").put("password",true),"Buscar"),"Selectors exclude password controls");
        check(LocalRoutes.matches(new JSONObject().put("view_id","com.android.settings:id/search"),"com.android.settings:id/search"),"Full resource selectors match");
        a=Action.parse("{\"action\":\"scroll\",\"reason\":\"Buscar en la lista\",\"text\":\"down\"}");
        check(!SafetyPolicy.needsApproval(false,a,"sin etiqueta",a.reason,false),"Semantic scroll is routine navigation");
        invalid("{\"action\":\"scroll\",\"reason\":\"x\",\"text\":\"delete\"}");
        check(ActionBatch.parse("{\"summary\":\"x\",\"actions\":["+first+",{\"action\":\"tap\",\"reason\":\"Buscar\",\"node_id\":5,\"target\":\"Buscar\"}]}").actions.get(1).nodeId==-1,"Later selectors discard stale indices instead of discarding the useful plan");
        org.json.JSONArray apps=new org.json.JSONArray().put(new JSONObject().put("label","Ajustes").put("package","com.android.settings"));
        check(LocalRoutes.requestedPackage("Abre Ajustes y busca Bluetooth",apps).equals("com.android.settings"),"An explicitly requested app opens without consulting a model");
        check(LocalRoutes.requestedPackage("No abras Ajustes",apps).isEmpty(),"Mentioning an app is not an instruction to open it");
        check(LocalRoutes.requestedPackage("Compara las funciones de Ajustes",apps).isEmpty(),"App references in discussion must not trigger execution");
        a=Action.parse("{\"action\":\"tap\",\"reason\":\"Activar la búsqueda\",\"node_id\":3}");
        check(!SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,false),"Activating a search control is not a settings permission change");
        check(!SafetyPolicy.outsideReadOnlyGoal("Busca Bluetooth sin cambiar nada",a,"Buscar"),"Search focus stays within a read-only task");
        a=Action.parse("{\"action\":\"tap\",\"reason\":\"Enviar un correo\",\"node_id\":3}");
        check(SafetyPolicy.needsApproval(false,a,"Buscar",a.reason,false),"Search labels cannot launder a proposed send operation");
        a=Action.parse("{\"action\":\"type_text\",\"reason\":\"Buscar\",\"text\":\"Bluetooth\",\"node_id\":2}");
        check(a.focused().nodeId==-1 && a.focused().target.isEmpty() && a.focused().text.equals("Bluetooth"),"Local focus recovery preserves the text but never reuses the old index");
        String searchGoal="Abre Ajustes y busca Bluetooth. Deja los resultados visibles sin cambiar ninguna configuración.";
        check(LocalRoutes.settingsSearchTerm(searchGoal).equals("bluetooth"),"Recognize only a supported Settings search goal");
        check(LocalRoutes.settingsSearchTerm("Abre Ajustes y busca Bluetooth. Después actívalo").isEmpty(),"Do not complete a compound task after only its search part");
        JSONObject screen=new JSONObject().put("package","com.android.settings").put("elements",new org.json.JSONArray().put(new JSONObject().put("text","Bluetooth").put("editable",true)));
        check(!LocalRoutes.settingsSearchComplete(searchGoal,screen),"A typed query without visible results is not success");
        screen.getJSONArray("elements").put(new JSONObject().put("text","Bluetooth"));
        check(LocalRoutes.settingsSearchComplete(searchGoal,screen),"Verify the visible query and a corresponding result without another model call");
        check(LocalRoutes.pageGoal("Abre Wi-Fi sin cambiar nada.").equals("wifi"),"Exact local page route");
        check(LocalRoutes.pageGoal("Abre Bluetooth y actívalo").isEmpty(),"No truncation of mutating compound request");
        check(LocalRoutes.pageBack("Abre Wi-Fi y vuelve atrás."),"Back recipe exact match");
        JSONObject context=new JSONObject().put("package","com.android.settings").put("elements",new org.json.JSONArray()
            .put(new JSONObject().put("text","Privacidad")).put(new JSONObject().put("text","Permisos")));
        Action guarded=Action.parse(new JSONObject().put("action","tap").put("reason","Abrir").put("target","Permisos")
            .put("expected_package","com.android.settings").put("screen_anchor","Privacidad").toString());
        check(BatchGuard.relocatable(guarded,context,"old","new",false),"Unique context plus target permits relocation");
        context.getJSONArray("elements").getJSONObject(0).put("text","Otra pantalla");
        check(!BatchGuard.relocatable(guarded,context,"old","new",false),"Same package and matching target without screen context must replan");
        context.getJSONArray("elements").put(new JSONObject().put("text","Privacidad")).put(new JSONObject().put("text","Permisos"));
        check(!BatchGuard.relocatable(guarded,context,"old","new",false),"Ambiguous selector must replan");
        check(guarded.resolved(4).screenAnchor.equals("Privacidad"),"Resolution preserves preconditions");
        check(!BatchGuard.relocatable(Action.parse("{\"action\":\"type_text\",\"reason\":\"Buscar\",\"text\":\"x\",\"expected_package\":\"com.android.settings\"}"),context,"old","new",false),"Focused followup needs an actual search context");
        for(Provider provider:Provider.values()){
            check(provider.base.startsWith("https://"),"Credential origin must use TLS");
            check(Provider.from(provider.id)==provider,"Provider identity roundtrip");
            check(!provider.validModel("x?key=secret"),"Model cannot alter request URL");
        }
        check(Provider.OPENROUTER.validModel("vendor/model:free"),"OpenRouter namespaced model accepted");
        check(!Provider.GEMINI.validModel("vendor/model"),"Gemini keeps its native model contract");
        check(!Provider.DEEPSEEK.images(),"No unsupported image capability assumed from wire compatibility");
        System.out.println("PASS · "+checks+" model-output and execution-policy checks");
    }
}
