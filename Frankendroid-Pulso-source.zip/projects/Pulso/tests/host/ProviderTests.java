package dev.pulso.assistant;

import java.net.*;
import java.io.*;
import java.security.cert.Certificate;
import javax.net.ssl.HttpsURLConnection;
import org.json.*;
import java.util.concurrent.*;

/** All HTTPS is intercepted in this JVM. Synthetic credentials only, no external requests. */
public final class ProviderTests {
    static int checks;static Mock last;static String response;static int code=200;static boolean block;
    static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
    static final class Mock extends HttpsURLConnection {
        final ByteArrayOutputStream written=new ByteArrayOutputStream();
        final CountDownLatch entered=new CountDownLatch(1),released=new CountDownLatch(1);
        Mock(URL u){super(u);}
        public String getCipherSuite(){return "mock";}public Certificate[] getLocalCertificates(){return null;}public Certificate[] getServerCertificates(){return null;}
        public void connect(){}public boolean usingProxy(){return false;}
        public void disconnect(){released.countDown();}
        public OutputStream getOutputStream(){return written;}
        public int getResponseCode()throws IOException{entered.countDown();if(block){try{released.await(3,TimeUnit.SECONDS);}catch(InterruptedException e){throw new InterruptedIOException();}throw new InterruptedIOException();}return code;}
        public InputStream getInputStream(){return new ByteArrayInputStream(response.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
        public InputStream getErrorStream(){return getInputStream();}
    }
    static android.os.Bundle balanced(ModelClient c,int started,int completed,int failed,int cancelled){
        android.os.Bundle b=new android.os.Bundle();c.counters(b);
        check(b.getInt("requests_started")==started,"started ledger");check(b.getInt("requests_completed")==completed,"completed ledger");check(b.getInt("requests_failed")==failed,"failed ledger");check(b.getInt("requests_cancelled")==cancelled,"cancelled ledger");check(b.getInt("requests_in_flight")==0 && b.getInt("active_streams")==0,"drained transport");return b;
    }
    public static void main(String[] args)throws Exception{
        URL.setURLStreamHandlerFactory(protocol->new URLStreamHandler(){protected URLConnection openConnection(URL u){last=new Mock(u);return last;}});
        String batch="{\"summary\":\"Volver\",\"actions\":[{\"action\":\"back\",\"reason\":\"Volver\"}]}";
        for(Provider p:Provider.values()){
            ModelClient c=new ModelClient("synthetic-provider-key",p);
            response=p==Provider.GEMINI?"{\"models\":[{\"name\":\"models/gemini-2.5-flash-lite\",\"supportedGenerationMethods\":[\"generateContent\"]},{\"name\":\"models/gemini-3.1-flash-lite\",\"supportedGenerationMethods\":[\"generateContent\"]}]}":"{\"data\":[{\"id\":\"vendor/chat-model\"},{\"id\":\"embedding-model\"}]}";
            java.util.List<String> models=c.listModels();check(!models.isEmpty(),"catalog parse");
            if(p==Provider.GEMINI)check(models.get(0).equals("gemini-3.1-flash-lite"),"No automatic preference for inaccessible legacy model");
            else check(models.size()==1,"Non-chat catalog filter");
            check(last.getURL().toString().startsWith(p.base),"provider origin isolated");check(!last.getInstanceFollowRedirects(),"no credential redirects");
            check("synthetic-provider-key".equals(last.getRequestProperty(p==Provider.GEMINI?"x-goog-api-key":"Authorization").replace("Bearer ","")),"auth format");
            response=p==Provider.GEMINI?new JSONObject().put("candidates",new JSONArray().put(new JSONObject().put("content",new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",batch)))))).put("usageMetadata",new JSONObject().put("promptTokenCount",7).put("candidatesTokenCount",3)).toString():new JSONObject().put("choices",new JSONArray().put(new JSONObject().put("message",new JSONObject().put("content",batch)))).put("usage",new JSONObject().put("prompt_tokens",7).put("completion_tokens",3)).toString();
            ActionBatch result=c.decide(p==Provider.GEMINI?"gemini-3.1-flash-lite":p==Provider.GROQ?"openai/gpt-oss-20b":"vendor/chat-model","Volver",new JSONObject(),null,new JSONArray(),new JSONArray());
            check(result.actions.get(0).kind==Action.Kind.back,"shared validated action contract");
            check(c.inputTokens()==7 && c.outputTokens()==3,"provider usage accounting");
            JSONObject body=new JSONObject(last.written.toString("UTF-8"));
            if(p!=Provider.GEMINI){check(body.getJSONObject("response_format").getString("type").equals("json_object"),"JSON output requested");check(!body.getBoolean("stream"),"no unowned streaming job");check(body.has(p==Provider.OPENAI?"max_completion_tokens":"max_tokens"),"provider token cap");}
            balanced(c,2,2,0,0);
            code=401;response="{}";try{c.listModels();throw new AssertionError("HTTP auth accepted");}catch(ModelClient.ApiException expected){check(expected.status==401,"HTTP error identity");}balanced(c,3,2,1,0);code=200;
            c.cancel();try{c.listModels();throw new AssertionError("Cancelled request started");}catch(InterruptedIOException expected){check(true,"cancel gate");}balanced(c,3,2,1,0);
        }
        block=true;ModelClient cancelled=new ModelClient("synthetic-provider-key",Provider.GROQ);
        Thread request=new Thread(()->{try{cancelled.listModels();throw new AssertionError("Cancelled request returned");}catch(InterruptedIOException expected){}catch(Exception e){throw new RuntimeException(e);}});last=null;request.start();
        long deadline=System.currentTimeMillis()+1000;while(last==null && System.currentTimeMillis()<deadline)Thread.sleep(1);
        check(last!=null && last.entered.await(1,TimeUnit.SECONDS),"request really in progress");cancelled.cancel();request.join(2000);check(!request.isAlive(),"cancel releases actual HTTP job");balanced(cancelled,1,0,0,1);
        System.out.println("PASS · "+checks+" isolated provider/transport checks (mock HTTPS, no live API)");
    }
}
