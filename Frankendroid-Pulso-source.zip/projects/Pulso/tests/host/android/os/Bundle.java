package android.os;
public class Bundle {
    private final java.util.Map<String,Integer> values=new java.util.HashMap<>();
    public void putInt(String key,int value){values.put(key,value);}
    public int getInt(String key){return values.getOrDefault(key,0);}
}
