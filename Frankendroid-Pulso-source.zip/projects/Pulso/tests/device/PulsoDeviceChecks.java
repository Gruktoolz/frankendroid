package dev.pulso.assistant.checks;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.UiAutomation;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;

/** Separate test process; never suppresses accessibility or traverses another app's content. */
public final class PulsoDeviceChecks extends Instrumentation {
    private UiAutomation ui;private boolean gemini,diagnostic,configure,stressLocal,stressGemini;private long expectedRun;private String stressProvider="gemini";
    private static final String PKG="dev.pulso.assistant",ID=PKG+":id/";
    @Override public void onCreate(Bundle args){super.onCreate(args);gemini="true".equals(args.getString("gemini"));diagnostic="true".equals(args.getString("diagnostic"));configure="true".equals(args.getString("configure"));stressLocal="true".equals(args.getString("stress_local"));stressGemini="true".equals(args.getString("stress_gemini"));String selected=args.getString("stress_provider");if(selected!=null){stressProvider=selected;stressGemini=true;}start();}
    private void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    private AccessibilityNodeInfo node(String id){
        // Check each root's package before any content query; only Pulso's own views are queried.
        if(android.os.Build.VERSION.SDK_INT>=33)ui.clearCache();
        for(AccessibilityWindowInfo w:ui.getWindows()){
            AccessibilityNodeInfo root=w.getRoot();if(root==null)continue;
            try{
                if(!PKG.contentEquals(root.getPackageName()==null?"":root.getPackageName()))continue;
                List<AccessibilityNodeInfo> found=root.findAccessibilityNodeInfosByViewId(ID+id);
                if(!found.isEmpty())return found.get(0);
            }finally{root.recycle();}
        }
        return null;
    }
    private String text(String id){AccessibilityNodeInfo n=node(id);if(n==null)return "";try{return n.getText()==null?"":n.getText().toString();}finally{n.recycle();}}
    private void click(String id){
        long end=SystemClock.elapsedRealtime()+2500;
        while(SystemClock.elapsedRealtime()<end){AccessibilityNodeInfo n=node(id);if(n!=null){try{if(n.performAction(AccessibilityNodeInfo.ACTION_CLICK))return;}finally{n.recycle();}}SystemClock.sleep(40);}
        throw new AssertionError("Pulso control not available: "+id);
    }
    private void open(){
        try(android.os.ParcelFileDescriptor.AutoCloseInputStream in=new android.os.ParcelFileDescriptor.AutoCloseInputStream(
                ui.executeShellCommand("am start -W --activity-clear-top -n dev.pulso.assistant/.MainActivity"))){
            byte[] buffer=new byte[1024];while(in.read(buffer)!=-1){}
        }catch(java.io.IOException e){throw new AssertionError("Could not open Pulso",e);}
        long end=SystemClock.elapsedRealtime()+5000;
        while(node("etAppInput")==null && SystemClock.elapsedRealtime()<end)SystemClock.sleep(60);
        check(node("etAppInput")!=null,"Pulso main panel not ready");
    }
    private android.os.Bundle runtime(){
        AccessibilityNodeInfo n=node("floatingTaskState");if(n==null)n=node("tvHeaderStatus");
        if(n==null)return new Bundle();try{return new Bundle(n.getExtras());}finally{n.recycle();}
    }
    private String metrics(){Bundle b=runtime();return b.getLong("pulso_task_id")!=expectedRun?"":b.getString("pulso_metrics","");}
    private void startTask(String goal){
        open();long old=runtime().getLong("pulso_task_id");AccessibilityNodeInfo input=node("etAppInput");
        try{Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,goal);check(input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b),"Could not enter test task");}finally{input.recycle();}
        click("btnAppSend");
        long end=SystemClock.elapsedRealtime()+2500;
        while(SystemClock.elapsedRealtime()<end){Bundle b=runtime();if(b.getLong("pulso_task_id")>old){expectedRun=b.getLong("pulso_task_id");return;}SystemClock.sleep(30);}
        throw new AssertionError("A new task did not start; no result from an older task can pass this check");
    }
    private String status(){Bundle b=runtime();return b.getLong("pulso_task_id")!=expectedRun?"":b.getString("pulso_state","");}
    private String waitFor(String expected,long timeout){
        long end=SystemClock.elapsedRealtime()+timeout;
        while(SystemClock.elapsedRealtime()<end){String s=status();if(s.contains(expected) && (!expected.equals("Finalizado") || runtime().getString("PulsoState","").equals("IDLE")))return s;SystemClock.sleep(40);}
        throw new AssertionError("Expected "+expected+", observed "+status());
    }
    private boolean searchVisible(){return searchVisible("Bluetooth");}
    private boolean searchVisible(String term){
        if(android.os.Build.VERSION.SDK_INT>=33)ui.clearCache();
        for(AccessibilityWindowInfo w:ui.getWindows()){
            AccessibilityNodeInfo root=w.getRoot();if(root==null)continue;
            try{
                if(!"com.android.settings".contentEquals(root.getPackageName()==null?"":root.getPackageName()))continue;
                boolean query=false,result=false;
                for(AccessibilityNodeInfo n:root.findAccessibilityNodeInfosByText(term)){
                    try{if(!n.isPassword() && n.isVisibleToUser() ){String label=String.valueOf(n.getText());if(n.isEditable() && label.equalsIgnoreCase(term))query=true;else if(!n.isEditable() && label.toLowerCase(java.util.Locale.ROOT).contains(term.toLowerCase(java.util.Locale.ROOT)))result=true;}}
                    finally{n.recycle();}
                }
                if(query && result)return true;
            }finally{root.recycle();}
        }
        return false;
    }
    private String shell(String command)throws java.io.IOException {
        try(android.os.ParcelFileDescriptor.AutoCloseInputStream in=new android.os.ParcelFileDescriptor.AutoCloseInputStream(ui.executeShellCommand(command))){
            java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[512];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);return out.toString("UTF-8").trim();
        }
    }
    private Bundle idle()throws Exception{
        long end=SystemClock.elapsedRealtime()+12000;Bundle b=runtime();
        while(!b.getString("PulsoState","").equals("IDLE") && SystemClock.elapsedRealtime()<end){SystemClock.sleep(40);b=runtime();}
        check(b.getLong("pulso_task_id")==expectedRun,"Runtime belongs to a different task");
        check(b.getString("PulsoState","").equals("IDLE"),"Task did not drain to IDLE: "+b);
        for(String key:new String[]{"requests_in_flight","global_requests_in_flight","pending_callbacks","queued_requests","active_streams","active_jobs","queue_size"})check(b.containsKey(key) && b.getInt(key)==0,"Nonzero or missing "+key);
        check(b.getInt("requests_started")==b.getInt("requests_completed")+b.getInt("requests_failed")+b.getInt("requests_cancelled"),"Requests ledger does not balance");
        return b;
    }
    private void row(StringBuilder report,String group,int index,long started,Bundle b){
        String line=group+","+index+","+(SystemClock.elapsedRealtime()-started)+","+b.getInt("requests_started")+","+b.getInt("requests_completed")+","+b.getInt("requests_failed")+","+b.getInt("requests_cancelled")+","+b.getInt("requests_in_flight")+","+b.getInt("active_jobs")+","+b.getInt("pending_callbacks")+","+b.getInt("queue_size")+","+b.getString("PulsoState")+","+b.getString("task_result")+"\n";
        report.append(line);Bundle update=new Bundle();update.putString("stream",line);sendStatus(0,update);
    }
    private void localStress(StringBuilder report)throws Exception{
        String[] goals={"Abre Ajustes sin cambiar nada.","Abre Wi-Fi sin cambiar nada.","Abre Bluetooth sin cambiar nada.","Abre Información del teléfono sin cambiar nada.","Abre Wi-Fi y vuelve atrás.","Abre Bluetooth y vuelve atrás."};
        for(int i=0;i<30;i++){
            long t=SystemClock.elapsedRealtime();startTask(goals[i%goals.length]);waitFor("Finalizado",15000);Bundle b=idle();
            check(b.getString("task_result").equals("SUCCESS"),"Local task failed at "+i);check(b.getInt("requests_started")==0,"Local task used API");row(report,"LOCAL",i+1,t,b);
        }
        report.append("LOCAL_STRESS PASS 30/30\n");
    }
    private void geminiTask(String term)throws Exception{
        startTask("Abre Ajustes y busca "+term+". Deja los resultados visibles sin cambiar ninguna configuración.");check(runtime().getString("pulso_provider","").equals(stressProvider),"Wrong provider selected for stress test");
        long end=SystemClock.elapsedRealtime()+90000;
        while(SystemClock.elapsedRealtime()<end){
            String s=status();Bundle b=runtime();if(b.getString("PulsoState","").equals("IDLE"))break;
            if(s.contains("Revisar") || s.contains("ayuda") || b.getInt("requests_started")>=6){String reason=s+" "+text("floatingTaskReview");click("floatingTaskStop");idle();throw new AssertionError("Unexpected intervention/call limit: "+reason);}
            SystemClock.sleep(60);
        }
        Bundle b=idle();check(b.getString("task_result").equals("SUCCESS"),"Gemini task failed: "+status()+" "+text("floatingTaskBrief"));
        check(b.getInt("requests_completed")>0,"No real Gemini request completed");check(searchVisible(term),"Query and actual results not verified for "+term);
    }
    private void geminiStress(StringBuilder report)throws Exception{
        String before=shell("settings get global bluetooth_on"),wifi=shell("settings get global wifi_on");
        String[] terms={"Bluetooth","Pantalla","Sonido","Batería","Seguridad","Aplicaciones","Almacenamiento","Idiomas","Fecha","Accesibilidad"};
        int[] seeds={11,29,73};
        for(int seed:seeds){
            java.util.List<String> order=new java.util.ArrayList<>();for(int i=0;i<30;i++)order.add(terms[i%terms.length]);java.util.Collections.shuffle(order,new java.util.Random(seed));
            for(int i=0;i<30;i++){
                long t=SystemClock.elapsedRealtime();geminiTask(order.get(i));Bundle b=idle();row(report,"MODEL_"+stressProvider+"_"+seed,i+1,t,b);
                check(before.equals(shell("settings get global bluetooth_on")) && wifi.equals(shell("settings get global wifi_on")),"A radio setting changed");
            }
        }
        report.append("MODEL_STRESS PASS 90/90\n");
    }
    @Override public void onStart(){
        Bundle results=new Bundle();StringBuilder report=new StringBuilder();
        try{
            ui=getUiAutomation(UiAutomation.FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES);
            AccessibilityServiceInfo info=ui.getServiceInfo();info.flags|=AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS|AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;ui.setServiceInfo(info);
            if(configure){open();click("btnComposerModel");results.putString("stream","CONFIG_OPEN\n");finish(Activity.RESULT_OK,results);return;}
            if(diagnostic){
                open();click("btnProgressDisclosure");SystemClock.sleep(150);
                for(AccessibilityWindowInfo w:ui.getWindows()){
                    AccessibilityNodeInfo root=w.getRoot();if(root==null)continue;
                    try{
                        if(!PKG.contentEquals(root.getPackageName()==null?"":root.getPackageName()))continue;
                        for(AccessibilityNodeInfo n:root.findAccessibilityNodeInfosByText("Nueva tarea")){
                            String value=String.valueOf(n.getText());int at=value.lastIndexOf("Nueva tarea");
                            if(at>=0)report.append(value.substring(at).replaceAll("AIza[0-9A-Za-z_-]{25,}","[clave oculta]"));
                            n.recycle();
                        }
                    }finally{root.recycle();}
                }
                results.putString("stream",report.toString());finish(Activity.RESULT_OK,results);return;
            }
            if(stressLocal || stressGemini){
                if(stressLocal)localStress(report);if(stressGemini)geminiStress(report);
                results.putString("stream",report.toString());finish(Activity.RESULT_OK,results);return;
            }
            String goal="Abre Ajustes y dime qué versión de Android tengo. No cambies ninguna configuración.";
            long started=SystemClock.elapsedRealtime();startTask(goal);waitFor("Finalizado",10000);
            String metrics=metrics();check(text("floatingTaskBrief").contains("Tu teléfono tiene Android "+android.os.Build.VERSION.RELEASE),"Wrong device version in the actual task result");check(metrics.contains("0 consultas") && metrics.contains("0 imágenes"),"Local route unexpectedly used model/image: "+metrics);
            report.append("LOCAL_VERSION PASS ").append(SystemClock.elapsedRealtime()-started).append("ms ").append(metrics).append('\n');
            startTask(goal);click("floatingTaskPause");waitFor("Pausado",2500);
            String pausedMetrics=metrics();SystemClock.sleep(400);
            check(status().contains("Pausado") && metrics().equals(pausedMetrics),"Paused task advanced");
            click("floatingTaskPause");waitFor("Finalizado",10000);report.append("PAUSE_RESUME PASS ").append(metrics()).append('\n');
            startTask(goal);click("floatingTaskStop");SystemClock.sleep(500);open();
            check(text("tvHeaderStatus").equals("Detenido"),"Stop state not retained");
            String stopped=text("btnProgressDisclosure");SystemClock.sleep(400);check(text("btnProgressDisclosure").equals(stopped),"Stopped task advanced");
            report.append("STOP PASS ").append(stopped).append('\n');
            if(gemini){
                String bluetoothBefore=shell("settings get global bluetooth_on");
                try(android.os.ParcelFileDescriptor.AutoCloseInputStream in=new android.os.ParcelFileDescriptor.AutoCloseInputStream(ui.executeShellCommand("am start -W -a android.settings.SETTINGS --activity-clear-top"))){byte[] buffer=new byte[1024];while(in.read(buffer)!=-1){}}
                started=SystemClock.elapsedRealtime();startTask("Abre Ajustes y busca Bluetooth. Deja los resultados visibles sin cambiar ninguna configuración.");
                long end=SystemClock.elapsedRealtime()+60000;String s="",m="";
                while(SystemClock.elapsedRealtime()<end){
                    s=status();m=metrics();
                    if(s.contains("Finalizado") || s.contains("No completado") || s.contains("Revisar") || s.contains("ayuda"))break;
                    String[] parts=m.split(" · ");if(parts.length>1 && Integer.parseInt(parts[1].split(" ")[0])>=4)break;
                    SystemClock.sleep(60);
                }
                if(s.contains("Revisar"))report.append("REVIEW ").append(text("floatingTaskReview")).append("\n");
                report.append("MODEL_SEARCH ").append(s).append(' ').append(SystemClock.elapsedRealtime()-started).append("ms ").append(m).append('\n');
                if(!s.contains("Finalizado")){click("floatingTaskStop");throw new AssertionError("Gemini route did not finish within four calls and 60 seconds");}
                check(searchVisible(),"No verified Bluetooth query and results on the Settings window");
                check(bluetoothBefore.equals(shell("settings get global bluetooth_on")),"Bluetooth system setting changed during the read-only test");
                report.append("MODEL_SEARCH PASS · query/results verified · Bluetooth state unchanged\n");
                idle();check(!runtime().getBoolean("pulso_active"),"A purported final result still has an active task");
            }
            results.putString("stream",report.toString());finish(Activity.RESULT_OK,results);
        }catch(Throwable error){
            try{click("floatingTaskStop");}catch(Throwable ignored){}
            results.putString("stream",report+"FAIL "+error.toString()+"\n");finish(Activity.RESULT_CANCELED,results);
        }
    }
}
