# Validación de la alfa

Fecha: 18 de octubre de 2026.

## Nota posterior de inspección y privacidad

Durante una comprobación posterior por USB, el primer plano cambió de Pulso a WhatsApp entre consultar la actividad y extraer la jerarquía de accesibilidad. La extracción devolvió texto de una conversación al asistente de esta sesión de PC. Se informó al usuario y se eliminó el XML temporal del teléfono; no se usó ese contenido para la prueba ni se ejecutaron acciones sobre la conversación. No se puede afirmar que esa comprobación no leyó contenido de WhatsApp. Esto no prueba que Pulso lo enviara a Gemini. La revisión posterior de reutilización de Tunnel Turbo se realizó sólo sobre código y recursos locales, sin inspeccionar el teléfono.

## Comprobado antes del cambio de autonomía

- 46 comprobaciones de host superadas para el contrato de acciones y la política de confirmación anterior.
- Todos los recursos XML compilan con Android Build Tools 36.0.0.
- Todo el código Java compila contra Android SDK 36; D8 genera el DEX con API mínima 30.
- El APK contiene el DEX de la última compilación, incluida la pausa al abrir la configuración del propio asistente.
- `apksigner verify --verbose` valida la firma del APK (esquema v3, compatible con la API mínima).
- `zipalign -c 4` y la comprobación de integridad ZIP pasan.
- El manifiesto compilado declara `dev.pulso.assistant`, versión 0.1.0, API mínima 30 y objetivo 36.
- Permisos ordinarios declarados: Internet y estado de red. El servicio de accesibilidad exige el permiso de enlace de sistema `BIND_ACCESSIBILITY_SERVICE` y activación manual del usuario.

Certificado de desarrollo, huella SHA-256 pública:

```text
[HUELLA OMITIDA]
```

La huella del archivo APK está en `dist/pulso-alpha.apk.sha256`.

## Cambio de autonomía preparado — 18 de octubre de 2026

- `python3 tools/build.py` pasó 50 comprobaciones de host y compiló los recursos, Java y DEX para API 36.
- La firma v3 y la alineación ZIP del APK actualizado se verificaron.
- SHA-256 del APK actualizado: `[HASH APK OMITIDO]`.
- El paquete fuente no incluye la clave privada del certificado original. Esta compilación se firmó con un certificado de desarrollo local distinto (SHA-256 público `[HUELLA OMITIDA]`), por lo que Android no permite instalarla encima del APK anterior.
- No se desinstaló ni reemplazó la app instalada para conservar los datos locales, incluida la API key. En la comprobación final, `adb devices -l` ya no mostraba un dispositivo conectado; el APK actualizado aún no se ha probado en el teléfono.
- Después, el usuario pidió instalar la actualización y autorizó la reinstalación con conocimiento de que se borrarían los datos locales. Se verificó un único dispositivo POCO X7 Pro / Android 16, se desinstaló la versión anterior, se instaló el APK actualizado con `Success` y `MainActivity` abrió con estado `ok`.
- La reinstalación revocó la activación de Accesibilidad y borró la configuración/API key anterior. El usuario aceptó la advertencia de Xiaomi, volvió a activar Pulso en Accesibilidad, autorizó el uso dentro de Pulso y confirmó que guardó la API key de nuevo. ADB confirma que `PhoneService` está habilitado; la API key no se leyó ni exportó.
- Al retomar la prueba, el primer plano era una conversación de WhatsApp. No se capturó ni envió su contenido; se pidió al usuario volver a Inicio y comenzar la prueba de solo lectura desde Pulso. El nuevo modo automático todavía no se ha probado.

## Prueba real en POCO X7 Pro — 18 de octubre de 2026

- Dispositivo verificado por ADB: Xiaomi `[MODELO DEL DISPOSITIVO REDACTADO]` / `[NOMBRE DE DISPOSITIVO REDACTADO]`, Android 16, API 36. Servicio de accesibilidad de Pulso activado y enlazado.
- El usuario indicó que guardó su API key dentro de Pulso. No se leyó, exportó ni incluyó en registros.
- Se inició la primera prueba con **Revisar cada interacción** activado, tal como pide el procedimiento guiado. Pulso llegó al paso 5; la tarea real consultó Gemini, pero no finalizó con una respuesta verificada.
- En Ajustes se observó la pantalla de información del teléfono, que mostraba Android 16. No se completó ni verificó por Pulso la respuesta final solicitada.
- El paso pendiente mostrado fue «Pulsar “sin etiqueta”», con la explicación de que volvería a tocar la versión del sistema operativo para activar el modo de desarrollador. Esta acción excedía la instrucción de solo consultar la versión y no se debía aprobar. Tras intentar detener la tarea, el panel de Pulso dejó de aparecer; no se capturó un estado final que confirmara expresamente “Detenido”. No se atribuye a Pulso ningún cambio de configuración.
- **Pausar** mostró “Pausado”; **Continuar** reanudó la tarea en el paso 5. Detener se intentó y el panel desapareció después, pero falta una confirmación visible inequívoca.
- La prueba revela dos límites distintos: el modo guiado solicita aprobación para cada interacción por diseño; el modo automático anterior también frenaba escritura, Intro y controles desconocidos.
- El código actualizado establece automático como valor inicial en instalaciones nuevas. En este modo, acciones rutinarias sobre controles identificados, búsqueda y escritura en campos editables normales pueden avanzar. Acciones sensibles, campos/controles sin etiqueta y coordenadas se detienen para revisión. Si una tarea pide explícitamente solo lectura, los pasos que indiquen cambiar algo fuera de ese objetivo se descartan y se registran. El modo de revisión completa sigue disponible.
- Esta actualización se ha compilado y probado en host; aún no se ha instalado en el teléfono. En la instalación actual hay una preferencia de revisión guardada de la primera prueba, así que el usuario deberá desmarcar **Revisar cada interacción** si conserva la versión instalada.

## Pendiente

1. Repetir la consulta de Android con un plan que se limite a lectura y sin entrar en Opciones de desarrollador. En la prueba guiada, aprobar solo pasos que claramente abran páginas de información; rechazar controles desconocidos o cambios de configuración.
2. Instalar el código actualizado y hacer una prueba separada del modo automático, primero con una tarea de lectura sencilla.
3. Confirmar explícitamente el estado final de **Detener** en una ejecución controlada.
4. Probar tareas en las apps concretas que se quieran usar; una tarea que funciona en Ajustes no garantiza el mismo comportamiento en otra app.

No incluyas la API key en informes o capturas.

## Prueba local por USB — 18 de octubre de 2026

Comprobado en la PC local con Pop!_OS 24.04 y Android Platform Tools del SDK local:

- ADB detectó un único dispositivo autorizado por USB (`[SERIAL REDACTADO]`). Sus propiedades reportan fabricante Xiaomi, modelo `[MODELO DEL DISPOSITIVO REDACTADO]`, dispositivo `[NOMBRE DE DISPOSITIVO REDACTADO]`, Android 16 y API 36; el modelo corresponde al POCO X7 Pro.
- El SHA-256 del APK coincide con `dist/pulso-alpha.apk.sha256`.
- `adb install -r` terminó con `Success`; `dev.pulso.assistant/.MainActivity` abrió con estado `ok` y el paquete quedó instalado.
- `python3 tools/build.py --test-only` pasó las 46 comprobaciones de host antes del cambio de política.
- Accesibilidad de Pulso se activó manualmente. No se ha leído ni exportado ninguna API key.

Comprobación posterior, tras la intervención del usuario:

- ADB confirma que Accesibilidad está activada y que `dev.pulso.assistant/dev.pulso.assistant.PhoneService` aparece enlazado.
- El usuario confirma que guardó su API key dentro de Pulso. No se leyó ni exportó.
- Pulso protege su ventana contra capturas; la captura por ADB devuelve una imagen negra. No se inspeccionaron los campos de configuración.

La tarea real llamó a Gemini y observó Ajustes, pero no terminó correctamente. Ver detalles de la ejecución arriba.
