# Pulso · Alfa 0.2

Asistente Android nativo para tareas en tu teléfono. API mínima 30; compilación/objetivo 36. Java y vistas XML, sin root, Shizuku ni ordenador durante el uso normal.

## Uso

Abre Pulso, entra en **☰ → Configuración**, acepta una vez el uso de pantalla, activa Accesibilidad y elige el proveedor y guarda su API key dentro de la app. La actualización conserva el almacenamiento y la firma de desarrollo existente. La clave nunca se muestra en el chat.

Escribe una tarea y pulsa ↑. Pulso pasa al fondo y presenta su estado en el panel flotante. **Pausar/Continuar** y **Detener** siguen disponibles. El menú **Primera prueba** prepara la consulta de versión Android. Al volver a la conversación aparece el resultado o el error real de la tarea.

El modo inicial es automático. Navegar, abrir apps, buscar, escribir en un campo de búsqueda y desplazar listas no pide revisión cuando el destino y el contexto están identificados. La opción **Revisar cada interacción** sigue disponible para quien la active. Operaciones sensibles y destinos ambiguos conservan controles; la app no puede concederse permisos de Android, atravesar bloqueo/biometría ni garantizar completar cualquier tarea.

## Ruta rápida y consumo

- **Una observación semántica:** un recorrido de la interfaz produce el snapshot compartido. No se vuelve a recorrer todo el árbol para obtener por separado texto, paquete y controles. La espera entre cambios utiliza eventos, no sondeos repetidos del árbol.
- **Sin imagen por defecto:** se envían sólo los controles visibles relevantes y sus propiedades no vacías. Los límites de pantalla se incluyen para la ruta visual, no en todas las consultas de texto.
- **Lotes de 1–6 acciones:** El modelo prepara una pequeña secuencia previsible. Pulso la ejecuta localmente, resolviendo los selectores en la nueva observación tras cada acción. Se vuelve al modelo al terminar el lote o cuando hace falta una decisión nueva. Cada paso mantiene su política y cancelación.
- **Campo enfocado:** después de abrir una búsqueda, escribir o pulsar Intro puede utilizar el único campo editable enfocado. Android debe identificarlo de nuevo en esa observación; nunca se escribe por defecto en un campo desconocido o de contraseña.
- **Atajos locales:** abrir una app nombrada explícitamente y consultar la versión Android tienen rutas locales. La consulta de versión abre información del teléfono y obtiene la versión del sistema sin Gemini ni capturas. Si la semántica contiene esa misma versión, también se indica la comprobación en pantalla.
- **Modelo económico:** `auto` prioriza Flash-Lite disponible y reutiliza el descubrimiento hasta 24 horas. Una selección explícita se respeta. El precio real depende del modelo y de la cuenta; la app muestra consultas, imágenes y tokens, no una factura estimada.
- **Imágenes puntuales:** `inspect_screen` amplía la observación cuando los controles no bastan. Máximo tres intentos de imagen por tarea; se omiten si hay campos de contraseña. Las pantallas protegidas no se atraviesan.
- **Recuperación acotada:** reintentos locales para controles que aún no aparecen, reutilización de selectores tras cambios y reintentos de conexión. Los límites de acciones, consultas y 20 minutos evitan bucles de gasto. No hay una promesa de ejecución infinita.

El panel muestra acciones, consultas e imágenes. Al expandir el progreso se muestran observaciones, recuperaciones y tokens informados por Gemini. Una acción aceptada por Android no se presenta automáticamente como objetivo conseguido; el resultado se decide sobre la observación posterior. Un `done` anticipado al final de un lote se descarta y exige una nueva decisión.

## Groq y otros proveedores

En **☰ → Configuración → Proveedor y modelo**, elige **Groq**, introduce allí su clave y conserva o introduce `openai/gpt-oss-20b`. También puedes usar **Probar conexión y elegir modelo**. Guarda y vuelve al chat. Una comprobación de catálogo verifica acceso al listado; la generación y la calidad del plan sólo se comprueban con una tarea real.

El selector también ofrece Gemini, OpenRouter, DeepSeek y OpenAI. Las claves y los modelos se conservan por proveedor; no hay conmutación automática ni envío de claves de un servicio a otro. Fuera de Gemini debes elegir un modelo concreto de chat con JSON; el listado puede contener modelos que no admitan este contrato. Esas conexiones usan sólo semántica, sin imágenes en esta alfa.

La tarea siguiente no empieza mientras la anterior mantiene HTTP, callbacks operativos o acciones pendientes. El estado interno `IDLE` se distingue del resultado «Finalizado». El presupuesto impide ciclos infinitos de solicitudes cobradas.

## Interacción reutilizada de Tunnel Turbo

El panel usa la cabecera, conversación, compositor, fondos y paleta de Tunnel Turbo, adaptados al controlador de Pulso. La actividad y el runtime completos de Tunnel no se importaron.

La pulsación prefiere el nodo accesible; puede probar un contenedor de tamaño comparable y después su centro observado. El desplazamiento prefiere la acción semántica de la lista y puede usar un gesto dentro de sus límites actuales. Estos gestos derivados de un nodo no necesitan imagen. Los gestos libres por coordenadas sí requieren una imagen actual.

Los callbacks son asíncronos: no se copian las esperas bloqueantes del otro servicio. Esta versión no crea ni controla pantallas virtuales, ni incorpora ejecución de comandos arbitrarios.

## Datos y límites

Durante tareas con modelo se envían al origen HTTPS fijo del proveedor elegido el objetivo, controles de pantalla, apps disponibles e historial reciente; sólo se añade imagen cuando se solicita. Cada API key se guarda por separado y se cifra con Android Keystore y autentica HTTPS mediante cabecera, sin incluirse en el objetivo o en el chat. Las capturas se mantienen en memoria y no se archivan. La conversación y actividad recientes se guardan en el almacenamiento privado sin respaldo de Android.

La configuración y el panel propio se excluyen de la entrada del agente. Antes de recorrer otra app se comprueba el paquete de la misma raíz que se va a leer. Si otra app ocupa la pantalla, la ejecución se pausa; una comprobación previa de actividad en la PC no sustituye este control. Un teclado puede tener la raíz activa: se consulta la ventana de aplicación autorizada y no se recorre el contenido del teclado.

El teléfono debe estar encendido y desbloqueado. Abrir Pulso durante una tarea la pausa; Continuar vuelve a la app antes de observar. Pausa y parada invalidan decisiones pendientes. Un gesto ya enviado puede terminar antes de la parada. La tarea no se reanuda sola si Android mata el servicio o se reinicia el teléfono.

## Compilar y comprobar

```sh
python3 tools/build.py
python3 tools/build.py --test-only
```

El compilador portable usa Python, Java 17+ y herramientas fijadas por SHA-256; no exige Gradle. Produce `dist/pulso-alpha.apk` y su SHA-256. Conserva `.tools/pulso-debug.jks` para instalar futuras actualizaciones con la misma firma. El certificado es de desarrollo; la clave privada no forma parte de una distribución de fuentes.

Para pruebas controladas en dispositivo:

```sh
python3 tools/device_checks.py --serial SERIAL
python3 tools/device_checks.py --serial SERIAL --gemini
python3 tools/device_checks.py --serial SERIAL --stress-local
python3 tools/device_checks.py --serial SERIAL --stress-provider groq
```

Los comandos de modelo realizan tareas reales con la clave del proveedor ya elegido en la app y consumen cuota. La ronda larga tiene 30 tareas por tres órdenes; comprueba el drenaje entre tareas y se detiene en el primer fallo. Todos instalan un APK temporal de comprobación que se elimina al finalizar. El proceso de prueba es independiente y usa `FLAG_DONT_SUPPRESS_ACCESSIBILITY_SERVICES`. No exporta claves ni genera capturas/dumps de pantalla. Consulta únicamente controles identificados de Pulso. La prueba con Gemini tiene un límite propio de tiempo y consultas y detiene la tarea si lo alcanza.

Los detalles y resultados reales están en `VALIDACION.md`. Las decisiones y referencias externas están en `CAMBIOS-0.2.md`.
