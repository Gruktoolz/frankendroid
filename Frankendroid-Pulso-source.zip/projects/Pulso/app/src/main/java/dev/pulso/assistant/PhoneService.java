package dev.pulso.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

public final class PhoneService extends AccessibilityService {
    public static volatile PhoneService instance;
    final Handler main = new Handler(Looper.getMainLooper());
    AgentController agent;
    private WindowManager windows;
    private LinearLayout panel;
    private boolean panelRequested, obscured;
    private final Object changeMonitor=new Object();
    private volatile long uiEpoch,lastUiChange;
    volatile String lastLaunchPackage="";
    private volatile String observationScope="";
    private final java.util.concurrent.atomic.AtomicInteger callbacks=new java.util.concurrent.atomic.AtomicInteger();
    int pendingCallbacks(){return callbacks.get();}
    private void postTracked(Runnable task,long delay){
        callbacks.incrementAndGet();
        if(!main.postDelayed(()->{try{task.run();}finally{callbacks.decrementAndGet();}},delay))callbacks.decrementAndGet();
    }
    void drain() throws Exception {onMain(()->true);}
    private final Map<String,String> launchable = new LinkedHashMap<>();

    static final class ChangedScreen extends Exception {
        ChangedScreen() { super("La pantalla cambió; vuelvo a observar."); }
    }
    static final class UnexpectedApp extends Exception { UnexpectedApp(){super("Otra aplicación ocupó la pantalla. Pausé la tarea para no leerla.");} }
    static final class OwnScreen extends Exception {
        OwnScreen() { super("Pulsa Continuar y volver para operar otras aplicaciones."); }
    }
    static final class Observation implements AutoCloseable {
        JSONObject screen;
        String signature, jpeg, packageName;
        int width, height;
        long capturedAt,epoch;
        int windowId;
        boolean protectedContent,physicalFallback;
        final Map<Integer,AccessibilityNodeInfo> nodes = new LinkedHashMap<>();
        final Map<Integer,String> labels = new LinkedHashMap<>();
        String label(Action a) { return labels.getOrDefault(a.nodeId,"sin etiqueta"); }
        boolean editable(Action a) {
            AccessibilityNodeInfo n=nodes.get(a.nodeId);
            return n!=null && n.isEditable() && !n.isPassword();
        }
        boolean searchControl(Action a){
            AccessibilityNodeInfo n=nodes.get(a.nodeId);if(n==null || n.isPassword())return false;
            return LocalRoutes.searchResource(n.getViewIdResourceName()) || LocalRoutes.normalized(label(a)).matches(".*\\b(buscar|busqueda|search)\\b.*");
        }
        String selector(Action a){
            AccessibilityNodeInfo n=nodes.get(a.nodeId);if(n==null)return "";
            if(n.getViewIdResourceName()!=null && !n.getViewIdResourceName().isEmpty())return n.getViewIdResourceName();
            return label(a).equals("sin etiqueta")?"":label(a);
        }
        @Override public void close() { for (AccessibilityNodeInfo n : nodes.values()) n.recycle(); nodes.clear(); }
    }

    @Override protected void onServiceConnected() {
        super.onServiceConnected(); windows=(WindowManager)getSystemService(WINDOW_SERVICE);
        agent=new AgentController(this); instance=this;
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(event==null || event.getPackageName()==null)return;
        String pkg=event.getPackageName().toString();
        if(getPackageName().equals(pkg))return;
        if(!pkg.equals(observationScope) && event.getEventType()!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)return;
        synchronized(changeMonitor){uiEpoch++;lastUiChange=SystemClock.elapsedRealtime();changeMonitor.notifyAll();}
    }
    long changeEpoch(){return uiEpoch;}
    /** Wait on metadata only: no hierarchy walks or model calls inside this wait. */
    void settle(long previousEpoch,BooleanSupplier alive) throws InterruptedException {
        long deadline=SystemClock.elapsedRealtime()+1000;
        synchronized(changeMonitor){
            while(alive.getAsBoolean()){
                long now=SystemClock.elapsedRealtime();
                if(now>=deadline || (uiEpoch!=previousEpoch && now-lastUiChange>=100))return;
                changeMonitor.wait(Math.max(1,Math.min(100,deadline-now)));
            }
        }
    }
    void goHome() throws Exception {onMain(()->{
        assertAvailable();Intent home=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo info=getPackageManager().resolveActivity(home,android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        if(info==null || info.activityInfo==null)throw new IllegalStateException("No pude identificar la pantalla de Inicio");
        lastLaunchPackage=info.activityInfo.packageName;performGlobalAction(GLOBAL_ACTION_HOME);return true;
    });}
    void openPackage(String pkg) throws Exception {onMain(()->{
        assertAvailable();if(pkg.equals("com.android.settings")){launchSettings("settings");return true;}
        if(!launchable.containsKey(pkg) || getPackageName().equals(pkg))throw new IllegalArgumentException("Aplicación fuera de la lista permitida");
        Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);if(launch==null)throw new IllegalArgumentException("La app no tiene entrada de inicio");
        lastLaunchPackage=pkg;startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));return true;
    });}
    void openDeviceInfo() throws Exception {onMain(()->{launchSettings("device_info");return true;});}
    void openSettingsPage(String page)throws Exception {onMain(()->{launchSettings(page);return true;});}
    void back()throws Exception{onMain(()->{assertAvailable();if(!performGlobalAction(GLOBAL_ACTION_BACK))throw new IllegalStateException("Android no aceptó Volver");return true;});}
    private void launchSettings(String page) {
        String action=page.equals("device_info")?android.provider.Settings.ACTION_DEVICE_INFO_SETTINGS:page.equals("wifi")?android.provider.Settings.ACTION_WIFI_SETTINGS:page.equals("bluetooth")?android.provider.Settings.ACTION_BLUETOOTH_SETTINGS:android.provider.Settings.ACTION_SETTINGS;
        Intent intent=new Intent(action);
        if(intent.resolveActivity(getPackageManager())==null)throw new IllegalStateException("Esta página de Ajustes no está disponible.");
        lastLaunchPackage=intent.resolveActivity(getPackageManager()).getPackageName();
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
    }
    @Override public void onInterrupt() { if (agent != null) agent.stop(); }
    @Override public void onDestroy() {
        if (agent != null) agent.shutdown(); instance=null;
        if (panel != null) { windows.removeView(panel); panel=null; }
        super.onDestroy();
    }

    void assertAvailable() {
        if (((KeyguardManager)getSystemService(KEYGUARD_SERVICE)).isKeyguardLocked()
                || !((PowerManager)getSystemService(POWER_SERVICE)).isInteractive())
            throw new IllegalStateException("Desbloquea el teléfono y mantén la pantalla encendida para continuar.");
    }

    <T> T onMain(Callable<T> call) throws Exception {
        if (Looper.myLooper() == Looper.getMainLooper()) return call.call();
        CompletableFuture<T> result=new CompletableFuture<>();
        postTracked(()->{if(result.isDone())return;try { result.complete(call.call()); } catch(Throwable e) { result.completeExceptionally(e); } },0);
        try{return result.get(6,TimeUnit.SECONDS);}catch(Exception e){result.cancel(false);throw e;}
    }

    JSONArray apps() throws Exception {
        return onMain(()->{
            launchable.clear();
            List<ResolveInfo> resolved=getPackageManager().queryIntentActivities(
                new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);
            for (ResolveInfo r:resolved) if (!getPackageName().equals(r.activityInfo.packageName))
                launchable.put(r.activityInfo.packageName,r.loadLabel(getPackageManager()).toString());
            JSONArray result=new JSONArray();
            for (Map.Entry<String,String> e:launchable.entrySet()) result.put(new JSONObject().put("package",e.getKey()).put("label",e.getValue()));
            return result;
        });
    }

    /** An IME can own the active root. Read only the top application window in the authorized scope. */
    private AccessibilityNodeInfo scopedRoot(String expectedPackage) throws Exception {
        AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)throw new ChangedScreen();
        String pkg=String.valueOf(root.getPackageName());
        if(expectedPackage!=null && !expectedPackage.isEmpty() && expectedPackage.equals(pkg))return root;
        AccessibilityWindowInfo window=root.getWindow();int type=window==null?-1:window.getType();if(window!=null)window.recycle();
        root.recycle();
        if(getPackageName().equals(pkg) && type!=AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY)throw new OwnScreen();
        if(type==AccessibilityWindowInfo.TYPE_INPUT_METHOD || (type==AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY && getPackageName().equals(pkg))){
            AccessibilityNodeInfo top=null;int layer=Integer.MIN_VALUE;
            for(AccessibilityWindowInfo w:getWindows()){
                if(w.getType()!=AccessibilityWindowInfo.TYPE_APPLICATION || w.getLayer()<=layer)continue;
                AccessibilityNodeInfo candidate=w.getRoot();if(candidate==null)continue;
                if(top!=null)top.recycle();top=candidate;layer=w.getLayer();
            }
            if(top!=null){
                if(expectedPackage!=null && expectedPackage.equals(String.valueOf(top.getPackageName())))return top;
                top.recycle();
            }
        }
        android.util.Log.i("PulsoRuntime","scope_mismatch expected="+expectedPackage+" active="+pkg+" windowType="+type);
        throw new UnexpectedApp();
    }

    private Observation frame(String expectedPackage,boolean includeBounds) throws Exception {
        assertAvailable();
        AccessibilityNodeInfo root=scopedRoot(expectedPackage);
        if (root==null) throw new IllegalStateException("No puedo leer la ventana activa. Abre una aplicación y reintenta.");
        Observation o=new Observation();o.epoch=uiEpoch;
        try {
            o.packageName=String.valueOf(root.getPackageName());o.windowId=root.getWindowId();
            if (getPackageName().equals(o.packageName)) throw new OwnScreen();
            if(expectedPackage==null || expectedPackage.isEmpty() || !expectedPackage.equals(o.packageName))throw new UnexpectedApp();
            DisplayMetrics metrics=new DisplayMetrics(); windows.getDefaultDisplay().getRealMetrics(metrics);
            o.width=metrics.widthPixels; o.height=metrics.heightPixels;
            JSONArray elements=new JSONArray();
            int[] visited={0}; collect(root,o,elements,visited,0,includeBounds);
            o.screen=new JSONObject().put("package",o.packageName).put("window_id",root.getWindowId())
                .put("width",o.width).put("height",o.height).put("elements",elements);
            byte[] hash=MessageDigest.getInstance("SHA-256").digest(o.screen.toString().getBytes(StandardCharsets.UTF_8));
            o.signature=Base64.encodeToString(hash,Base64.NO_WRAP);
            if(uiEpoch!=o.epoch)throw new ChangedScreen();
            o.screen.put("truncated",visited[0]>=1800 || elements.length()>=300);
            o.capturedAt=SystemClock.elapsedRealtime(); return o;
        } catch (Exception e) { o.close(); throw e; }
        finally { root.recycle(); }
    }

    private void collect(AccessibilityNodeInfo n,Observation o,JSONArray list,int[] visited,int depth,boolean includeBounds) throws Exception {
        if (++visited[0]>1800 || depth>40 || list.length()>=300) return;
        Rect b=new Rect(); n.getBoundsInScreen(b);
        if (n.isPassword())o.protectedContent=true;
        boolean relevant=n.getText()!=null || n.getContentDescription()!=null || n.getHintText()!=null || n.isClickable() || n.isEditable() || n.isScrollable();
        if (n.isVisibleToUser() && !b.isEmpty() && relevant) {
            int id=list.length();
            String text=n.isPassword()?"[campo protegido]":clip(n.getText(),500);
            String desc=n.isPassword()?"":clip(n.getContentDescription(),300);
            String hint=n.isPassword()?"":clip(n.getHintText(),200);
            o.nodes.put(id,AccessibilityNodeInfo.obtain(n));
            String label=n.isEditable()
                ?(!hint.isEmpty()?hint:!desc.isEmpty()?desc:!text.isEmpty()?text:"sin etiqueta")
                :(!text.isEmpty()?text:!desc.isEmpty()?desc:!hint.isEmpty()?hint:"sin etiqueta");
            if(!n.isPassword() && LocalRoutes.searchResource(n.getViewIdResourceName()) && (label.equals("sin etiqueta") || (n.isEditable() && hint.isEmpty() && desc.isEmpty())))label="Buscar";
            o.labels.put(id,label);
            JSONObject entry=new JSONObject().put("id",id);
            if(!text.isEmpty())entry.put("text",text);
            if(!desc.isEmpty())entry.put("description",desc);
            if(!hint.isEmpty())entry.put("hint",hint);
            String viewId=clip(n.getViewIdResourceName(),250);if(!viewId.isEmpty())entry.put("view_id",viewId);
            if(n.isFocused())entry.put("focused",true);if(n.isEditable())entry.put("editable",true);if(n.isPassword())entry.put("password",true);
            if(n.isClickable())entry.put("clickable",true);if(!n.isEnabled())entry.put("enabled",false);
            if(n.isScrollable())entry.put("scrollable",true);
            if(includeBounds)entry.put("bounds",new JSONArray().put(b.left).put(b.top).put(b.right).put(b.bottom));
            list.put(entry);
        }
        for(int i=0;i<n.getChildCount() && visited[0]<1800 && list.length()<300;i++) {
            AccessibilityNodeInfo child=n.getChild(i);
            if(child!=null) try { collect(child,o,list,visited,depth+1,includeBounds); } finally { child.recycle(); }
        }
    }
    private static String clip(CharSequence s,int max) { return s==null?"":s.subSequence(0,Math.min(s.length(),max)).toString(); }

    Observation observe(BooleanSupplier alive,boolean image,String expectedPackage) throws Exception {
        observationScope=expectedPackage;
        CompletableFuture<Observation> result=new CompletableFuture<>();
        postTracked(()->{
            if(result.isDone() || !alive.getAsBoolean()){result.cancel(false);return;}
            obscured=true;render();
            postTracked(()->{
                if(result.isDone() || !alive.getAsBoolean()){restorePanel();result.cancel(false);return;}
                Observation snapshot;
                try{snapshot=frame(expectedPackage,image);}catch(Exception e){restorePanel();result.completeExceptionally(e);return;}
                if(!image || snapshot.protectedContent){
                    if(!result.complete(snapshot))snapshot.close();restorePanel();return;
                }
                try{
                    callbacks.incrementAndGet();
                    takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
                        @Override public void onSuccess(ScreenshotResult shot){
                            HardwareBuffer buffer=shot.getHardwareBuffer();Bitmap hardware=null,bitmap=null,scaled=null;
                            try{
                                if(!alive.getAsBoolean())throw new ChangedScreen();
                                checkContext(snapshot);
                                hardware=Bitmap.wrapHardwareBuffer(buffer,shot.getColorSpace());
                                if(hardware==null)throw new IllegalStateException("Captura no disponible");
                                if(hardware.getWidth()!=snapshot.width || hardware.getHeight()!=snapshot.height)throw new ChangedScreen();
                                bitmap=hardware.copy(Bitmap.Config.ARGB_8888,false);
                                float scale=Math.min(1f,1024f/Math.max(bitmap.getWidth(),bitmap.getHeight()));
                                scaled=Bitmap.createScaledBitmap(bitmap,Math.max(1,Math.round(bitmap.getWidth()*scale)),Math.max(1,Math.round(bitmap.getHeight()*scale)),true);
                                ByteArrayOutputStream out=new ByteArrayOutputStream();scaled.compress(Bitmap.CompressFormat.JPEG,70,out);
                                snapshot.jpeg=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
                                if(!result.complete(snapshot))snapshot.close();
                            }catch(Exception e){snapshot.close();result.completeExceptionally(e);}
                            finally{
                                if(scaled!=null && scaled!=bitmap)scaled.recycle();if(bitmap!=null)bitmap.recycle();
                                if(hardware!=null)hardware.recycle();buffer.close();restorePanel();callbacks.decrementAndGet();
                            }
                        }
                        @Override public void onFailure(int code){
                            try{snapshot.screen.put("image_unavailable",code);}catch(Exception ignored){}
                            if(!result.complete(snapshot))snapshot.close();restorePanel();callbacks.decrementAndGet();
                        }
                    });
                }catch(Exception e){callbacks.decrementAndGet();snapshot.close();restorePanel();result.completeExceptionally(e);}
            },60);
        },0);
        try{return result.get(8,TimeUnit.SECONDS);}catch(Exception e){result.cancel(false);throw e;}
    }

    Action resolve(Action a,Observation o) throws Exception {
        if(!a.expectedPackage.isEmpty() && !a.expectedPackage.equals(o.packageName))throw new ChangedScreen();
        if((a.kind==Action.Kind.type_text || a.kind==Action.Kind.enter) && a.nodeId<0 && a.target.isEmpty()){
            int focused=-1;
            for(Map.Entry<Integer,AccessibilityNodeInfo> e:o.nodes.entrySet()){
                AccessibilityNodeInfo n=e.getValue();
                if(n.isEditable() && n.isFocused() && !n.isPassword() && n.isEnabled()){
                    if(focused>=0)throw new IllegalArgumentException("Hay más de un campo enfocado");focused=e.getKey();
                }
            }
            if(focused<0)throw new IllegalArgumentException("No hay un campo editable enfocado");return a.resolved(focused);
        }
        if(a.kind==Action.Kind.scroll && a.nodeId<0 && a.target.isEmpty()){
            int candidate=-1;
            for(Map.Entry<Integer,AccessibilityNodeInfo> e:o.nodes.entrySet())if(e.getValue().isScrollable()){
                if(candidate>=0)throw new IllegalArgumentException("Hay varias listas; identifica el contenedor");candidate=e.getKey();
            }
            if(candidate<0)throw new IllegalArgumentException("No hay una lista desplazable visible");
            return a.resolved(candidate);
        }
        if(a.nodeId>=0 || a.target.isEmpty())return a;
        int found=-1;
        JSONArray entries=o.screen.getJSONArray("elements");
        for(int i=0;i<entries.length();i++){
            JSONObject n=entries.getJSONObject(i);
            if(!LocalRoutes.matches(n,a.target))continue;
            if((a.kind==Action.Kind.type_text || a.kind==Action.Kind.enter) && !n.optBoolean("editable"))continue;
            if(found>=0)throw new IllegalArgumentException("El selector tiene varios destinos: "+a.target);
            found=n.getInt("id");
        }
        if(found<0)throw new IllegalArgumentException("Aún no aparece el control: "+a.target);
        return a.resolved(found);
    }

    boolean execute(Action a,Observation observed,BooleanSupplier alive) throws Exception {
        CompletableFuture<Boolean> result=new CompletableFuture<>();
        postTracked(()->{
            if(result.isDone() || !alive.getAsBoolean()) { result.cancel(false); return; }
            try {
                assertAvailable();
                if(SystemClock.elapsedRealtime()-observed.capturedAt>60000) throw new ChangedScreen();
                checkContext(observed);
                if(!alive.getAsBoolean()) { result.cancel(false); return; }
                obscured=true; render();
                postTracked(()->{
                    if(result.isDone() || !alive.getAsBoolean()) { restorePanel(); result.cancel(false); return; }
                    try { perform(a,observed,result,alive); }
                    catch(Exception e) { result.completeExceptionally(e); restorePanel(); }
                },120);
            } catch(Exception e) { restorePanel(); result.completeExceptionally(e); }
        },0);
        try { return result.get(7,TimeUnit.SECONDS); }
        catch(Exception e) { result.cancel(false); throw e; }
        finally { postTracked(this::restorePanel,180); }
    }

    private void perform(Action a,Observation o,CompletableFuture<Boolean> result,BooleanSupplier alive) throws Exception {
        assertAvailable();
        if(!alive.getAsBoolean() || result.isDone()) { result.cancel(false); return; }
        checkContext(o);
        if(!alive.getAsBoolean() || result.isDone()){result.cancel(false);return;}
        boolean success;
        switch(a.kind) {
            case open_app:
                if(!launchable.containsKey(a.packageName) || getPackageName().equals(a.packageName)) throw new IllegalArgumentException("Aplicación fuera de la lista permitida.");
                Intent launch=getPackageManager().getLaunchIntentForPackage(a.packageName);
                if(launch==null) throw new IllegalArgumentException("Esta aplicación no se puede abrir.");
                lastLaunchPackage=a.packageName;startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); success=true; break;
            case open_settings: launchSettings(a.text);success=true;break;
            case back: success=performGlobalAction(GLOBAL_ACTION_BACK); break;
            case home: goHome();success=true;break;
            case type_text: case enter: {
                AccessibilityNodeInfo n=target(o,a);
                if(!n.isEditable() || n.isPassword()) throw new IllegalArgumentException("Solo se permiten campos editables no protegidos.");
                if(a.kind==Action.Kind.enter)success=n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
                else {
                    android.os.Bundle args=new android.os.Bundle();
                    args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,a.text);
                    success=n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args);
                }
                break;
            }
            case scroll: {
                AccessibilityNodeInfo n=target(o,a);if(!n.isScrollable())throw new IllegalArgumentException("El destino no es desplazable");
                boolean forward=!a.text.equals("up") && !a.text.equals("left");
                int direction=a.text.equals("up")?AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.getId():
                    a.text.equals("left")?AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.getId():
                    a.text.equals("right")?AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.getId():AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId();
                if(n.performAction(direction) || n.performAction(forward?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)){success=true;break;}
                semanticGesture(n,a,o,result,true);return;
            }
            case tap:
                if(a.nodeId>=0){
                    AccessibilityNodeInfo original=target(o,a);Rect originalBounds=new Rect();original.getBoundsInScreen(originalBounds);
                    AccessibilityNodeInfo n=AccessibilityNodeInfo.obtain(original);
                    try{
                        success=n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        for(int i=0;i<3 && !success;i++){
                            AccessibilityNodeInfo parent=n.getParent();if(parent==null)break;
                            Rect bounds=new Rect();parent.getBoundsInScreen(bounds);
                            boolean wrapper=bounds.contains(originalBounds) && bounds.width()<=originalBounds.width()*1.7 && bounds.height()<=originalBounds.height()*1.7;
                            if(!wrapper){parent.recycle();break;}
                            n.recycle();n=parent;success=n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                        }
                    }finally{n.recycle();}
                    if(success)break;
                    semanticGesture(original,a,o,result,false);return;
                }
                gesture(a,o,result);return;
            case swipe: gesture(a,o,result); return;
            default: throw new IllegalArgumentException("Acción no ejecutable");
        }
        result.complete(success); restorePanel();
    }

    void ensureCurrent(Observation o) throws Exception {onMain(()->{checkContext(o);return true;});}

    /** Cheap context guard and per-target refresh, never another whole-tree traversal. */
    private void checkContext(Observation o) throws Exception {
        if(uiEpoch!=o.epoch || SystemClock.elapsedRealtime()-o.capturedAt>60000)throw new ChangedScreen();
        AccessibilityNodeInfo root=scopedRoot(o.packageName);
        if(root==null)throw new ChangedScreen();
        try{if(root.getWindowId()!=o.windowId || !o.packageName.equals(String.valueOf(root.getPackageName())))throw new ChangedScreen();}
        finally{root.recycle();}
    }

    private AccessibilityNodeInfo target(Observation o,Action a) {
        AccessibilityNodeInfo node=o.nodes.get(a.nodeId);
        if(node==null || !node.refresh() || node.getWindowId()!=o.windowId || !o.packageName.equals(String.valueOf(node.getPackageName())) || !node.isEnabled() || !node.isVisibleToUser() || node.isPassword()) throw new IllegalArgumentException("El elemento ya no está disponible.");
        return node;
    }
    /** Bounds come from a refreshed semantic target; no pixel guessing and no screenshot required. */
    private void semanticGesture(AccessibilityNodeInfo node,Action a,Observation o,CompletableFuture<Boolean> result,boolean scroll) throws Exception {
        checkContext(o);if(!node.refresh() || !node.isEnabled() || !node.isVisibleToUser() || node.isPassword())throw new ChangedScreen();
        Rect b=new Rect();node.getBoundsInScreen(b);Rect before=new Rect(b);
        if(!b.intersect(0,0,o.width,o.height) || b.isEmpty())throw new ChangedScreen();
        if(node.getWindowId()!=o.windowId || !o.packageName.equals(String.valueOf(node.getPackageName())))throw new ChangedScreen();
        if(!scroll){
            String selector=o.selector(a);int matches=0;
            for(int i=0;i<o.screen.getJSONArray("elements").length();i++)if(LocalRoutes.matches(o.screen.getJSONArray("elements").getJSONObject(i),selector))matches++;
            if(selector.isEmpty() || matches!=1 || !b.equals(before) || (long)b.width()*b.height()>(long)o.width*o.height*45/100)
                throw new IllegalArgumentException("El centro del destino no es suficientemente preciso para un gesto");
        }
        int layer=Integer.MIN_VALUE;
        List<AccessibilityWindowInfo> visible=getWindows();
        try{
            for(AccessibilityWindowInfo w:visible)if(w.getId()==o.windowId)layer=w.getLayer();
            if(layer==Integer.MIN_VALUE)throw new ChangedScreen();
            for(AccessibilityWindowInfo w:visible){
                if(w.getLayer()<=layer)continue;Rect covering=new Rect();w.getBoundsInScreen(covering);
                if(!covering.contains(b.centerX(),b.centerY()))continue;
                AccessibilityNodeInfo root=w.getRoot();boolean own=false;
                if(root!=null){try{own=getPackageName().equals(String.valueOf(root.getPackageName())) && w.getType()==AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY;}finally{root.recycle();}}
                if(!own)throw new IllegalArgumentException("Otra ventana tapa el centro del destino");
            }
        }finally{for(AccessibilityWindowInfo w:visible)w.recycle();}
        o.physicalFallback=true;
        Path path=new Path();
        if(scroll){
            boolean horizontal=a.text.equals("left") || a.text.equals("right"),back=a.text.equals("up") || a.text.equals("left");
            float x=b.centerX(),y=b.centerY(),delta=(horizontal?b.width():b.height())*0.28f;
            if(horizontal){path.moveTo(x+(back?-delta:delta),y);path.lineTo(x+(back?delta:-delta),y);}
            else{path.moveTo(x,y+(back?-delta:delta));path.lineTo(x,y+(back?delta:-delta));}
        }else path.moveTo(b.centerX(),b.centerY());
        dispatchPath(path,scroll?320:80,result);
    }
    private void dispatchPath(Path path,long duration,CompletableFuture<Boolean> result){
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,duration)).build();
        callbacks.incrementAndGet();final java.util.concurrent.atomic.AtomicBoolean ended=new java.util.concurrent.atomic.AtomicBoolean();
        Runnable finish=()->{if(ended.compareAndSet(false,true))callbacks.decrementAndGet();};
        try{
            boolean accepted=dispatchGesture(g,new GestureResultCallback(){
                @Override public void onCompleted(GestureDescription gesture){try{result.complete(true);restorePanel();}finally{finish.run();}}
                @Override public void onCancelled(GestureDescription gesture){try{result.complete(false);restorePanel();}finally{finish.run();}}
            },main);
            if(!accepted){finish.run();result.complete(false);restorePanel();}
        }catch(RuntimeException e){finish.run();throw e;}
    }

    private void gesture(Action a,Observation o,CompletableFuture<Boolean> result) {
        if(o.jpeg==null)throw new IllegalArgumentException("Los gestos por coordenadas requieren una captura.");
        Path path=new Path();path.moveTo(pixel(a.x,o.width),pixel(a.y,o.height));
        if(a.kind==Action.Kind.swipe)path.lineTo(pixel(a.x2,o.width),pixel(a.y2,o.height));
        o.physicalFallback=true;dispatchPath(path,a.kind==Action.Kind.swipe?a.duration:80,result);
    }
    private static float pixel(int value,int dimension){return Math.min(dimension-1,Math.max(0,value*dimension/1000f));}

    void requestPanel(boolean visible) { main.post(()->{panelRequested=visible;render();}); }
    void refreshPanel() { main.post(this::render); }
    private void restorePanel(){obscured=false;render();}
    private void render(){
        if(agent==null || windows==null)return;
        if(!panelRequested || obscured){if(panel!=null)panel.setVisibility(View.GONE);return;}
        if(panel==null){
            panel=Ui.column(this);int pad=Ui.dp(this,12);panel.setPadding(pad,pad,pad,pad);
            panel.setBackground(Ui.rounded(this,Ui.CARD,18));panel.setElevation(Ui.dp(this,8));
            int width=Math.min(Ui.dp(this,350),getResources().getDisplayMetrics().widthPixels-Ui.dp(this,24));
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(width,-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,PixelFormat.TRANSLUCENT);
            lp.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;lp.y=Ui.dp(this,48);windows.addView(panel,lp);
        }
        panel.removeAllViews();panel.setVisibility(View.VISIBLE);
        WindowManager.LayoutParams current=(WindowManager.LayoutParams)panel.getLayoutParams();
        if(agent.isActive())current.flags|=WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        else current.flags&=~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        windows.updateViewLayout(panel,current);
        TextView title=Ui.title(this,"● Pulso · "+agent.statusLabel(),15);title.setId(R.id.floatingTaskState);Ui.runtimeMetadata(title,()->agent);panel.addView(title);
        TextView metrics=Ui.text(this,agent.metrics(),11,Ui.MUTED);metrics.setId(R.id.floatingTaskMetrics);panel.addView(metrics);
        if(agent.hasPendingApproval()){
            long approvalId=agent.pendingId();
            ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);
            TextView detail=Ui.text(this,agent.pendingDetail(),14,Ui.INK);detail.setId(R.id.floatingTaskReview);scroll.addView(detail);
            panel.addView(scroll,new LinearLayout.LayoutParams(-1,Ui.dp(this,140)));
            LinearLayout approval=new LinearLayout(this);
            Ui.rowButton(approval,Ui.button(this,"Aprobar paso",true,()->agent.approve(approvalId,true)));
            Ui.rowButton(approval,Ui.button(this,"Rechazar",false,()->agent.approve(approvalId,false)));panel.addView(approval);
        } else {
            TextView brief=Ui.text(this,agent.brief(),13,Ui.MUTED);brief.setId(R.id.floatingTaskBrief);brief.setMaxLines(3);panel.addView(brief);
        }
        LinearLayout controls=new LinearLayout(this);
        if(agent.waitingForUser()) Ui.rowButton(controls,Ui.button(this,"Responder",true,this::openPanel));
        else if(agent.isActive()){android.widget.Button pause=Ui.button(this,agent.isPaused()?"Continuar":"Pausar",false,agent::togglePause);pause.setId(R.id.floatingTaskPause);Ui.rowButton(controls,pause);}
        else Ui.rowButton(controls,Ui.button(this,"Abrir",false,this::openPanel));
        android.widget.Button stop=Ui.button(this,"Detener",false,()->{agent.stop();requestPanel(false);});stop.setId(R.id.floatingTaskStop);Ui.rowButton(controls,stop);panel.addView(controls);
    }
    private void openPanel(){startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));}
}
