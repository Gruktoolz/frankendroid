package dev.pulso.assistant;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(0,0,0), CARD = Color.rgb(26,27,35), INK = Color.rgb(242,241,250),
        MUTED = Color.rgb(182,184,197), GREEN = Color.rgb(185,177,255);
    static void runtimeMetadata(TextView view,java.util.function.Supplier<AgentController> source){
        view.setAccessibilityDelegate(new android.view.View.AccessibilityDelegate(){
            @Override public void onInitializeAccessibilityNodeInfo(android.view.View host,android.view.accessibility.AccessibilityNodeInfo info){
                super.onInitializeAccessibilityNodeInfo(host,info);AgentController a=source.get();if(a==null)return;
                android.os.Bundle extra=info.getExtras();extra.putLong("pulso_task_id",a.taskId());extra.putString("pulso_state",a.statusLabel());
                extra.putAll(a.runtime());extra.putString("pulso_metrics",a.metrics());extra.putBoolean("pulso_active",a.isActive());
            }
        });
    }
    static int dp(Context c, int value) { return Math.round(value * c.getResources().getDisplayMetrics().density); }
    static GradientDrawable rounded(Context c, int color, int radius) {
        GradientDrawable b = new GradientDrawable(); b.setColor(color); b.setCornerRadius(dp(c, radius)); return b;
    }
    static TextView text(Context c, String value, int size, int color) {
        TextView view = new TextView(c); view.setText(value); view.setTextColor(color); view.setTextSize(size);
        view.setPadding(0, dp(c,5), 0, dp(c,5)); return view;
    }
    static TextView title(Context c, String value, int size) {
        TextView v = text(c,value,size,INK); v.setTypeface(null, Typeface.BOLD); return v;
    }
    static LinearLayout column(Context c) {
        LinearLayout v = new LinearLayout(c); v.setOrientation(LinearLayout.VERTICAL); return v;
    }
    static LinearLayout card(Context c) {
        LinearLayout v = column(c); int p=dp(c,16); v.setPadding(p,p,p,p); v.setBackground(rounded(c,CARD,18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(c,14); v.setLayoutParams(lp); return v;
    }
    static Button button(Context c, String label, boolean primary, Runnable click) {
        Button b = new Button(c); b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setTextColor(primary ? BG : INK); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary ? GREEN : Color.rgb(41,57,76)));
        b.setOnClickListener(v->click.run()); return b;
    }
    static void rowButton(LinearLayout row, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(2,0,2,0); row.addView(b,lp);
    }
}
