package dev.pulso.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Credentials are entered here, never in the task conversation or agent input. */
public final class SettingsActivity extends Activity {
    private SharedPreferences prefs;private SecretStore secrets;private Provider provider;private android.widget.Spinner providers;private TextViewHolder providerNotes;
    private static final class TextViewHolder {android.widget.TextView view;}
    private volatile ModelClient testClient;
    private EditText key,model,limit;private Switch supervised;private CheckBox consent;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();private boolean testing;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        prefs=getSharedPreferences("pulso",MODE_PRIVATE);provider=Provider.from(prefs.getString("provider","gemini"));secrets=new SecretStore(this,provider);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(Ui.BG);LinearLayout root=Ui.column(this);int pad=Ui.dp(this,20);root.setPadding(pad,pad,pad,pad);scroll.addView(root);root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets b=insets.getInsets(android.view.WindowInsets.Type.systemBars());v.setPadding(pad+b.left,pad+b.top,pad+b.right,pad+b.bottom);return insets;});
        root.addView(Ui.button(this,"← Volver a Pulso",false,this::finish));root.addView(Ui.title(this,"Configuración",28));
        LinearLayout permission=Ui.card(this);root.addView(permission);permission.addView(Ui.title(this,"Control del teléfono",19));
        permission.addView(Ui.text(this,"Durante una tarea Pulso lee los controles visibles y puede pulsar y escribir. Envía al proveedor que elijas tu objetivo, controles e historial reciente; sólo pide una imagen cuando necesita interpretar contenido visual. La clave se guarda cifrada. Las tareas locales compatibles no usan una API.",14,Ui.INK));
        consent=new CheckBox(this);consent.setText("Entiendo y autorizo este uso al iniciar una tarea");consent.setTextColor(Ui.INK);consent.setChecked(prefs.getBoolean("consent",false));permission.addView(consent);
        consent.setOnCheckedChangeListener((v,checked)->{prefs.edit().putBoolean("consent",checked).apply();if(!checked && PhoneService.instance!=null)PhoneService.instance.agent.stop();});
        permission.addView(Ui.button(this,"Activar Accesibilidad",true,()->{if(!consent.isChecked()){toast("Lee y acepta el uso de pantalla primero.");return;}startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}));
        permission.addView(Ui.button(this,"Información de la app",false,()->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())))));
        permission.addView(Ui.text(this,"Si Android muestra Ajuste restringido: Información de la app → ⋮ → Permitir ajustes restringidos. Después activa Pulso en Accesibilidad.",12,Ui.MUTED));
        LinearLayout api=Ui.card(this);root.addView(api);api.addView(Ui.title(this,"Proveedor y modelo",19));
        providers=new android.widget.Spinner(this);String[] names=new String[Provider.values().length];for(int i=0;i<names.length;i++)names[i]=Provider.values()[i].label;
        android.widget.ArrayAdapter<String> adapter=new android.widget.ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);providers.setAdapter(adapter);providers.setSelection(provider.ordinal());api.addView(providers);
        key=field(secrets.hasKey()?"API key guardada · deja vacío para conservarla":"API key");key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);api.addView(key);
        model=field("auto o identificador del modelo");model.setSingleLine(true);model.setText(prefs.getString("model","auto"));api.addView(model);
        providerNotes=new TextViewHolder();providerNotes.view=Ui.text(this,"",13,Ui.MUTED);api.addView(providerNotes.view);updateProviderNotes();
        providers.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> parent){}
            public void onItemSelected(android.widget.AdapterView<?> parent,android.view.View v,int position,long id){
                Provider next=Provider.values()[position];if(next==provider)return;
                if(testClient!=null)testClient.cancel();prefs.edit().putString("model_"+provider.id,model.getText().toString().trim()).apply();
                provider=next;secrets=new SecretStore(SettingsActivity.this,provider);key.setText("");key.setHint(secrets.hasKey()?"API key guardada · deja vacío para conservarla":"API key de "+provider.label);
                model.setText(prefs.getString("model_"+provider.id,provider==Provider.GEMINI?"auto":provider==Provider.GROQ?"openai/gpt-oss-20b":""));updateProviderNotes();
            }
        });
        api.addView(Ui.button(this,"Probar conexión y elegir modelo",false,this::test));
        api.addView(Ui.button(this,"Obtener API key",false,()->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(provider.keyPage)))));
        api.addView(Ui.button(this,"Borrar clave guardada",false,()->new AlertDialog.Builder(this).setMessage("¿Borrar la clave del teléfono?").setPositiveButton("Borrar",(d,w)->{if(PhoneService.instance!=null)PhoneService.instance.agent.stop();secrets.clear();key.setText("");key.setHint("API key");}).setNegativeButton("Cancelar",null).show()));
        LinearLayout options=Ui.card(this);root.addView(options);options.addView(Ui.title(this,"Ejecución",19));
        supervised=new Switch(this);supervised.setText("Revisar cada interacción");supervised.setTextColor(Ui.INK);supervised.setChecked(prefs.getBoolean("supervised",false));options.addView(supervised);
        options.addView(Ui.text(this,"Automático: ejecuta la navegación y los lotes sin preguntar. Las operaciones sensibles y los controles ambiguos conservan revisión. Reintenta errores recuperables con límites para controlar consumo.",13,Ui.MUTED));
        options.addView(Ui.text(this,"Límite de acciones y consultas (1–60)",13,Ui.MUTED));limit=field("30");limit.setInputType(InputType.TYPE_CLASS_NUMBER);limit.setText(String.valueOf(prefs.getInt("limit",30)));options.addView(limit);
        root.addView(Ui.button(this,"Guardar y volver",true,()->{try{save();finish();}catch(Exception e){toast(e.getMessage());}}));setContentView(scroll);
    }
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(Ui.INK);e.setHintTextColor(Ui.MUTED);return e;}
    private void save() throws Exception{
        String value=key.getText().toString().trim();
        if(!value.isEmpty()){if(!value.matches("[!-~]{15,4096}"))throw new IllegalArgumentException("Revisa el formato de la clave.");secrets.save(value);key.setText("");key.setHint("API key guardada");}
        String chosen=model.getText().toString().trim();if(chosen.isEmpty())chosen="auto";
        if(!chosen.equals("auto") && !provider.validModel(chosen))throw new IllegalArgumentException("Modelo inválido.");
        int steps=Integer.parseInt(limit.getText().toString().trim());if(steps<1 || steps>60)throw new IllegalArgumentException("El límite debe estar entre 1 y 60.");
        prefs.edit().putString("provider",provider.id).putString("model_"+provider.id,chosen).putString("model",chosen).putInt("limit",steps).putBoolean("supervised",supervised.isChecked()).apply();
    }
    private void test(){
        if(testing)return;
        try{save();String value=secrets.read();if(value.isEmpty()){toast("Guarda tu clave primero.");return;}testing=true;toast("Comprobando acceso…");
            final Provider testedProvider=provider;final ModelClient client=new ModelClient(value,testedProvider);testClient=client;
            worker.submit(()->{try{List<String> models=client.listModels();runOnUiThread(()->{
                if(isFinishing() || isDestroyed() || provider!=testedProvider)return;
                if(models.isEmpty()){toast("El proveedor no devolvió modelos. Puedes introducir el identificador manualmente.");return;}
                int offset=testedProvider==Provider.GEMINI?1:0;String[] choices=new String[models.size()+offset];if(offset==1)choices[0]="Auto · económico";for(int i=0;i<models.size();i++)choices[i+offset]=models.get(i);
                new AlertDialog.Builder(this).setTitle("Elige modelo").setItems(choices,(d,index)->{model.setText(offset==1 && index==0?"auto":models.get(index-offset));if(testedProvider==Provider.GEMINI)prefs.edit().putString("resolved_model",models.get(0)).putLong("model_time",System.currentTimeMillis()).apply();}).setNegativeButton("Cerrar",null).show();
            });}catch(Exception e){runOnUiThread(()->{if(provider==testedProvider)toast(e.getMessage());});}finally{client.cancel();runOnUiThread(()->{testClient=null;testing=false;});}});
        }catch(Exception e){toast(e.getMessage());}
    }
    private void updateProviderNotes(){providerNotes.view.setText(provider==Provider.GEMINI?"Auto prioriza Flash-Lite disponible. La clave de Gemini se conserva al cambiar de proveedor.":"Introduce un modelo o consulta el listado. Elige uno de chat con salida JSON. Esta conexión usa controles semánticos, sin imágenes. La clave se guarda por separado para "+provider.label+"; no se prueba ni se envía a otro proveedor automáticamente.");}
    @Override protected void onDestroy(){if(testClient!=null)testClient.cancel();worker.shutdownNow();super.onDestroy();}
    private void toast(String text){if(!isFinishing() && !isDestroyed())Toast.makeText(this,text==null?"Revisa los datos.":text,Toast.LENGTH_LONG).show();}
}
