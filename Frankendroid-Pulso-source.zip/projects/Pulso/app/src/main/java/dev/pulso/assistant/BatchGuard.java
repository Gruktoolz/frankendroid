package dev.pulso.assistant;

import org.json.JSONArray;
import org.json.JSONObject;

/** Preconditions are evaluated against the one current semantic observation. */
public final class BatchGuard {
    public static boolean unique(JSONObject screen,String selector)throws Exception{
        if(selector.isEmpty())return false;int count=0;JSONArray nodes=screen.getJSONArray("elements");
        for(int i=0;i<nodes.length();i++)if(LocalRoutes.matches(nodes.getJSONObject(i),selector))count++;
        return count==1;
    }
    public static boolean relocatable(Action a,JSONObject screen,String origin,String signature,boolean focusedSearch)throws Exception{
        if(origin.equals(signature))return true;
        if(a.expectedPackage.isEmpty() || !a.expectedPackage.equals(screen.optString("package")))return false;
        if(focusedSearch && (a.kind==Action.Kind.type_text || a.kind==Action.Kind.enter) && a.nodeId<0 && a.target.isEmpty())return true;
        if(a.screenAnchor.isEmpty() || LocalRoutes.normalized(a.screenAnchor).equals(LocalRoutes.normalized(a.target)))return false;
        if(!unique(screen,a.screenAnchor))return false;
        return !a.target.isEmpty() && unique(screen,a.target);
    }
}
