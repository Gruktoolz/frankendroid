package dev.pulso.assistant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/** A bounded plan. Later screens use selectors, never indices from a previous screen. */
public final class ActionBatch {
    public final String summary;
    public final List<Action> actions;
    private ActionBatch(String summary,List<Action> actions){this.summary=summary;this.actions=Collections.unmodifiableList(actions);}
    public static ActionBatch parse(String raw) throws Exception {
        if(raw==null || raw.length()>32000)throw new IllegalArgumentException("Lote demasiado grande");
        JSONTokener t=new JSONTokener(raw.trim());Object value=t.nextValue();
        if(!(value instanceof JSONObject) || t.nextClean()!=0)throw new IllegalArgumentException("Lote JSON inválido");
        JSONObject j=(JSONObject)value;
        if(j.has("action"))return new ActionBatch("Siguiente paso",Collections.singletonList(Action.parse(raw)));
        Object title=j.get("summary");
        if(!(title instanceof String) || ((String)title).length()>300)throw new IllegalArgumentException("Resumen inválido");
        JSONArray entries=j.getJSONArray("actions");
        if(entries.length()<1 || entries.length()>6)throw new IllegalArgumentException("Un lote admite entre 1 y 6 acciones");
        List<Action> actions=new ArrayList<>();
        for(int i=0;i<entries.length();i++){
            Action a=Action.parse(entries.getJSONObject(i).toString());
            if(i>0 && a.nodeId>=0){
                if(a.target.isEmpty())break; // Execute only the already grounded prefix, never a future stale index.
                a=a.resolved(-1);
            }
            if(entries.length()>1 && (a.kind==Action.Kind.done || a.kind==Action.Kind.ask_user || a.kind==Action.Kind.inspect_screen)){
                if(i==0)throw new IllegalArgumentException("Un resultado terminal no puede preceder a un lote");
                break; // A planned success is not evidence. Observe and decide again after the prefix.
            }
            actions.add(a);
        }
        return new ActionBatch((String)title,actions);
    }
    public static JSONObject schema() throws Exception {
        return new JSONObject().put("type","OBJECT").put("properties",new JSONObject()
            .put("summary",new JSONObject().put("type","STRING"))
            .put("actions",new JSONObject().put("type","ARRAY").put("minItems",1).put("maxItems",6).put("items",Action.schema())))
            .put("required",new JSONArray().put("summary").put("actions"));
    }
}
