package dev.pulso.assistant;

import android.content.SharedPreferences;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;
import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A single worker owns each observe/decide/approve/execute loop. */
final class AgentController {
    private final PhoneService phone;
    private final SharedPreferences prefs;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Object monitor=new Object();
    private volatile Run run;
    private volatile Pending pending;
    private volatile String status="Listo",brief="Escribe una tarea para empezar.";
    private volatile boolean waitingForUser;
    private String log;
    private long nextApproval;

    private static final class Run {
        final String goal,model;final Provider provider;
        final int limit;
        final boolean supervised;
        final ModelClient client;
        volatile boolean cancelled,paused,finished;
        volatile long revision;
        String answer;
        final long id=System.currentTimeMillis();
        volatile int actions,calls,observations,images,recoveries;
        final Deque<Action> queue=new ConcurrentLinkedDeque<>();
        Run(String goal,String model,int limit,boolean supervised,String key,Provider provider){
            this.goal=goal;this.model=model;this.limit=limit;this.supervised=supervised;this.provider=provider;client=new ModelClient(key,provider);
        }
    }
    private static final class Pending {
        final long id,expires,revision;
        final Run owner;
        final String detail;
        int decision;
        Pending(long id,Run r,String detail,long expires,long revision){this.id=id;owner=r;this.detail=detail;this.expires=expires;this.revision=revision;}
    }
    private static final class Paused extends Exception { }

    AgentController(PhoneService phone){
        this.phone=phone;prefs=phone.getSharedPreferences("pulso",0);log=prefs.getString("log","");
    }
    boolean isActive(){Run r=run;return ModelClient.globalInFlight()!=0 || r!=null && (!r.finished || r.client.inFlight()!=0 || phone.pendingCallbacks()!=0);}
    android.os.Bundle runtime(){
        synchronized(monitor){
            android.os.Bundle b=new android.os.Bundle();Run r=run;
            if(r!=null)r.client.counters(b);b.putString("pulso_provider",r==null?prefs.getString("provider","gemini"):r.provider.id);b.putInt("global_requests_in_flight",ModelClient.globalInFlight());
            b.putInt("active_jobs",r!=null && !r.finished?1:0);b.putInt("pending_callbacks",phone.pendingCallbacks());
            b.putInt("queue_size",r==null?0:r.queue.size());b.putInt("queued_requests",0);
            b.putString("PulsoState",!isActive()?"IDLE":r==null || r.cancelled || r.finished?"DRAINING":r.paused?"PAUSED":"RUNNING");
            b.putString("task_result",r!=null && r.cancelled?"CANCELLED":status.equals("Finalizado")?"SUCCESS":r!=null && r.finished?"FAILED":"PENDING");
            return b;
        }
    }
    boolean isPaused(){Run r=run;return r!=null && r.paused;}
    boolean waitingForUser(){return waitingForUser;}
    boolean hasPendingApproval(){return pending!=null;}
    long pendingId(){Pending p=pending;return p==null?-1:p.id;}
    String pendingDetail(){Pending p=pending;return p==null?"":p.detail;}
    String statusLabel(){return status;}
    String brief(){return brief;}
    long taskId(){Run r=run;return r==null?0:r.id;}
    String metrics(){Run r=run;return r==null?"":r.actions+" acciones · "+r.calls+" consultas · "+r.images+" imágenes";}
    String detailedMetrics(){Run r=run;return r==null?"":metrics()+"\n"+r.observations+" observaciones · "+r.recoveries+" recuperaciones\n"+r.client.inputTokens()+" tokens de entrada · "+r.client.outputTokens()+" de salida";}
    synchronized String log(){return log;}
    synchronized void clearLog(){log="";prefs.edit().remove("log").apply();}
    private synchronized void record(String message){
        log += android.text.format.DateFormat.format("HH:mm:ss",System.currentTimeMillis())+"  "+message+"\n\n";
        if(log.length()>16000)log=log.substring(log.length()-16000);
        prefs.edit().putString("log",log).apply();
    }
    private boolean alive(Run r){return r!=null && run==r && !r.cancelled && !r.finished;}
    private boolean ready(Run r){return alive(r) && !r.paused;}
    private boolean ready(Run r,long revision){return ready(r) && r.revision==revision;}
    private void state(Run r,String next,String message){
        if(!alive(r))return;
        status=r.paused?"Pausado":next;brief=message;phone.refreshPanel();
    }

    void start(String goal,String model,int limit,boolean supervised,String key){
        synchronized(monitor){
            if(isActive())throw new IllegalStateException("Detén la tarea actual antes de iniciar otra.");
            if(goal.trim().isEmpty() || goal.length()>4000)throw new IllegalArgumentException("Escribe una tarea de hasta 4000 caracteres.");
            if(limit<1 || limit>60)throw new IllegalArgumentException("El límite debe estar entre 1 y 60 pasos.");
            Run next=new Run(goal.trim(),model.trim(),limit,supervised,key,Provider.from(prefs.getString("provider","gemini")));
            run=next;pending=null;waitingForUser=false;status="Iniciando";brief="Preparando la tarea…";
            record("Nueva tarea · límite de "+limit+" pasos · "+(supervised?"revisión de cada paso":"navegación automática limitada"));
            phone.requestPanel(true);worker.submit(()->execute(next));
        }
    }

    void stop(){
        Run r;
        synchronized(monitor){
            r=run;if(r!=null)r.cancelled=true;
            pending=null;waitingForUser=false;status="Detenido";brief="No se ejecutarán más pasos.";monitor.notifyAll();
        }
        if(r!=null)r.client.cancel();phone.refreshPanel();
    }
    void shutdown(){stop();worker.shutdownNow();}
    void togglePause(){
        synchronized(monitor){
            Run r=run;if(!alive(r) || waitingForUser)return;
            r.paused=!r.paused;r.revision++;pending=null;
            status=r.paused?"Pausado":"Observando";
            brief=r.paused?"Pulsa Continuar para observar de nuevo.":"Comprobaré la pantalla antes de continuar.";
            monitor.notifyAll();
        }
        phone.refreshPanel();
    }
    void approve(long id,boolean allow){
        synchronized(monitor){
            Pending p=pending;
            if(p==null || p.id!=id || p.decision!=0 || !ready(p.owner,p.revision) || SystemClock.elapsedRealtime()>p.expires)return;
            p.decision=allow?1:-1;monitor.notifyAll();
        }
    }
    void answer(String answer){
        synchronized(monitor){
            Run r=run;if(!alive(r) || !waitingForUser)return;
            if(answer.trim().isEmpty() || answer.length()>4000)throw new IllegalArgumentException("Escribe una respuesta de hasta 4000 caracteres.");
            r.answer=answer.trim();monitor.notifyAll();
        }
    }

    private void awaitReady(Run r) throws InterruptedException {
        synchronized(monitor){while(alive(r) && r.paused)monitor.wait(1000);}
        if(!alive(r))throw new InterruptedException();
    }
    private void delay(Run r,long ms) throws InterruptedException,Paused {
        long until=SystemClock.elapsedRealtime()+ms;
        synchronized(monitor){
            while(alive(r) && SystemClock.elapsedRealtime()<until){
                if(r.paused)throw new Paused();monitor.wait(Math.min(200,Math.max(1,until-SystemClock.elapsedRealtime())));
            }
        }
        if(!alive(r))throw new InterruptedException();
    }
    private int approval(Run r,long revision,Action a,PhoneService.Observation o) throws InterruptedException {
        String detail=a.description(o.label(a))+"\n\n"+a.reason;
        if(a.kind==Action.Kind.type_text)detail+="\n\nTexto completo:\n"+a.text;
        Pending p;
        synchronized(monitor){
            if(!ready(r,revision))return 0;
            p=new Pending(++nextApproval,r,detail,o.capturedAt+60000,revision);pending=p;
            state(r,"Revisar paso","Esperando tu aprobación. Si cambia la pantalla, se descarta este paso.");
            while(ready(r,revision) && pending==p && p.decision==0 && SystemClock.elapsedRealtime()<p.expires)monitor.wait(500);
            if(pending==p)pending=null;
        }
        phone.refreshPanel();
        return !ready(r,revision) || SystemClock.elapsedRealtime()>p.expires?0:p.decision;
    }
    private String ask(Run r,String question) throws InterruptedException {
        synchronized(monitor){
            if(!alive(r))throw new InterruptedException();
            waitingForUser=true;r.answer=null;
            state(r,"Necesito tu ayuda",question);record("Pregunta: "+question);
            while(alive(r) && r.answer==null)monitor.wait(1000);
            waitingForUser=false;if(!alive(r))throw new InterruptedException();
            return r.answer;
        }
    }
    private void history(JSONArray history,JSONObject entry) throws Exception {
        history.put(entry);while(history.length()>12)history.remove(0);
    }

    private String selectModel(Run r,boolean refresh) throws Exception {
        if(!r.model.isEmpty() && !"auto".equalsIgnoreCase(r.model))return r.model;
        if(r.provider!=Provider.GEMINI)throw new IllegalArgumentException("Elige un modelo de "+r.provider.label+" en Configuración");
        String cached=prefs.getString("resolved_model","");
        if(!refresh && !cached.isEmpty() && System.currentTimeMillis()-prefs.getLong("model_time",0)<86400000)return cached;
        List<String> models=r.client.listModels();
        if(models.isEmpty())throw new IllegalStateException("No hay modelos Flash disponibles en esta cuenta.");
        String selected=models.get(0);prefs.edit().putString("resolved_model",selected).putLong("model_time",System.currentTimeMillis()).apply();
        return selected;
    }

    private void execute(Run r){
        JSONArray history=new JSONArray();Deque<Action> queue=r.queue;
        String model="",scope="",prior="",batchOrigin="",searchScope="",effectBefore="";
        Action effect=null;boolean physicalEffect=false;int repeats=0,failures=0,missing=0,contextMisses=0,unstable=0;
        int imageAttempts=0;
        String localPage=LocalRoutes.pageGoal(r.goal);boolean localVersion=LocalRoutes.androidVersionGoal(r.goal);
        boolean imageNext=false,local=localVersion || !localPage.isEmpty(),modelRefreshed=false;
        long deadline=SystemClock.elapsedRealtime()+20*60*1000;long lastRevision=r.revision;
        try{
            try{delay(r,200);}catch(Paused ignored){awaitReady(r);}
            awaitReady(r);
            state(r,"Preparando",local?"Abriendo información del teléfono…":"Abriendo Inicio para preparar tu tarea…");
            JSONArray apps=local?new JSONArray():phone.apps();
            String requested=local?"":LocalRoutes.requestedPackage(r.goal,apps);
            long launchEpoch=phone.changeEpoch();
            if(local)phone.openSettingsPage(localVersion?"device_info":localPage);else if(!requested.isEmpty())phone.openPackage(requested);else phone.goHome();
            scope=phone.lastLaunchPackage;r.actions++;phone.settle(launchEpoch,()->ready(r));
            if(!local){state(r,"Conectando","Seleccionando el modelo…");model=selectModel(r,false);record("Modelo: "+model);}
            while(alive(r) && (local || r.actions<r.limit) && (r.calls<r.limit || !queue.isEmpty()) && SystemClock.elapsedRealtime()<deadline){
                awaitReady(r);final long revision=r.revision;
                if(lastRevision!=revision){queue.clear();searchScope="";effect=null;lastRevision=revision;}
                PhoneService.Observation observed=null;
                try{
                    state(r,"Observando","Leyendo los controles de la pantalla…");
                    if(imageNext)imageAttempts++;
                    observed=phone.observe(()->ready(r,revision),imageNext,scope);imageNext=false;
                    r.observations++;if(observed.jpeg!=null)r.images++;contextMisses=0;
                    if(!ready(r,revision)){queue.clear();searchScope="";continue;}
                    if(effect!=null){
                        boolean changed=!effectBefore.equals(observed.signature);
                        boolean expected=!effect.effectAnchor.isEmpty() && BatchGuard.unique(observed.screen,effect.effectAnchor);
                        if(effect.kind==Action.Kind.type_text){
                            try{Action destination=phone.resolve(effect.focused(),observed);
                                expected=observed.editable(destination) && observed.nodes.get(destination.nodeId).getText()!=null && effect.text.contentEquals(observed.nodes.get(destination.nodeId).getText());
                            }catch(IllegalArgumentException noFocus){expected=false;}
                        }
                        history(history,new JSONObject().put("effect_observed",changed).put("expected_effect_verified",expected));
                        if(!changed || (physicalEffect && !expected)){
                            queue.clear();r.recoveries++;
                            history(history,new JSONObject().put("replan_reason",!changed?"La acción enviada no cambió la pantalla":"Gesto terminado sin postcondición comprobada; replantea con esta observación"));
                        }
                        effect=null;physicalEffect=false;
                    }
                    if(local && !localVersion){
                        phone.ensureCurrent(observed);
                        if(LocalRoutes.pageBack(r.goal)){
                            phone.back();r.actions++;phone.settle(observed.epoch,()->ready(r));
                            phone.goHome();r.actions++;scope=phone.lastLaunchPackage;
                            // Return to a known authorized surface instead of traversing an arbitrary previous app.
                            phone.settle(observed.epoch,()->ready(r));
                            try(PhoneService.Observation after=phone.observe(()->ready(r),false,scope)){r.observations++;phone.ensureCurrent(after);}
                        }
                        state(r,"Finalizado",LocalRoutes.pageBack(r.goal)?"Abrí la página solicitada, volví atrás y dejé Inicio visible.":"Abrí la página solicitada sin cambiar ninguna configuración.");return;
                    }
                    if(local){
                        String visible=LocalRoutes.visibleAndroidVersion(observed.screen.getJSONArray("elements"));
                        String version=android.os.Build.VERSION.RELEASE;
                        boolean shown=!visible.isEmpty() && visible.equals(version);
                        String answer="Tu teléfono tiene Android "+version+"."+(shown?" Comprobado en la información del teléfono.":" Confirmado con el dato del sistema; abrí la información del teléfono.");
                        state(r,"Finalizado",answer);record("Resultado: "+answer+" · ruta local, 0 consultas a Gemini");return;
                    }
                    if(LocalRoutes.settingsSearchComplete(r.goal,observed.screen)){
                        phone.ensureCurrent(observed);String answer="Busqué «"+LocalRoutes.settingsSearchTerm(r.goal)+"» en Ajustes y dejé los resultados visibles.";
                        state(r,"Finalizado",answer);record("Resultado verificado localmente: "+answer);return;
                    }
                    if(queue.isEmpty()){
                        state(r,"Preparando lote","Eligiendo los siguientes pasos…");r.calls++;
                        ActionBatch batch=r.client.decide(model,r.goal,observed.screen,observed.jpeg,history,apps);
                        if(!ready(r,revision))continue;
                        queue.addAll(batch.actions);batchOrigin=observed.signature;record("Lote: "+batch.summary+" · "+batch.actions.size()+" acciones");
                        history(history,new JSONObject().put("current_plan",batch.summary));
                    }
                    Action planned=queue.peekFirst();
                    boolean focusedSearch=searchScope.equals(observed.packageName) && !searchScope.isEmpty();
                    if(!BatchGuard.relocatable(planned,observed.screen,batchOrigin,observed.signature,focusedSearch)){
                        queue.clear();r.recoveries++;searchScope="";
                        history(history,new JSONObject().put("batch_state","REQUIRES_REPLAN").put("reason","Las precondiciones de pantalla del siguiente paso no se cumplen"));continue;
                    }
                    if(planned.kind==Action.Kind.done){
                        phone.ensureCurrent(observed);
                        state(r,"Finalizado",planned.reason);record("Resultado: "+planned.reason);return;
                    }
                    if(planned.kind==Action.Kind.inspect_screen){
                        queue.clear();
                        if(!r.provider.images() || observed.jpeg!=null || imageAttempts>=3){
                            history(history,new JSONObject().put("image_request_declined","Usa la semántica disponible; no hay presupuesto para más imágenes."));
                        }else imageNext=true;
                        continue;
                    }
                    if(planned.kind==Action.Kind.ask_user){
                        queue.clear();String answer=ask(r,planned.reason);
                        history(history,new JSONObject().put("user_clarification",answer));continue;
                    }
                    if(planned.kind==Action.Kind.wait){
                        queue.removeFirst();delay(r,Math.min(planned.duration,2000));continue;
                    }
                    Action action=phone.resolve(planned,observed);
                    if((action.kind==Action.Kind.type_text || action.kind==Action.Kind.enter) && !observed.editable(action)){
                        if(action.kind==Action.Kind.type_text && observed.searchControl(action) && !observed.selector(action).isEmpty()){
                            queue.removeFirst();queue.addFirst(planned.focused());batchOrigin=observed.signature;
                            queue.addFirst(Action.parse(new JSONObject().put("action","tap").put("reason","Abrir el buscador solicitado")
                                .put("target",observed.selector(action)).put("expected_package",observed.packageName).toString()));
                            r.recoveries++;record("Preparé localmente el foco del buscador antes de escribir; sin otra consulta.");continue;
                        }
                        throw new IllegalArgumentException("El destino no es editable; se descarta el paso imposible antes de pedir aprobación");
                    }
                    if((action.kind==Action.Kind.tap && action.nodeId<0 || action.kind==Action.Kind.swipe) && observed.jpeg==null){
                        queue.clear();r.recoveries++;history(history,new JSONObject().put("grounding_error","Las coordenadas no están autorizadas por una imagen actual. Usa nodos o scroll semántico, o solicita inspect_screen."));continue;
                    }
                    String label=observed.label(action);
                    if(focusedSearch && observed.editable(action) && observed.nodes.get(action.nodeId).isFocused() && (action.kind==Action.Kind.type_text || action.kind==Action.Kind.enter))label="Buscar";
                    String signature=observed.signature+"/"+action.signature();
                    repeats=signature.equals(prior)?repeats+1:1;prior=signature;
                    if(repeats>=2){
                        queue.clear();r.recoveries++;
                        history(history,new JSONObject().put("failed_action",action.signature()).put("instruction","Esta acción no avanzó. Usa otra ruta; no la repitas."));
                        if(repeats>=4)throw new IllegalStateException("No encontré una ruta que avance dentro del presupuesto. No hice más cambios.");
                        continue;
                    }
                    if(SafetyPolicy.outsideReadOnlyGoal(r.goal,action,label)){
                        queue.clear();r.recoveries++;
                        history(history,new JSONObject().put("blocked_out_of_scope",action.description(observed.label(action))).put("instruction","El objetivo es de lectura. Usa otra ruta sin cambios."));continue;
                    }
                    if(SafetyPolicy.needsApproval(r.supervised,action,label,action.reason,observed.editable(action))){
                        android.util.Log.i("PulsoRuntime","approval kind="+action.kind+" labelKnown="+!observed.label(action).equals("sin etiqueta")+" image="+(observed.jpeg!=null));
                        int choice=approval(r,revision,action,observed);
                        if(choice<=0){queue.clear();history(history,new JSONObject().put("rejected_action",action.description(observed.label(action))));continue;}
                    }
                    if(!ready(r,revision)){queue.clear();continue;}
                    state(r,"Ejecutando",action.description(observed.label(action)));
                    boolean performed=phone.execute(action,observed,()->ready(r,revision));
                    if(!alive(r))return;
                    r.actions++;queue.removeFirst();
                    if(performed){
                        effect=action;effectBefore=observed.signature;physicalEffect=observed.physicalFallback;
                        if(action.kind==Action.Kind.tap && observed.searchControl(action))searchScope=observed.packageName;
                        else if(action.kind!=Action.Kind.type_text && action.kind!=Action.Kind.enter)searchScope="";
                    }else searchScope="";
                    missing=0;unstable=0;failures=0;
                    record("Acción "+r.actions+" · "+action.description(observed.label(action))+" · "+(performed?"enviada":"sin efecto"));
                    history(history,new JSONObject().put("action",action.kind.name()).put("target",observed.label(action)).put("accepted",performed));
                    if(!performed){queue.clear();r.recoveries++;}
                    if(action.kind==Action.Kind.open_app || action.kind==Action.Kind.open_settings || action.kind==Action.Kind.home)scope=phone.lastLaunchPackage;
                    phone.settle(observed.epoch,()->ready(r,revision));
                }catch(Exception error){
                    Throwable cause=root(error);if(!alive(r))return;
                    android.util.Log.i("PulsoRuntime","recover="+cause.getClass().getSimpleName()+" queue="+queue.size()+" calls="+r.calls);
                    if(r.paused || cause instanceof Paused || cause instanceof java.util.concurrent.CancellationException){queue.clear();continue;}
                    if(cause instanceof PhoneService.OwnScreen || cause instanceof PhoneService.UnexpectedApp){
                        if(cause instanceof PhoneService.UnexpectedApp && ++contextMisses<=3){delay(r,180);continue;}
                        synchronized(monitor){r.paused=true;r.revision++;pending=null;queue.clear();state(r,"Pausado",cause.getMessage());}
                        continue;
                    }
                    if(cause instanceof PhoneService.ChangedScreen){
                        queue.clear();searchScope="";
                        r.recoveries++;if(++unstable>12)throw new IllegalStateException("La pantalla no se estabiliza. Pausa las otras interacciones y vuelve a intentar.");
                        delay(r,150);continue;
                    }
                    if(cause instanceof ModelClient.ApiException){
                        ModelClient.ApiException api=(ModelClient.ApiException)cause;android.util.Log.i("PulsoRuntime","provider_error status="+api.status);
                        if(api.status==404 && !modelRefreshed && (r.model.isEmpty() || r.model.equals("auto"))){String rejected=model;List<String> refreshed=r.client.listModels();refreshed.remove(rejected);if(refreshed.isEmpty())throw error;model=refreshed.get(0);prefs.edit().putString("resolved_model",model).putLong("model_time",System.currentTimeMillis()).apply();record("Modelo alternativo tras HTTP 404: "+model);modelRefreshed=true;queue.clear();continue;}
                        if(api.status!=429 && api.status<500)throw error;
                    }
                    if(cause instanceof IllegalArgumentException || cause instanceof org.json.JSONException){
                        r.recoveries++;
                        if(!queue.isEmpty() && ++missing<=2){delay(r,200);continue;}
                        queue.clear();missing=0;
                        history(history,new JSONObject().put("execution_problem",cause.getMessage()).put("instruction","El selector no sirve; elige otro destino con la observación actual."));
                        if(++failures<=3)continue;
                    }else if(++failures<=2){
                        r.recoveries++;queue.clear();state(r,"Reintentando","La conexión o la pantalla falló; recuperando la tarea…");delay(r,1500L*failures);continue;
                    }
                    throw error;
                }finally{if(observed!=null)observed.close();}
            }
            if(alive(r))state(r,"Presupuesto alcanzado","Se alcanzó el límite de acciones, consultas o tiempo. El progreso quedó en la actividad reciente.");
        }catch(Exception e){
            if(alive(r)){Throwable cause=root(e);String message=cause.getMessage();if(message==null)message="No pude completar la tarea";state(r,"No completado",message);record("Interrumpido: "+message);}
        }finally{
            queue.clear();r.client.cancel();
            synchronized(monitor){if(run==r){pending=null;waitingForUser=false;}}
            // Cancellation is a request, not proof of completion. Keep the next task gated until callbacks drain.
            long drainDeadline=SystemClock.elapsedRealtime()+10000;
            while(phone.pendingCallbacks()!=0 && SystemClock.elapsedRealtime()<drainDeadline){
                try{phone.drain();Thread.sleep(25);}catch(Exception ignored){break;}
            }
            if(run==r)record(detailedMetrics());
            synchronized(monitor){r.finished=true;monitor.notifyAll();}
            if(run==r){android.util.Log.i("PulsoRuntime","task_end runtime="+runtime());phone.refreshPanel();}
        }
    }
    private static Throwable root(Throwable t){while(t.getCause()!=null)t=t.getCause();return t;}
}
