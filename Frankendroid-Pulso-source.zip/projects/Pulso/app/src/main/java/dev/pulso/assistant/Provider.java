package dev.pulso.assistant;

/** Fixed HTTPS origins: a saved credential can never follow a model-provided URL. */
public enum Provider {
    GEMINI("gemini","Gemini","https://generativelanguage.googleapis.com/v1beta/","https://aistudio.google.com/apikey"),
    OPENROUTER("openrouter","OpenRouter","https://openrouter.ai/api/v1/","https://openrouter.ai/settings/keys"),
    GROQ("groq","Groq","https://api.groq.com/openai/v1/","https://console.groq.com/keys"),
    DEEPSEEK("deepseek","DeepSeek","https://api.deepseek.com/","https://platform.deepseek.com/api_keys"),
    OPENAI("openai","OpenAI","https://api.openai.com/v1/","https://platform.openai.com/api-keys");
    public final String id,label,base,keyPage;
    Provider(String id,String label,String base,String keyPage){this.id=id;this.label=label;this.base=base;this.keyPage=keyPage;}
    public static Provider from(String id){for(Provider p:values())if(p.id.equals(id))return p;throw new IllegalArgumentException("Proveedor no reconocido");}
    public boolean validModel(String model){return this==GEMINI?model.equals("auto") || model.matches("gemini-[A-Za-z0-9._-]+") : model.matches("[A-Za-z0-9][A-Za-z0-9._:/@+\\-]{0,199}") && !model.equals("auto");}
    public boolean images(){return this==GEMINI;}
}
