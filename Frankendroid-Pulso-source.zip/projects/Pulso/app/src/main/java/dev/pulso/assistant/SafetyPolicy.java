package dev.pulso.assistant;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Automatically allows ordinary, grounded UI work and pauses on high-impact or poorly grounded actions. */
public final class SafetyPolicy {
    private static final Pattern HIGH_IMPACT = Pattern.compile(
        "\\b(enviar|envia|send|submit|publicar|publica|post|comprar|compra|buy|pagar|pago|pay|"+
        "eliminar|elimina|borrar|borra|delete|remove|permitir|permite|allow|denegar|deny|"+
        "activar|activa|desactivar|desactiva|habilitar|desarrollador|developer|seguridad|security|"+
        "permiso|permission|restablecer|restaurar|reset|factory|instalar|desinstalar|install|uninstall|"+
        "compartir|share|confirmar|confirm|autorizar|authorize|contrase[nñ]a|password|c[oó]digo|otp|pin|biometr[ií]a|transferencia|transfer|pago|payment|suscripci[oó]n|subscription)\\b");
    private static final Pattern HARD_IMPACT=Pattern.compile("\\b(enviar|send|submit|publicar|post|comprar|buy|pagar|pay|borrar|eliminar|delete|permitir|allow|developer|desarrollador|transferir|transfer)\\b");
    private static final Pattern SEARCH_FIELD = Pattern.compile(
        "\\b(buscar|b[uú]squeda|search|find|consulta|query|direcci[oó]n|url|address)\\b");
    private static final Pattern SECRET = Pattern.compile(
        "(?i)(AIza[0-9A-Za-z_-]{25,}|(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)[A-Za-z0-9_+/=-]{32,})");
    private static final Pattern READ_ONLY_GOAL = Pattern.compile(
        "\\b(no cambies|no cambie|no modifiques|sin cambiar|sin modificar|solo consulta|solo lee|solo observa|read only|do not change)\\b");
    private static final Pattern MUTATION = Pattern.compile(
        "\\b(activar|activa|desactivar|desactiva|habilitar|permitir|cambiar|modificar|restablecer|"+
        "restaurar|borrar|eliminar|instalar|desinstalar|enable|disable|change|modify|reset|delete|install)\\b");

    /** Drop clearly conflicting steps instead of interrupting a read-only task to ask about them. */
    public static boolean outsideReadOnlyGoal(String goal, Action action, String label) {
        if (!READ_ONLY_GOAL.matcher(normalize(goal)).find()) return false;
        String target=normalize(label), rationale=normalize(action.reason);
        if(searchAction(action,target,rationale))return false;
        return MUTATION.matcher(rationale).find() || HIGH_IMPACT.matcher(target).find();
    }

    public static boolean needsApproval(boolean supervised, Action action, String label,
                                        String reason, boolean editable) {
        if (!action.changesPhone()) return false;
        if (supervised) return true;

        if(action.kind==Action.Kind.open_app || action.kind==Action.Kind.open_settings || action.kind==Action.Kind.back || action.kind==Action.Kind.home || action.kind==Action.Kind.swipe || action.kind==Action.Kind.scroll)return false;

        String target = normalize(label);
        String rationale = normalize(reason);
        if(searchAction(action,target,rationale)){
            if(action.kind==Action.Kind.type_text)return !editable || SECRET.matcher(action.text).find();
            return action.kind==Action.Kind.enter && !editable;
        }
        if (target.isEmpty() || target.equals("sin etiqueta") || HIGH_IMPACT.matcher(target).find()
                || HIGH_IMPACT.matcher(rationale).find()) return true;

        switch (action.kind) {
            case open_app: case back: case home: case swipe:
                return false;
            case tap:
                return action.nodeId < 0; // Coordinates have no semantic target to verify.
            case type_text:
                return !editable || SECRET.matcher(action.text).find();
            case enter:
                return !editable || !SEARCH_FIELD.matcher(target).find();
            default:
                return false;
        }
    }

    private static boolean searchAction(Action a,String label,String reason){
        return a.nodeId>=0 && (a.kind==Action.Kind.tap || a.kind==Action.Kind.type_text || a.kind==Action.Kind.enter)
            && SEARCH_FIELD.matcher(label).find() && !HIGH_IMPACT.matcher(label).find() && !HARD_IMPACT.matcher(reason).find();
    }
    private static String normalize(String s) {
        return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
            .replaceAll("\\p{M}", "").trim().toLowerCase(Locale.ROOT);
    }
}
