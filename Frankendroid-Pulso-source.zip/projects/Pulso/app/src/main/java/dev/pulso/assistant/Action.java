package dev.pulso.assistant;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

/** Untrusted model output crosses this boundary before it can reach Android. */
public final class Action {
    public enum Kind { open_app, open_settings, tap, type_text, enter, scroll, swipe, back, home, wait, inspect_screen, done, ask_user }
    public final Kind kind;
    public final String reason, text, packageName, target, expectedPackage, screenAnchor, effectAnchor;
    public final int nodeId, x, y, x2, y2, duration;

    private Action(JSONObject j) throws Exception {
        kind = Kind.valueOf(j.getString("action"));
        reason = string(j, "reason", 1000, true);
        text = string(j, "text", 4000, false);
        packageName = string(j, "package", 200, false);
        target = string(j, "target", 300, false);
        expectedPackage = string(j, "expected_package", 200, false);
        screenAnchor = string(j,"screen_anchor",300,false);effectAnchor=string(j,"effect_anchor",300,false);
        if (!expectedPackage.isEmpty() && !expectedPackage.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+"))
            throw new IllegalArgumentException("Contexto de aplicación inválido");
        nodeId = integer(j, "node_id", -1, -1, 10000);
        x = integer(j, "x", -1, -1, 1000); y = integer(j, "y", -1, -1, 1000);
        x2 = integer(j, "x2", -1, -1, 1000); y2 = integer(j, "y2", -1, -1, 1000);
        duration = integer(j, "duration_ms", kind == Kind.wait ? 1200 : 450, 100, 5000);
        switch (kind) {
            case tap:
                if (nodeId < 0 && target.isEmpty() && (x < 0 || y < 0)) throw new IllegalArgumentException("Falta destino de toque");
                break;
            case type_text: case enter:
                if (kind == Kind.type_text && !j.has("text")) throw new IllegalArgumentException("Falta text");
                break;
            case open_settings:
                if (!text.equals("device_info") && !text.equals("settings"))
                    throw new IllegalArgumentException("Página de ajustes no permitida");
                break;
            case scroll:
                if(!text.isEmpty() && !text.matches("down|up|left|right"))throw new IllegalArgumentException("Dirección de desplazamiento inválida");
                break;
            case swipe:
                if (x < 0 || y < 0 || x2 < 0 || y2 < 0 || duration > 1500)
                    throw new IllegalArgumentException("Deslizamiento inválido");
                break;
            case open_app:
                if (!packageName.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+"))
                    throw new IllegalArgumentException("Paquete inválido");
                break;
            default: break;
        }
    }

    public static Action parse(String raw) throws Exception {
        if (raw == null || raw.length() > 16000) throw new IllegalArgumentException("Respuesta inválida");
        JSONTokener tokenizer = new JSONTokener(raw.trim());
        Object value = tokenizer.nextValue();
        if (!(value instanceof JSONObject) || tokenizer.nextClean() != 0)
            throw new IllegalArgumentException("Se esperaba un único objeto JSON");
        return new Action((JSONObject) value);
    }

    private static String string(JSONObject j, String key, int max, boolean required) throws Exception {
        if (!j.has(key)) {
            if (required) throw new IllegalArgumentException("Falta " + key);
            return "";
        }
        Object v = j.get(key);
        if (!(v instanceof String) || ((String) v).length() > max)
            throw new IllegalArgumentException("Campo inválido: " + key);
        return (String) v;
    }

    private static int integer(JSONObject j, String key, int fallback, int min, int max) throws Exception {
        if (!j.has(key)) return fallback;
        Object v = j.get(key);
        if (!(v instanceof Number)) throw new IllegalArgumentException("Número inválido: " + key);
        double n = ((Number) v).doubleValue();
        if (!Double.isFinite(n) || n != Math.rint(n) || n < min || n > max)
            throw new IllegalArgumentException("Fuera de rango: " + key);
        return (int) n;
    }

    public boolean changesPhone() { return kind != Kind.done && kind != Kind.ask_user && kind != Kind.wait && kind != Kind.inspect_screen; }

    Action resolved(int id) throws Exception {return copy(id,target);}
    Action focused() throws Exception {return copy(-1,"");}
    private Action copy(int id,String selector) throws Exception {
        JSONObject j=new JSONObject().put("action",kind.name()).put("reason",reason).put("text",text)
            .put("package",packageName).put("expected_package",expectedPackage).put("target",selector)
            .put("screen_anchor",screenAnchor).put("effect_anchor",effectAnchor).put("node_id",id).put("x",x).put("y",y).put("x2",x2).put("y2",y2).put("duration_ms",duration);
        return new Action(j);
    }

    public String description(String label) {
        switch (kind) {
            case open_app: return "Abrir " + packageName;
            case open_settings: return "Abrir información del teléfono";
            case tap: return nodeId >= 0 ? "Pulsar «" + label + "»" : "Tocar pantalla (" + x + ", " + y + ")";
            case type_text: return "Escribir " + text.length() + " caracteres en «" + label + "»";
            case enter: return "Enviar / Intro en «" + label + "»";
            case scroll: return "Desplazar la lista";
            case swipe: return "Deslizar la pantalla";
            case back: return "Volver atrás";
            case home: return "Ir al inicio";
            case wait: return "Esperar " + duration + " ms";
            case done: return "Finalizar";
            case inspect_screen: return "Ampliar la observación con una imagen";
            default: return "Pedirte información";
        }
    }

    public String signature() {
        return kind + ":" + nodeId + ":" + target + ":" + x + ":" + y + ":" + x2 + ":" + y2 + ":" + packageName + ":" + text;
    }

    public static JSONObject schema() throws Exception {
        JSONObject props = new JSONObject();
        JSONArray kinds = new JSONArray();
        for (Kind kind : Kind.values()) kinds.put(kind.name());
        props.put("action", new JSONObject().put("type", "STRING").put("enum", kinds));
        for (String key : new String[]{"reason", "text", "package", "target", "expected_package", "screen_anchor", "effect_anchor"})
            props.put(key, new JSONObject().put("type", "STRING"));
        for (String key : new String[]{"node_id", "x", "y", "x2", "y2", "duration_ms"})
            props.put(key, new JSONObject().put("type", "INTEGER"));
        return new JSONObject().put("type", "OBJECT").put("properties", props)
            .put("required", new JSONArray().put("action").put("reason"));
    }
}
