package dev.pulso.assistant;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small explicit recipes, independent of a model and of any particular screen coordinates. */
public final class LocalRoutes {
    public static String normalized(String s){return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}","").trim().toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
    public static boolean androidVersionGoal(String goal){
        String g=normalized(goal);
        return g.length()<=260 && g.contains("android") && (g.contains("version") || g.contains("version tengo"))
            && !Pattern.compile("\\b(envia|enviar|comparte|compartir|publica|actualiza|actualizar|instala|instalar|descarga|descargar|recomienda|recomiendas|compara|navegador|web|archivo|mensaje|correo|busca en internet)\\b").matcher(g).find();
    }
    public static String pageGoal(String goal){
        String g=normalized(goal).replaceAll("[.!]+$","");
        java.util.regex.Matcher m=Pattern.compile("^(?:abre|abrir|open) (?:los |la pagina de )?(ajustes|configuracion|wi-fi|wifi|bluetooth|informacion del telefono)(?: y (?:vuelve|volver) atras)?(?: sin cambiar (?:nada|ninguna configuracion))?$").matcher(g);
        if(!m.matches())return "";String page=m.group(1);return page.equals("wifi") || page.equals("wi-fi")?"wifi":page.equals("bluetooth")?"bluetooth":page.equals("informacion del telefono")?"device_info":"settings";
    }
    public static boolean pageBack(String goal){return !pageGoal(goal).isEmpty() && normalized(goal).matches(".*\\by (vuelve|volver) atras\\b.*");}
    public static String requestedPackage(String goal,JSONArray apps) throws Exception {
        String g=normalized(goal);
        for(int i=0;i<apps.length();i++){
            JSONObject app=apps.getJSONObject(i);String label=normalized(app.optString("label"));
            if(label.isEmpty())continue;
            String prefix="^(?:abre|abrir|inicia|entra en|open|launch)\\s+(?:la app |la aplicacion |app )?"+Pattern.quote(label)+"(?:\\b|$)";
            if(Pattern.compile(prefix).matcher(g).find())return app.getString("package");
            if(app.optString("package").equals("com.android.settings") && Pattern.compile("^(abre|abrir|open) (ajustes|configuracion|settings)\\b").matcher(g).find())return app.getString("package");
        }
        return "";
    }
    public static String settingsSearchTerm(String goal){
        String g=normalized(goal);Matcher m=Pattern.compile("^abre (?:ajustes|configuracion) y busca ([^.,]{1,80})(?:[.,](.*))?$").matcher(g);
        if(!m.matches())return "";String term=m.group(1).trim(),rest=m.group(2)==null?"":m.group(2).replaceAll("[.,]","").trim();
        int at=term.indexOf(" sin cambiar");if(at>=0){rest=term.substring(at+1)+(rest.isEmpty()?"":" "+rest);term=term.substring(0,at).trim();}
        if(!rest.isEmpty() && !rest.matches("(?:deja (?:los )?resultados visibles(?: )?)?(?:sin cambiar (?:ninguna configuracion|nada|ajustes))?"))return "";
        return term.isEmpty()?"":term;
    }
    public static boolean settingsSearchComplete(String goal,JSONObject screen) throws Exception {
        String term=settingsSearchTerm(goal);if(term.isEmpty() || !screen.optString("package").equals("com.android.settings"))return false;
        boolean query=false,result=false;JSONArray list=screen.getJSONArray("elements");
        for(int i=0;i<list.length();i++){
            JSONObject n=list.getJSONObject(i);if(n.optBoolean("password"))continue;
            if(normalized(n.optString("text")).equals(term)){if(n.optBoolean("editable"))query=true;else result=true;}
        }
        return query && result;
    }
    /** Return only a version anchored to a visible Android label, never a bare unrelated number. */
    public static String visibleAndroidVersion(JSONArray elements) throws Exception {
        Pattern inline=Pattern.compile("(?i)\\bandroid\\s*(?:version\\s*)?[:·\\-]?\\s*(\\d{1,2}(?:\\.\\d{1,2}){0,2})(?![\\d.])");
        for(int i=0;i<elements.length();i++){
            JSONObject node=elements.getJSONObject(i);
            if(node.optBoolean("password"))continue;
            String text=node.optString("text","");Matcher m=inline.matcher(text);
            if(m.find())return m.group(1);
            String label=normalized(text);
            if(label.equals("version de android") || label.equals("android version")){
                for(int k=i+1;k<Math.min(elements.length(),i+3);k++){
                    JSONObject next=elements.getJSONObject(k);
                    if(next.optBoolean("password"))continue;
                    String n=next.optString("text","").trim();
                    if(n.matches("\\d{1,2}(?:\\.\\d{1,2}){0,2}"))return n;
                }
            }
        }
        return "";
    }
    public static boolean searchResource(String id){String s=normalized(id);return s.contains("search") || s.contains("buscar") || s.contains("query");}
    public static boolean matches(JSONObject node,String selector){
        if(node.optBoolean("password") || !node.optBoolean("enabled",true))return false;
        String s=normalized(selector);
        if(s.isEmpty())return false;
        for(String key:new String[]{"view_id","text","description","hint"})
            if(s.equals(normalized(node.optString(key,""))))return true;
        return false;
    }
}
