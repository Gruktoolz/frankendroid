package dev.pulso.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

/** Chat presentation adapted from Tunnel Turbo; execution and secrets stay in Pulso. */
public final class MainActivity extends Activity {
    private static final String FIRST="Abre Ajustes, busca la información del teléfono y dime qué versión de Android tengo. No cambies ninguna configuración.";
    private final Handler main=new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private JSONArray messages;
    private LinearLayout chat,progress,details,controls;
    private ScrollView scroll;
    private EditText input;
    private TextView header;
    private Button send,pause,stop,model,disclosure;
    private boolean expanded;
    private String rendered="";
    private final Runnable tick=new Runnable(){public void run(){refresh();main.postDelayed(this,500);}};

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        prefs=getSharedPreferences("pulso",MODE_PRIVATE);
        if(!prefs.getBoolean("fast_v2",false))prefs.edit().putBoolean("supervised",false).putString("model","auto").remove("resolved_model").putBoolean("fast_v2",true).apply();
        try{messages=new JSONArray(prefs.getString("chat_history","[]"));}catch(Exception e){messages=new JSONArray();}
        setContentView(R.layout.pulso_main_panel);
        View root=findViewById(android.R.id.content);
        root.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets b=insets.getInsets(WindowInsets.Type.systemBars());v.setPadding(b.left,b.top,b.right,b.bottom);return insets;});
        header=findViewById(R.id.tvHeaderStatus);Ui.runtimeMetadata(header,()->PhoneService.instance==null?null:PhoneService.instance.agent);input=findViewById(R.id.etAppInput);
        chat=findViewById(R.id.llChatMessages);scroll=findViewById(R.id.scrollChat);send=findViewById(R.id.btnAppSend);
        progress=findViewById(R.id.agentProgressPanel);details=findViewById(R.id.llProgressDetails);
        disclosure=findViewById(R.id.btnProgressDisclosure);model=findViewById(R.id.btnComposerModel);
        model.setVisibility(View.VISIBLE);model.setOnClickListener(v->settings());
        controls=new LinearLayout(this);progress.addView(controls);
        pause=Ui.button(this,"Pausar",false,this::pauseOrResume);Ui.rowButton(controls,pause);
        stop=Ui.button(this,"Detener",false,()->{PhoneService p=PhoneService.instance;if(p!=null){p.agent.stop();p.requestPanel(false);}refresh();});Ui.rowButton(controls,stop);
        disclosure.setOnClickListener(v->{expanded=!expanded;refresh();});
        findViewById(R.id.btnToggleMode).setOnClickListener(v->{
            PopupMenu menu=new PopupMenu(this,v);
            menu.getMenu().add("Configuración").setOnMenuItemClickListener(i->{settings();return true;});
            menu.getMenu().add("Primera prueba").setOnMenuItemClickListener(i->{input.setText(FIRST);return true;});
            menu.getMenu().add("Borrar conversación").setOnMenuItemClickListener(i->{new AlertDialog.Builder(this).setMessage("¿Borrar esta conversación local?").setPositiveButton("Borrar",(d,w)->{messages=new JSONArray();saveMessages();renderMessages();}).setNegativeButton("Cancelar",null).show();return true;});
            menu.show();
        });
        if(prefs.getString("resolved_model","").startsWith("gemini-2.5-"))prefs.edit().remove("resolved_model").remove("model_time").apply();
        send.setOnClickListener(v->send());renderMessages();refresh();
    }
    private void settings(){startActivity(new Intent(this,SettingsActivity.class));}
    private void send(){
        String text=input.getText().toString().trim();if(text.isEmpty())return;
        if(text.matches("(?s).*(?:AIza[0-9A-Za-z_-]{25,}|sk-[A-Za-z0-9_-]{15,}|gsk_[A-Za-z0-9_-]{15,}).*")){input.setText("");toast("Guarda la API key en Configuración.");settings();return;}
        PhoneService phone=PhoneService.instance;
        if(phone==null){toast("Activa el control del teléfono en Configuración.");settings();return;}
        try{
            AgentController a=phone.agent;
            if(a.waitingForUser()){a.answer(text);append("user",text);input.setText("");moveTaskToBack(true);return;}
            if(a.isActive()){toast("Pausa o detén la tarea actual antes de iniciar otra.");return;}
            if(!prefs.getBoolean("consent",false)){toast("Completa la configuración inicial de pantalla.");settings();return;}
            String key=new SecretStore(this).read();
            if(key.isEmpty() && !LocalRoutes.androidVersionGoal(text) && LocalRoutes.pageGoal(text).isEmpty()){toast("Conecta un proveedor desde Configuración.");settings();return;}
            a.start(text,prefs.getString("model","auto"),prefs.getInt("limit",30),prefs.getBoolean("supervised",false),key);
            append("user",text);input.setText("");moveTaskToBack(true);
        }catch(Exception e){toast(e.getMessage()==null?"No pude iniciar la tarea.":e.getMessage());}
    }
    private void pauseOrResume(){
        PhoneService p=PhoneService.instance;if(p==null || !p.agent.isActive())return;
        if(p.agent.isPaused()){
            moveTaskToBack(true);main.postDelayed(()->{if(PhoneService.instance==p && p.agent.isPaused())p.agent.togglePause();},400);
        }else p.agent.togglePause();refresh();
    }
    private void append(String role,String text){
        try{messages.put(new JSONObject().put("role",role).put("text",text));while(messages.length()>40)messages.remove(0);saveMessages();renderMessages();}catch(Exception ignored){}
    }
    private void saveMessages(){prefs.edit().putString("chat_history",messages.toString()).apply();}
    private void renderMessages(){
        chat.removeAllViews();
        if(messages.length()==0){
            TextView welcome=Ui.text(this,"Dime qué quieres hacer.\n\nPuedes empezar con: ¿qué versión de Android tengo?",17,Ui.INK);
            welcome.setPadding(Ui.dp(this,20),Ui.dp(this,36),Ui.dp(this,20),Ui.dp(this,20));chat.addView(welcome);
        }
        for(int i=0;i<messages.length();i++){
            JSONObject m=messages.optJSONObject(i);if(m==null)continue;boolean user=m.optString("role").equals("user");
            TextView text=Ui.text(this,m.optString("text"),15,Ui.INK);text.setTextIsSelectable(true);
            text.setPadding(Ui.dp(this,14),Ui.dp(this,12),Ui.dp(this,14),Ui.dp(this,12));
            text.setBackgroundResource(user?R.drawable.bg_user_bubble:R.drawable.bg_assistant_bubble);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(user?-2:-1,-2);lp.gravity=user?Gravity.END:Gravity.START;lp.setMargins(Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8),Ui.dp(this,8));chat.addView(text,lp);
        }
        scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
    }
    private void refresh(){
        if(header==null)return;PhoneService p=PhoneService.instance;AgentController a=p==null?null:p.agent;
        String selected=prefs.getString("model","auto");Provider provider=Provider.from(prefs.getString("provider","gemini"));model.setText(provider.label+" · "+(selected.equals("auto")?"Auto ▾":selected+" ▾"));
        boolean active=a!=null && a.isActive(),answering=a!=null && a.waitingForUser();
        header.setText(a==null?"Configura el control del teléfono":a.statusLabel());
        input.setEnabled(!active || answering);input.setHint(answering?"Escribe la información que falta":"Escribe una tarea para Pulso");send.setEnabled(!active || answering);
        progress.setVisibility(a!=null && a.taskId()!=0?View.VISIBLE:View.GONE);
        controls.setVisibility(active?View.VISIBLE:View.GONE);pause.setText(a!=null && a.isPaused()?"Continuar y volver":"Pausar");pause.setEnabled(active && !answering);
        if(a==null)return;
        if(!active && a.taskId()!=0 && prefs.getLong("seen_task",0)!=a.taskId()){
            append("assistant",a.brief());prefs.edit().putLong("seen_task",a.taskId()).apply();
        }
        disclosure.setText(a.statusLabel()+" · "+a.metrics()+(expanded?" ▴":" ▾"));
        String state=a.statusLabel()+a.brief()+a.log()+a.pendingDetail()+expanded;
        if(!state.equals(rendered)){
            rendered=state;details.removeAllViews();details.setVisibility(expanded || answering || a.hasPendingApproval()?View.VISIBLE:View.GONE);
            details.addView(Ui.text(this,a.brief(),14,Ui.INK));
            if(expanded){details.addView(Ui.text(this,a.detailedMetrics(),12,Ui.MUTED));TextView events=Ui.text(this,a.log(),12,Ui.MUTED);events.setTextIsSelectable(true);details.addView(events);}
            if(a.hasPendingApproval()){
                details.addView(Ui.text(this,a.pendingDetail(),14,Ui.INK));long id=a.pendingId();
                details.addView(Ui.button(this,"Autorizar esta operación",true,()->{moveTaskToBack(true);main.postDelayed(()->a.approve(id,true),450);}));
                details.addView(Ui.button(this,"Omitir esta operación",false,()->a.approve(id,false)));
            }
        }
    }
    @Override protected void onResume(){super.onResume();PhoneService p=PhoneService.instance;if(p!=null && p.agent.isActive() && !p.agent.isPaused() && !p.agent.waitingForUser() && !p.agent.hasPendingApproval())p.agent.togglePause();main.post(tick);}
    @Override protected void onPause(){main.removeCallbacks(tick);super.onPause();}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
}
