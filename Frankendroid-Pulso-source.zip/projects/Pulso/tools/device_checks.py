#!/usr/bin/env python3
"""Build a temporary instrumentation APK. Never dumps screens or exports API keys."""
from pathlib import Path
import argparse, os, subprocess, shutil, zipfile
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--serial',required=True);p.add_argument('--gemini',action='store_true');p.add_argument('--stress-local',action='store_true');p.add_argument('--stress-gemini',action='store_true');p.add_argument('--stress-provider',choices=['gemini','groq','openrouter','deepseek','openai']);p.add_argument('--diagnostic',action='store_true');p.add_argument('--configure',action='store_true');args=p.parse_args()
BT=ROOT/'.tools/build-tools/android-16';PLATFORM=ROOT/'.tools/platform/android-36/android.jar'
OUT=ROOT/'build/device-checks';OUT.mkdir(parents=True,exist_ok=True)
def run(cmd,**kwargs):return subprocess.run([str(x) for x in cmd],cwd=ROOT,check=True,**kwargs)
classes=OUT/'classes';shutil.rmtree(classes,ignore_errors=True);classes.mkdir()
dex=OUT/'dex';shutil.rmtree(dex,ignore_errors=True);dex.mkdir()
manifest=OUT/'AndroidManifest.xml';manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dev.pulso.assistant.checks"><uses-sdk android:minSdkVersion="30" android:targetSdkVersion="36"/><instrumentation android:name="dev.pulso.assistant.checks.PulsoDeviceChecks" android:targetPackage="dev.pulso.assistant.checks" android:functionalTest="true"/><application android:label="Pulso checks"/></manifest>')
run(['java','-jar',ROOT/'.tools/ecj.jar','-8','-proc:none','-nowarn','-encoding','UTF-8','-bootclasspath',str(PLATFORM)+os.pathsep+str(BT/'core-lambda-stubs.jar'),'-cp',ROOT/'build/classes','-d',classes,ROOT/'tests/device/PulsoDeviceChecks.java'])
run([BT/'d8','--release','--min-api','30','--lib',PLATFORM,'--classpath',ROOT/'build/classes','--output',dex,*classes.rglob('*.class')])
run([BT/'aapt2','link','-I',PLATFORM,'--manifest',manifest,'-o',OUT/'unsigned.apk'])
with zipfile.ZipFile(OUT/'unsigned.apk','a',compression=zipfile.ZIP_DEFLATED) as z:z.write(dex/'classes.dex','classes.dex')
run([BT/'zipalign','-f','4',OUT/'unsigned.apk',OUT/'aligned.apk'])
run([BT/'apksigner','sign','--ks',ROOT/'.tools/pulso-debug.jks','--ks-pass','pass:android','--key-pass','pass:android','--ks-key-alias','pulso-debug','--out',OUT/'checks.apk',OUT/'aligned.apk'])
try:
    run(['adb','-s',args.serial,'install','--no-incremental','-r',OUT/'checks.apk'])
    command=['adb','-s',args.serial,'shell','am','instrument','-w']
    if args.gemini:command+=['-e','gemini','true']
    if args.stress_local:command+=['-e','stress_local','true']
    if args.stress_provider:command+=['-e','stress_provider',args.stress_provider]
    if args.stress_gemini:command+=['-e','stress_gemini','true']
    if args.configure:command+=['-e','configure','true']
    if args.diagnostic:command+=['-e','diagnostic','true']
    command+=['dev.pulso.assistant.checks/dev.pulso.assistant.checks.PulsoDeviceChecks']
    result=run(command,capture_output=True,text=True);print(result.stdout)
    markers=(['LOCAL_STRESS PASS 30/30'] if args.stress_local else [])+(['MODEL_STRESS PASS 90/90'] if args.stress_gemini or args.stress_provider else [])
    if not markers:markers=['LOCAL_VERSION PASS','PAUSE_RESUME PASS','STOP PASS']+(['MODEL_SEARCH PASS'] if args.gemini else [])
    if not args.diagnostic and not args.configure and any(marker not in result.stdout for marker in markers):raise SystemExit(1)
finally:
    subprocess.run(['adb','-s',args.serial,'uninstall','dev.pulso.assistant.checks'],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
