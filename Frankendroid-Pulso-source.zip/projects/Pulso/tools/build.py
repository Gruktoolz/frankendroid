#!/usr/bin/env python3
"""Reproducible Linux build using a Java 17+ runtime, Python and pinned Android tools.

No Gradle, system SDK install, javac, API key or phone is required. Tools are cached
in .tools (or PULSO_TOOLS_DIR). No SDK license acceptance flags are written.
"""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import urllib.request
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
TOOLS = Path(os.environ.get("PULSO_TOOLS_DIR", str(ROOT / ".tools"))).resolve()
ARTIFACTS = {
    "ecj.jar": ("https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.41.0/ecj-3.41.0.jar", "47bda183cd94a8bdb704f5b35690224f75b7d2fb563c8b8f9bbcfab987c3029b"),
    "json.jar": ("https://repo.maven.apache.org/maven2/org/json/json/20250107/json-20250107.jar", "85d4c1ab192d3117fd02c7fff1ec0fe63ade45cf56def7fe950ef060cf06e99f"),
    "build-tools.zip": ("https://dl.google.com/android/repository/build-tools_r36_linux.zip", "5d9ac77fb6ff43d9da518a337b4fcf8f9097113df531d99ccefe80ef7ce8250b"),
    "platform.zip": ("https://dl.google.com/android/repository/platform-36_r02.zip", "37607369a28c5b640b3a7998868d45898ebcb777565a0e85f9acf36f29631d2e"),
}


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def fetch(name):
    url, expected = ARTIFACTS[name]
    target = TOOLS / name
    if not target.exists() or digest(target) != expected:
        print(f"Descargando {name}…", flush=True)
        temp = target.with_suffix(".part")
        with urllib.request.urlopen(url, timeout=90) as response, temp.open("wb") as out:
            shutil.copyfileobj(response, out)
        if digest(temp) != expected:
            temp.unlink(missing_ok=True)
            raise RuntimeError(f"La descarga no coincide con el SHA-256 fijado: {name}")
        temp.replace(target)
    return target


def unpack(name, destination):
    archive = fetch(name)
    directory = TOOLS / destination
    marker = directory / ".pulso-ready"
    if not marker.exists() or marker.read_text() != ARTIFACTS[name][1]:
        directory.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive) as z:
            z.extractall(directory)
        marker.write_text(ARTIFACTS[name][1])
    return directory


def run(args):
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-only", action="store_true")
    args = parser.parse_args()
    if not shutil.which("java"):
        raise SystemExit("Instala Java 17 o superior y añade java al PATH.")
    TOOLS.mkdir(parents=True, exist_ok=True)
    compiler, json = fetch("ecj.jar"), fetch("json.jar")
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    source = ROOT / "app/src/main/java/dev/pulso/assistant"
    test_classes = build / "test-classes"
    if test_classes.exists():
        shutil.rmtree(test_classes)
    test_classes.mkdir()
    run(["java", "-jar", compiler, "-17", "-proc:none", "-nowarn", "-encoding", "UTF-8", "-cp", json,
         "-d", test_classes, source / "Action.java", source / "ActionBatch.java", source / "BatchGuard.java", source / "Provider.java", source / "LocalRoutes.java", source / "SafetyPolicy.java", ROOT / "tests/CoreTests.java", source / "ModelClient.java", ROOT / "tests/host/ProviderTests.java", *sorted((ROOT / "tests/host/android").rglob("*.java"))])
    run(["java", "-cp", f"{test_classes}{os.pathsep}{json}", "dev.pulso.assistant.CoreTests"])
    run(["java", "-cp", f"{test_classes}{os.pathsep}{json}", "dev.pulso.assistant.ProviderTests"])
    if args.test_only:
        return
    bt = unpack("build-tools.zip", "build-tools") / "android-16"
    platform = unpack("platform.zip", "platform") / "android-36/android.jar"
    for name in ("aapt2", "zipalign", "apksigner", "d8"):
        (bt / name).chmod((bt / name).stat().st_mode | 0o111)
    for directory in ("classes", "generated", "dex"):
        path = build / directory
        if path.exists():
            shutil.rmtree(path)
        path.mkdir()
    run([bt / "aapt2", "compile", "--dir", ROOT / "app/src/main/res", "-o", build / "res.zip"])
    # Gradle injects namespace; direct aapt2 needs it in an intermediate manifest.
    ET.register_namespace("android", "http://schemas.android.com/apk/res/android")
    manifest = ET.parse(ROOT / "app/src/main/AndroidManifest.xml")
    manifest.getroot().set("package", "dev.pulso.assistant")
    manifest.write(build / "AndroidManifest.xml", encoding="utf-8", xml_declaration=True)
    run([bt / "aapt2", "link", "-I", platform, "--manifest", build / "AndroidManifest.xml",
         "--java", build / "generated", "--min-sdk-version", "30", "--target-sdk-version", "36",
         "--version-code", "2", "--version-name", "0.2.0", "-o", build / "resources.apk", build / "res.zip"])
    sources = sorted((ROOT / "app/src/main/java").rglob("*.java")) + sorted((build / "generated").rglob("*.java"))
    boot = str(platform) + os.pathsep + str(bt / "core-lambda-stubs.jar")
    run(["java", "-jar", compiler, "-8", "-proc:none", "-nowarn", "-encoding", "UTF-8", "-bootclasspath", boot,
         "-d", build / "classes", *sources])
    run([bt / "d8", "--release", "--min-api", "30", "--lib", platform, "--output", build / "dex",
         *sorted((build / "classes").rglob("*.class"))])
    unsigned = build / "unsigned.apk"
    shutil.copyfile(build / "resources.apk", unsigned)
    with zipfile.ZipFile(unsigned, "a", compression=zipfile.ZIP_DEFLATED) as apk:
        for dex in sorted((build / "dex").glob("*.dex")):
            apk.write(dex, dex.name)
    run([bt / "zipalign", "-f", "-p", "4", unsigned, build / "aligned.apk"])
    keystore = TOOLS / "pulso-debug.jks"
    if not keystore.exists():
        run(["keytool", "-genkeypair", "-keystore", keystore, "-storepass", "android", "-keypass", "android",
             "-alias", "pulso-debug", "-keyalg", "RSA", "-keysize", "2048", "-validity", "3650",
             "-dname", "CN=Pulso Alpha Debug,O=Personal Development,C=ES", "-noprompt"])
    dist = ROOT / "dist"
    dist.mkdir(exist_ok=True)
    result = dist / "pulso-alpha.apk"
    run([bt / "apksigner", "sign", "--ks", keystore, "--ks-pass", "pass:android", "--key-pass", "pass:android",
         "--ks-key-alias", "pulso-debug", "--out", result, build / "aligned.apk"])
    run([bt / "apksigner", "verify", "--verbose", result])
    run([bt / "zipalign", "-c", "4", result])
    (dist / "pulso-alpha.apk.sha256").write_text(digest(result) + "  pulso-alpha.apk\n")
    print(f"APK listo: {result} ({result.stat().st_size:,} bytes)", flush=True)


if __name__ == "__main__":
    main()
