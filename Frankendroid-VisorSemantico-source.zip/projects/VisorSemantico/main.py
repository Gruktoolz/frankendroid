#!/usr/bin/env python3
"""Local GNOME semantic screenshot prototype."""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Atspi", "2.0")
from gi.repository import Atspi, Gdk, Gtk


MAX_NODES = 300


def safe(call, default=None):
    try:
        return call()
    except Exception:
        return default


def rect_for(accessible):
    component = safe(accessible.get_component_iface)
    if component is None:
        return None
    ext = safe(lambda: component.get_extents(Atspi.CoordType.SCREEN))
    if ext is None or ext.width <= 0 or ext.height <= 0:
        return None
    return [int(ext.x), int(ext.y), int(ext.width), int(ext.height)]


def state_names(accessible):
    state_set = safe(accessible.get_state_set)
    if state_set is None:
        return []
    pairs = (
        (Atspi.StateType.SHOWING, "visible"),
        (Atspi.StateType.ENABLED, "enabled"),
        (Atspi.StateType.FOCUSABLE, "focusable"),
        (Atspi.StateType.FOCUSED, "focused"),
        (Atspi.StateType.CHECKED, "checked"),
        (Atspi.StateType.SELECTED, "selected"),
        (Atspi.StateType.EXPANDED, "expanded"),
    )
    return [label for state, label in pairs if safe(lambda: state_set.contains(state), False)]


def action_names(accessible):
    if not safe(accessible.is_action, False):
        return []
    action = safe(accessible.get_action_iface)
    if action is None:
        return []
    n = min(safe(action.get_n_actions, 0), 8)
    return [safe(lambda i=i: action.get_action_name(i), "") for i in range(n)]


def top_level_windows():
    """Return app windows exposed by AT-SPI; no text-field contents are read."""
    Atspi.init()
    desktop = Atspi.get_desktop(0)
    found = []
    for app_i in range(safe(desktop.get_child_count, 0)):
        app = safe(lambda i=app_i: desktop.get_child_at_index(i))
        if app is None:
            continue
        app_name = safe(app.get_name, "") or "Aplicación"
        for win_i in range(safe(app.get_child_count, 0)):
            window = safe(lambda i=win_i: app.get_child_at_index(i))
            if window is None or rect_for(window) is None:
                continue
            role = safe(window.get_role_name, "") or "ventana"
            if role.lower() not in ("frame", "window", "dialog", "alert"):
                continue
            title = safe(window.get_name, "") or "(sin título)"
            states = safe(window.get_state_set)
            active = bool(states and safe(lambda: states.contains(Atspi.StateType.ACTIVE), False))
            found.append({"app": app_name, "title": title, "role": role, "active": active, "accessible": window})
    return sorted(found, key=lambda w: not w["active"])


def inspect_window(window):
    items = []
    stack = [window]
    seen = set()
    while stack and len(items) < MAX_NODES:
        item = stack.pop()
        if item is None:
            continue
        ident = safe(item.get_id)
        key = (safe(item.get_name, ""), safe(item.get_role_name, ""), ident)
        if key in seen:
            continue
        seen.add(key)
        bounds = rect_for(item)
        role = safe(item.get_role_name, "") or "elemento"
        name = safe(item.get_name, "") or ""
        desc = safe(item.get_description, "") or ""
        actions = action_names(item)
        states = state_names(item)
        if bounds and (name or desc or actions) and ("visible" in states or role.lower() in ("frame", "window")):
            items.append({
                "name": name.strip()[:180],
                "role": role,
                "description": desc.strip()[:240],
                "actions": [a for a in actions if a],
                "states": states,
                "bounds": bounds,
            })
        child_count = safe(item.get_child_count, 0)
        # Reverse push retains the visual order in the resulting list.
        for i in range(min(child_count, 500)):
            child = safe(lambda i=i: item.get_child_at_index(i))
            if child is not None:
                stack.append(child)
    return items


class SemanticViewer(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.tunnelturbo.SemanticViewer")
        self.windows = []
        self.nodes = []
        self.selected = None
        self.texture = None

    def do_activate(self):
        if hasattr(self, "window"):
            self.window.present()
            return
        self.build_ui()
        self.refresh_windows()
        self.window.present()

    def build_ui(self):
        self.window = Gtk.ApplicationWindow(application=self, title="Visor semántico · Tunnel Turbo")
        self.window.set_default_size(1180, 760)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        root.set_margin_top(12)
        root.set_margin_bottom(12)
        root.set_margin_start(12)
        root.set_margin_end(12)
        self.window.set_child(root)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        root.append(header)
        title = Gtk.Label(label="Captura semántica", xalign=0)
        title.add_css_class("title-1")
        header.append(title)
        self.window_combo = Gtk.DropDown.new_from_strings([])
        self.window_combo.set_hexpand(True)
        header.append(self.window_combo)
        refresh = Gtk.Button(label="Actualizar ventanas")
        refresh.connect("clicked", lambda *_: self.refresh_windows())
        header.append(refresh)
        self.capture_button = Gtk.Button(label="Abrir captura…")
        self.capture_button.add_css_class("suggested-action")
        self.capture_button.connect("clicked", self.open_capture)
        header.append(self.capture_button)

        self.status = Gtk.Label(label="Elige una ventana accesible y captura la pantalla.", xalign=0)
        self.status.add_css_class("dim-label")
        root.append(self.status)

        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        paned.set_wide_handle(True)
        paned.set_vexpand(True)
        root.append(paned)

        self.picture = Gtk.Picture()
        self.picture.set_content_fit(Gtk.ContentFit.CONTAIN)
        self.picture.set_can_shrink(True)
        self.overlay = Gtk.DrawingArea()
        self.overlay.set_draw_func(self.draw_overlay)
        image_stack = Gtk.Overlay()
        image_stack.set_child(self.picture)
        image_stack.add_overlay(self.overlay)
        paned.set_start_child(image_stack)
        paned.set_resize_start_child(True)
        paned.set_shrink_start_child(False)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        right.set_size_request(320, -1)
        paned.set_end_child(right)
        self.detail = Gtk.Label(label="Los elementos encontrados aparecerán aquí.", xalign=0, yalign=0)
        self.detail.set_wrap(True)
        right.append(self.detail)
        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox.connect("row-selected", self.node_selected)
        scroller = Gtk.ScrolledWindow()
        scroller.set_vexpand(True)
        scroller.set_child(self.listbox)
        right.append(scroller)

        note = Gtk.Label(label="Toma primero una captura con Impr Pant. Después selecciona la ventana correspondiente y ábrela aquí. Los nombres y roles se leen localmente mediante AT-SPI.", xalign=0)
        note.set_wrap(True)
        note.add_css_class("dim-label")
        root.append(note)

    def refresh_windows(self):
        try:
            self.windows = top_level_windows()
        except Exception as exc:
            self.windows = []
            self.status.set_text(f"No se pudo consultar AT-SPI: {exc}")
        labels = [("● ACTIVA · " if w["active"] else "") + f"{w['app']} — {w['title']}" for w in self.windows]
        self.window_combo.set_model(Gtk.StringList.new(labels))
        if labels:
            self.window_combo.set_selected(0)
            self.status.set_text(f"{len(labels)} ventana(s) con accesibilidad. Elige la que vas a capturar.")
        else:
            self.status.set_text("No encontré ventanas accesibles. Verifica que el soporte de accesibilidad esté activo.")

    def open_capture(self, *_):
        index = self.window_combo.get_selected()
        if index == Gtk.INVALID_LIST_POSITION or index >= len(self.windows):
            self.status.set_text("Selecciona una ventana accesible primero.")
            return
        chooser = Gtk.FileChooserNative.new(
            "Abrir captura de pantalla", self.window,
            Gtk.FileChooserAction.OPEN, "Abrir", "Cancelar",
        )
        image_filter = Gtk.FileFilter()
        image_filter.set_name("Imágenes")
        for mime in ("image/png", "image/jpeg", "image/webp", "image/bmp"):
            image_filter.add_mime_type(mime)
        chooser.add_filter(image_filter)
        chooser.connect("response", self.capture_chosen, index)
        chooser.show()

    def capture_chosen(self, chooser, response, window_index):
        if response != Gtk.ResponseType.ACCEPT:
            return
        selected_window = self.windows[window_index]
        try:
            # The user chooses a local image; its pixels are not uploaded or copied.
            self.texture = Gdk.Texture.new_from_file(chooser.get_file())
            self.picture.set_paintable(self.texture)
            self.nodes = inspect_window(selected_window["accessible"])
            self.selected = None
            self.rebuild_node_list()
            self.status.set_text(
                f"Imagen {self.texture.get_width()}×{self.texture.get_height()} · "
                f"{len(self.nodes)} elemento(s) semántico(s) de "
                f"{selected_window['app']} — {selected_window['title']}. "
                "Comprueba que la ventana no haya cambiado desde la captura."
            )
        except Exception as exc:
            self.status.set_text(f"No pude cargar la imagen o leer AT-SPI: {exc}")

    def rebuild_node_list(self):
        child = self.listbox.get_first_child()
        while child:
            next_child = child.get_next_sibling()
            self.listbox.remove(child)
            child = next_child
        for i, node in enumerate(self.nodes):
            name = node["name"] or node["description"] or "(sin etiqueta)"
            label = Gtk.Label(label=f"{i + 1:03d}  {node['role']}  ·  {name}", xalign=0)
            label.set_ellipsize(3)
            label.set_margin_top(5)
            label.set_margin_bottom(5)
            label.set_margin_start(7)
            label.set_margin_end(7)
            row = Gtk.ListBoxRow()
            row.set_child(label)
            row._semantic_index = i
            self.listbox.append(row)
        self.overlay.queue_draw()

    def node_selected(self, _listbox, row):
        if row is None:
            self.selected = None
            self.overlay.queue_draw()
            return
        self.selected = row._semantic_index
        n = self.nodes[self.selected]
        bounds = n["bounds"]
        lines = [f"{n['role']}: {n['name'] or '(sin etiqueta)'}"]
        if n["description"]:
            lines.append(n["description"])
        lines.append(f"Estado: {', '.join(n['states']) or 'sin datos'}")
        lines.append(f"Acciones: {', '.join(n['actions']) or 'ninguna declarada'}")
        lines.append(f"Posición AT-SPI: x={bounds[0]}, y={bounds[1]}, {bounds[2]}×{bounds[3]}")
        self.detail.set_text("\n".join(lines))
        self.overlay.queue_draw()

    def draw_overlay(self, _area, cr, width, height):
        if not self.texture or not self.nodes:
            return
        iw, ih = self.texture.get_width(), self.texture.get_height()
        if not iw or not ih:
            return
        scale = min(width / iw, height / ih)
        ox = (width - iw * scale) / 2
        oy = (height - ih * scale) / 2
        # AT-SPI uses desktop coordinates. The imported image spans the display;
        # the primary-display mapping is scaled to the returned image dimensions.
        monitors = Gdk.Display.get_default().get_monitors()
        min_x = min_y = 0
        logical_w, logical_h = iw, ih
        if monitors.get_n_items() > 0:
            rects = [monitors.get_item(i).get_geometry() for i in range(monitors.get_n_items())]
            min_x = min(r.x for r in rects)
            min_y = min(r.y for r in rects)
            logical_w = max(r.x + r.width for r in rects) - min_x
            logical_h = max(r.y + r.height for r in rects) - min_y
        sx, sy = iw / max(1, logical_w), ih / max(1, logical_h)
        for i, node in enumerate(self.nodes):
            x, y, w, h = node["bounds"]
            x = ox + (x - min_x) * sx * scale
            y = oy + (y - min_y) * sy * scale
            w, h = w * sx * scale, h * sy * scale
            if w < 2 or h < 2:
                continue
            if i == self.selected:
                cr.set_source_rgba(1.0, 0.8, 0.0, 0.95)
                cr.set_line_width(3)
            else:
                cr.set_source_rgba(0.0, 0.9, 0.45, 0.72)
                cr.set_line_width(1.2)
            cr.rectangle(x, y, w, h)
            cr.stroke()


def main():
    app = SemanticViewer()
    return app.run(None)


if __name__ == "__main__":
    raise SystemExit(main())
