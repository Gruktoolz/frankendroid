# Tunnel Turbo — Visor semántico de escritorio (prototipo)

Prototipo local para GNOME en Wayland. Abre una captura local y dibuja encima los límites de controles que la ventana seleccionada expone mediante AT-SPI. Al seleccionar un control muestra su rol, nombre, descripción, estados, acciones declaradas y posición.

## Ejecutar

En GNOME, toma una captura de pantalla con **Impr Pant** y guárdala. Ejecuta `./run.sh`, selecciona la ventana correspondiente en la lista y pulsa **Abrir captura…**. La imagen aparece con los controles semánticos en verde; el elemento seleccionado se resalta en amarillo.

Requiere Python 3 con PyGObject, GTK 4 y el typelib de AT-SPI 2. No usa pip ni sube datos a la red. Este entorno ya dispone de esas dependencias.

## Qué hace y qué no

- La consulta a AT-SPI ocurre localmente y no lee el valor escrito dentro de campos de texto.
- La aplicación solo abre imágenes locales elegidas por el usuario; no captura la pantalla por su cuenta, no copia la imagen ni la elimina.
- Solo lee e inspecciona: no hace clic, no escribe y no envía capturas a un modelo.
- Los nombres o roles incompletos reflejan lo que la aplicación expone. AT-SPI no puede inventar la semántica que falta en un canvas o control personalizado.
- La lista se limita a 300 elementos. El overlay es una correspondencia visual aproximada para el monitor lógico; escritorios con varias pantallas o escalas distintas pueden mostrar desplazamientos.
- El árbol se lee al importar la imagen. Si la ventana cambió desde que se tomó la captura, el overlay puede no coincidir.
- En esta sesión de GNOME Wayland, el servicio XDG Desktop Portal no publica `org.freedesktop.portal.Screenshot`. Por eso la captura se hace con la herramienta de GNOME y luego se importa. El prototipo no intenta evitar el control de captura de Wayland.

## Investigación consultada el 19 de octubre de 2026

1. **“Screenshot” — XDG Desktop Portal** — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Screenshot.html  
   Respalda: que existe una interfaz estándar de captura y los objetivos que puede anunciar.  
   No demuestra: que la interfaz esté instalada o publicada por este portal; la introspección de esta sesión mostró que no está disponible.
2. **“Architecture of the accessibility stack” — GNOME AT-SPI** — https://gnome.pages.gitlab.gnome.org/at-spi2-core/devel-docs/architecture.html  
   Respalda: AT-SPI como árbol de objetos accesibles y el patrón de consultar nombres, hijos y acciones.  
   No demuestra: que cada app exponga información completa o coordenadas perfectamente alineadas con los píxeles.
3. **“Atspi.Accessible” — GNOME AT-SPI** — https://gnome.pages.gitlab.gnome.org/at-spi2-core/libatspi/class.Accessible.html  
   Respalda: interfaces de nombre, descripción, roles, hijos y acciones que utiliza el prototipo.  
   No demuestra: la calidad o exactitud semántica de los proveedores de cada aplicación.
4. **“Surfaces” — OpenAdapt** — https://docs.openadapt.ai/concepts/backends/  
   Respalda: un enfoque comparable que prefiere estructura de accesibilidad y usa imagen/OCR como alternativa cuando hace falta.  
   No demuestra: que OpenAdapt ni este prototipo funcionen en todas las apps. La documentación de captura de OpenAdapt indica que su captura Linux actualmente cubre X11, no Wayland: https://openadapt.ai/platform/capture.

La investigación orientó la selección de APIs y límites. No se usa como prueba de que este prototipo haya funcionado en aplicaciones externas.
